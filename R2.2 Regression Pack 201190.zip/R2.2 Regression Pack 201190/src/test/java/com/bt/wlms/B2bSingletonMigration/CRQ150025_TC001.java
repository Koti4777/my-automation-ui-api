package com.bt.wlms.B2bSingletonMigration;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.B2BBeanDetails;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.pages.operations.UserDetailsPageOperations;
import com.hqnRegression.pages.operations.UserListPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ150025_TC001 extends SeleniumImplementation
{
	
	private  WebDriver driver;
	private String CLASS_NAME = "CRQ150025_TC001";
	
	private String IN_FILE = "B2BDetails.csv";
	List<B2BBeanDetails> B2BList = null;
	B2BBeanDetails B2BDetails = null;
	
	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("UserAndGroupAdmin_Asset");

	
	@Test
	public CRQ150025_TC001() {
		PropertyConfigurator.configure(loggerPath);
	}
	
	
	
	@BeforeMethod
	public void setUp() throws Exception {
		
		
		B2BList = CSVOperation_New.readB2BSingletonDetails(IN_FILE);

		if (B2BList != null && B2BList.size() > 0) {
			testCount = B2BList.size();
		}

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * B2B Singleton Migration
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testCRQ150025_TC001(Method method) throws IOException {

		
		try {

             logger.info(" Start Test-CRQ150025_TC001 : Start the CRQ150025_TC001 ");

             B2BDetails = B2BList.get(count);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());
			
		    UserListPageOperations userListPageOperations = userAndGroupAdminPageOperations
		    		.clickShowUsers(CLASS_NAME, method.getName());
           
		    UserDetailsPageOperations userDetailsPageOperations = userListPageOperations
        		   .search(B2BDetails.getSearchValue(), CLASS_NAME, method.getName());	
           
		    userListPageOperations.clickAdminLink(B2BDetails.getName());
		    
		    userListPageOperations.clickAdminRdBtn(CLASS_NAME, method.getName());
		   
		    userAndGroupAdminPageOperations = userDetailsPageOperations.clickSaveBtn(CLASS_NAME, method.getName());
           
            CommonMethods.logOut(driver, CLASS_NAME, method.getName());
            
            driver = createBrowserInstance(BrowserType.FIREFOX);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
			 loginPageOperations = CMCHomePageOperations
			.navigateTo(driver);
			 
			 homePageOperations = loginPageOperations
				.agentLogin(CLASS_NAME, method.getName());
			  
			 userAndGroupAdminPageOperations = homePageOperations
						.clickAdmin(CLASS_NAME, method.getName());
				
			 userListPageOperations = userAndGroupAdminPageOperations
			    		.clickShowUsers(CLASS_NAME, method.getName());
	           
			 userDetailsPageOperations = userListPageOperations
	        		   .search(B2BDetails.getSearchValue(), CLASS_NAME, method.getName());	
	           
			 userListPageOperations.clickAdminLink(B2BDetails.getName());
			  
			 userListPageOperations.clickAgentRdBtn(CLASS_NAME, method.getName());
	           
			 userAndGroupAdminPageOperations = userDetailsPageOperations.clickSaveBtn(CLASS_NAME, method.getName());
	           
		
			 CommonMethods.logOut(driver,CLASS_NAME, method.getName());
			 logger.info(" End Test-CRQ150025_TC001 : End the CRQ150025_TC001 ");
			 
		}

		catch (Exception e) {
			e.printStackTrace();

			logger.error("unable to click on B2BSingleton checkbox");
		}
	}
	
	
	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}
}
