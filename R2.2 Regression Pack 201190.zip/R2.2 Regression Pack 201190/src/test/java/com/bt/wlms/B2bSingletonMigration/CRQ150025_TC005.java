package com.bt.wlms.B2bSingletonMigration;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class CRQ150025_TC005 extends SeleniumImplementation
{
	
	private WebDriver driver;
	private String CLASS_NAME = "CRQ150025_TC005";

	private String IN_FILE = "NonNGAB2BDetails.csv";
	List<AssetBeanDetails> assetDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int count = 0;
	public Order order = null;
	private int testCount = 0;

	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ150025_TC005");
	
	
	public CRQ150025_TC005()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 
  /*      
	@Rule
	public TestName name = new TestName();
*/
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		assetDetailsList = CSVOperation_New.readAssetDetails(IN_FILE);
		order = new Order();

		if (assetDetailsList != null && assetDetailsList.size() > 0) {
			testCount = assetDetailsList.size();
		}

	}

	
	/**
	 * prerequisite- it requires to create a business account with order management permission
	 * and login with those credentials N1B2BAdmin,N1B2BAdmin@
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testCRQ150025_TC005(Method method) throws IOException {
		

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-CRQ150025_TC005 : Start the CRQ150025_TC005 creation ");
				
				assetBeanDetails = assetDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.agentLogin(CLASS_NAME, method.getName());

				RegisterNewServicePageOperations servicePageOperations = homePageOperations
						.clickBusinessCustomer();
				
				CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
						  .searchByBusinessAccountName(assetBeanDetails
						     .getBusinessAccount(),CLASS_NAME, method.getName());

				CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
						.clickBusinessAccount(assetBeanDetails
								.getBusinessAccount());

				LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
						.clickAddSite(CLASS_NAME, method.getName());
				
				
				
				lineDetailsPageOperations.clickB2BSingletonCheckboxpresent();
				lineDetailsPageOperations.clickB2BSingletonCheckbox();
				
				
				
                  CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				logger.info(" End Test -  CRQ150025_TC005 : End the CRQ150025_TC005 creation");

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to place the order");
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				//driver.close();

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		//driver.quit();
		//driver.close();

	}

}
