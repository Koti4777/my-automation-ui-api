package com.bt.wlms.B2bSingletonMigration;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
public class CRQ150025_TC016 extends SeleniumImplementation {

	
	private WebDriver driver;
	public String CLASS_NAME = "CRQ150025_TC016";

	private String IN_FILE = "CRQ150025_TC016.csv";
	List<AssetBeanDetails> assetDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ150025_TC016");
	
	public CRQ150025_TC016()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	  

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {
		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


		assetDetailsList = CSVOperation_New.readDPIProfile(IN_FILE);

		if (assetDetailsList != null && assetDetailsList.size() > 0) {
			testCount = assetDetailsList.size();

	}
	
	}
	

	@Test
	public void applyDunningRestrictions(Method method) throws IOException {

   System.out.println("method name is --->"+method.getName());

		
   while (count < testCount) {

		order = new Order();

		try {
			
			 logger.info(" Start Test-Modify_Asset : Start the Modify_Asset creation ");

			 assetBeanDetails = assetDetailsList.get(count);

			 

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		//Assert.assertTrue(false);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(assetBeanDetails.getOrderId(), "Order Number",
						CLASS_NAME, method.getName());
		String product = searchResultPageOperations.getProductForActiveOrder();
		
		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
				.clickProductLink();
		
		
		AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
					.clickApplyDunningRestrictions(CLASS_NAME, method.getName());
		
		agentDetailsPageOperations.clickSameAgent();
		
		ProductDetailsPageOperations productDetailsPageOperations = agentDetailsPageOperations
					.clickNextForDunningRestrictions(CLASS_NAME, method.getName());
		
		//productDetailsPageOperations.clickDebtMgmtDPIProfile();
		
		productDetailsPageOperations.selectProductOffering_DPIProfile(
				product, assetBeanDetails.getBroadbandCare(),
				assetBeanDetails.getRouter(),
				assetBeanDetails.getBusinessRateCard(),
				assetBeanDetails.getCalls(), assetBeanDetails.getCarelevel(),
				assetBeanDetails.getSelectcalls(),
			    assetBeanDetails.getDPIIProfiles(),
				assetBeanDetails.getContract(),
				assetBeanDetails.getOneOffCharge(),
				assetBeanDetails.getRateCardDiscount(),
				assetBeanDetails.getSalesPromotion(),
				assetBeanDetails.getCustomerDiscount(),
				assetBeanDetails.getPostCode(), assetBeanDetails.getTitle(),
				assetBeanDetails.getFirstName(),
				assetBeanDetails.getSurName(),
				assetBeanDetails.getServiceId(),
				assetBeanDetails.getDdiRangeNum(),
				assetBeanDetails.getSddirangeNum(),
				assetBeanDetails.getManagedInstall(),assetBeanDetails.getBroadbandFeatures(), CLASS_NAME,
				method.getName());
		
		
		CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
		HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

		if (productDetailsPageOperations.isHardwarepageAvailable) {

			hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
					.clickNextForHardware(CLASS_NAME,
							method.getName());

			appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
					.clickNext(CLASS_NAME, method.getName());
		} else {

			appointmentManagementPageOperations = productDetailsPageOperations
					.clickNextForCRD(CLASS_NAME, method.getName());
		}

		appointmentManagementPageOperations.selectFutureCalendarDate(
				CLASS_NAME, method.getName(), 1);

		appointmentManagementPageOperations
				.fillEngineerNotes(assetBeanDetails.getEngineeringNotes());

		if (product.contains("Call") || product.contains("Line")
				|| product.contains("40:") || product.contains("ISDN") || product.contains("Business") ) {

			appointmentManagementPageOperations
					.fillHealthAndsafetyVeificationFields(assetBeanDetails
							.getHealthAndSafetyNotes());
		}

		OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
				.clickNext(CLASS_NAME, method.getName());

		orderSummaryPageOperations.selectCommunication(assetBeanDetails
				.getCommunicationBy());

		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

		OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
				.confirmOrder(CLASS_NAME, method.getName());

		String orderId = orderConfirmationPageOperations.getOrderId();

		accountDetailsPageOperations = orderConfirmationPageOperations
				.clickCompleteModify(CLASS_NAME, method.getName());


		CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		 logger.info(" End Test-Modify_Asset : End the Modify_Asset creation ");

	} catch (Exception e) {
		e.printStackTrace();
		//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
	}
	count++;
}

}

@AfterMethod
public void tearDown() {

//driver.close();
//driver.quit();

}


}
