
package com.bt.wlms.B2bSingletonMigration;



import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.ConfirmDNPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegradeOrderPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ150025_TC020 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "CRQ150025_TC020";

	private String IN_FILE = "CRQ150025_TC020.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ150025_TC019");
	
	
	public CRQ150025_TC020()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readAssetDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testCRQ150025_TC020(Method method) throws IOException {

      System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-Regrade_Asset : Start the Regrade_Asset creation ");

				assetBeanDetails = bbDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(assetBeanDetails.getOrderId(), "Order Number",
								CLASS_NAME, method.getName());
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				AgentDetailsPageOperations agentDetailsPageOperations;
				if (!product.contains("Line") && !product.contains("Calls")) {
					ConfirmDNPageOperations confirmDNPageOperations = accountDetailsPageOperations
							.clickRegradeForConfirmDN(CLASS_NAME,
									method.getName());
					agentDetailsPageOperations = confirmDNPageOperations
							.clickContinue(CLASS_NAME, method.getName());
				} else {
					agentDetailsPageOperations = accountDetailsPageOperations
							.clickRegrade(CLASS_NAME, method.getName());
				}
				agentDetailsPageOperations.clickSameAgent();

				LineCheckResultPageOperations lineCheckResultPageOperations = agentDetailsPageOperations
						.clickNextForRegrade(CLASS_NAME, method.getName());

				RegradeOrderPageOperations regradeOrderPageOperations = lineCheckResultPageOperations
						.clickNextforRegrade(CLASS_NAME, method.getName());
				
				
				/*regradeOrderPageOperations
				.selectPropositionByName(assetBeanDetails
						.getProposition());*/

		ProductDetailsPageOperations productDetailsPageOperations = regradeOrderPageOperations
				.clickNext(CLASS_NAME, method.getName());

			
				logger.info(" End Test-Regrade_Asset : End the Regrade_Asset creation ");

			} 
			
			
			catch (Exception e) {
				e.printStackTrace();
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}   logger.error("Unable to regrade the orderid " + assetBeanDetails.getOrderId());
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		//driver.close();
		//driver.quit();

	}

}

