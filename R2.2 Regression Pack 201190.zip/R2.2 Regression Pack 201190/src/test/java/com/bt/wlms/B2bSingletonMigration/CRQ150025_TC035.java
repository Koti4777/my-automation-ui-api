package com.bt.wlms.B2bSingletonMigration;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.BusinessAccountDetails;
import com.hqnRegression.beans.CreditCardDetails;
import com.hqnRegression.pages.operations.AccountSetUpPageOperations;
import com.hqnRegression.pages.operations.AssignContactsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.PrimaryAccountPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ150025_TC035 extends SeleniumImplementation

{
	
	
	private WebDriver driver;
	private String CLASS_NAME = "CRQ150025_TC035";

	private String IN_FILE = "AccountDetails.csv";
	private String CARD_FILE = "CreditCardDetails.csv";
	List<BusinessAccountDetails> busAccountList = null;
	List<CreditCardDetails> creditCardDetailsList = null;
	BusinessAccountDetails account = null;
	CreditCardDetails creditCardDetails = null;

	private int testCount = 0;
	private int count = 0;
	

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ150025_TC035");
	
	public CRQ150025_TC035()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 
	
/*
	@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		busAccountList = CSVOperation_New.readBusinessAccountDetails(IN_FILE);
		creditCardDetailsList = CSVOperation_New
				.readCreditCardDetails(CARD_FILE);

		if (busAccountList != null && busAccountList.size() > 0) {
			testCount = busAccountList.size();
		}

	}

	@Test
	public void testCRQ150025_TC035(Method method) throws IOException {

       System.out.println("method name is --->"+method.getName());
		
		

		while (count < testCount) {

			try {
				
				logger.info(" Start Test-CRQ150025_TC035 : Start the CRQ150025_TC035 creation ");
				
				account = busAccountList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				
				HomePageOperations homePageOperations = loginPageOperations
						.agentLogin(CLASS_NAME, method.getName());

				PrimaryAccountPageOperations primaryAccountPageOperations = homePageOperations
						.clickBusinessAccount();
				
				primaryAccountPageOperations.fillPrimaryAccountFileds(
						account.getCompanyName(), account.getCompanyRegistrationNo(),
						account.getSegmentation(), account.getMobileAccNo(), account.getVatNo(), account.getTitle(),
						account.getFirstName(), account.getSurName(),account.getPhoneNo(), account.getMobileNo(),
						account.getAdditionalContactNo(), account.getEmailAddress(),account.getPostCode(),
						account.getPremisesName(), account.getStreetName(), account.getTown(), account.getCounty(),
						account.getNotification(),CLASS_NAME, method.getName());

				AccountSetUpPageOperations accountSetUpPageOperations = primaryAccountPageOperations
						.clickNext(CLASS_NAME, method.getName());

				accountSetUpPageOperations.fillAccountSetUpName(

						account.getEmailFirstName(),
						account.getEmailLastName());

			    AssignContactsPageOperations assignContactsPageOperations = accountSetUpPageOperations

						.clickAvailabilityButton(CLASS_NAME, method.getName());

						accountSetUpPageOperations.fillAccountSetUpPassword(

						account.getPassWord(),

						account.getConfirmPassword(), account.getSecurityKey(),

						account.getSecurityConfirmPassword());


				assignContactsPageOperations = accountSetUpPageOperations
						.clickNext(CLASS_NAME, method.getName());
				PaymentDetailsPageOperations paymentDetailsPageOperations = assignContactsPageOperations
						.clickNext(CLASS_NAME, method.getName());
				
				paymentDetailsPageOperations.checkPaymentMethod("paymentmethod", CLASS_NAME, method.getName());
	
				String sortCode = account.getSortCode();
				String debitSortCode1 = null;
				String debitSortCode2 = null;
				String debitSortCode3 = null;
				if (sortCode != null && !"".equalsIgnoreCase(sortCode)
						&& sortCode.length() >= 6) {
					debitSortCode1 = sortCode.substring(0, 2);
					debitSortCode2 = sortCode.substring(2, 4);
					debitSortCode3 = sortCode.substring(4, 6);
				}

				if ("BACS".equalsIgnoreCase(account.getPaymentMethod())) {

					paymentDetailsPageOperations.fillPaymentDetailsForBACS(
							account.getBillRequiredDate(),
							account.getBillType());
/*					paymentDetailsPageOperations.clickNext(CLASS_NAME,
							method.getName());*/

				} else if ("Direct Debit".equalsIgnoreCase(account
						.getPaymentMethod())) {

					paymentDetailsPageOperations
							.fillPaymentDetailsForDirectDebitCard(
									account.getAccountHolderName(),
									debitSortCode1, debitSortCode2,
									debitSortCode3, account.getAccountNumber(),
									account.getBillRequiredDate(),
									account.getBillType());

				} else if (account.getPaymentMethod().contains(
						"Direct Debit with")) {

					paymentDetailsPageOperations
							.fillPaymentDetailsForDebitCard(
									account.getAccountHolderName(),
									debitSortCode1, debitSortCode2,
									debitSortCode3, account.getAccountNumber(),
									account.getBillRequiredDate(),
									account.getBillType());

				} else if (account.getPaymentMethod().contains("Credit")) {

					if (account.getCreditCardType() != null
							&& !"".equals(account.getCreditCardType())) {
						for (CreditCardDetails creditCardDetails : creditCardDetailsList) {
							if (creditCardDetails.getCardType().contains(
									account.getCreditCardType())) {
								paymentDetailsPageOperations
										.fillPaymentDetailsForCreditBebitCard(
												creditCardDetails.getCardType(),
												creditCardDetails.getName(),
												creditCardDetails
														.getCardNumber(),
												creditCardDetails
														.getValidFromMonth(),
												creditCardDetails
														.getValidFromYear(),
												creditCardDetails
														.getExpiryDateMonth(),
												creditCardDetails
														.getExpiryDateYear(),
												creditCardDetails
														.getIssueNumber(),
												creditCardDetails.getCv2(),
												account.getBillRequiredDate(),
												account.getBillType());
							}
						}
					}

				}

				paymentDetailsPageOperations.clickNext(CLASS_NAME,
						method.getName());

				paymentDetailsPageOperations.clickComplete(CLASS_NAME,
						method.getName());

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				
			} catch (Exception e) {
				System.out.println(e);
				e.printStackTrace();
				logger.error("Unable to  create a business accunt");
                
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

	
	

}
