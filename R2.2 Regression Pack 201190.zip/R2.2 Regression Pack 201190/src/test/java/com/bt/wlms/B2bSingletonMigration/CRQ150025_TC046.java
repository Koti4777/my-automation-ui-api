package com.bt.wlms.B2bSingletonMigration;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ150025_TC046 extends SeleniumImplementation
{
	
	private WebDriver driver;
	private String CLASS_NAME = "CRQ150025_TC046";
	
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ150025_TC046");
	
	
	@Test
	public CRQ150025_TC046()
	{
		PropertyConfigurator.configure(loggerPath);
	}

	
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}
	
	
	@Test
	public void testCRQ150025_TC046(Method method) throws IOException {

     		

			try {
				
				logger.info(" Start Test-CRQ150025_TC035 : Start the CRQ150025_TC035 creation ");
				
				
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo_B2BSCP(driver);
				
				
				HomePageOperations homePageOperations = loginPageOperations
						.b2bSelfCareLogin(CLASS_NAME, method.getName());
				
                 CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				
			} catch (Exception e) {
				System.out.println(e);
				e.printStackTrace();
				logger.error("Unable to login B2BSCP");
                
			}
			
		}

	
	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

	
}


