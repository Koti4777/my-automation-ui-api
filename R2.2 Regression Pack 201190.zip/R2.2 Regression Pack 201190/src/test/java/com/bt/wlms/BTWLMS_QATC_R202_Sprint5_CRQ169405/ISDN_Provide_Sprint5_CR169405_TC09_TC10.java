package com.bt.wlms.BTWLMS_QATC_R202_Sprint5_CRQ169405;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.ConfirmDNPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegradeOrderPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class ISDN_Provide_Sprint5_CR169405_TC09_TC10 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "Regrade_isdn";

	private String IN_FILE = "ISDN_Provide_Sprint4.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Regrade_isdn");
	
	
	public ISDN_Provide_Sprint5_CR169405_TC09_TC10()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

	bbDetailsList = CSVOperation_New.readISDN2eSystemSprint5Details(IN_FILE);


		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testRegradeOrder(Method method) throws IOException {

      System.out.println("method name is --->"+method.getName());

		/*while (count < testCount) {

			order = new Order();
*/
			try {
				
				logger.info(" Start Test-Regrade_Asset : Start the Regrade_Asset creation ");

				assetBeanDetails = bbDetailsList.get(2);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(assetBeanDetails.getOrderId(), "Order Number",
								CLASS_NAME, method.getName());
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				AgentDetailsPageOperations agentDetailsPageOperations;
				if (!product.contains("Line") && !product.contains("Calls")) {
					ConfirmDNPageOperations confirmDNPageOperations = accountDetailsPageOperations
							.clickRegradeForConfirmDN(CLASS_NAME,
									method.getName());
					agentDetailsPageOperations = confirmDNPageOperations
							.clickContinue(CLASS_NAME, method.getName());
				} else {
					agentDetailsPageOperations = accountDetailsPageOperations
							.clickRegrade(CLASS_NAME, method.getName());
				}
				agentDetailsPageOperations.clickSameAgent();

				LineCheckResultPageOperations lineCheckResultPageOperations = agentDetailsPageOperations
						.clickNextForRegrade(CLASS_NAME, method.getName());
				
				
				RegradeOrderPageOperations regradeOrderPageOperations = lineCheckResultPageOperations
						.clickNextforRegrade(CLASS_NAME, method.getName());
			
			
						
				System.out.println("I came here to verify If Proposition is equal to ISDN 30 DASS or not");
				if (assetBeanDetails.getProposition().contains("ISDN 30 ETSI"))
				{		logger.info(" Start Test-Create_ISDN_Asset for ISDN 30 DASS : Start the Create_ISDN_Asset creation ISDN 30 DASS"); 
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"Regrade Order Preposition" + ".png", driver, "");
						//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
						
						/*CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
								"Regrade Order Preposition" + ".png", driver, "");*/
						
						
						System.out.println(" End Test-Create_ISDN_Asset for ISDN 30 DASS : End the Create_ISDN_Asset creation ISDN 30 DASS..Exiting for the same Reason");
				}
				
				
			
				
				else 
					if (assetBeanDetails.getProposition().contains("ISDN 30 DASS"))
											
					{			regradeOrderPageOperations
						.selectPropositionByName_Sprint5(assetBeanDetails
								.getProposition());
					
					ProductDetailsPageOperations productDetailsPageOperations = regradeOrderPageOperations
						.clickNext(CLASS_NAME, method.getName());

				System.out.println("Came to Product Offering Page Operation");
				productDetailsPageOperations.selectProductOffering_Asset_Sprint5_001(
						assetBeanDetails.getProposition(),
						assetBeanDetails.getBroadbandCare(),
						assetBeanDetails.getRouter(),
						assetBeanDetails.getBusinessRateCard(),
						assetBeanDetails.getCalls(),
						assetBeanDetails.getRentalCharge(),
						assetBeanDetails.getCarelevel(),
						assetBeanDetails.getSelectcalls(),
						assetBeanDetails.getContract(),
						assetBeanDetails.getOneOffCharge(),
						assetBeanDetails.getRateCardDiscount(),
						assetBeanDetails.getSalesPromotion(),
						assetBeanDetails.getCustomerDiscount(),
						assetBeanDetails.getPostCode(),
						assetBeanDetails.getTitle(),
						assetBeanDetails.getFirstName(),
						assetBeanDetails.getSurName(),
						assetBeanDetails.getServiceId(),
						assetBeanDetails.getDdiRangeNum(),
						assetBeanDetails.getSddirangeNum(),
						assetBeanDetails.getManagedInstall(),
						assetBeanDetails.getBroadbandFeatures(),
						assetBeanDetails.getQuantity_VoiceCarelevel(),
						assetBeanDetails.getQuantity_ISDN2eSystem(),
						assetBeanDetails.getQuantity_ContractTerm(),
						assetBeanDetails.getContractTerm(),
						
						method.getName(), 
						CLASS_NAME);
				
				System.out.println("All Task related to Product Offering Page Operation Completed");
				
				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				System.out.println("came Here 1");
				appointmentManagementPageOperations = productDetailsPageOperations
						.clickNextForCRD(CLASS_NAME, method.getName());
				System.out.println("going from Here 1");

				appointmentManagementPageOperations.selectActivateDate();

				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(assetBeanDetails
						.getCommunicationBy());
				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
				
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"OrderConfirmationPage1" + ".png", driver, "");

				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());
				
				

			/*	String orderId = orderConfirmationPageOperations.getOrderId();

				order.setLineSiteId(assetBeanDetails.getNewSite());

				order.setOrdeId(orderId);*/

				// calling save method for storing order object in CSV
				//CSVOperations.saveOrders("Order.csv", order);

				orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
						method.getName());
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				
			logger.info(" End Test-Regrade_Asset : End the Regrade_Asset creation ");

			} 
			

			}
			
			
				catch (Exception e) {
			
				e.printStackTrace();
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}
	logger.error("Unable to regrade the orderid " + assetBeanDetails.getOrderId());
		//	count++;
		}
	
	//}
	

	@AfterMethod
	public void tearDown() {
		/*driver.close();
		driver.quit();*/

	}

}

