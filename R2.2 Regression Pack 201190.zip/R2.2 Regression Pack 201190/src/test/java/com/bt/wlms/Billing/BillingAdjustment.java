package com.bt.wlms.Billing;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.BillingAdjustmentPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class BillingAdjustment extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "BroadbandFaultChecker";

	private String IN_FILE = "BillingDetails.csv";
	
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;
	
	/*  List<Bbband> BbandList = new ArrayList<Bbband>();
	  Bbband band;*/

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("BroadbandFaultChecker");

	public BillingAdjustment() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		bbDetailsList = CSVOperation_New.readBillingadjustment(IN_FILE);
		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * using this method we can click the"Broadband" TAB and check whether
	 * "Broadband Fault Checker"are the hyperlink are not be present
	 * 
	 * @param method
	 * @throws IOException
	 */

	@Test
	public void testCreateBroadbandFault(Method method) throws IOException {

		try {

			logger.info(" Start Test-BroadbandFaultChecker : Start the BroadbandFaultChecker creation");

			assetBeanDetails = bbDetailsList.get(count);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLoginD7(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(assetBeanDetails.getSearchBy(), assetBeanDetails.getSearchValue(),
							CLASS_NAME, method.getName());
			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink(CLASS_NAME, method.getName());
			accountDetailsPageOperations.clickBillingTab(CLASS_NAME,method.getName());
			
			BillingAdjustmentPageOperations billingAdjustmentPageOperations=
					accountDetailsPageOperations.clickMakeAdjustment(CLASS_NAME,method.getName());
			billingAdjustmentPageOperations.fillBillingAdjustmentFields(
					
					assetBeanDetails.getAdjustmentType(),
					assetBeanDetails.getAdjustmentAmount(),
					assetBeanDetails.getAdjustmentDescription(),CLASS_NAME,method.getName());
			billingAdjustmentPageOperations.clickSaveButton(CLASS_NAME,method.getName());
			
		
			logger.info(" End Test - BroadbandFaultChecker : End the BroadbandFaultChecker-Asset creation");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do Fault BroadBand Asset");

			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}

	}

	@AfterMethod
	public void tearDown() {
		// driver.close();
		// driver.quit();

	}

}

