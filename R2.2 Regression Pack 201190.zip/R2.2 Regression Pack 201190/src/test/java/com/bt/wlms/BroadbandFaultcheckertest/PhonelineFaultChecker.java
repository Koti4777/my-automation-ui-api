package com.bt.wlms.BroadbandFaultcheckertest;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.phband;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class PhonelineFaultChecker extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "PhonelineFaultChecker";

	private String IN_FILE = "phonelinecheck.csv";
	List<phband> phbandList = new ArrayList<phband>();
	phband band;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("PhonelineFaultChecker");

	public PhonelineFaultChecker() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		phbandList = CSVOperation_New.readPhonelinefaultcheck(IN_FILE);
		if (phbandList != null && phbandList.size() > 0) {
			testCount = phbandList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * In the Account Details pageclick the "Phone Line" TAB and check whether
	 * "Phone Line Fault Checker" are the hyperlink are not be present.
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testCreatePhonelineFault(Method method) throws IOException {

		try {

			logger.info(" Start Test-PhonelineFaultChecker: Start the PhonelineFaultChecker creation ");

			band = phbandList.get(count);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.agentLogin(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(band.getSearchBy(), band.getSearchValue(),
							CLASS_NAME, method.getName());
			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink(CLASS_NAME, method.getName());
			accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME,
					method.getName());

			logger.info(" End Test - PhonelineFaultChecker : End the PhonelineFaultChecker-Asset creation");

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do Fault Phoneline Asset");

			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}

	}

	@AfterMethod
	public void tearDown() {
		// driver.close();
		// driver.quit();

	}

}
