package com.bt.wlms.BroadbandFaultcheckertest;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Bbwband;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class withBroadbandFaultChecker extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "withBroadbandFaultChecker";

	private String IN_FILE = "Faultchecker.csv";
	List<Bbwband> BwbandList = new ArrayList<Bbwband>();
	Bbwband band;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("withBroadbandFaultChecker");

	public withBroadbandFaultChecker() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		BwbandList = CSVOperation_New.readwithBroadbandfaultcheck(IN_FILE);
		if (BwbandList != null && BwbandList.size() > 0) {
			testCount = BwbandList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * In the Account Details pageclick the "Broadband" TAB and check whether
	 * "Broadband Fault Checker" are the hyperlink to be present.
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testCreatewithBroadbandFault(Method method) throws IOException {

		try {

			logger.info(" Start Test-withBroadbandFaultChecker : Start the withBroadbandFaultChecker creation ");

			band = BwbandList.get(count);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.agentLogin(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(band.getSearchBy(), band.getSearchValue(),
							CLASS_NAME, method.getName());
			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink(CLASS_NAME, method.getName());
			accountDetailsPageOperations.clickBroadbandTab(CLASS_NAME,
					method.getName());

			try {
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"lastPageOperations" + ".png", driver, "end");
			} catch (IOException e) {
				e.printStackTrace();
			}

			logger.info(" End Test - withBroadbandFaultChecker : End the withBroadbandFaultChecker  creation");

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do  wihtBroadBandFault Asset");

			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}

	}

	@AfterMethod
	public void tearDown() {
		// driver.close();
		// driver.quit();

	}

}
