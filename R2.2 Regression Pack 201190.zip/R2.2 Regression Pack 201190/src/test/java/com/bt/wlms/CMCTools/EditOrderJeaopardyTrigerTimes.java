package com.bt.wlms.CMCTools;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.EditOrderException_JeopardyTriggerTimesBean;
import com.hqnRegression.pages.EditOrderException_JeopardyTriggerTimesPage;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CMCTools_EditOrderException_JeopardyTriggerTimesOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class EditOrderJeaopardyTrigerTimes extends SeleniumImplementation
{
	private WebDriver driver;
	private String CLASS_NAME = "CMCTools_EditOrderException_JeopardyTriggerTimes";

	private String IN_FILE = "CMCTools_EditOrderException_JeopardyTriggerTimes.csv";
	
	List<EditOrderException_JeopardyTriggerTimesBean>  editOrderException_JeopardyTriggerTimesBeanList = null;
	 EditOrderException_JeopardyTriggerTimesBean editOrderException_JeopardyTriggerTimesBean = null;
	 EditOrderException_JeopardyTriggerTimesPage editOrderException_JeopardyTriggerTimesPage = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("EditOrderJeaopardyTrigerTimes");
	
	public EditOrderJeaopardyTrigerTimes()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	
	@BeforeMethod
	public void setUp() throws Exception {
		logger.debug("setup entered");
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	
		editOrderException_JeopardyTriggerTimesBeanList = CSVOperation_New.readEditOrderException_JeopardyTriggerTimes(IN_FILE);
	}
	
	@Test
	public void testEditOrder_JeopardyTriggerTimes(Method method) throws IOException {
		
		try {
		logger.info(" Start Test-EditOrderJeaopardyTrigerTimes : Start the EditOrderJeaopardyTrigerTimes creation ");
		
		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		
		System.out.println(editOrderException_JeopardyTriggerTimesBeanList.get(0));
		HomePageOperations homePageOperations = loginPageOperations
				.adminLogin(CLASS_NAME, method.getName());
		homePageOperations.clickCMCTools(CLASS_NAME, method.getName());
		CMCTools_EditOrderException_JeopardyTriggerTimesOperations cMCTools_EditTicketActivityGatewayOperations = homePageOperations
				.clickEditOrderJeopardyTriggerTimes();
		editOrderException_JeopardyTriggerTimesBean = editOrderException_JeopardyTriggerTimesBeanList.get(0);
		
		CMCHomePageOperations cmcHomePageOperations = cMCTools_EditTicketActivityGatewayOperations
				.EditOrderException_JeopardyTriggerTimes(
						 editOrderException_JeopardyTriggerTimesBean.getProvideIPstreamAcceptance(), 
						 editOrderException_JeopardyTriggerTimesBean.getProvideWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getProvideRADIUSCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getProvideCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationRADIUSCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationOLOIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationOLOWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationOLORADIUSCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getMigrationOLOCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getTransferWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getTransferWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getStartWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getStartWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getTakeoverWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getTakeoverWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getNewlineWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getNewlineWCLIAcceptance(), 
						 editOrderException_JeopardyTriggerTimesBean.getMPFconversionWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMPFconversionWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getProvideWLR3a0logueAcceptance1(),  
						 editOrderException_JeopardyTriggerTimesBean.getProvideWCLIAcceptance1(),
						 editOrderException_JeopardyTriggerTimesBean.getProvideIPstreamAcceptance1(),
						 editOrderException_JeopardyTriggerTimesBean.getProvideWBCAcceptance1(),
						 editOrderException_JeopardyTriggerTimesBean.getProvideRADIUSCompleted1(),
						 editOrderException_JeopardyTriggerTimesBean.getProvideCPECompleted1(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWWCLIAcceptance(),  
						 editOrderException_JeopardyTriggerTimesBean.getBTWIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWRADIUSCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPRADIUSCompleted(), 
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getStartsimWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getStartsimWCLIAcceptance(), 
						 editOrderException_JeopardyTriggerTimesBean.getStartsimIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getStartsimWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getStartsimRADIUSCompleted(), 
						 editOrderException_JeopardyTriggerTimesBean.getStartsimCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getWLTsimWLR3a0logueAcceptance(), 
						 editOrderException_JeopardyTriggerTimesBean.getWLTsimWCLIAcceptance(), 
						 editOrderException_JeopardyTriggerTimesBean.getWLTsimIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getWLTsimWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getWLTsimRADIUSCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getWLTsimCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getNewlinesimWLR3a0logueAcceptance(), 
						 editOrderException_JeopardyTriggerTimesBean.getNewlinesimWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getNewlinesimIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getNewlinesimWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getNewlinesimRADIUSCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getNewlinesimCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getMPFsimWLR3a0logueAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMPFsimWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMPFsimIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMPFsimWBCAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getMPFsimRADIUSCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getMPFsimCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getLineTransferWLR3a0logueAcceptance(), 
						 editOrderException_JeopardyTriggerTimesBean.getLineTransferWCLIAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getLineTransferIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getLineTransferWBCOrderAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getLineTransferRADIUSOrderCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getLineTransferCPEOrderCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWBBIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWBBWBCOrderAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWBBRADIUSOrderCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getBTWBBCPEOrderCompleted(), 
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPSMPFIPstreamAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPSMPFWBCOrderAcceptance(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPSMPFRADIUSOrderCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getOLOCPSMPFCPEOrderCompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getSolusbroadbandProvideCPECompleted(),
						 editOrderException_JeopardyTriggerTimesBean.getLineBroadbandProvideCPECompleted(),
						 CLASS_NAME, method.getName());	
		
			logger.info(" End Test - EditOrderJeaopardyTrigerTimes : End the EditOrderJeaopardyTrigerTimes creation");

		}catch (Exception e) {
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}
	}
	
	
	
	@AfterMethod
	public void tearDown(Method method) {
		
		 //driver.close();
		 //driver.quit();
		 logger.info(",EditOrderJeaopardyTrigerTimes,pass");

	}

}
