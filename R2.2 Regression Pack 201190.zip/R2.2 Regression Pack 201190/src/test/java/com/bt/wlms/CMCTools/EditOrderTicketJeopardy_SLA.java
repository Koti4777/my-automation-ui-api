package com.bt.wlms.CMCTools;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.EditOrderTicketBean;
import com.hqnRegression.pages.EditOrderTicketJeopardyPages;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CMCTools_EditOrderTicketJeopardyOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class EditOrderTicketJeopardy_SLA extends SeleniumImplementation
{
	private WebDriver driver;
	private String CLASS_NAME = "CmcToolsEditTicketOrder";

	private String IN_FILE = "CMCToolsEditOrderTicketJeopardy.csv";

	List<EditOrderTicketBean> editOrderTicketBeanList = null;
	EditOrderTicketBean editOrderTicketBean = null;
	EditOrderTicketJeopardyPages editOrderTicketJeopardy = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("EditOrderTicketJeopardy_SLA");

	public EditOrderTicketJeopardy_SLA() {
		PropertyConfigurator.configure(loggerPath);
	}
	
	@BeforeMethod
	public void setUp() throws Exception {
		logger.debug("setup entered");
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		editOrderTicketBeanList = CSVOperation_New.readEditTicketOrderJeopardySLA(IN_FILE);

	}
	
	@Test
	public void editOrderticketJeopardySLATimes(Method method) throws IOException {

		
		try {
			logger.info(" Start Test-EditOrderTicketJeopardy_SLA : Start the EditOrderTicketJeopardy_SLA creation ");

			editOrderTicketBean = editOrderTicketBeanList.get(0);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());
			homePageOperations.clickCMCTools(CLASS_NAME, method.getName());
			CMCTools_EditOrderTicketJeopardyOperations editOrderTicketJeopardyOperations = homePageOperations
					.clickEditOrderTicketJeopardy();
			CMCHomePageOperations cmcHomePageOperations = editOrderTicketJeopardyOperations
					.EditOrderTicket(
					editOrderTicketBean.getTransferLineTicketing1(),
					editOrderTicketBean.getTransferLineTicketing2(),
					editOrderTicketBean.getNewLine1(),
					editOrderTicketBean.getNewLine2(),
					editOrderTicketBean.getBB1(),
					editOrderTicketBean.getBB2(),
					editOrderTicketBean.getBBOnly1(),
					editOrderTicketBean.getBBOnly2(),
					editOrderTicketBean.getCPENotOrdered1(),
					editOrderTicketBean.getCPENotOrdered2(),
					editOrderTicketBean.getCPENotDispatched1(),
					editOrderTicketBean.getCPENotDispatched2(),
					editOrderTicketBean.getCalls1(),
					editOrderTicketBean.getCalls2(), CLASS_NAME, method.getName());
			
			logger.info(" End Test - EditOrderTicketJeopardy_SLA : End the EditOrderTicketJeopardy_SLA creation");

		} catch (Exception e) {
			logger.error("Unable to do the EditOrderTicketJeopardy_SLA operation " + editOrderTicketBean);
			
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}
	}
	
	
	
	@AfterMethod
	public void tearDown(Method method) {
		
		 //driver.close();
		 //driver.quit();
		logger.info(",EditOrderTicketJeopardy_SLA,pass");

	}
}
