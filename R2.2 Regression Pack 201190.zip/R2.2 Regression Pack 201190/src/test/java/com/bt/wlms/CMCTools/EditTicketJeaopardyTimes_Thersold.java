package com.bt.wlms.CMCTools;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.EditTicketActivityGateTimes;
import com.hqnRegression.pages.EditTicketActivityGateTimesPage;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CMCTools_EditTicketActivityGatewayOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class EditTicketJeaopardyTimes_Thersold  extends
		SeleniumImplementation {
	private WebDriver driver;
	private String CLASS_NAME = "CMCTools_EditTicketActivityGateTimes";

	private String IN_FILE = "CMCTools_EditTicketActivityGateTimes.csv";

	List<EditTicketActivityGateTimes> editTicketActivityGateTimesList = null;
	EditTicketActivityGateTimes editTicketActivityGateTimes = null;
	EditTicketActivityGateTimesPage editTicketActivityGateTimesPage = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("EditTicketJeaopardyTimes_Thersold");

	public EditTicketJeaopardyTimes_Thersold() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		logger.debug("setup entered");
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		editTicketActivityGateTimesList = CSVOperation_New
				.readEditTicketActivityGateway(IN_FILE);
	}
	@Test
	public void testEditTicketActivityGateTimes(Method method) throws IOException {

		try {
			logger.info(" Start Test-EditTicketJeaopardyTimes_Thersold : Start the EditTicketJeaopardyTimes_Thersold creation ");

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());
			homePageOperations.clickCMCTools(CLASS_NAME, method.getName());
			CMCTools_EditTicketActivityGatewayOperations cMCTools_EditTicketActivityGatewayOperations = homePageOperations
					.clickEditTicketJeopardyTriggerTimes();
			editTicketActivityGateTimes = editTicketActivityGateTimesList.get(0);
			CMCHomePageOperations cmcHomePageOperations = cMCTools_EditTicketActivityGatewayOperations
					.EditTicketActivityGateway(
							editTicketActivityGateTimes.getBBReception(),
							editTicketActivityGateTimes.getBBDiagnose(),
							editTicketActivityGateTimes.getBBFix(),
							editTicketActivityGateTimes.getBBClear(),
							editTicketActivityGateTimes.getBBSLA(),
							editTicketActivityGateTimes.getEmailTouchRespond(),
							editTicketActivityGateTimes.getEmailClear(),
							editTicketActivityGateTimes.getEmailSLA(),
							editTicketActivityGateTimes.getEnhancedBBReception(),
							editTicketActivityGateTimes.getEnhancedBBDiagnose(),
							editTicketActivityGateTimes.getEnhancedBBFix(),
							editTicketActivityGateTimes.getEnhancedBBClear(),
							editTicketActivityGateTimes.getEnhancedBBSLA(),
							editTicketActivityGateTimes.getEnhancedLineReception(),
							editTicketActivityGateTimes.getEnhancedLineDiagnose(),
							editTicketActivityGateTimes.getEnhancedLineFix(),
							editTicketActivityGateTimes.getEnhancedLineClear(),
							editTicketActivityGateTimes.getEnhancedLineSLA(),
							editTicketActivityGateTimes.getNonAppointedBBReception(),
							editTicketActivityGateTimes.getNonAppointedBBDiagnose(),
							editTicketActivityGateTimes.getNonAppointedBBFix(),
							editTicketActivityGateTimes.getNonAppointedBBClear(),
							editTicketActivityGateTimes.getNonAppointedBBSLA(),
							editTicketActivityGateTimes.getNonAppointedLineReception(),
							editTicketActivityGateTimes.getNonAppointedLineDiagnose(),
							editTicketActivityGateTimes.getNonAppointedLineFix(),
							editTicketActivityGateTimes.getNonAppointedLineClear(),
							editTicketActivityGateTimes.getNonAppointedLineSLA(),
							editTicketActivityGateTimes.getWhiteEmailTouchRespond(),
							editTicketActivityGateTimes.getWhiteEmailClear(),
							editTicketActivityGateTimes.getWhiteEmailSLA(),
							CLASS_NAME, method.getName());
			logger.info(" End Test - EditTicketJeaopardyTimes_Thersold : End the EditTicketJeaopardyTimes_Thersold creation");

		}catch (Exception e) {
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}
}

@AfterMethod
public void tearDown(Method method) {
	
	 //driver.close();
	 //driver.quit();
	logger.info(",EditTicketJeaopardyTimes_Thersold,pass");

	}
	
}
