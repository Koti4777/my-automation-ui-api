package com.bt.wlms.CRQ200058;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.PSTNISDNRegradeBeanDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.ConfirmDNPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegradeOrderPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class CRQ200058_TC0001 
extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "CRQ200058_TC0001";

	private String IN_FILE = "PSTN_ISDN_Regrade.csv";
	List<PSTNISDNRegradeBeanDetails> PSTNISDNRegradeList = null;
	PSTNISDNRegradeBeanDetails pstnisdnregradebeandetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ200058_TC0001");

	public CRQ200058_TC0001() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		PSTNISDNRegradeList = CSVOperation_New.readPSTNISDNRegradeBeanDetails(IN_FILE);

		if (PSTNISDNRegradeList != null && PSTNISDNRegradeList.size() > 0) {
			testCount = PSTNISDNRegradeList.size();
		}

	}
	@Test
	public void testRegrade_ISDN_PSTNCRQ200058_TC0001(Method method) throws IOException {

		System.out.println("method name is --->" + method.getName());

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		while (count < testCount) {
			try {
			logger.info(" Start ISDN_PSTN_Regrade : Start the ISDN_PSTN_Regrade ");

			pstnisdnregradebeandetails = PSTNISDNRegradeList.get(count);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
			        .adminLogin(CLASS_NAME, method.getName());
			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(pstnisdnregradebeandetails.getOrderId(), "Order Number",
					CLASS_NAME, method.getName());
			String product = searchResultPageOperations
					.getProductForActiveOrder();

			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink(CLASS_NAME, method.getName());
			AgentDetailsPageOperations agentDetailsPageOperations;
			if (!product.contains("Line") && !product.contains("Calls")) {
				ConfirmDNPageOperations confirmDNPageOperations = accountDetailsPageOperations
					.clickRegradeForConfirmDN(CLASS_NAME,
								method.getName());
				agentDetailsPageOperations = confirmDNPageOperations
					.clickContinue(CLASS_NAME, method.getName());
			} else {
				agentDetailsPageOperations = accountDetailsPageOperations
					.clickRegrade(CLASS_NAME, method.getName());
			}
			agentDetailsPageOperations.clickSameAgent();

			LineCheckResultPageOperations lineCheckResultPageOperations = agentDetailsPageOperations
					.clickNextForRegrade(CLASS_NAME, method.getName());

			RegradeOrderPageOperations regradeOrderPageOperations = lineCheckResultPageOperations
					.clickNextforRegrade(CLASS_NAME, method.getName());

			regradeOrderPageOperations.selectPropositionByName(pstnisdnregradebeandetails
					.getProposition());
			ProductDetailsPageOperations productDetailsPageOperations = regradeOrderPageOperations
					.clickNext(CLASS_NAME, method.getName());
			//productDetailsPageOperations.isNewContract(CLASS_NAME, method.getName());
			productDetailsPageOperations.selectProductOffering_ISDN_PSTN_Regrade(
					pstnisdnregradebeandetails.getProposition(),
					pstnisdnregradebeandetails.getBroadbandCare(),
					pstnisdnregradebeandetails.getRouter(),
					pstnisdnregradebeandetails.getBusinessRateCard(),
					pstnisdnregradebeandetails.getCalls(),
					pstnisdnregradebeandetails.getCarelevel(),
					pstnisdnregradebeandetails.getSelectcalls(),
					pstnisdnregradebeandetails.getContract(),
					pstnisdnregradebeandetails.getOneOffCharge(),
					pstnisdnregradebeandetails.getRateCardDiscount(),
					pstnisdnregradebeandetails.getSalesPromotion(),
					pstnisdnregradebeandetails.getCustomerDiscount(),
					pstnisdnregradebeandetails.getPostCode(),
					pstnisdnregradebeandetails.getTitle(),
					pstnisdnregradebeandetails.getFirstName(),
					pstnisdnregradebeandetails.getSurName(),
					pstnisdnregradebeandetails.getServiceId(),
					pstnisdnregradebeandetails.getDdiRangeNum(),
					pstnisdnregradebeandetails.getSddirangeNum(),
					"", CLASS_NAME,
					method.getName(), CLASS_NAME,
					pstnisdnregradebeandetails.getQuantity_VoiceCarelevel(),
					pstnisdnregradebeandetails.getQuantity_ISDN(),
					pstnisdnregradebeandetails.getQuantity_ContractTerm(),
					pstnisdnregradebeandetails.getAdminControlledSelectiveCallNationalInternational(),
					pstnisdnregradebeandetails.getWlroneoffcharges());
			productDetailsPageOperations.isNewContract(pstnisdnregradebeandetails.getWaiveETCReason(),CLASS_NAME, method.getName());
			CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
			HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

			if (productDetailsPageOperations.isHardwarepageAvailable) {

				hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
						.clickNextForHardware(CLASS_NAME,
								method.getName());

				appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
						.clickNext(CLASS_NAME, method.getName());
			} else {

				appointmentManagementPageOperations = productDetailsPageOperations
						.clickNextForCRD(CLASS_NAME, method.getName());
			}

			appointmentManagementPageOperations.selectFutureCalendarDate(
					CLASS_NAME, method.getName(), 7);

			boolean isPresent = appointmentManagementPageOperations
					.isVoiceAppointmentButtonPresent();
			appointmentManagementPageOperations
			.fillVoiceAppointmentManagementFieldsRegrade(pstnisdnregradebeandetails
					.getEngineeringNotes());
			if (isPresent) {
				
				if (pstnisdnregradebeandetails.getIncludeOutofHours()
						.equalsIgnoreCase("yes")) {
					appointmentManagementPageOperations
							.clickOutOfHoursAppointment();
				}

				ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
						.clickAvailableAppointmentButton();

				reserveAppointmentPageOperations
						.selectFirstAvailableAppointmentDate();

				if (pstnisdnregradebeandetails.getIncludeOutofHours()
						.equalsIgnoreCase("yes")) {
					if (pstnisdnregradebeandetails.getAppointmentCharges().contains(
							"Accept additional")) {
						reserveAppointmentPageOperations
								.clickAcceptAdditionalCharges();
					}
					if (pstnisdnregradebeandetails.getAppointmentCharges().contains(
							"both")) {
						reserveAppointmentPageOperations
								.clickAcceptAdditionalCharges();
						reserveAppointmentPageOperations
								.getWaiveAdditionalCharges();
					} else {
						reserveAppointmentPageOperations
								.getWaiveAdditionalCharges();
					}
				}

				appointmentManagementPageOperations = reserveAppointmentPageOperations
						.clickReserveAppointmentButton(CLASS_NAME,
								method.getName());
			}

			isPresent = appointmentManagementPageOperations
					.isFTTCAppointmentButtonPresent();

			if (isPresent) {

				FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
						.fillBBFTTCAppointmentManagement(CLASS_NAME,
								method.getName());
				fttcAvailableAppointmentsPageOperations
						.selectFirstAvailableAppointmentDate();
				appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
						.clickReserveAppointmentButton(CLASS_NAME,
								method.getName());
			}

			if (pstnisdnregradebeandetails.getProposition().contains("Call")
					|| pstnisdnregradebeandetails.getProposition().contains("Line")
					|| product.contains("Call") || product.contains("Line")) {

				appointmentManagementPageOperations
						.fillHealthAndsafetyVeificationFields(pstnisdnregradebeandetails
								.getHealthAndSafetyNotes());
			}
			OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
			.clickNext(CLASS_NAME, method.getName());
			orderSummaryPageOperations.totalPricePresent(CLASS_NAME, method.getName());
			orderSummaryPageOperations.selectCommunication(pstnisdnregradebeandetails
			.getCommunicationBy());
			orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

			/*OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
					.confirmOrder(CLASS_NAME, method.getName());

			
			String orderId = orderConfirmationPageOperations.getOrderId();
			System.out.println(orderId);
			
			homePageOperations = orderConfirmationPageOperations.
					clickCompleteOrderButton(CLASS_NAME,method.getName());
			 
			searchResultPageOperations = homePageOperations
					.search(orderId,"Order Number", CLASS_NAME,method.getName());
			String productu = searchResultPageOperations
					.getProductForPendingOrder();
				
			accountDetailsPageOperations = searchResultPageOperations
					.clickProductLinkForPendingOrder(CLASS_NAME,method.getName());
			accountDetailsPageOperations.clickticketsTab(CLASS_NAME, method.getName());

			accountDetailsPageOperations.verifyFoidRequest(CLASS_NAME, method.getName());
			*/
			logger.info(" End ISDN_PSTN_Regrade : End the ISDN_PSTN_Regrade");
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to place the order");
				// CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				// driver.close();
			}
			count++;
		}
	}
	@AfterMethod
	public void tearDown() {
		//driver.quit();
		//driver.close();

	}
}

