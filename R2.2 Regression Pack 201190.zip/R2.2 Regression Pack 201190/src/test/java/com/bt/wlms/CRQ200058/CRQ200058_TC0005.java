package com.bt.wlms.CRQ200058;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.pages.operations.ChangeYourPlanPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ200058_TC0005 extends SeleniumImplementation {
        private WebDriver driver;
        private String baseUrl;

        private String CLASS_NAME = "B2cSelfcarePortal";
        private String IN_FILE = "RegradeDetails.csv";
        
        private int testCount = 0;
    	private int count = 0;
        
        private String loggerPath = CommonMethods.getProperty("log4j.properties");
    	private static Logger logger = Logger.getLogger("CRQ200058_TC0005");
    	
    	
    	List<AssetBeanDetails> bbDetailsList = null;
    	AssetBeanDetails assetBeanDetails = null;

        
       @BeforeMethod
        public void setUp() throws Exception 
        {
    	   
    	   bbDetailsList = CSVOperation_New.readAssetDetails(IN_FILE);

   		if (bbDetailsList != null && bbDetailsList.size() > 0) {
   			testCount = bbDetailsList.size();
   		}
                        driver = new FirefoxDriver();
                        baseUrl = "https://163.164.37.104/";
                        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

                     

        }

        @Test
        public void testCRQ200058_TC0005(Method method) throws Exception 
        
        {
                      
          SelfCarePortalLoginOperations selfCarePortalLoginOperations = 
           SelfCarePortalLoginOperations.navigateTob2bscp(driver, baseUrl,
        		   CLASS_NAME, method.getName());
                  
          SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = 
      		  selfCarePortalLoginOperations.Login(CLASS_NAME, method.getName());
          
          ChangeYourPlanPageOperations changeYourPlanPageOperations = 
       		  selfCarePortalHomePageOperations.clickChangeYourPlanlink(CLASS_NAME, method.getName());

          changeYourPlanPageOperations.clickUpgradeNowBtn(CLASS_NAME, method.getName());
          
          changeYourPlanPageOperations.clickRadioBtn(CLASS_NAME, method.getName());
       
          changeYourPlanPageOperations.clickSelectBtn(CLASS_NAME, method.getName());
           
          changeYourPlanPageOperations.selectProductOffering_SCP(
        		  assetBeanDetails.getProposition(),
        		  assetBeanDetails.getCalls(),
        		  assetBeanDetails.getCarelevel(),
        		  assetBeanDetails.getContract(),
        		  CLASS_NAME, method.getName());
        		         
        }
        
        
        @AfterMethod
        public void tearDown() throws Exception
        {
        	             //driver.close();
                         //driver.quit();
                         
        }
}
