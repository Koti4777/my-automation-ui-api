package com.bt.wlms.CRQ200058;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.UpgradeBeanDetails;
import com.hqnRegression.pages.operations.BroadbandUsageOperations;
import com.hqnRegression.pages.operations.CurrentPlanFeaturesOperations;
import com.hqnRegression.pages.operations.SCPOrderSummaryPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ200058_TC0005_Upgrade_B2B extends SeleniumImplementation {

	private WebDriver driver;

	private String CLASS_NAME = "CRQ200058_TC0005_Upgrade_B2B";
	private String IN_FILE = "SCPUpgradeB2BDetails.csv";
	List<UpgradeBeanDetails> upgradeDetailsList = null;
	UpgradeBeanDetails upgradeBeanDetails = null;

	private int testCount = 0;
	private int count = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ200058_TC0006_Upgrade_B2B");

	public CRQ200058_TC0005_Upgrade_B2B() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		upgradeDetailsList = CSVOperation_New.readSCPUpgradeDetails(IN_FILE);

		if (upgradeDetailsList != null && upgradeDetailsList.size() > 0) {
			testCount = upgradeDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void tesCRQ200058_TC0005_Upgrade_B2B(Method method) throws Exception {

		logger.info(" Start Test-tesCRQ200058_TC0005_Upgrade : Start the SCP_Upgrade_B2B");

		while (count < testCount) {

			try {

				upgradeBeanDetails = upgradeDetailsList.get(count);

				SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
						.navigateTob2bscp(driver);

				SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
						.selfcareLogin(CLASS_NAME, method.getName());

				BroadbandUsageOperations broadbandUsageOperations = selfCarePortalHomePageOperations
						.clickChangePlan(CLASS_NAME, method.getName());

				broadbandUsageOperations.clickContinue(CLASS_NAME,
						method.getName());
				
				broadbandUsageOperations
						.selectPropositionByName(upgradeBeanDetails
								.getPraposition());

				CurrentPlanFeaturesOperations features = broadbandUsageOperations
						.clickSelect(CLASS_NAME, method.getName());

				features.selectCurrentFeatures(upgradeBeanDetails.getRouter(),
						upgradeBeanDetails.getCalls(),
						upgradeBeanDetails.getVoiceCarelevel(),
						upgradeBeanDetails.getContract(),
						upgradeBeanDetails.getCnfFeature(),
						upgradeBeanDetails.getCarelevel(), CLASS_NAME,
						method.getName());

				SCPOrderSummaryPageOperations orderSumaryPageOperations = features
						.clickSelect1(CLASS_NAME, method.getName());

				orderSumaryPageOperations.totalCostPresent(CLASS_NAME,
						method.getName());
				orderSumaryPageOperations.selectTermsAndConditionsCheckBox(
						CLASS_NAME, method.getName());
				orderSumaryPageOperations
						.selectCommunication(upgradeBeanDetails
								.getCommunicationBy());

				CommonMethods.b2bselfCareLogOut(driver, CLASS_NAME,
						method.getName());

				logger.info(" End Test-tesCRQ200058_TC0005_Upgrade : Start the SCP_Upgrade_B2B");

			} catch (Exception e) {
				e.printStackTrace();
				logger.info(" Unable to Perform SCP_Upgrade_B2B ");
				CommonMethods.b2bselfCareLogOut(driver, CLASS_NAME,
						method.getName());

			}
			count++;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception {

		driver.close();
		driver.quit();

	}

}
