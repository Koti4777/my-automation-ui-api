package com.bt.wlms.CRQ200137;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ200137TC_01 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "NGA_Asset";

	private String IN_FILE = "RetrieveAppointment.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ200137TC_01");

	public CRQ200137TC_01() {
		PropertyConfigurator.configure(loggerPath);
	}

	/*

	 * @Rule public TestName name = new TestName();
	 */

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readAssetBeanDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}

	}

	@Test
	public void testCRQ200137TC_01(Method method) throws IOException {

		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-CRQ200137TC_01 : Start the CRQ200137TC_01 creation ");

				assetBeanDetails = bbDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				// Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				RegisterNewServicePageOperations servicePageOperations = homePageOperations
						.clickBusinessCustomer();

				CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
						.searchByBusinessAccountName(
								assetBeanDetails.getBusinessAccount(),
								CLASS_NAME, method.getName());

				CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
						.clickBusinessAccount(assetBeanDetails
								.getBusinessAccount());

				LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
						.clickAddSite(CLASS_NAME, method.getName());

				LineCheckResultPageOperations lineCheckResultPageOperations = null;

				if ("".equalsIgnoreCase(assetBeanDetails.getLandlinePhone())) {

					AddressSelectionPageOperations addressSelectionPageOperations = lineDetailsPageOperations
							.createSiteWithPostCodeOnly(
									assetBeanDetails.getNewSite(),
									assetBeanDetails.getLandlinePhone(),
									assetBeanDetails.getPostCode(),
									assetBeanDetails.getAddressValue(),
									assetBeanDetails.getPremisesName(),
									assetBeanDetails.getStreetName(),
									assetBeanDetails.getTown(),
									assetBeanDetails.getCountry(), CLASS_NAME,
									method.getName());

					lineCheckResultPageOperations = addressSelectionPageOperations
							.submitAddressButton(CLASS_NAME,
									method.getName());
				} else {

					lineCheckResultPageOperations = lineDetailsPageOperations
							.createSiteWithPostCodeAndPremisesDetails(
									assetBeanDetails.getNewSite(),
									assetBeanDetails.getLandlinePhone(),
									assetBeanDetails.getPostCode(),
									assetBeanDetails.getAddressValue(),
									assetBeanDetails.getPremisesName(),
									assetBeanDetails.getStreetName(),
									assetBeanDetails.getTown(),
									assetBeanDetails.getCountry(), CLASS_NAME,
									method.getName());

				}


				lineCheckResultPageOperations
						.selectPropositionByName(assetBeanDetails
								.getProposition());

				AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
						.clickNext(CLASS_NAME, method.getName());

				AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
						.submit(CLASS_NAME, method.getName());

				ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
						.submit(CLASS_NAME, method.getName());

				productDetailsPageOperations.selectProductOffering_Asset(
						assetBeanDetails.getProposition(),
						assetBeanDetails.getBroadbandCare(),
						assetBeanDetails.getRouter(),
						assetBeanDetails.getBusinessRateCard(),

						assetBeanDetails.getCalls(),
						assetBeanDetails.getCarelevel(),
						assetBeanDetails.getSelectcalls(),
						assetBeanDetails.getContract(),
						assetBeanDetails.getOneOffCharge(),
						assetBeanDetails.getRateCardDiscount(),
						assetBeanDetails.getSalesPromotion(),
						assetBeanDetails.getCustomerDiscount(),
						assetBeanDetails.getPostCode(),
						assetBeanDetails.getTitle(),
						assetBeanDetails.getFirstName(),
						assetBeanDetails.getSurName(),
						assetBeanDetails.getServiceId(),
						assetBeanDetails.getDdiRangeNum(),
						assetBeanDetails.getSddirangeNum(),
						assetBeanDetails.getManagedInstall(),
						assetBeanDetails.getBroadbandFeatures(),
						method.getName(), CLASS_NAME);

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				if (productDetailsPageOperations.isHardwarepageAvailable) {

					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
							.clickNextForHardware(CLASS_NAME, method.getName());

					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
							.clickNext(CLASS_NAME, method.getName());
				} else {

					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
				}

				appointmentManagementPageOperations.selectFutureCalendarDate(
						CLASS_NAME, method.getName(), 18);
                  
								
				
				/*boolean isPresent = appointmentManagementPageOperations
						.isVoiceAppointmentButtonPresent();*/
				
				appointmentManagementPageOperations.clickPreviouslyReservedAppointment
				(CLASS_NAME, method.getName());				
				
				boolean isButtonPresent = appointmentManagementPageOperations
						.isRetrieveAppointmentButtonPresent();
				
				if(isButtonPresent)
				
				   {
					 appointmentManagementPageOperations.fillAppointmentReference
					 (CLASS_NAME, method.getName(),assetBeanDetails.getAppointmentreference());
				   }

				appointmentManagementPageOperations.isErrorMessagePresent();
				
				logger.info(" End Test -  CRQ200137TC_01 : End the CRQ200137TC_01");

			}
				catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to place the find the message");

			}
			count++;
		}

		}

	@AfterMethod
	public void tearDown() {

		// driver.close();
		// driver.quit();

	}

}

