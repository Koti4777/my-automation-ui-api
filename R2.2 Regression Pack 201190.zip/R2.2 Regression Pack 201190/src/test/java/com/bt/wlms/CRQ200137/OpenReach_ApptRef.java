package com.bt.wlms.CRQ200137;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AppointingServiceDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AppointingServicesPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.MyDashBoardOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class OpenReach_ApptRef extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "OpenReach_ApptRef";

	private String IN_FILE = "AppointingServiceDetails.csv";
	List<AppointingServiceDetails> busAccountList = null;
	AppointingServiceDetails account = null;
	private int count = 0;
	public Order order = null;
	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("OpenReach_ApptRef");

	public OpenReach_ApptRef() {
		PropertyConfigurator.configure(loggerPath);
	}

	
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.CHROME);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		busAccountList = CSVOperation_New
				.readAppointmentServicesDetails(IN_FILE);

		if (busAccountList != null && busAccountList.size() > 0) {
			testCount = busAccountList.size();
		}

	}

	/**
	 * This methods reads address reference from CSV and get the rerence, date from OPen reach and placed it into new CSV
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testOpenReach_ApptRef(Method method) throws IOException {

		while (count < testCount) {

		
			try {
				logger.info(" ******************************************************************");
				logger.info(" Start Test-OpenReach_ApptRef : Start the OpenReach_ApptRef creation ");

				account = busAccountList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo_OpernReach(driver);

				CommonMethods.clickOpenReachLoginLink(driver);

				MyDashBoardOperations dashPageOperations = loginPageOperations
						.openReachLogin(CLASS_NAME, method.getName());

				AppointingServicesPageOperations servicePageOperations = dashPageOperations
						.clickAppointingServices(CLASS_NAME, method.getName());

				servicePageOperations.clickLaunchapplication(CLASS_NAME,
						method.getName());

				servicePageOperations.fillAppointingRefenceDetails(
						account.getGoldAddressKey(), account.getDistCode(),
						CLASS_NAME, method.getName());

				servicePageOperations.clickListApointments(CLASS_NAME,
						method.getName());

				servicePageOperations.clickAvailableApointments(CLASS_NAME,
						method.getName());

				servicePageOperations.clickReserveApointments(CLASS_NAME,
						method.getName());

				List<AppointingServiceDetails> fetchAppointmentDetailsList = new ArrayList<AppointingServiceDetails>();

				AppointingServiceDetails details = servicePageOperations
						.getDetails();

				details.setGoldAddressKey(account.getGoldAddressKey());
				details.setAppointmentReference(details
						.getAppointmentReference());
				details.setAppointmentDate(details.getAppointmentDate());

				if (details != null) {
					fetchAppointmentDetailsList.add(details);
					logger.info("Apointment details size " + fetchAppointmentDetailsList.size());
				}

				if (fetchAppointmentDetailsList.size() > 0) {

					logger.info("Check Appointment Info : write the Appointment Info to CSV file");
					CSVOperation_New.writeAppointmentDetails(
							"AppointmentRefDetails.csv",
							fetchAppointmentDetailsList);
				}

				CommonMethods.clickOpenReachLogoutLink(driver, CLASS_NAME,
						method.getName());

				logger.info(" End Test-OpenReach_ApptRef : End the OpenReach_ApptRef creation ");

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to  create Appointment Refrence number");
				CommonMethods.clickOpenReachLogoutLink(driver, CLASS_NAME,
						method.getName());
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

}
