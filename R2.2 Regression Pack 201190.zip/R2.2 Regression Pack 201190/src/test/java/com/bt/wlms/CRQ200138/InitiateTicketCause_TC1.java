package com.bt.wlms.CRQ200138;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class InitiateTicketCause_TC1 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "InitiateTicketCause_TC1";

	private String IN_FILE = "initiateticket.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	private int orderid = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("InitiateTicketCause_TC1");

	/*
	 * @Rule public TestName name = new TestName();
	 */

	public InitiateTicketCause_TC1() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readTicketdetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		// logger.info(",Description,status");

	}
	

  /**
   * This method is used for In the "Tickets" TAB check whether "Initiate Ticket"
    button is should not  be present in the "CustomerDetailsPage"... 
   * @param method
   * @throws IOException
   */
	@Test
	public void testIntiateTicketCause(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				logger.info(" Start Test-InitiateTicketCause_TC1 : Start the InitiateTicketCause_TC1 creation ");

				assetBeanDetails = bbDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLoginD7(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(assetBeanDetails.getOrderId(), "Order Number",
								CLASS_NAME, method.getName());
				
				CustomerDetailsPageOperations customerDetailsPageOperations=searchResultPageOperations
						.clickProductLink1(CLASS_NAME, method.getName());
				
				customerDetailsPageOperations.clickTicketTab1(CLASS_NAME, method.getName());

				customerDetailsPageOperations.clickInitiateTicket(CLASS_NAME, method.getName());
				
				String windw = driver.getWindowHandle();
				
				AccountDetailsPageOperations accountdetailspageoperations = customerDetailsPageOperations
					.checkTicketCauseB2B(CLASS_NAME, method.getName());
				
				accountdetailspageoperations.clickRefreshTab(CLASS_NAME, method.getName());
				
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
	
			} catch (Exception e) {
				e.printStackTrace();
				logger.info(" End Test - InitiateTicketCause_TC1 : End the InitiateTicketCause_TC1 creation");
			}
			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();
		logger.info(",InitiateTicket,pass");
	}

}

