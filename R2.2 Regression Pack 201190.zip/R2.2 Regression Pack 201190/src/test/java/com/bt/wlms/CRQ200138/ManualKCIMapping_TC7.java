package com.bt.wlms.CRQ200138;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.ManageHistoryDetails;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ManualKCIMappingPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.pages.operations.UserListPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class ManualKCIMapping_TC7 extends SeleniumImplementation {

	private  WebDriver driver;
	private String CLASS_NAME = "ManualKCIMapping_TC7";
	private String IN_FILE = "ManualKCIMapping.csv";
	List<ManageHistoryDetails> HistoryList = null;
	ManageHistoryDetails account = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("ManualKCIMapping_TC7");

	private int testCount = 0;
	private int count = 0;
	
	@Test
	public ManualKCIMapping_TC7() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		HistoryList = CSVOperation_New.readManualKCIMappingDetails(IN_FILE);
		
		if (HistoryList != null && HistoryList.size() > 0) {
			testCount = HistoryList.size();
		}

	}

	
	/**
	 * operations in user and group admin page
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testManualKCIMapping(Method method) throws IOException {

		

		try {

			logger.info(" Start Test-ManualKCIMapping_TC7 : Start the ManualKCIMapping_TC7 ");

			
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			

			HomePageOperations homePageOperations = loginPageOperations
					.adminLoginD7(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());
			
			ManualKCIMappingPageOperations manualKCIMappingPageOperations = userAndGroupAdminPageOperations
					.clickManualKCIMapping(CLASS_NAME, method.getName());
			
			/*for(int i=2; i< 250; i++)
			{
				WebElement ticketCauseNum = driver.findElement(By.xpath("//form[@id='ticketCauseTemplateListVO']/table[1]/tbody/tr["+i+"]/td[1]"));
				if(ticketCauseNum.equals("Abuse Management"));
				{
					WebElement ticketCauseNum1 = driver.findElement(By.xpath("//form[@id='ticketCauseTemplateListVO']/table[1]/tbody/tr["+i+"]/td[1]"));
					
				}
				
			}
			
			String CauseName = ticketCauseNum.getText();*/
			
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			
			logger.info("End Test ManualKCIMapping_TC7");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();

	}

}
