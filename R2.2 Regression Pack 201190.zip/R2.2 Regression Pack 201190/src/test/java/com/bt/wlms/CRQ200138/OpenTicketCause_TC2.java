package com.bt.wlms.CRQ200138;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class OpenTicketCause_TC2 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "OpenTicketCause_TC2";

	private String IN_FILE = "TicketInitiate.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	private int orderid = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("OpenTicketCause_TC2");

	/*
	 * @Rule public TestName name = new TestName();
	 */

	public OpenTicketCause_TC2() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readTicketInitiatedetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		// logger.info(",Description,status");

	}
	

  /**
   * This method is used for In the "Tickets" TAB check whether "Initiate Ticket"
    button is should not  be present in the "CustomerDetailsPage"... 
   * @param method
   * @throws IOException
   */

	@Test
	public void testOpenTicketCause_TC2(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				logger.info(" Start Test-OpenTicketCause_TC2 : Start the OpenTicketCause_TC2 creation ");

				assetBeanDetails = bbDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLoginD7(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(assetBeanDetails.getOrderId(), "Order Number",
								CLASS_NAME, method.getName());
				
				String product = searchResultPageOperations
				.getProductForActiveOrder();
				
				CustomerDetailsPageOperations customerDetailsPageOperations=searchResultPageOperations
						.clickProductLink1(CLASS_NAME, method.getName());
				
				customerDetailsPageOperations.clickTicketTab1(CLASS_NAME, method.getName());
				
				WebElement ticketNum = driver.findElement(By.xpath("//div[@id='ticketTree"
						+ assetBeanDetails.getTicketReferenceNumber() + "OPEN']/img"));
				ticketNum.click();
				
				WebElement ticketCauseStatus = driver.findElement(By.xpath("//div[@id='"
						+ assetBeanDetails.getTicketReferenceNumber() + "OPEN']/div/div[3]/div/table/tbody/tr[1]/td[2]"));
				String status = ticketCauseStatus.getText();
				
				logger.info("Ticket Cause Status  "+status);
				
				//customerDetailsPageOperations.verifyTicketCause(CLASS_NAME, method.getName());
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
			} catch (Exception e) {
				e.printStackTrace();
				
				logger.info(" End Test - OpenTicketCause_TC2 : End the OpenTicketCause_TC2 creation");

							}
			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();
		logger.info(",OpenTicketCause_TC2,pass");
	}
}