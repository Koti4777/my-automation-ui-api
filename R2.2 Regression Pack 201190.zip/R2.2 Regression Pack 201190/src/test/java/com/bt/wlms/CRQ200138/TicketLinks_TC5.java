package com.bt.wlms.CRQ200138;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.ChangePoolPageOperation;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PutOnHoldPageOperations;
import com.hqnRegression.pages.operations.ResolvePageOperation;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.UpdateTicketPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class TicketLinks_TC5 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "TicketLinks_TC5";

	private String IN_FILE = "TiketLinks.csv";
	List<WLRFaultCareLevel> wlrFaultCareLevelList = new ArrayList<WLRFaultCareLevel>();
	WLRFaultCareLevel wlrFaultCareLevel;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	WebElement ticketNum = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("TicketLinks_TC5");

	/*
	 * @Rule public TestName name = new TestName();
	 */

	public TicketLinks_TC5() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		wlrFaultCareLevelList = CSVOperation_New.readTicketLinks(IN_FILE);
		if (wlrFaultCareLevelList != null && wlrFaultCareLevelList.size() > 0) {
			testCount = wlrFaultCareLevelList.size();
		}
	}

  /**
   * This method is used for In the "Tickets" TAB check whether "Initiate Ticket"
    button is should not  be present in the "CustomerDetailsPage"... 
   * @param method
   * @throws IOException
   */

	@Test
	public void testTicketLinks_TC5(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());
	
		while (count < testCount) {
			
				order = new Order();
				
			try {
				
				logger.info(" Start Test-TicketLinks_TC5 : Start the TicketLinks_TC5 creation ");

				wlrFaultCareLevel = wlrFaultCareLevelList.get(count);
				
				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLoginD7(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(wlrFaultCareLevel.getSearchBy(),
								wlrFaultCareLevel.getSearchValue(), CLASS_NAME,
								method.getName());

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,
						method.getName());
								
				WebElement ticketNum1 = driver
						.findElement(By.xpath("//div[@id='ticketTree"
								+ wlrFaultCareLevel.getNum() + "OPEN']/img"));

				ticketNum1.click();

				UpdateTicketPageOperations updateTicketPageOperations = accountDetailsPageOperations
						.clickupdate(CLASS_NAME, method.getName());

				String windw = driver.getWindowHandle();

				CommonMethods.doPause(5);
					// use ClickUpdateLink1 method if u have SupplierTicket

				updateTicketPageOperations.clickNewUpdateLink(
							wlrFaultCareLevel.getInternalNotes(),
							wlrFaultCareLevel.getContactType(),
							wlrFaultCareLevel.getB2Links(),
							wlrFaultCareLevel.getB2BTree(),
							wlrFaultCareLevel.getB2BEmailUpdate(),
							wlrFaultCareLevel.getMessageText(),
							wlrFaultCareLevel.getEmailText(),
							wlrFaultCareLevel.getClearCode(),
							CLASS_NAME,method.getName());

				/*accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
							method.getName());*/
				accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,
						method.getName());
				
				WebElement ticketNum2 = driver.findElement(By
						.xpath("//div[@id='ticketTree" + wlrFaultCareLevel.getNum()
								+ "OPEN']/img"));
				ticketNum2.click();
				CommonMethods.doPause(5);

				ResolvePageOperation resolvePageOperation = accountDetailsPageOperations
						.clickResolve(CLASS_NAME, method.getName());

				String name1 = driver.getWindowHandle();

				CommonMethods.doPause(5);
				resolvePageOperation.clickTicketResolve(
						wlrFaultCareLevel.getInternalResolveNotes(),
						wlrFaultCareLevel.getContactType(),
						wlrFaultCareLevel.getB2Links(),
						wlrFaultCareLevel.getB2BTree(),
						wlrFaultCareLevel.getB2BEmailUpdate(),
						wlrFaultCareLevel.getMessageText(),
						wlrFaultCareLevel.getEmailText(),
						wlrFaultCareLevel.getClearCode(),
					    CLASS_NAME,method.getName());
				
				accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,
						method.getName());
				
				WebElement ticketNum3 = driver.findElement(By
						.xpath("//div[@id='ticketTree" + wlrFaultCareLevel.getNum()
								+ "OPEN']/img"));
				ticketNum3.click();
				CommonMethods.doPause(5);
				
				ChangePoolPageOperation changePoolPageOperation = accountDetailsPageOperations
						.clickChangePool(CLASS_NAME, method.getName());
				
				changePoolPageOperation.changePoolDetails(
						wlrFaultCareLevel.getTicketType(), 
						wlrFaultCareLevel.getSubType(), 
						wlrFaultCareLevel.getPool(),
						wlrFaultCareLevel.getContactType(),
						wlrFaultCareLevel.getComments(), 
						CLASS_NAME, method.getName());
				
				accountDetailsPageOperations = changePoolPageOperation
						.clickAllocateButton(CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,
						method.getName());
				WebElement ticketNum4 = driver.findElement(By
						.xpath("//div[@id='ticketTree" + wlrFaultCareLevel.getNum()
								+ "OPEN']/img"));
				ticketNum4.click();
				CommonMethods.doPause(5);
				
				PutOnHoldPageOperations putOnHoldPageOperations = accountDetailsPageOperations
						.clickPutOnHoldLink(CLASS_NAME, method.getName());
				putOnHoldPageOperations.selectActivateDate(CLASS_NAME, method.getName());
				
				putOnHoldPageOperations.putOnHoldDetails(
						wlrFaultCareLevel.getHoldReason(),
						wlrFaultCareLevel.getContactType(),
						wlrFaultCareLevel.getComments(),
						CLASS_NAME, method.getName());
				
				accountDetailsPageOperations = putOnHoldPageOperations.submitPutOnHold(
						CLASS_NAME, method.getName());
				
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do Fault PhoneLine Asset");
			CommonMethods.acceptAlert(driver);
		}
		count++;
     }
	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();
		logger.info(",OpenTicketCause_TC2,pass");
	}
}