package com.bt.wlms.CRQ200138;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.UpdateTicketPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class UpdateTicket_TC6 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "UpdateTicket_TC6";

	private String IN_FILE = "UpdateInitiateTicket.csv";
	List<WLRFaultCareLevel> wlrFaultCareLevelList = new ArrayList<WLRFaultCareLevel>();
	WLRFaultCareLevel wlrFaultCareLevel;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	WebElement ticketNum = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("UpdateTicket_TC6");

	/*
	 * @Rule public TestName name = new TestName();
	 */

	public UpdateTicket_TC6() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		wlrFaultCareLevelList = CSVOperation_New.readUpdateInitiateTicket(IN_FILE);
		if (wlrFaultCareLevelList != null && wlrFaultCareLevelList.size() > 0) {
			testCount = wlrFaultCareLevelList.size();
		}
	}

  /**
   * This method is used for In the "Tickets" TAB check whether "Initiate Ticket"
    button is should not  be present in the "CustomerDetailsPage"... 
   * @param method
   * @throws IOException
   */

	@Test
	public void testUpdateTicket_TC6(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());
		
		order = new Order();
			try {
				logger.info(" Start Test-UpdateTicket_TC6 : Start the UpdateTicket_TC6 creation ");

				wlrFaultCareLevel = wlrFaultCareLevelList.get(count);
				
				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLoginD7(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(wlrFaultCareLevel.getSearchBy(),
								wlrFaultCareLevel.getSearchValue(), CLASS_NAME,
								method.getName());

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,
						method.getName());
				
				while (count < testCount) {

				String parentWindow = driver.getWindowHandle();

				try {
					wlrFaultCareLevel = wlrFaultCareLevelList.get(count);

					WebElement ticketNum1 = driver
							.findElement(By.xpath("//div[@id='ticketTree"
									+ wlrFaultCareLevel.getNum() + "OPEN']/img"));

					ticketNum1.click();

					UpdateTicketPageOperations updateTicketPageOperations = accountDetailsPageOperations
							.clickupdate(CLASS_NAME, method.getName());

					String windw = driver.getWindowHandle();

					CommonMethods.doPause(5);
					// use ClickUpdateLink1 method if u have SupplierTicket

					updateTicketPageOperations.clickNewUpdateLink(
							wlrFaultCareLevel.getInternalNotes(),
							wlrFaultCareLevel.getContactType(),
							wlrFaultCareLevel.getB2Links(),
							wlrFaultCareLevel.getB2BTree(),
							wlrFaultCareLevel.getB2BEmailUpdate(),
							wlrFaultCareLevel.getMessageText(),
							wlrFaultCareLevel.getEmailText(), 
							wlrFaultCareLevel.getClearCode(),
							CLASS_NAME,method.getName());

					accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
							method.getName());

				} catch (org.openqa.selenium.NoSuchElementException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					driver.close();
					CommonMethods.acceptAlert(driver);

				}
				driver.switchTo().window(parentWindow);
				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
						method.getName());
				count++;	
				}
				
				accountDetailsPageOperations.clickInitiateTicket(CLASS_NAME, method.getName());
				
				String windw = driver.getWindowHandle();
				
				UpdateTicketPageOperations updateTicketPageOperations = accountDetailsPageOperations
						.initiateTicket(
						wlrFaultCareLevel.getTicketType(),wlrFaultCareLevel.getSubType(),
						wlrFaultCareLevel.getContactType(),wlrFaultCareLevel.getInternalNotes(),
						wlrFaultCareLevel.getB2Links(),wlrFaultCareLevel.getB2BTree(),
						wlrFaultCareLevel.getB2BEmailUpdate(),wlrFaultCareLevel.getMessageText(),
						wlrFaultCareLevel.getEmailText(),wlrFaultCareLevel.getClearCode(),
						CLASS_NAME, method.getName());
				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
						method.getName());
				
		}catch (Exception e) {
			e.printStackTrace();
			logger.info(" End Test - UpdateTicket_TC6 : End the UpdateTicket_TC6 creation");
			CommonMethods.acceptAlert(driver);
			}
	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();
		logger.info(",OpenTicketCause_TC2,pass");
	}
}
