package com.bt.wlms.CRQ200153;



import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.WLR3Details;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class LLU_Create_SMPF_For_Other_Cp_2 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "LLU_Create_SMPF_For_Other_Cp_2";
	private static InputStream inputStream;
	private static Properties testProps;

	private String IN_FILE = "WLR3Details.csv";
	List<WLR3Details> wlr3DetailsList = new ArrayList<WLR3Details>();
	WLR3Details wlr3Details;

	private int testCount = 0;
	private int count = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("LLU_Create_SMPF_For_Other_Cp_2");

	public LLU_Create_SMPF_For_Other_Cp_2() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);

		wlr3DetailsList = CSVOperation_New.readWLR3Details(IN_FILE);
		if (wlr3DetailsList != null && wlr3DetailsList.size() > 0) {
			testCount = wlr3DetailsList.size();
		}

		inputStream = new FileInputStream(
				"./src/test/resources/com/hqnRegression/login-wlr3.properties");
		testProps = new Properties();
		testProps.load(inputStream);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testWLR3Progression(Method method) throws Exception {
		while (count < testCount) {

			try {

				logger
						.info("LLU_Create_SMPF_For_Other_Cp_2 : Start the LLU_Create_SMPF_For_Other_Cp_2 progression ");

				wlr3Details = wlr3DetailsList.get(count);

				driver.get(testProps.getProperty("baseUrl")
						+ "/faces/jsp/CPLogin.jsp");
				driver.findElement(By.id("j_id_id2:loginusername")).clear();
				driver.findElement(By.id("j_id_id2:loginusername")).sendKeys(
						testProps.getProperty("username"));
				driver.findElement(By.id("j_id_id2:loginpassword")).clear();
				driver.findElement(By.id("j_id_id2:loginpassword")).sendKeys(
						testProps.getProperty("password"));

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"LoginPage" + ".png", driver, "Start");

				driver.findElement(By.id("j_id_id2:submit")).click();

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"CVFHomepage" + ".png", driver, "");

				

						logger
								.info(" LLU_Create_SMPF_For_Other_Cp_2 : PSTN Tie Cable id ::::::::");

						new Select(driver.findElement(By
								.id("cpportal:eventType")))
								.selectByVisibleText("Create an asset");
						new Select(driver.findElement(By.id("cpportal:event")))
								.selectByVisibleText("LLU - Create SMPF Asset for Other CP with LOR");

						logger
								.info("WLR3Automation : Fill the SMPF Asset details ");

						driver.findElement(
								By.id("itemstable:0:itemstabletextbox"))
								.clear();
						driver.findElement(
								By.id("itemstable:0:itemstabletextbox"))
								.sendKeys(wlr3Details.getAddressValue());
						driver.findElement(
								By.id("itemstable:1:itemstabletextbox"))
								.clear();
						driver.findElement(
								By.id("itemstable:1:itemstabletextbox"))
								.sendKeys(wlr3Details.getPostCode());
						driver.findElement(
								By.id("itemstable:3:itemstabletextbox"))
								.clear();
						driver.findElement(
								By.id("itemstable:3:itemstabletextbox"))
								.sendKeys(wlr3Details.getPstnTieCableId());
						driver.findElement(
								By.id("itemstable:4:itemstabletextbox"))
								.clear();
						driver.findElement(
								By.id("itemstable:4:itemstabletextbox"))
								.sendKeys("001");
						driver.findElement(
								By.id("itemstable:5:itemstabletextbox"))
								.clear();
						driver.findElement(
								By.id("itemstable:5:itemstabletextbox"))
								.sendKeys(wlr3Details.getMpfTieCableId());
						driver.findElement(
								By.id("itemstable:6:itemstabletextbox"))
								.clear();
						driver.findElement(
								By.id("itemstable:6:itemstabletextbox"))
								.sendKeys("001");
						new Select(driver.findElement(By
								.id("itemstable:7:itemstabledropdown")))
								.selectByVisibleText(wlr3Details.getCssDistrictCode() + wlr3Details.getExchangeCode());
						
						new Select(driver.findElement(By
								.id("itemstable:8:itemstabletextbox")))
								.selectByVisibleText(wlr3Details.getLinkedSMPFReference());
						
						driver.findElement(By.name("itemstable:j_idt51"))
								.click();
						CommonMethods.doPause(5);

						

					

				

			} catch (Exception e) {
				try {
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"lastPageOperations" + ".png", driver, "end");
				} catch (IOException ex) {
					ex.printStackTrace();
				}
				e.printStackTrace();
				logger.error("Unable to do the LLU_Create_SMPF_For_Other_Cp_2 progression");
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() throws Exception {
		driver.close();
		driver.quit();

	}

}
