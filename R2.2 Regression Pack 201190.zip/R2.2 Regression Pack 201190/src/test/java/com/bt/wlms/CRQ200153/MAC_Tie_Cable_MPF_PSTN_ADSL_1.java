package com.bt.wlms.CRQ200153;



import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.DN_creation_fttc;
import com.hqnRegression.beans.WLR3Details;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class MAC_Tie_Cable_MPF_PSTN_ADSL_1 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "FTTC_Over_PSTN_For_Other_Cp_With_LOR_3";
	private static InputStream inputStream;
	private static Properties testProps;

	private String IN_FILE = "WLR3Details.csv";
	List<DN_creation_fttc> DN_creation_fttclist = new ArrayList<DN_creation_fttc>();
	DN_creation_fttc dN_creation_fttc;

	private int testCount = 0;
	private int count = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("FTTC_Over_PSTN_For_Other_Cp_With_LOR_3");

	public MAC_Tie_Cable_MPF_PSTN_ADSL_1() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);

		DN_creation_fttclist = CSVOperation_New.readDN_creation_fttc(IN_FILE);
		if (DN_creation_fttclist != null && DN_creation_fttclist.size() > 0) {
			testCount = DN_creation_fttclist.size();
		}

		inputStream = new FileInputStream(
				"./src/test/resources/com/hqnRegression/login-wlr3.properties");
		testProps = new Properties();
		testProps.load(inputStream);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testWLR3Progression(Method method) throws Exception {
		while (count < testCount) {

			try {

				logger
						.info("WLR3Automation : Start the WLR3Automation progression ");

				dN_creation_fttc = DN_creation_fttclist.get(count);

				driver.get(testProps.getProperty("baseUrl")
						+ "/faces/jsp/CPLogin.jsp");
				driver.findElement(By.id("j_id_id2:loginusername")).clear();
				driver.findElement(By.id("j_id_id2:loginusername")).sendKeys(
						testProps.getProperty("username"));
				driver.findElement(By.id("j_id_id2:loginpassword")).clear();
				driver.findElement(By.id("j_id_id2:loginpassword")).sendKeys(
						testProps.getProperty("password"));

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"LoginPage" + ".png", driver, "Start");

				driver.findElement(By.id("j_id_id2:submit")).click();

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"CVFHomepage" + ".png", driver, "");

				new Select(driver.findElement(By.id("cpportal:submittingcp")))
						.selectByVisibleText(dN_creation_fttc.getSubmiitingCP());
				new Select(driver.findElement(By.id("cpportal:eventType")))
						.selectByVisibleText(dN_creation_fttc.getEventType());
				new Select(driver.findElement(By.id("cpportal:event")))
						.selectByVisibleText(dN_creation_fttc.getEvent());

				logger.info(" WLR3Automation : Fill MPF Tie Cable details ");
				
				
				new Select(driver.findElement(By
						.id("itemstable:0:itemstabledropdown")))
						.selectByVisibleText("Other CP");
				new Select(driver.findElement(By
						.id("itemstable:1:itemstabledropdown")))
						.selectByVisibleText("MPF Tie Cable");
				
				new Select(driver.findElement(By
						.id("itemstable:2:itemstabledropdown")))
						.selectByVisibleText(dN_creation_fttc.getMdfSiteId());
				new Select(driver.findElement(By
						.id("itemstable:3:itemstabledropdown")))
						.selectByVisibleText(dN_creation_fttc.getNetwork());
				
				driver.findElement(By.name("itemstable:j_idt51")).click();
				
				
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"CVFHomepageAfterDataEntry" + ".png", driver, "");
				
				driver.wait(100);
				
				new Select(driver.findElement(By.id("cpportal:submittingcp")))
				.selectByVisibleText(dN_creation_fttc.getSubmiitingCP());
		       new Select(driver.findElement(By.id("cpportal:eventType")))
				.selectByVisibleText(dN_creation_fttc.getEventType());
		      new Select(driver.findElement(By.id("cpportal:event")))
				.selectByVisibleText(dN_creation_fttc.getEvent());

		       logger.info(" WLR3Automation : Fill MPF Tie Cable details ");
		
		
		new Select(driver.findElement(By
				.id("itemstable:0:itemstabledropdown")))
				.selectByVisibleText("Other CP");
		new Select(driver.findElement(By
				.id("itemstable:1:itemstabledropdown")))
				.selectByVisibleText("PSTN Tie Cable");
		
		new Select(driver.findElement(By
				.id("itemstable:2:itemstabledropdown")))
				.selectByVisibleText(dN_creation_fttc.getMdfSiteId());
		new Select(driver.findElement(By
				.id("itemstable:3:itemstabledropdown")))
				.selectByVisibleText(dN_creation_fttc.getNetwork());
		
		driver.findElement(By.name("itemstable:j_idt51")).click();
		
		
		CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
				"CVFHomepageAfterDataEntry" + ".png", driver, "");
		
		driver.wait(100);

				
					}

				

			 catch (Exception e) {
				try {
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"lastPageOperations" + ".png", driver, "end");
				} catch (IOException ex) {
					ex.printStackTrace();
				}
				e.printStackTrace();
				logger.error("Unable to do the WLR3 progression");
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() throws Exception {
		driver.close();
		driver.quit();

	}

}
