

package com.bt.wlms.CRQ200170;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bt.wlms.pages.operations.AmendConfirmationPageOperartions;
import com.bt.wlms.pages.operations.AmendSummaryPageOperations;
import com.bt.wlms.pages.operations.EditOrderPageOperations;
import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AmendOrderPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class NGA_Amend extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "NGA_Amend_D7";
	private String IN_FILE = "AmendAsset_R20.csv";
	List<AssetBeanDetails> amendList = null;
	AssetBeanDetails amendDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("NGA_Amend_D7");

	public NGA_Amend() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		amendList = CSVOperation_New.AmendInFlightDetails(IN_FILE);

		if (amendList != null && amendList.size() > 0) {
			testCount = amendList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testAmendOrder(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		try {

			logger.info(" Start Test-Amend_Asset : Start the Amend_Asset creation ");
			amendDetails = amendList.get(count);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());
			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(amendDetails.getSearchValue(),
							amendDetails.getSearchBy(), CLASS_NAME,
							method.getName());
			String product = searchResultPageOperations
					.getProductForPendingOrder();
			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLinkForPendingOrder(CLASS_NAME,
							method.getName());

			AmendOrderPageOperations amendOrderPageOperations = accountDetailsPageOperations
					.clickAmendOrderLink(CLASS_NAME, method.getName());

			amendOrderPageOperations.selectReasonForAmending(
					amendDetails.getAmendReason(), CLASS_NAME, method.getName());

			/*EditOrderPageOperations editOrderPageOperations = amendOrderPageOperations
					.clickEditForCustomerRequiredDate_Amend(CLASS_NAME,
							method.getName());

			amendOrderPageOperations = editOrderPageOperations
					.selectFutureCalendarDate_Amend(CLASS_NAME,
							method.getName(), 0);*/

			CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;

			if (amendOrderPageOperations.isVoiceAppointmentButtonPresent()) {

				ReserveAppointmentPageOperations reserveAppointmentPageOperations = amendOrderPageOperations
						.clickRequestAvailableAppointmentButton(CLASS_NAME,
								method.getName());

				reserveAppointmentPageOperations
						.selectFirstAvailableAppointmentDate();

				amendOrderPageOperations = reserveAppointmentPageOperations
						.clickReserveAppointmentButton_Amend(CLASS_NAME,
								method.getName());
				EditOrderPageOperations	editOrderPageOperations = amendOrderPageOperations
						.clickEditforEngineeringNotes();
				amendOrderPageOperations = editOrderPageOperations
						.fillEngineeringNotes(CLASS_NAME, method.getName());

				editOrderPageOperations = amendOrderPageOperations
						.clickEditForHazardNotes(CLASS_NAME, method.getName());
				amendOrderPageOperations = editOrderPageOperations
						.fillHazardNotes(CLASS_NAME, method.getName());

			}

			if (amendOrderPageOperations.isFTTCAppointmentButtonPresent()) {

				FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = amendOrderPageOperations
						.clickFTTCAppointment(CLASS_NAME, method.getName());

				fttcAvailableAppointmentsPageOperations
						.selectFirstAvailableAppointmentDate();

				fttcAvailableAppointmentsPageOperations
						.clickReserveAppointmentButton_Amend(CLASS_NAME,
								method.getName());

				EditOrderPageOperations	 editOrderPageOperations = amendOrderPageOperations
						.clickEditForPassword_SpecialNotes_SiteVisitNotes(
								CLASS_NAME, method.getName());
				amendOrderPageOperations = editOrderPageOperations
						.fillPassword_SpecialNotes_SiteVisitNotes(CLASS_NAME,
								method.getName());

					editOrderPageOperations = amendOrderPageOperations
						.clickEditForHazardNotes(CLASS_NAME, method.getName());
				amendOrderPageOperations = editOrderPageOperations
						.fillHazardNotes(CLASS_NAME, method.getName());

			}

			AmendSummaryPageOperations amendSummaryPageOperations = amendOrderPageOperations
					.clickAmendOrderButton(CLASS_NAME, method.getName());

			AmendConfirmationPageOperartions amendConfirmationPageOperartions = amendSummaryPageOperations
					.clickSubmitButton(CLASS_NAME, method.getName());
			accountDetailsPageOperations = amendConfirmationPageOperartions
					.clickNextButton(CLASS_NAME, method.getName());
			
			accountDetailsPageOperations.clickticketsTab(CLASS_NAME, method.getName());

			accountDetailsPageOperations.verifyFoidRequest(CLASS_NAME, method.getName());
			
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			logger.info(" End Test-Amend_Asset : End the Amend_Asset creation ");

		} catch (Exception e) {

			e.printStackTrace();
			logger.error("Unable to Amend the orderid "
					+ amendDetails.getOrderId());
			 CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}

