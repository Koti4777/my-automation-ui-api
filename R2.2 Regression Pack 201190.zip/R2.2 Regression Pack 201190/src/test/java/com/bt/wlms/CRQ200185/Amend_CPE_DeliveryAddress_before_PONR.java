package com.bt.wlms.CRQ200185;



import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bt.wlms.pages.operations.AmendConfirmationPageOperartions;
import com.bt.wlms.pages.operations.AmendSummaryPageOperations;
import com.bt.wlms.pages.operations.EditOrderPageOperations;
import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AddDeliveryContactPageOperations;
import com.hqnRegression.pages.operations.AmendOrderPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Amend_CPE_DeliveryAddress_before_PONR extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Amend_CPE_DeliveryAddress_before_PONR";
	private String IN_FILE = "Amend_CPE_DeliveryAddress_before_PONR.csv";
	List<AssetBeanDetails> amendList = null;
	AssetBeanDetails amendDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Amend_CPE_DeliveryAddress_before_PONR");

	public Amend_CPE_DeliveryAddress_before_PONR() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		amendList = CSVOperation_New.AmendInFlightDetails(IN_FILE);

		if (amendList != null && amendList.size() > 0) {
			testCount = amendList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testAmend_CPE_DeliveryAddress_before_PONR(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		try {

			logger.info(" Start Test-Amend_CPE_DeliveryAddress_before_PONR : Start the Amend_CPE_DeliveryAddress_before_PONR creation ");
			amendDetails = amendList.get(count);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());
			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(amendDetails.getSearchValue(),
							amendDetails.getSearchBy(), CLASS_NAME,
							method.getName());
			searchResultPageOperations
					.getProductForPendingOrder();
			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLinkForPendingOrder(CLASS_NAME,
							method.getName());
			accountDetailsPageOperations.check_CPEDeliveryAddress(CLASS_NAME,
							method.getName());
			accountDetailsPageOperations.isChangeLinkPresent(CLASS_NAME,
					method.getName());
			
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			logger.info(" End Test-Amend_CPE_DeliveryAddress_before_PONR : End the Amend_CPE_DeliveryAddress_before_PONR creation ");

		} catch (Exception e) {

			e.printStackTrace();
			logger.error("Unable to Amend the orderid "
					+ amendDetails.getOrderId());
			 CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}

