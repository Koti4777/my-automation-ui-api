package com.bt.wlms.CRQ200185;

/**
 * 
 */






import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.TrackYourOrdersPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CPE_Address_Updated_SCP extends SeleniumImplementation {
	
	private String CLASS_NAME = "CPE_Address_Updated_SCP";

	List<AssetBeanDetails> assetDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int count = 0;
	public Order order = null;
	private int testCount = 0;
	private	String CPE_Address = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CPE_Address_Updated_SCP");

	public CPE_Address_Updated_SCP() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		order = new Order();

		if (assetDetailsList != null && assetDetailsList.size() > 0) {
			testCount = assetDetailsList.size();
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testCPE_Address_Updated_SCP(Method method) throws Exception {

		PropertyConfigurator.configure(loggerPath);
		logger.info(" Start Test-CPE_Address_Updated_SCP : Start the CPE_Address_Updated_SCP ");

		SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
				.navigateToB2B_SCP(driver, CLASS_NAME, method.getName());

		SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
				.Login_withMyUsername(CLASS_NAME, method.getName());

		TrackYourOrdersPageOperations trackYourOrdersPageOperations = selfCarePortalHomePageOperations
				.clickTrackYourOrdersLink(CLASS_NAME, method.getName());
		
		CPE_Address = driver.findElement(By.xpath("//dt[contains(.,'CPE delivery name and address')]/following-sibling::dd[2]")).getText();
		System.out.println(CPE_Address);
		Assert.assertTrue(CPE_Address.contains("49,Stonyhurst Road, BB2 1NQ, Blackburn"));
		
		
		logger.info(" End Test-CPE_Address_Updated_SCP : End the CPE_Address_Updated_SCP ");
		


	}

	@AfterMethod
	public void tearDown() throws Exception {
		
		  driver.close();
		  driver.quit();
		 
	}

}
