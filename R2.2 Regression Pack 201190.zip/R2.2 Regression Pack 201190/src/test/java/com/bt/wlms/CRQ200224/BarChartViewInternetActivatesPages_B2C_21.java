package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.BroadBandUsagePageOperations;
import com.hqnRegression.pages.operations.DataUsagePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class BarChartViewInternetActivatesPages_B2C_21 extends
		SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "BarChartViewInternetActivatesPages_B2C_21";

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("BarChartViewInternetActivatesPages_B2C_21");

	public BarChartViewInternetActivatesPages_B2C_21() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testBarChartViewInternetActivatesPages_B2C_21(Method method)
			throws IOException {

		try {

			PropertyConfigurator.configure(loggerPath);

			logger.info(" Start BarChartViewInternetActivatesPages_B2C_21 : Start the BarChartViewInternetActivatesPages_B2C_21");
			SelfCarePortalLoginOperations selfCarePortalLoginOperations = null;

			selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2C_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());
			CommonMethods.doPause(5);
			BroadBandUsagePageOperations broadBandUsagePageOperations = selfCarePortalHomePageOperations
					.clickYourDataUsageLink(CLASS_NAME, method.getName());

			DataUsagePageOperations dateUsagePageOperations = broadBandUsagePageOperations
					.clickViewYourBroadbandDataUsage(CLASS_NAME,
							method.getName());
			dateUsagePageOperations.clickForBarDiagram(CLASS_NAME,
					method.getName());

			CommonMethods.doPause(5);

			CommonMethods.clickSCPLogoutButton(driver);

			logger.info("End BarChartViewInternetActivatesPages_B2C_21 : End the BarChartViewInternetActivatesPages_B2C_21");

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
