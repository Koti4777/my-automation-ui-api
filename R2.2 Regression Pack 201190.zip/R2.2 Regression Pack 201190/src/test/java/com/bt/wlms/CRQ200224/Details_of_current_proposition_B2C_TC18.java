package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.ChangeYourPlanPageOperations;
import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Details_of_current_proposition_B2C_TC18 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Details_of_current_proposition_B2C_TC18";
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Details_of_current_proposition_B2C_TC18");

	public Details_of_current_proposition_B2C_TC18() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testDetails_of_current_proposition_B2C_TC18(Method method) throws IOException {
		

		try {


			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-Details_of_current_proposition_B2C_TC18 : Start the Details_of_current_proposition_B2C_TC18");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2B_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());

			selfCarePortalHomePageOperations
					.clickChangeYourPlan(CLASS_NAME, method.getName());
			CommonMethods.clickSCPLogoutButton(driver);
			

			logger.info("End Test-Details_of_current_proposition_B2C_TC18 : End the Details_of_current_proposition_B2C_TC18");
			


		
			
		} catch (Exception e) {

			e.printStackTrace();
			
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}

	}

	@AfterMethod
	public void tearDown() {

		//driver.quit();
		//driver.close();

	}

}
