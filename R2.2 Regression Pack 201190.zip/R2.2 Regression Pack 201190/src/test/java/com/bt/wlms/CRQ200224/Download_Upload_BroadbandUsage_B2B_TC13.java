package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.BroadBandUsagePageOperations;
import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.ViewBillingDetailsPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Download_Upload_BroadbandUsage_B2B_TC13 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Download_Upload_BroadbandUsage_B2B_TC13";
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Download_Upload_BroadbandUsage_B2B_TC13");

	public Download_Upload_BroadbandUsage_B2B_TC13() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testDownload_Upload_BroadbandUsage_B2B_TC13(Method method) throws IOException {
		

		try {


			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-Download_Upload_BroadbandUsage_B2B_TC13 : Start the Download_Upload_BroadbandUsage_B2B_TC13");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2B_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());

			 BroadBandUsagePageOperations broadBandUsagePageOperations = selfCarePortalHomePageOperations
					.clickYourDataUsageLink(CLASS_NAME, method.getName());

			 broadBandUsagePageOperations.verifyDownload_Upload_UsageFields(CLASS_NAME, method.getName());
			
			logger.info("End Test-Download_Upload_BroadbandUsage_B2B_TC13 : End the Download_Upload_BroadbandUsage_B2B_TC13");
			


		
			
		} catch (Exception e) {

			e.printStackTrace();
			
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
