package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.ViewBillingDetailsPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09";
	private String IN_FILE = "Payment_Details.csv";
	List<AssetBeanDetails> assetDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int count = 0;
	public Order order = null;
	private int testCount = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09");

	public ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		assetDetailsList = CSVOperation_New.readDetailsForPayment(IN_FILE);
		order = new Order();

		if (assetDetailsList != null && assetDetailsList.size() > 0) {
			testCount = assetDetailsList.size();
		}
	}

	@Test
	public void testErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09(Method method) throws IOException {
		
		while (count < testCount) {

			order = new Order();


		try {


			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-Verify_ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09 : Start the Verify_ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2C_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());

			ViewBillingDetailsPageOperations viewBillingDetailsPageOperations = selfCarePortalHomePageOperations
					.clickBillingDetailsLink(CLASS_NAME, method.getName());

			EditPaymentDetailsPageOperations editPaymentDetailsPageOperations = viewBillingDetailsPageOperations
					.clickEditForChangingPaymentMode(CLASS_NAME,
							method.getName());
			CommonMethods.doPause(15);
			editPaymentDetailsPageOperations.clickCreditCardInMonthlyInstallments(CLASS_NAME, method.getName());
			CommonMethods.doPause(15);
		
			editPaymentDetailsPageOperations.enterTheNewDirectDebitDetails2(CLASS_NAME, method.getName(),assetBeanDetails.getDebitCardNumber());
			CommonMethods.doPause(15);
			editPaymentDetailsPageOperations.select_Payment_Method_Amex(CLASS_NAME,
					method.getName());
			
			editPaymentDetailsPageOperations.enterTheNewDirectDebitDetails2(CLASS_NAME,
					method.getName(),assetBeanDetails.getDebitCardNumber());
			logger.info("End Test-Verify_ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09: End the Verify_ErrorMessage_CardNumber_EditPaymentdetailsScreen_B2C_TC09");
			


		
			
		} catch (Exception e) {

			e.printStackTrace();
			
			
		}
		
		count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
