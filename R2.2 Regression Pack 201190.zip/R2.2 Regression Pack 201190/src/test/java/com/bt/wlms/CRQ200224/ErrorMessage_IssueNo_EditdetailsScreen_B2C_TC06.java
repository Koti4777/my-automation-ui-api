package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.ViewBillingDetailsPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06";
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06");

	public ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06(Method method) throws IOException {
		

		try {

			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06 : Start the ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06 ");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2C_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());

			ViewBillingDetailsPageOperations viewBillingDetailsPageOperations = selfCarePortalHomePageOperations
					.clickBillingDetailsLink(CLASS_NAME, method.getName());

			EditPaymentDetailsPageOperations editPaymentDetailsPageOperations = viewBillingDetailsPageOperations
					.clickEditButtonChangingPaymentMode(CLASS_NAME,
							method.getName());

			editPaymentDetailsPageOperations.clickDebitCard_Recurring(
					CLASS_NAME, method.getName());

			CommonMethods.doPause(20);

			logger.info("End ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06 : End the ErrorMessage_IssueNo_EditdetailsScreen_B2C_TC06");

		} catch (Exception e) {

			e.printStackTrace();
			
			
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
