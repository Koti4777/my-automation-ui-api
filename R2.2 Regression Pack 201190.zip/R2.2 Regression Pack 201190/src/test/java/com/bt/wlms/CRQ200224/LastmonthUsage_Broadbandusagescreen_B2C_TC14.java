package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.BroadBandUsagePageOperations;
import com.hqnRegression.pages.operations.Last31DaysUsagePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class LastmonthUsage_Broadbandusagescreen_B2C_TC14 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "LastmonthUsage_Broadbandusagescreen_B2C_TC14";
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("LastmonthUsage_Broadbandusagescreen_B2C_TC14");

	public LastmonthUsage_Broadbandusagescreen_B2C_TC14() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testLastmonthUsage_Broadbandusagescreen_B2C_TC14(Method method) throws IOException {
		

		try {

			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-LastmonthUsage_Broadbandusagescreen_B2C_TC14 : Start the LastmonthUsage_Broadbandusagescreen_B2C_TC14");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateTob2cscp(driver);

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());

			BroadBandUsagePageOperations broadBandUsagePageOperations = selfCarePortalHomePageOperations
					.clickYourDataUsageLink(CLASS_NAME, method.getName());

			CommonMethods.doPause(10);
			
			broadBandUsagePageOperations.clickLastMonthUsageLink(CLASS_NAME,
					method.getName());
			
			CommonMethods.doPause(10);

			CommonMethods.clickSCPLogoutButton(driver);

			logger.info("End Test-LastmonthUsage_Broadbandusagescreen_B2C_TC14 : End the LastmonthUsage_Broadbandusagescreen_B2C_TC14");

		} catch (Exception e) {

			e.printStackTrace();
			
			
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
