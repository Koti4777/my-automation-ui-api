package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.ViewBillingDetailsPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08";
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08");

	public OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testOtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08(Method method) throws IOException {
		

		try {


			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-Verify_OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08 : Start the Verify_OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2B_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());

			ViewBillingDetailsPageOperations viewBillingDetailsPageOperations = selfCarePortalHomePageOperations
					.clickBillingDetailsLink(CLASS_NAME, method.getName());

			EditPaymentDetailsPageOperations editPaymentDetailsPageOperations = viewBillingDetailsPageOperations
					.clickEditForChangingPaymentMode(CLASS_NAME,
							method.getName());
			CommonMethods.doPause(15);
			editPaymentDetailsPageOperations.editPaymentMethod(CLASS_NAME, method.getName());
			CommonMethods.doPause(15);
	
			editPaymentDetailsPageOperations.enterTheNewDirectDebitDetails1(CLASS_NAME, method.getName());
			CommonMethods.doPause(15);
		
			logger.info("End Test-Verify_OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08 : End the Verify_OtherPAymentCard_CardNumber_EditPaymentScreen_B2B_TC08");
			


		
			
		} catch (Exception e) {

			e.printStackTrace();
			
			
		}

	}

	@AfterMethod
	public void tearDown() {

		//driver.quit();
		//driver.close();

	}

}
