package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.BroadBandUsagePageOperations;
import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.ViewBillingDetailsPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Preload_Mouse_OverImages_SCPhomePage_B2B_TC17 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Preload_Mouse_OverImages_SCPhomePage_B2B_TC17";
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Preload_Mouse_OverImages_SCPhomePage_B2B_TC17");

	public Preload_Mouse_OverImages_SCPhomePage_B2B_TC17() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testPreload_Mouse_OverImages_SCPhomePage_B2B_TC17(Method method) throws IOException {
		

		try {


			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-Preload_Mouse_OverImages_SCPhomePage_B2B_TC17 : Start the Preload_Mouse_OverImages_SCPhomePage_B2B_TC17");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2B_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());
		
			CommonMethods.clickSCPLogoutButton(driver);
			logger.info("End Test-Preload_Mouse_OverImages_SCPhomePage_B2B_TC17: End the Preload_Mouse_OverImages_SCPhomePage_B2B_TC17");
	
		} catch (Exception e) {

			e.printStackTrace();

		}
	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
