package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.ViewBillingDetailsPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Verify_Details_For_DebitPaymentMethod_B2C_TC2 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Verify_Details_For_DebitPaymentMethod_B2C_TC2";

	private String IN_FILE = "Payment_Details.csv";
	List<AssetBeanDetails> assetDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int count = 0;
	public Order order = null;
	private int testCount = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Verify_Details_For_DebitPaymentMethod_B2C_TC2");
	
	public Verify_Details_For_DebitPaymentMethod_B2C_TC2() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		assetDetailsList = CSVOperation_New.readDetailsForPayment(IN_FILE);
		order = new Order();

		if (assetDetailsList != null && assetDetailsList.size() > 0) {
			testCount = assetDetailsList.size();
		}

	}

	@Test
	public void testVerify_Details_For_DebitPaymentMethod_B2C_TC2(Method method) throws IOException {
		
		while (count < testCount) {

			order = new Order();

		try {


			PropertyConfigurator.configure(loggerPath);
			assetBeanDetails = assetDetailsList.get(count);
			logger.info(" Start Test-Verify_Details_For_DebitPaymentMethod_B2C_TC2 : Start the Verify_Details_For_DebitPaymentMethod_B2C_TC2");
			SelfCarePortalLoginOperations selfCarePortalLoginOperations =null;
			
				selfCarePortalLoginOperations = SelfCarePortalLoginOperations
						.navigateToB2C_SCP(driver, CLASS_NAME, method.getName());
				
			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());
			CommonMethods.doPause(5);
			ViewBillingDetailsPageOperations viewBillingDetailsPageOperations = selfCarePortalHomePageOperations
					.clickBillingDetailsLink(CLASS_NAME, method.getName());
			CommonMethods.doPause(5);
			EditPaymentDetailsPageOperations editPaymentDetailsPageOperations = viewBillingDetailsPageOperations
					.clickEditButtonChangingPaymentMode(CLASS_NAME,
							method.getName());
			CommonMethods.doPause(5);
			editPaymentDetailsPageOperations.editPaymentMethod(CLASS_NAME, method.getName());
			CommonMethods.doPause(5);
			editPaymentDetailsPageOperations.enterTheNewDirectDebitDetails(CLASS_NAME, method.getName(),assetBeanDetails.getBankAccountHolderName(),
					assetBeanDetails.getDebitCardNumber());
			CommonMethods.doPause(5);
			
			CommonMethods.clickSCPLogoutButton(driver);

			logger.info("End Test-Verify_Details_For_DebitPaymentMethod_B2C_TC2 : End the Verify_Details_For_DebitPaymentMethod_B2C_TC2");
			
			

		
			
		} catch (Exception e) {

			e.printStackTrace();
			
			
		}
		count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
