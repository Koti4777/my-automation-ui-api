package com.bt.wlms.CRQ200224;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.EditPaymentDetailsPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.ViewBillingDetailsPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Verify_ValidationMessage_for_CardNumber_Amex_TC7 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Verify_ValidationMessage_for_CardNumber_Amex_TC7";
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Verify_ValidationMessage_for_CardNumber_Amex_TC7");

	public Verify_ValidationMessage_for_CardNumber_Amex_TC7() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testVerify_ValidationMessage_for_CardNumber_Amex_TC7(Method method) throws IOException {
		

		try {


			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-Verify_ValidationMessage_for_CardNumber_Amex_TC7 : Start the Verify_ValidationMessage_for_CardNumber_Amex_TC7 ");

			SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
					.navigateToB2B_SCP(driver, CLASS_NAME, method.getName());

			SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
					.Login_withMyUsername(CLASS_NAME, method.getName());

			ViewBillingDetailsPageOperations viewBillingDetailsPageOperations = selfCarePortalHomePageOperations
					.clickBillingDetailsLink(CLASS_NAME, method.getName());

			EditPaymentDetailsPageOperations editPaymentDetailsPageOperations = viewBillingDetailsPageOperations
					.clickEditForChangingPaymentMode(CLASS_NAME,
							method.getName());
			String st = driver.getWindowHandle();
			System.out.println(st);
			CommonMethods.doPause(7);
			editPaymentDetailsPageOperations.select_Payment_Method_Amex(CLASS_NAME, method.getName());
			CommonMethods.doPause(7);
			driver.switchTo().frame("payframe");
			editPaymentDetailsPageOperations.fillAmexCardNumber(CLASS_NAME, method.getName());
			
			logger.info("End Test-Verify_ValidationMessage_for_CardNumber_Amex_TC7 : End the Verify_ValidationMessage_for_CardNumber_Amex_TC7");
			


		
			
		} catch (Exception e) {

			e.printStackTrace();
			
			
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.quit();
		driver.close();

	}

}
