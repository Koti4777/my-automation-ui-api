package com.bt.wlms.CancelInFlight;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bt.wlms.pages.operations.CancelOrderPageOperations;
import com.hqnRegression.beans.Bbband;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AmendOrderPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Create_ISDN_DASS_Cancel extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Create_ISDN_DASS_Cancel";
	private String IN_FILE = "ISDNCancel.csv";
	List<Bbband> BbandList = new ArrayList<Bbband>();
	Bbband band;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Create_ISDN_DASS_Cancel");

	public Create_ISDN_DASS_Cancel() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		BbandList = CSVOperation_New.readBroadbandfaultcheck(IN_FILE);
		if (BbandList != null && BbandList.size() > 0) {
			testCount = BbandList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testCancelInFlightOrder(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		try {

			logger.info(" Start Test-Create_ISDN_DASS_Cancel : Start the Create_ISDN_DASS_Cancel creation ");
			band = BbandList.get(count);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());
			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(band.getSearchValue(), band.getSearchBy(),
							CLASS_NAME, method.getName());

			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLinkForPendingOrder(CLASS_NAME,
							method.getName());

			AmendOrderPageOperations amendOrderPageOperations = accountDetailsPageOperations
					.clickAmendOrderLink(CLASS_NAME, method.getName());

			CancelOrderPageOperations cancelOrderPageOperations = amendOrderPageOperations
					.clickCancelOrder(CLASS_NAME, method.getName());

			cancelOrderPageOperations.selectReasonForCancelling("Price",
					CLASS_NAME, method.getName());

			accountDetailsPageOperations = cancelOrderPageOperations
					.clickOkButton(CLASS_NAME, method.getName());

			accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,
					method.getName());
			accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
					method.getName());

			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			logger.info(" End  Test-Create_ISDN_DASS_Cancel :end the Create_ISDN_DASS_Cancel creation ");

		} catch (Exception e) {

			e.printStackTrace();
			logger.error("Unable to CanceInFlight the orderid "
					+ band.getSearchValue());
			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}

	}

	@AfterMethod
	public void tearDown() {

		// driver.quit();
		// driver.close();

	}

}
