package com.bt.wlms.Cease;

import java.io.IOException;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.lang.reflect.Method;

import com.hqnRegression.beans.CeaseDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CeasePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;


public class ISDN_Cease extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "Cease_Asset";

	private String IN_FILE = "CeaseDetails_Foid.csv";
	List<CeaseDetails> bbDetailsList = null;
	CeaseDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	private int orderid = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Cease_Asset");

	/*
	 * @Rule public TestName name = new TestName();
	 */

	public ISDN_Cease() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readCeaseDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		// logger.info(",Description,status");

	}

	@Test
	public void testCeaseOrder(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				logger.info(" Start Test-Cease_Asset : Start the Cease-Asset creation ");

				assetBeanDetails = bbDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(assetBeanDetails.getServiceID(), "Service ID",
								CLASS_NAME, method.getName());
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink();

				AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
						.clickCease(CLASS_NAME, method.getName());
				agentDetailsPageOperations.clickSameAgent();

				CeasePageOperations ceasePageOperations = agentDetailsPageOperations
						.clickNextForCease(CLASS_NAME, method.getName());
				ceasePageOperations.selectActivateDate();

				ceasePageOperations.ceasonReason(assetBeanDetails
						.getCeaseReason());

				OrderSummaryPageOperations orderSummaryPageOperations = ceasePageOperations
						.clickSubmit(CLASS_NAME, method.getName());
				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

				//orderSummaryPageOperations.confirmOrder(CLASS_NAME,method.getName());

				OrderConfirmationPageOperations conform = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());

				conform.clickComplete_Cease(CLASS_NAME, method.getName());
				accountDetailsPageOperations.clickticketsTab(CLASS_NAME,
						method.getName());

				accountDetailsPageOperations.verifyFoidRequest(CLASS_NAME,
						method.getName());
				
				
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.info(" End Test - Cease_Aseet : End the Cease-Asset creation");

			} catch (Exception e) {
				e.printStackTrace();
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.error("Unable to cease the orderid "
						+ assetBeanDetails.getOrderId());

			}
			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();
		logger.info(",Cease_Asset,pass");
	}

}
