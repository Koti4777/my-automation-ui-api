package com.bt.wlms.DWH.CRQ156864;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.SuspendServiceDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalAccountSummaryPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.pages.operations.SuspendServicePageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class Suspend_PLine_Service extends SeleniumImplementation {
	
	private WebDriver driver;
	public String CLASS_NAME = "Suspend_PLine_Service";

	private String IN_FILE = "Suspend_BB_Service.csv";
	List<SuspendServiceDetails> ssDetailsList = null;
	SuspendServiceDetails suspendServiceBeanDetails = null;
	
	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Suspend_BB_Service");
	
	
	public Suspend_PLine_Service()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	
	
	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		ssDetailsList = CSVOperation_New.readSuspendServiceDetails(IN_FILE);

		if (ssDetailsList != null && ssDetailsList.size() > 0) {
			testCount = ssDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	@Test
	public void testSuspend_PLine_Service(Method method) throws IOException {

      System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();
			

			try {
				
				logger.info(" Start Test-Suspend_PLine_Service : Start the Suspend_PLine_Service creation ");

				suspendServiceBeanDetails = ssDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());
				
				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.searchSuspand(suspendServiceBeanDetails.getOrderId(), "Order Number",suspendServiceBeanDetails.getCustomerType(),
								CLASS_NAME, method.getName());
				
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
								
				accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME, method.getName());
				
				SuspendServicePageOperations suspandServicePage = accountDetailsPageOperations.
						clickSuspendVoice(CLASS_NAME, method.getName());
				
				 suspandServicePage.clickReason (suspendServiceBeanDetails.getReason(),CLASS_NAME, method.getName());
				 
				 OrderConfirmationPageOperations orderConfirmationPage  = suspandServicePage
						 .clickSubmit (CLASS_NAME, method.getName());
					orderConfirmationPage.clickComplete_SS(CLASS_NAME, method.getName());
					
					 CommonMethods.logOut(driver, CLASS_NAME, method.getName());
					 
						  		
				}
				catch (Exception e) {
					e.printStackTrace();
						}  
			
			try {

                logger.info(" Start : SelfCarePortalOperations");

                driver = createBrowserInstance(BrowserType.FIREFOX);
                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

                SelfCarePortalLoginOperations selfCarePortalLoginOperations = null;

                if(suspendServiceBeanDetails.getCustomerType().equalsIgnoreCase("B2B")){
                       System.out.println(suspendServiceBeanDetails.getOrderId() +"b2b");
                       selfCarePortalLoginOperations = SelfCarePortalLoginOperations
                                     .navigateTob2bscp(driver);
                       }else{
                              System.out.println(suspendServiceBeanDetails.getOrderId() + "b2c");
                              selfCarePortalLoginOperations = SelfCarePortalLoginOperations
                                            .navigateTob2cscp(driver);
                              
                       }
                
                SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
                              .selfcareLogin(CLASS_NAME, method.getName());

                SelfCarePortalAccountSummaryPageOperations selfCarePortalAccountSummaryPageOperations = selfCarePortalHomePageOperations
                              .clickAccountSummaryLink(CLASS_NAME, method.getName());
                selfCarePortalAccountSummaryPageOperations.viewYourPlanDetails(
                              CLASS_NAME, method.getName());

                selfCarePortalAccountSummaryPageOperations.click_SCP_Logout(
                              CLASS_NAME, method.getName());
                CommonMethods.b2bselfCareLogOut(driver, CLASS_NAME,
                              method.getName());

                 logger.info(" Start : SelfCarePortalOperations");

          }
                catch(Exception e){
                       e.printStackTrace();
                       
                       logger.error("Unable to  do SelfCarePortalOperations");
                       
                };

				
				logger.error("Unable to click the requestControl link" + suspendServiceBeanDetails.getOrderId());
				count++;
			}

		}
		@AfterMethod
		public void tearDown() {
			//driver.close();
			//driver.quit();

		}

		}
			
					


