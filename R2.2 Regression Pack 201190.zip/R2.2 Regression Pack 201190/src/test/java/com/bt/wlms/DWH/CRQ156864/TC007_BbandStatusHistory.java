package com.bt.wlms.DWH.CRQ156864;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.BBandStatusHistoryDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.BBandServiceStatusHistoryOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class TC007_BbandStatusHistory extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "TC007_BbandStatusHistory";

	private String IN_FILE = "BbandStatusHistory.csv";
	List<BBandStatusHistoryDetails> bBandStatusHistorys = new ArrayList<BBandStatusHistoryDetails>();
	BBandStatusHistoryDetails bBandStatusHistory;

	private int testCount = 0;
	private int count = 0;
	

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("TC007_BbandStatusHistory");

	public TC007_BbandStatusHistory() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		bBandStatusHistorys = CSVOperation_New
				.readBBandStatusHistoryDetails(IN_FILE);
		if (bBandStatusHistorys != null && bBandStatusHistorys.size() > 0) {
			testCount = bBandStatusHistorys.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * This method displays the Suspended, ceased orders history
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testViewBbandServiceSHistory(Method method) throws IOException {
		logger.info(":	start the testViewBbandService Status History");

		while (count < testCount) {

			try {

				logger.info(" : Start the View BbandService Status History ");

				bBandStatusHistory = bBandStatusHistorys.get(count);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());
				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.searchBoxFunctioning(bBandStatusHistory.getOrderId(),
								"Order Number", bBandStatusHistory.getCustomerType(),CLASS_NAME, method.getName());
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				accountDetailsPageOperations.clickBroadbandTab1(CLASS_NAME,
						method.getName());

				BBandServiceStatusHistoryOperations history = accountDetailsPageOperations
						.clickServiceStatusHistory(CLASS_NAME, method.getName());
				String name = driver.getWindowHandle();
				CommonMethods.doPause(5);

				accountDetailsPageOperations = history.viewCeasedStatus(
						bBandStatusHistory.getSuspendedStatus(),
						bBandStatusHistory.getCeasedStatus(), CLASS_NAME,
						method.getName());
				logger.info(" : end the View BbandService Status History ");
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			}

			catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to view Service history");
				logger.info(":	end the testViewBband Status erviceSHistory");

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();

	}
}
