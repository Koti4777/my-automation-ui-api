package com.bt.wlms.DWH.CRQ156864;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.ConfirmDNPageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegradeOrderPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalAccountSummaryPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class TC028_BBSuspendedservice_ApplyDunning extends SeleniumImplementation

{
	
	private WebDriver driver;
	public String CLASS_NAME = "CRQ156864_TC028";

	private String IN_FILE = "CRQ156864_TC028.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ156864_TC028");
	

	public TC028_BBSuspendedservice_ApplyDunning()
	{
		PropertyConfigurator.configure(loggerPath);
	}

	
	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readApplyDunning(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	
	/**
	 * operations on billing tab in customer details page
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void CRQ156864_TC028(Method method) throws IOException {

      
		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start TC028_BBSuspendedservice_ApplyDunning : Start the TC028_BBSuspendedservice_ApplyDunning ");

				assetBeanDetails = bbDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		//Assert.assertTrue(false);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(assetBeanDetails.getOrderId(), "Order Number",
						CLASS_NAME, method.getName());
		String product = searchResultPageOperations.getProductForActiveOrder();
		
		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
				.clickProductLink();
		
		
		AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
					.clickApplyDunningRestrictions(CLASS_NAME, method.getName());
		
		agentDetailsPageOperations.clickSameAgent();
		
		ProductDetailsPageOperations productDetailsPageOperations = agentDetailsPageOperations
					.clickNextForDunningRestrictions(CLASS_NAME, method.getName());
		
		productDetailsPageOperations.selectProductOffering_VoiceTab(CLASS_NAME, method.getName());
		
		
		CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null  ;
		HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;
		

		
		//appointmentManagementPageOperations = productDetailsPageOperations.clickNextForCRD(CLASS_NAME, method.getName());
		
		
		if (productDetailsPageOperations.isHardwarepageAvailable) {

			hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
					.clickNextForHardware(CLASS_NAME,
							method.getName());

			appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
					.clickNext(CLASS_NAME, method.getName());
		} else {

			appointmentManagementPageOperations = productDetailsPageOperations
					.clickNextForCRD(CLASS_NAME, method.getName());
		}

		appointmentManagementPageOperations.selectFutureCalendarDate(
				CLASS_NAME, method.getName(), 7);

		boolean isPresent = appointmentManagementPageOperations
				.isVoiceAppointmentButtonPresent();

		if (isPresent) {
			appointmentManagementPageOperations
					.fillVoiceAppointmentManagementFields(assetBeanDetails
							.getEngineeringNotes());
			if (assetBeanDetails.getIncludeOutofHours()
					.equalsIgnoreCase("yes")) {
				appointmentManagementPageOperations
						.clickOutOfHoursAppointment();
			}

			ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
					.clickAvailableAppointmentButton();

			reserveAppointmentPageOperations
					.selectFirstAvailableAppointmentDate();

			if (assetBeanDetails.getIncludeOutofHours()
					.equalsIgnoreCase("yes")) {
				if (assetBeanDetails.getAppointmentCharges().contains(
						"Accept additional")) {
					reserveAppointmentPageOperations
							.clickAcceptAdditionalCharges();
				}
				if (assetBeanDetails.getAppointmentCharges().contains(
						"both")) {
					reserveAppointmentPageOperations
							.clickAcceptAdditionalCharges();
					reserveAppointmentPageOperations
							.getWaiveAdditionalCharges();
				} else {
					reserveAppointmentPageOperations
							.getWaiveAdditionalCharges();
				}
			}

			appointmentManagementPageOperations = reserveAppointmentPageOperations
					.clickReserveAppointmentButton(CLASS_NAME,
							method.getName());
		}

		isPresent = appointmentManagementPageOperations
				.isFTTCAppointmentButtonPresent();

		if (isPresent) {

			FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
					.fillBBFTTCAppointmentManagement(CLASS_NAME,
							method.getName());
			fttcAvailableAppointmentsPageOperations
					.selectFirstAvailableAppointmentDate();
			appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
					.clickReserveAppointmentButton(CLASS_NAME,
							method.getName());
		}

		

			appointmentManagementPageOperations
					.fillHealthAndsafetyVeificationFields(assetBeanDetails.getHazardNotes()
							);
		

		OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
				.clickNext(CLASS_NAME, method.getName());

		orderSummaryPageOperations.selectCommunication(assetBeanDetails
				.getCommunicationBy());
		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

		OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
				.confirmOrder(CLASS_NAME, method.getName());

		orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME, method.getName());

		
	   
		
        accountDetailsPageOperations.clickBBTab(CLASS_NAME,method.getName());
        
        
        accountDetailsPageOperations.verifyingServicePlanStatus(CLASS_NAME, method.getName());

        accountDetailsPageOperations.verifyingBroadBandServiceStatus(CLASS_NAME, method.getName());



       // accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME,method.getName());

		
	
		CommonMethods.logOut(driver, CLASS_NAME, method.getName());

//			String orderId = orderConfirmationPageOperations.getOrderId();

//			order.setLineSiteId(assetBeanDetails.getNewSite());

//			order.setOrdeId(orderId);

	
		logger.info(" End TC028_BBSuspendedservice_ApplyDunning : End the TC028_BBSuspendedservice_ApplyDunning ");

	} 
	
	
	catch (Exception e) {
		e.printStackTrace();
		//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
	}   logger.error("Unable to ApplyDunningthe orderid " + assetBeanDetails.getOrderId());
	count++;
}
		
		
		
		
		
		try {

            logger.info(" Start : SelfCarePortalOperations");

            driver = createBrowserInstance(BrowserType.FIREFOX);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

            SelfCarePortalLoginOperations selfCarePortalLoginOperations = null;

            if(assetBeanDetails.getCustomerType().equalsIgnoreCase("B2B")){
                   System.out.println(assetBeanDetails.getOrderType() +"b2b");
                   selfCarePortalLoginOperations = SelfCarePortalLoginOperations
                                 .navigateTob2bscp(driver);
                   }else{
                          System.out.println(assetBeanDetails.getOrderType() + "b2c");
                          selfCarePortalLoginOperations = SelfCarePortalLoginOperations
                                        .navigateTob2cscp(driver);
                          
                   }
            
            SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
                          .selfcareLogin(CLASS_NAME, method.getName());

            SelfCarePortalAccountSummaryPageOperations selfCarePortalAccountSummaryPageOperations = selfCarePortalHomePageOperations
                          .clickAccountSummaryLink(CLASS_NAME, method.getName());
            selfCarePortalAccountSummaryPageOperations.viewYourPlanDetails(
                          CLASS_NAME, method.getName());

            selfCarePortalAccountSummaryPageOperations.click_SCP_Logout(
                          CLASS_NAME, method.getName());
            CommonMethods.b2bselfCareLogOut(driver, CLASS_NAME,
                          method.getName());

             logger.info(" Start : SelfCarePortalOperations");

      }
            catch(Exception e){
                   e.printStackTrace();
                   
                   logger.error("Unable to  do SelfCarePortalOperations");
                   
            };

}

@AfterMethod
public void tearDown() {
//driver.close();
//driver.quit();

}

}























			
	
	
