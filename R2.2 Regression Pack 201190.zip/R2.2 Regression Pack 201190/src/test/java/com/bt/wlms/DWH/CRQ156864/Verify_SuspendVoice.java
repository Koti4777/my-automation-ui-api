package com.bt.wlms.DWH.CRQ156864;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.SuspendServiceDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class Verify_SuspendVoice extends SeleniumImplementation{
	
	private WebDriver driver;
	public String CLASS_NAME = "Verify_SuspendVoice";

	private String IN_FILE = "Suspend_BB_Service.csv";
	List<SuspendServiceDetails> ssDetailsList = null;
	SuspendServiceDetails suspendServiceBeanDetails = null;
	
	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Verify_SuspendVoice");
	
	
	public Verify_SuspendVoice()
	{
		PropertyConfigurator.configure(loggerPath);
	}

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		ssDetailsList = CSVOperation_New.readSuspendServiceDetails(IN_FILE);

		if (ssDetailsList != null && ssDetailsList.size() > 0) {
			testCount = ssDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	@Test
	public void testCRQ156864_TC011(Method method) throws IOException {

      System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();
			

			try {
				
				logger.info(" Start testCRQ156864_TC011 : Start the Verifing SuspandService Button ");

				suspendServiceBeanDetails = ssDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.searchSuspand(suspendServiceBeanDetails.getOrderId(), "Order Number",suspendServiceBeanDetails.getCustomerType(),
								CLASS_NAME, method.getName());
				
				String product = searchResultPageOperations
						.getProductForActiveOrder();
				
				
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME,method.getName());
				accountDetailsPageOperations.isSuspandVoiceButtonEnabled(CLASS_NAME, method.getName());
				logger.info(" End testCRQ156864_TC011: End the SuspendService ");
			}
			catch (Exception e) {
				e.printStackTrace();
					}   
			
			logger.error("Unable to click the requestControl link" + suspendServiceBeanDetails.getOrderId());
			count++;
		}

	}
	@AfterMethod
	public void tearDown() {
		//driver.close();
		//driver.quit();

	}

	}