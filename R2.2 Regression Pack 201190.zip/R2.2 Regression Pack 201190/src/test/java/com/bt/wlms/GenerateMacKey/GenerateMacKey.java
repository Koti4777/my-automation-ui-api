package com.bt.wlms.GenerateMacKey;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * @author dvasireddi
 *
 */
public class GenerateMacKey extends SeleniumImplementation

{
	
	private WebDriver driver;
	public String CLASS_NAME = "GenerateMacKey";

	private String IN_FILE = "MacKey.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("VerifyMacKeyLink");
	
	
	public GenerateMacKey()
	{
		PropertyConfigurator.configure(loggerPath);
	}

	
	/**
	 * 
	 * @throws Exception
	 */
	
	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readnewAssetDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	/**
	 * 
	 * @param method
	 * @throws IOException
	 */
	
	@Test
	public void testMacKeyLink(Method method) throws IOException {

     
		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-VerifyMacKeyLink ");

				assetBeanDetails = bbDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				
                 
				 HomePageOperations homePageOperations = loginPageOperations
						.agentLogin(CLASS_NAME, method.getName());
				
				 SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(assetBeanDetails.getOrderId(), "Order Number",
								CLASS_NAME, method.getName());
				
				 searchResultPageOperations.getProductForActiveOrder();

				
				 AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				
				 accountDetailsPageOperations.clickBroadbandTab(CLASS_NAME, method.getName());
				
				 accountDetailsPageOperations.clickGenerateMACKey(CLASS_NAME, method.getName());
				
				 logger.info("MacKey Link is verified");
				
			}
			
			catch (Exception e) {
				e.printStackTrace();
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}   logger.error("Unable to regrade the orderid " + assetBeanDetails.getOrderId());
			count++;
        }
     }
	
	@AfterMethod
	public void tearDown() 
	{
		driver.close();
		driver.quit();

	}

}