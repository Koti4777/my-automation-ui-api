package com.bt.wlms.HQN_LLTC_R20_SPC1315;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class HQN_TC_SPC1315_006 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "HQN_TC_SPC1315_006";

	private String IN_FILE = "NonNGAAssetDetails.csv";
	List<AssetBeanDetails> assetDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int count = 0;
	public Order order = null;
	private int testCount = 0;

	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("HQN_TC_SPC1315_006");
	
	
	public HQN_TC_SPC1315_006()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 
  /*      
	@Rule
	public TestName name = new TestName();
*/
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		assetDetailsList = CSVOperation_New.readAssetDetails(IN_FILE);
		order = new Order();

		if (assetDetailsList != null && assetDetailsList.size() > 0) {
			testCount = assetDetailsList.size();
		}

	}

	@Test
	public void testCreate_NON_NGA_Aseet(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-Create_NON_NGA_Aseet : Start the NON-NGA-Asset creation ");
				
				assetBeanDetails = assetDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				RegisterNewServicePageOperations servicePageOperations = homePageOperations
						.clickBusinessCustomer();
				
				CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
						  .searchByBusinessAccountName(assetBeanDetails
						     .getBusinessAccount(),CLASS_NAME, method.getName());

				CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
						.clickBusinessAccount(assetBeanDetails
								.getBusinessAccount());

				LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
						.clickAddSite(CLASS_NAME, method.getName());

				LineCheckResultPageOperations lineCheckResultPageOperations = null;

				if ("".equalsIgnoreCase(assetBeanDetails.getLandlinePhone())) {

					AddressSelectionPageOperations addressSelectionPageOperations = lineDetailsPageOperations
							.createSiteWithPostCodeOnly(
									assetBeanDetails.getNewSite(),
									assetBeanDetails.getLandlinePhone(),
									assetBeanDetails.getPostCode(),
									assetBeanDetails.getAddressValue(),
									assetBeanDetails.getPremisesName(),
									assetBeanDetails.getStreetName(),
									assetBeanDetails.getTown(),
									assetBeanDetails.getCountry(), CLASS_NAME,
									method.getName());

					lineCheckResultPageOperations = addressSelectionPageOperations
							.submitAddressButton(CLASS_NAME,
									method.getName());
				} else {

					lineCheckResultPageOperations = lineDetailsPageOperations
							.createSiteWithPostCodeAndPremisesDetails(
									assetBeanDetails.getNewSite(),
									assetBeanDetails.getLandlinePhone(),
									assetBeanDetails.getPostCode(),
									assetBeanDetails.getAddressValue(),
									assetBeanDetails.getPremisesName(),
									assetBeanDetails.getStreetName(),
									assetBeanDetails.getTown(),
									assetBeanDetails.getCountry(), CLASS_NAME,
									method.getName());

				}

               lineCheckResultPageOperations.estimatedLineSpeed(CLASS_NAME,
									method.getName());
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				logger.info(" End Test -  Create_NON_NGA_Aseet : End the NON-NGA-Asset creation");

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to place the order");
				

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		//driver.quit();
		//driver.close();

	}

}


