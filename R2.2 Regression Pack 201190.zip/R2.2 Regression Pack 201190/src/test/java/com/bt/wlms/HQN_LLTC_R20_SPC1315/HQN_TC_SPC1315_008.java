package com.bt.wlms.HQN_LLTC_R20_SPC1315;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bt.wlms.configurationOfWorkQues.SelfcareHouseMove;
import com.hqnRegression.pages.operations.ChangeYourPlanPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class HQN_TC_SPC1315_008 extends SeleniumImplementation {
	
	private WebDriver driver;
	private String baseUrl;
	private String CLASS_NAME = "HQN_TC_SPC1315_008";

	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("HQN_TC_SPC1315_008");

	public HQN_TC_SPC1315_008() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		// baseUrl = "https://213.212.114.164/";
		baseUrl = "https://163.164.37.104/";

		// ?https://163.164.37.104/b2bselfcare/b2b/myaccount?execution=e1s1
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}
	
	@Test
	public void testLineSpeed(Method method) throws Exception {

		PropertyConfigurator.configure(loggerPath);
		logger.info(" Start Test-testB2BHouseMove : Start the testModifyCardPayment ");

		SelfCarePortalLoginOperations selfCarePortalLoginOperations = SelfCarePortalLoginOperations
				.navigateTob2bscp(driver, baseUrl, CLASS_NAME, method.getName());

		SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = selfCarePortalLoginOperations
				.selfcareLogin(CLASS_NAME, method.getName());
		selfCarePortalHomePageOperations.clickOnYourPlan(CLASS_NAME, method.getName());
		
		ChangeYourPlanPageOperations changeYourPlanPageOperations = selfCarePortalHomePageOperations
				.verifyLineSpeed(CLASS_NAME, method.getName());
				
		//selfCarePortalLoginOperations = selfCarePortalHomePageOperations.clickLogout(CLASS_NAME, method.getName());
		
		logger.info(" Start Test-testB2BHouseMove : End the testModifyCardPayment ");
	}
    @AfterMethod
    public void tearDown() throws Exception
    {
         /*driver.close();
           driver.quit(); */
    }

   
}