package com.bt.wlms.HouseMove;



import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.HomeMoveDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LocationMovePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ManagedInstallationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.SiteDetailsPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class HQN_TS_SPC1325_S14C15_UC_0205_002_HouseMove_NGA extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "HouseMove_NGA_Asset";

	private String IN_FILE = "HouseMoveDetails.csv";
	List<HomeMoveDetails> bbDetailsList = null;
	HomeMoveDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("HouseMove_NGA_Asset");
	
	public HQN_TS_SPC1325_S14C15_UC_0205_002_HouseMove_NGA()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	

	/*@Rule
	public TestName name = new TestName();
*/
	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readHomeMoveDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}

	}

	@Test
	public void testHouseMoveOrder(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-HouseMove_NGA_Asset : Start the HouseMove_NGA_Asset creation ");

				assetBeanDetails = bbDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());
				SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(assetBeanDetails.getCompanyName(), "Company Name",
						CLASS_NAME, method.getName());
		
				
				CustomerDetailsPageOperations customerDetailsPageOperations = searchResultPageOperations.clickCustomerLinkForCompanyName(CLASS_NAME, method.getName());
		
				SiteDetailsPageOperations siteDetailsPageOperations = customerDetailsPageOperations
				.clickCustomerDetailsForCompanyName(CLASS_NAME, method.getName());
		
				AccountDetailsPageOperations accountDetailsPageOperations = siteDetailsPageOperations
				.clickSiteDetailsForCompanyName(CLASS_NAME, method.getName());
		
				

				LocationMovePageOperations locationMovePageOperations = accountDetailsPageOperations
						.clickPremisesMove(CLASS_NAME, method.getName());
				AddressSelectionPageOperations addressSelectionPageOperations = null;
				LineCheckResultPageOperations lineCheckResultPageOperations = null;
				ManagedInstallationPageOperations managedInstallationPageOperations = null;
			
				String product = siteDetailsPageOperations.getProductLinkSiteDetailsPage();
			
						
				if (!product.contains("Line") && !product.contains("Calls")) {

					locationMovePageOperations.fillLocationMoveDetails_LORN(
							assetBeanDetails.getApplyCeaseCharges(),
							assetBeanDetails.getNewSite(),
							assetBeanDetails.getPostCode(),assetBeanDetails
									.getAddressValue(), assetBeanDetails
									.getPremisesName(), assetBeanDetails
									.getStreetName(), assetBeanDetails
									.getTown(), assetBeanDetails.getCountry(),
							assetBeanDetails.getKeepExistingNumber(),
							assetBeanDetails.getLorn(), assetBeanDetails
									.getMoveOnDiffDate(), CLASS_NAME, method.getName());

				} else {
					locationMovePageOperations.fillLocationMoveDetails(
							assetBeanDetails.getApplyCeaseCharges(),
							assetBeanDetails.getNewSite(), assetBeanDetails
									.getPostCode(), assetBeanDetails
									.getAddressValue(), assetBeanDetails
									.getPremisesName(), assetBeanDetails
									.getStreetName(), assetBeanDetails
									.getTown(), assetBeanDetails.getCountry(),
							assetBeanDetails.getKeepExistingNumber(),
							assetBeanDetails.getMoveOnDiffDate(), CLASS_NAME,
							method.getName());

				}

				if (product.contains("40:")) {

					if (!product.contains("Line") && !product.contains("Call")) {

						managedInstallationPageOperations = locationMovePageOperations
								.clickManageInstallation(CLASS_NAME, method.getName());
					} else {

						addressSelectionPageOperations = locationMovePageOperations
								.clickLineCheckAddressSelection(CLASS_NAME,
										method.getName());

						managedInstallationPageOperations = addressSelectionPageOperations
								.clickNext(CLASS_NAME, method.getName());

					}

					lineCheckResultPageOperations = managedInstallationPageOperations
							.selectManagedInstallAndClickNext(assetBeanDetails
									.getManagedInstall(), CLASS_NAME, method.getName());

				} else {

					lineCheckResultPageOperations = addressSelectionPageOperations
							.submitAddressButton(CLASS_NAME, method.getName());

				}

				CRDAndAppointmentManagementPageOperations crdAndAppointmentManagementPageOperations = null;

				if (product.contains("Line")
						|| (!product.contains("Line") && !product
								.contains("Call"))) {

					AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
							.clickHomeMoveNext(CLASS_NAME, method.getName());

					AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
							.submit(CLASS_NAME, method.getName());

					crdAndAppointmentManagementPageOperations = assignUserContactPageOperations
							.submit1(CLASS_NAME, method.getName());

				} else {
					crdAndAppointmentManagementPageOperations = lineCheckResultPageOperations
							.clickHomeMoveNext_returnsCRDScreen(CLASS_NAME,
									method.getName());
				}

				crdAndAppointmentManagementPageOperations.selectActivateDate();

				boolean isPresent = crdAndAppointmentManagementPageOperations
						.isVoiceAppointmentButtonPresent();

				if (isPresent) {
					crdAndAppointmentManagementPageOperations
							.fillVoiceAppointmentManagementFields(assetBeanDetails
									.getEngineeringNotes());
					if (assetBeanDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						crdAndAppointmentManagementPageOperations
								.clickOutOfHoursAppointment();
					}

					ReserveAppointmentPageOperations reserveAppointmentPageOperations = crdAndAppointmentManagementPageOperations
							.clickAvailableAppointmentButton();

					reserveAppointmentPageOperations
							.selectFirstAvailableAppointmentDate();
					
					if (assetBeanDetails.getIncludeOutofHours().equalsIgnoreCase("yes")) 
					{
						System.out.println("........");
						
						if (assetBeanDetails.getAppointmentCharges().contains("Accept additional"))
						{
							System.out.println("........");
							reserveAppointmentPageOperations.clickAcceptAdditionalCharges();
						}
					if (assetBeanDetails.getAppointmentCharges().contains(
								"both")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						} else {
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						}
					}

					crdAndAppointmentManagementPageOperations = reserveAppointmentPageOperations
							.clickReserveAppointmentButton(CLASS_NAME, method.getName());
				}

				isPresent = crdAndAppointmentManagementPageOperations
						.isFTTCAppointmentButtonPresent();

				if (isPresent) {

					FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = crdAndAppointmentManagementPageOperations
							.fillBBFTTCAppointmentManagement(CLASS_NAME, method.getName());
					fttcAvailableAppointmentsPageOperations
							.selectFirstAvailableAppointmentDate();
					crdAndAppointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
							.clickReserveAppointmentButton(CLASS_NAME, method.getName());
				}

				if (product.contains("Call") || product.contains("Line")
						|| product.contains("40:")) {

					crdAndAppointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(assetBeanDetails
									.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = crdAndAppointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(assetBeanDetails
						.getCommunicationBy());
				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
				orderSummaryPageOperations.clickComplete_HM(CLASS_NAME, method.getName());
				
				logger.info(" End Test-HouseMove_NGA_Asset : End the HouseMove_NGA_Asset creation ");

				try {
					CommonClass.saveScreenshot(CLASS_NAME,
							method.getName(),
							"lastPageOperations" + ".png", driver, "end");
				} catch (IOException e) {
					e.printStackTrace();
				}

			} catch (Exception e) {
				try {
					CommonClass.saveScreenshot(CLASS_NAME,
							method.getName(),
							"lastPageOperations" + ".png", driver, "end");
				} catch (IOException ex) {
					ex.printStackTrace();
					
					logger.error("Unable to do HouseMoveNGAAsset for the orderid " + assetBeanDetails.getOrderId());
					
				}
				e.printStackTrace();
				logger.error("Unable to HouseMove NGA Asset for  the orderid " + assetBeanDetails.getOrderId());
			}
			count++;
		}

	}

	}
