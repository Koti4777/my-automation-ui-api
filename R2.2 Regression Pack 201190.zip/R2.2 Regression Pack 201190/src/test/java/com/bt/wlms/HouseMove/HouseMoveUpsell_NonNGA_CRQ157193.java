package com.bt.wlms.HouseMove;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.HomeMoveDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LocationMovePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderResultPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * This class performs House Move UpSell Operations NON NGA,Sprint 5+1 CR- CRQ157193
 * 
 */

public class HouseMoveUpsell_NonNGA_CRQ157193 extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "HouseMoveUpsell_NonNGA_CRQ157193";

	private String IN_FILE = "HouseMoveDetailsUpSell.csv";
	List<HomeMoveDetails> homeMoveDetailsList = null;
	HomeMoveDetails homeMoveDetails = null;

	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("HouseMoveUpsell_NonNGA_CRQ157193");

	public HouseMoveUpsell_NonNGA_CRQ157193() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		homeMoveDetailsList = CSVOperation_New
				.readHomeMoveDetailsUpSell(IN_FILE);

		if (homeMoveDetailsList != null && homeMoveDetailsList.size() > 0) {
			testCount = homeMoveDetailsList.size();
		}

	}

	@Test
	public void testHouseMoveUpsell_NonNGA_CRQ157193(Method method) throws IOException {
		while (count < testCount) {
			try {

				logger.info(" Start testHouseMoveUpsell_NonNGA_CRQ157193 creation ");

				homeMoveDetails = homeMoveDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.searchBoxFunctioning(homeMoveDetails.getOrderId(),
								"Order Number",
								homeMoveDetails.getCustomerType(), CLASS_NAME,
								method.getName());
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink();

				LocationMovePageOperations locationMovePageOperations = accountDetailsPageOperations
						.clickPremisesMove(CLASS_NAME, method.getName());

				// Broadband
				if (product.contains("Bussiness Essential Broadband")
						|| product.contains("Business Broadband")
						|| product.contains("Business Advanced Broadband")
						|| product.contains("Simply Broadband")) {

					locationMovePageOperations
							.fillLocationMoveDetails_UpSellPSTN(
									homeMoveDetails.getApplyCeaseCharges(),
									homeMoveDetails.getUpsellPSTN(),
									homeMoveDetails.getNewSite(),
									homeMoveDetails.getPostCode(),
									homeMoveDetails.getAddressValue(),
									homeMoveDetails.getPremisesName(),
									homeMoveDetails.getStreetName(),
									homeMoveDetails.getTown(),
									homeMoveDetails.getCountry(),
									homeMoveDetails.getKeepExistingNumber(),
									homeMoveDetails.getLorn(),
									homeMoveDetails.getMoveOnDiffDate(),
									CLASS_NAME, method.getName());
				}
				AddressSelectionPageOperations addressSelectionPageOperations = null;
				LineCheckResultPageOperations lineCheckResultPageOperations = null;
				CRDAndAppointmentManagementPageOperations crdAndAppointmentManagementPageOperations = null;

				addressSelectionPageOperations = locationMovePageOperations
						.clickLineCheckAddressSelection(CLASS_NAME,
								method.getName());
				lineCheckResultPageOperations = addressSelectionPageOperations
						.submitAddressButton(CLASS_NAME, method.getName());
				/* select
				 * Business Advanced BBand & Line Rental for BUSINESS ADVANCED BROADBAND
				 * Broadband & Anytime + Mobile Calls for SIMPLY BROADBAND
				 */
				String selectedProduct=homeMoveDetails
						.getPraposition();
						
						lineCheckResultPageOperations
						.selectPropositionByName(selectedProduct);

				AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
						.clickHomeMoveNext(CLASS_NAME, method.getName());

				AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
						.submit(CLASS_NAME, method.getName());

				ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
						.submit(CLASS_NAME, method.getName());

				productDetailsPageOperations.selectHouseMoveOfferDetails(
						homeMoveDetails.getPraposition(),
						homeMoveDetails.getFirstName(),
						homeMoveDetails.getSurName(),
						homeMoveDetails.getBusinessRateCard(), CLASS_NAME,
						method.getName(), homeMoveDetails.getTitle());

				crdAndAppointmentManagementPageOperations = assignUserContactPageOperations
						.submit2(CLASS_NAME, method.getName());

				crdAndAppointmentManagementPageOperations.selectActivateDate();
				boolean isPresent = crdAndAppointmentManagementPageOperations
						.isVoiceAppointmentButtonPresent();

				if (isPresent) {
					crdAndAppointmentManagementPageOperations
							.fillVoiceAppointmentManagementFields(homeMoveDetails
									.getEngineeringNotes());
					if (homeMoveDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						crdAndAppointmentManagementPageOperations
								.clickOutOfHoursAppointment();
					}

					ReserveAppointmentPageOperations reserveAppointmentPageOperations = crdAndAppointmentManagementPageOperations
							.clickAvailableAppointmentButton();

					reserveAppointmentPageOperations
							.selectFirstAvailableAppointmentDate();

					if (homeMoveDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						if (homeMoveDetails.getAppointmentCharges().contains(
								"Accept additional")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
						}
						if (homeMoveDetails.getAppointmentCharges().contains(
								"both")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						} else {
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						}
					}

					crdAndAppointmentManagementPageOperations = reserveAppointmentPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());
				}
				if (selectedProduct.contains("Call") || selectedProduct.contains("Line")
						|| selectedProduct.contains("40:")) {

					crdAndAppointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(homeMoveDetails
									.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = crdAndAppointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());
				orderSummaryPageOperations.selectCommunication(homeMoveDetails
						.getCommunicationBy());
				
				OrderResultPageOperations orderResultPageOperations = orderSummaryPageOperations
						.confirmOrder_HomeMove(CLASS_NAME, method.getName());
				orderResultPageOperations.clickComplete_HM(CLASS_NAME,
						method.getName());

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.info(" End testHouseMoveUpsell_NonNGA_CRQ157193 creation ");

			} catch (Exception e) {
				System.out.println(e);
				e.printStackTrace();
				logger.error("Unable to perform House move upsell non nga journey");
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();

	}
}
