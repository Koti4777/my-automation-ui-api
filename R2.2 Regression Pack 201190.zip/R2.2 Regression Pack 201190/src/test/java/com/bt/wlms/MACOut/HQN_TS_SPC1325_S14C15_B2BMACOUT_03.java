package com.bt.wlms.MACOut;


import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.lang.reflect.Method;

import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.GenerateMACKeyNextPageOperations;
import com.hqnRegression.pages.operations.GenerateMACKeyPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.SiteDetailsPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class HQN_TS_SPC1325_S14C15_B2BMACOUT_03 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "HQN_TS_SPC1325_S14C15_B2BMACOUT_03";

	private String IN_FILE = "MacoutDetails.csv";

	List<CPEDetails> macoutDetailsList = null;
	CPEDetails macoutDetails = null;

	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("HQN_TS_SPC1325_S14C15_B2BMACOUT_03");
	
	public HQN_TS_SPC1325_S14C15_B2BMACOUT_03()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		macoutDetailsList = CSVOperation_New.readCPEDetails(IN_FILE);

		if (macoutDetailsList != null && macoutDetailsList.size() > 0) {
			testCount = macoutDetailsList.size();
		}

	}

	@Test
	public void testHQN_TS_SPC1325_S14C15_B2BMACOUT_03(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			try {
				
				logger.info(" Start Test-Generate_Macout : Start the Generate_Macout creation ");
				
				macoutDetails = macoutDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(macoutDetails.getCompanyName(), "Company Name",
								CLASS_NAME, method.getName());

				CustomerDetailsPageOperations customerDetailsPageOperations = searchResultPageOperations
		.clickCustomerLinkForCompanyName(CLASS_NAME, method.getName());
		
				SiteDetailsPageOperations siteDetailsPageOperations = customerDetailsPageOperations
		.clickCustomerDetailsForCompanyName(CLASS_NAME, method.getName());
		
				AccountDetailsPageOperations accountDetailsPageOperations = siteDetailsPageOperations
		.clickSiteDetailsForCompanyName(CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickBroadbandTab(CLASS_NAME,
						method.getName());

				GenerateMACKeyPageOperations generateMACKeyPageOperations = accountDetailsPageOperations
						.clickGenerateMACKey(CLASS_NAME, method.getName());

				GenerateMACKeyNextPageOperations generateMACKeyNextPageOperations = generateMACKeyPageOperations
						.clickGenerate(CLASS_NAME, method.getName());

				accountDetailsPageOperations = generateMACKeyNextPageOperations
						.clickContinue(CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickticketsTab(CLASS_NAME,
						method.getName());

				accountDetailsPageOperations.verifyMacRequest(CLASS_NAME,
						method.getName());
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				logger.info(" End Test-Generate_Macout : End the Generate_Macout creation ");

			} catch (Exception e) {
				System.out.println(e);
				e.printStackTrace();
				logger.error("Unable to create Generate Macout");
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}
			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();
		logger.info(",Generate_Macout,pass");

	}
}
