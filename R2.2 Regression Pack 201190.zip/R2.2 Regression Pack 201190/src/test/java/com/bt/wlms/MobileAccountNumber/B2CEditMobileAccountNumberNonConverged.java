package com.bt.wlms.MobileAccountNumber;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.BusinessAccountDetails;
import com.hqnRegression.beans.CreditCardDetails;
import com.hqnRegression.pages.EditCustomerDetailsPage;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.EditCustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PrimaryAccountPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class B2CEditMobileAccountNumberNonConverged extends
		SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "B2CEditMobileAccountNumberNonConverged";

	private String IN_FILE = "MobileAccountNumberUpdate.csv";
	List<AssetBeanDetails> ecDetailsList = null;
	AssetBeanDetails beanDetails = null;
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("B2CEditMobileAccountNumberNonConverged");

	public B2CEditMobileAccountNumberNonConverged() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		ecDetailsList = CSVOperation_New.readEditCustomerDetails(IN_FILE);
			
	}
	@Test
	public void testValidateB2CEditMobileNumberNonConverged(Method method) throws IOException {
		beanDetails = ecDetailsList.get(0);
		
		logger.info(" Start B2CEditMobileAccountNumberNonConverged : testValidateB2CEditMobileAccountNumberNonConverged");

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
		.searchT2(beanDetails.getOrderId(),"B2C","Order Number", CLASS_NAME,
				method.getName());
		String product = searchResultPageOperations.getProductForActiveOrder();

		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
		.clickProductLink();
		
		EditCustomerDetailsPageOperations editCustomerDetailsPageOperations = accountDetailsPageOperations
		.clickEditCustomerAccountDetails(CLASS_NAME, method.getName());

		editCustomerDetailsPageOperations.fillEditCustomerDetailsMobileAccountNumbrNonConverged(
		beanDetails.getSalutation(),
		beanDetails.getFirstName(), 
		beanDetails.getSurName(),
		beanDetails.getMobileAccountNumber(),
		beanDetails.getTelephoneNumber(),
		beanDetails.getMobileNumber(),
		beanDetails.getAdditionalTelephoneNumber(),
		beanDetails.getEmailAddress(), 
		beanDetails.getDob(),
		CLASS_NAME, method.getName());
	
	accountDetailsPageOperations = editCustomerDetailsPageOperations
	.clickSave(CLASS_NAME, method.getName());
	logger.info(" End B2CEditMobileAccountNumberNonConverged : testValidateB2CEditMobileAccountNumberNonConverged");
	//CommonMethods.selfCareLogOut(driver, CLASS_NAME, method.getName());
}
	
			
		@AfterMethod
		public void tearDown() {
			//driver.close();
			//driver.quit();
		}
	}

	

