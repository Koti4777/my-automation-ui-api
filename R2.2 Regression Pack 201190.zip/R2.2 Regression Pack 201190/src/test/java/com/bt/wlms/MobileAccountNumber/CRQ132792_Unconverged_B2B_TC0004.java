package com.bt.wlms.MobileAccountNumber;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.EditCustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class CRQ132792_Unconverged_B2B_TC0004 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "CRQ132792_Unconverged_B2B_TC0004";

	private String IN_FILE = "CRQ132792_Unconverged_B2C_or_B2B_TC0004.csv";
	List<AssetBeanDetails> ecDetailsList = null;
	AssetBeanDetails beanDetails = null;
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("CRQ132792_Unconverged_B2B_TC0004");

	public CRQ132792_Unconverged_B2B_TC0004() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		ecDetailsList = CSVOperation_New.readCustomerDetails(IN_FILE);
			
	}
	@Test
	public void testCRQ132792_Unconverged_B2B_TC0004(Method method)
			throws IOException {
		
		beanDetails = ecDetailsList.get(0);

		logger.info(" Start CRQ132792_Unconverged_B2B_TC0004 ");

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.searchT2(beanDetails.getSearchValue(),beanDetails.getOrderType(),beanDetails.getSearchBy(), CLASS_NAME,
						method.getName());

		CustomerDetailsPageOperations customerDetailsPageOperations = searchResultPageOperations.clickCustomerLink(CLASS_NAME,
						method.getName(),beanDetails.getCustomerName());
		
		customerDetailsPageOperations.clickCustomerDetailsTab(CLASS_NAME,
				method.getName());
		
		EditCustomerDetailsPageOperations  editCustomerDetailsPageOperations		
				= customerDetailsPageOperations.clickEditLinkforEditCustomerDetailsPage(CLASS_NAME,
						method.getName(),beanDetails.getCustomerName());
		
		editCustomerDetailsPageOperations.unSelectConvergeFlag(CLASS_NAME,
				method.getName());

		editCustomerDetailsPageOperations.editCustomerDetails(

		beanDetails.getMobileAccountNumber(), CLASS_NAME, method.getName());

		customerDetailsPageOperations =  editCustomerDetailsPageOperations
				.clickSaveButton(CLASS_NAME, method.getName());
		
		CommonMethods.doPause(10);
		
		customerDetailsPageOperations.clickCustomerDetailsTab(CLASS_NAME,
				method.getName());
		
		customerDetailsPageOperations.VerifyConvegedStatus_B2B_Customer(CLASS_NAME,
				method.getName(),beanDetails.getCustomerName());
		
		CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		
		logger.info(" End :  CRQ132792_Unconverged_B2B_TC0004 ");

		

	}
	
			
		@AfterMethod
		public void tearDown() {
			driver.close();
			driver.quit();
		}
	
}
