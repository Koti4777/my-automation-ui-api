package com.bt.wlms.MobileAccountNumber;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.ConfirmDNPageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.EditCustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegradeOrderPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Conversion_Charge_Converged_Unconverged_Customer_B2B_01 extends
		SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "Conversion_Charge_Converged_Unconverged_Customer_B2B_01";

	private String IN_FILE = "Converged_Regrade.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("Conversion_Charge_Converged_Unconverged_Customer_B2B_01");

	public Conversion_Charge_Converged_Unconverged_Customer_B2B_01() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readConverged(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}

	}

	@Test
	public void testRegradeOrder(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-RegradeNGADetails : Start the RegradeNGADetails creation ");

				assetBeanDetails = bbDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());
				if ("B2B".equalsIgnoreCase(assetBeanDetails.getCustomerType())) {

					SearchResultPageOperations searchResultPageOperations = homePageOperations
							.searchT2(
									assetBeanDetails.getBillingAccountNumber(),
									assetBeanDetails.getCustomerType(),
									"Billing Account Number", CLASS_NAME,
									method.getName());

					CustomerDetailsPageOperations customerDetailsPageOperations = searchResultPageOperations
							.clickCustomerLink(CLASS_NAME, method.getName(),
									assetBeanDetails.getCustomerName());
 
					customerDetailsPageOperations.clickCustomerDetailsTab(
							CLASS_NAME, method.getName());

					EditCustomerDetailsPageOperations editCustomerDetailsPageOperations = customerDetailsPageOperations
							.clickEditLinkforEditCustomerDetailsPage(
									CLASS_NAME, method.getName(),
									assetBeanDetails.getCustomerName());

					editCustomerDetailsPageOperations.selectTheConvergeFlag(
							CLASS_NAME, method.getName());

					customerDetailsPageOperations = editCustomerDetailsPageOperations
							.clickSaveButton(CLASS_NAME, method.getName());
					homePageOperations.getHome();

				}
				
				
			SearchResultPageOperations	searchResultPageOperations = 
					homePageOperations.selectB2BrB2C(assetBeanDetails.getOrderId(),
								"Order Number", assetBeanDetails.getCustomerType(),
								CLASS_NAME, method.getName());

				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink();
				AgentDetailsPageOperations agentDetailsPageOperations = null;

				if ("B2C".equalsIgnoreCase(assetBeanDetails.getCustomerType())) {

					EditCustomerDetailsPageOperations editCustomerDetailsPageOperations = accountDetailsPageOperations.clickEditCustomerAccountDetails(	CLASS_NAME, method.getName());
				accountDetailsPageOperations =	editCustomerDetailsPageOperations.convergedToNonconverged(assetBeanDetails.getConverged(), CLASS_NAME,method.getName());	
				}

				if (!product.contains("Line") && !product.contains("Calls")) {
					ConfirmDNPageOperations confirmDNPageOperations = accountDetailsPageOperations
							.clickRegradeForConfirmDN(CLASS_NAME,
									method.getName());
					agentDetailsPageOperations = confirmDNPageOperations
							.clickContinue(CLASS_NAME, method.getName());
				} else {
					agentDetailsPageOperations = accountDetailsPageOperations
							.clickRegrade(CLASS_NAME, method.getName());
				}
				agentDetailsPageOperations.clickSameAgent();

				LineCheckResultPageOperations lineCheckResultPageOperations = agentDetailsPageOperations
						.clickNextForRegrade(CLASS_NAME, method.getName());

				RegradeOrderPageOperations regradeOrderPageOperations = lineCheckResultPageOperations
						.clickNextforRegrade(CLASS_NAME, method.getName());

				regradeOrderPageOperations
						.selectPropositionByName(assetBeanDetails
								.getProposition());

				ProductDetailsPageOperations productDetailsPageOperations = regradeOrderPageOperations
						.clickNext(CLASS_NAME, method.getName());

				productDetailsPageOperations.selectProductOffering_Asset(
						assetBeanDetails.getProposition(),
						assetBeanDetails.getBroadbandCare(),
						assetBeanDetails.getRouter(),
						assetBeanDetails.getBusinessRateCard(),
						assetBeanDetails.getCalls(),
						assetBeanDetails.getCarelevel(),
						assetBeanDetails.getSelectcalls(),
						assetBeanDetails.getContract(),
						assetBeanDetails.getOneOffCharge(),
						assetBeanDetails.getRateCardDiscount(),
						assetBeanDetails.getSalesPromotion(),
						assetBeanDetails.getCustomerDiscount(),
						assetBeanDetails.getPostCode(),
						assetBeanDetails.getTitle(),
						assetBeanDetails.getFirstName(),
						assetBeanDetails.getSurName(),
						assetBeanDetails.getServiceId(),
						assetBeanDetails.getDdiRangeNum(),
						assetBeanDetails.getSddirangeNum(),
						assetBeanDetails.getManagedInstall(), CLASS_NAME,
						method.getName(), product);

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				if (productDetailsPageOperations.isHardwarepageAvailable) {

					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
							.clickNextForHardware(CLASS_NAME, method.getName());

					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
							.clickNext(CLASS_NAME, method.getName());
				} else {

					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
				}

				appointmentManagementPageOperations.selectFutureCalendarDate(
						CLASS_NAME, method.getName(), 7);

				boolean isPresent = appointmentManagementPageOperations
						.isVoiceAppointmentButtonPresent();

				if (isPresent) {
					appointmentManagementPageOperations
							.fillVoiceAppointmentManagementFields(assetBeanDetails
									.getEngineeringNotes());
					if (assetBeanDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						appointmentManagementPageOperations
								.clickOutOfHoursAppointment();
					}

					ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
							.clickAvailableAppointmentButton();

					reserveAppointmentPageOperations
							.selectFirstAvailableAppointmentDate();

					if (assetBeanDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						if (assetBeanDetails.getAppointmentCharges().contains(
								"Accept additional")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
						}
						if (assetBeanDetails.getAppointmentCharges().contains(
								"both")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						} else {
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						}
					}

					appointmentManagementPageOperations = reserveAppointmentPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());
				}

				isPresent = appointmentManagementPageOperations
						.isFTTCAppointmentButtonPresent();

				if (isPresent) {

					FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
							.fillBBFTTCAppointmentManagement(CLASS_NAME,
									method.getName());
					fttcAvailableAppointmentsPageOperations
							.selectFirstAvailableAppointmentDate();
					appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());
				}

				if (assetBeanDetails.getProposition().contains("Call")
						|| assetBeanDetails.getProposition().contains("Line")
						|| product.contains("Call") || product.contains("Line")) {

					appointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(assetBeanDetails
									.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(assetBeanDetails
						.getCommunicationBy());
				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations

				.confirmOrder(CLASS_NAME, method.getName());

				String orderId = orderConfirmationPageOperations.getOrderId();

				orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
						method.getName());

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.info(" End Test-RegradeNGADetails : End the RegradeNGADetails creation ");

				try {
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"lastPageOperations" + ".png", driver, "end");
				} catch (IOException e) {
					e.printStackTrace();
				}

			} catch (Exception e) {
				try {
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"lastPageOperations" + ".png", driver, "end");
				} catch (IOException ex) {
					ex.printStackTrace();
					logger.error("Unable to RegradeNGADetails the orderid "
							+ assetBeanDetails.getOrderId());
				}
				e.printStackTrace();
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

	}

}
