package com.bt.wlms.MobileAccountNumber;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.supercsv.cellprocessor.constraint.StrMinMax;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.pages.EditCustomerDetailsPage;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.EditCustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PrimaryAccountPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class EditCustomerDetails extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "B2BEditCustomerDetails";

	private String IN_FILE = "B2BEditCustomerDetails.csv";
	
	List<AssetBeanDetails> ecDetailsList = null;
	AssetBeanDetails beanDetails = null;
	Properties testProps = null;
		private int count = 0;
	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("B2BEditCustomerDetails");

	public EditCustomerDetails() {
		PropertyConfigurator.configure(loggerPath);
		
	}
	
	@BeforeMethod
	public void setUp() throws Exception {
		
		ecDetailsList = CSVOperation_New.readB2CEditCustomerDetails(IN_FILE);

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		testProps = CommonMethods.readErrorMSGs(driver);
		if (ecDetailsList != null && ecDetailsList.size() > 0) {
			testCount = ecDetailsList.size();
		}
	}
	@Test
	public void testValidateB2BEditCustomerDetails(Method method)
			throws IOException {

		beanDetails = ecDetailsList.get(0);

	 logger.info(" Start B2BEditCustomerDetails : testValidateB2BEditCustomerDetails");

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.searchT2(beanDetails.getCompanyName(),"B2B","Company Name", CLASS_NAME,
						method.getName());
		String product = searchResultPageOperations.getProductForActiveOrder();

		CustomerDetailsPageOperations customerDetailsPageOperations = searchResultPageOperations
		.clickProductLinkForAccount(CLASS_NAME, method.getName());
		
		
		EditCustomerDetailsPageOperations editCustomerDetailsPageOperations = customerDetailsPageOperations
					.clickCompanyNameEdit(CLASS_NAME, method.getName());
		
		 editCustomerDetailsPageOperations = customerDetailsPageOperations.fillB2BEditCustomerDetails(
				 beanDetails.getCompanyName(),
				 beanDetails.getCompanyRegistrationNumber(),
				 beanDetails.getCustomerSegmentation(),
				  beanDetails.getMobileAccountNumber(),
				  beanDetails.getVatNumber(),beanDetails.getTitle(),
			beanDetails.getFirstName(),beanDetails.getSurName(),
			beanDetails.getPhoneNum(),beanDetails.getMobileNum(),
			beanDetails.getAdditionalContacNum(),beanDetails.getEmailAddress(), 
			beanDetails.getPostCode(),beanDetails.getAddressValue(), 
			beanDetails.getPremisesName(), beanDetails.getStreetName(),
			beanDetails.getTown(),beanDetails.getCountry(),
						CLASS_NAME,method.getName());
	
		customerDetailsPageOperations = editCustomerDetailsPageOperations
		.clickSaveMobileAccountNumber(CLASS_NAME, method.getName());
		 logger.info(" End B2BEditCustomerDetails : testValidateB2BEditCustomerDetails");

			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			
		}
	
	
			
		@AfterMethod
		public void tearDown() {
			//driver.close();
			//driver.quit();
		}
	}
