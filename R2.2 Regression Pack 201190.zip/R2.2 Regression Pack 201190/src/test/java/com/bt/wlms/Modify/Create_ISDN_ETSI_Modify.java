/**
 * 
 */
package com.bt.wlms.Modify;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Create_ISDN_ETSI_Modify extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "Create_ISDN_ETSI_Modify";

	private String IN_FILE = "ModifyDetails.csv";
	List<AssetBeanDetails> modifyList = null;
	AssetBeanDetails modifyDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Create_ISDN_ETSI_Modify");
	
	public Create_ISDN_ETSI_Modify()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 
	

	@BeforeMethod
	public void setUp() throws Exception {

		modifyList = CSVOperation_New.readAssetDetails(IN_FILE);

		if (modifyList != null && modifyList.size() > 0) {
			testCount = modifyList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	


	
	
     /**
      * using this method we can click the"Broadband" TAB and check whether 
           "Broadband Fault Checker"are the hyperlink are not be present
      * @param method
      * @throws IOException
      */
    
     
    @Test
	    public void testCreateBroadbandFault(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-Create_ISDN_DASS_Amend : Start the Create_ISDN_DASS_Amend creation");

				modifyDetails = modifyList.get(count);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(modifyDetails.getServiceId(), "Service ID",
								CLASS_NAME, method.getName());
				
			
			
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
						.clickModify(CLASS_NAME, method.getName());

				agentDetailsPageOperations.clickSameAgent();
				ProductDetailsPageOperations productDetailsPageOperations = agentDetailsPageOperations
						.clickNextForModify(CLASS_NAME, method.getName());

				productDetailsPageOperations.selectProductOffering_ISDN30Voice_Line_30ETSI_Modify(
						modifyDetails.getCarelevel(),
						modifyDetails.getProposition(),
						
					    CLASS_NAME, method.getName());

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				if (productDetailsPageOperations.isHardwarepageAvailable) {

					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
							.clickNextForHardware(CLASS_NAME,
									method.getName());

					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
							.clickNext(CLASS_NAME, method.getName());
				} else {

					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
				}

				appointmentManagementPageOperations.selectFutureCalendarDate(
						CLASS_NAME, method.getName(), 1);

				appointmentManagementPageOperations
						.fillEngineerNotes(modifyDetails.getEngineeringNotes());

				if (product.contains("Call") || product.contains("Line")
						|| product.contains("40:") || product.contains("ISDN") || product.contains("Business") ) {

					appointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(modifyDetails
									.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(modifyDetails
						.getCommunicationBy());

				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());

				String orderId = orderConfirmationPageOperations.getOrderId();

				accountDetailsPageOperations = orderConfirmationPageOperations
						.clickCompleteModify(CLASS_NAME, method.getName());

				accountDetailsPageOperations.checkOrderStatus(orderId,
						CLASS_NAME, method.getName());
				

				SearchResultPageOperations searchResultPageOperations1 = homePageOperations
						.search(orderId, "Order Number", CLASS_NAME, method
								.getName());

				AccountDetailsPageOperations accountDetailsPageOperations1 = searchResultPageOperations
						.clickProductLinkForPendingOrder(CLASS_NAME, method
								.getName());

				accountDetailsPageOperations.clickticketsTab(CLASS_NAME, method
						.getName());

				 CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				 logger.info(" End Test-Modify_Asset : End the Modify_Asset creation ");

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to modify the orderid " + modifyDetails.getOrderId());
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();

	}

}
