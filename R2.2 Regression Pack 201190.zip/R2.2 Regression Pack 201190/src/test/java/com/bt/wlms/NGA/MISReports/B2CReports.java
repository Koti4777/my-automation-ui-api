package com.bt.wlms.NGA.MISReports;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.ReportDetails;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.DownloadNGAReportsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ReportsPageOperations;
import com.hqnRegression.util.CSVOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class B2CReports extends SeleniumImplementation{
	private WebDriver driver;
	public String CLASS_NAME = "B2CReports";
	
	private String IN_FILE = "B2CReports.csv";
	List<ReportDetails> reportDetailsList = null;
	ReportDetails reportDetails = null;


	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		reportDetailsList = CSVOperations.readReportDetails(IN_FILE);
	}
	
	
	
	@Test
	public void testB2CReport(Method method) throws Throwable {

		try {
			reportDetails = reportDetailsList.get(0);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			ReportsPageOperations reportsPageOperations = homePageOperations
					.clickReportsTab(CLASS_NAME, method.getName());

			DownloadNGAReportsPageOperations downloadB2BReportsPageOperations = reportsPageOperations.clickB2CReports1();
					downloadB2BReportsPageOperations.downloadB2CReports(reportDetails.getReportName(),reportDetails.getReportSchedule(), 
					reportDetails.getFrom_year(),
					reportDetails.getFrom_month(), reportDetails.getFrom_day(),
					reportDetails.getYear(),
					reportDetails.getMonth(), reportDetails.getDay(),
					CLASS_NAME, method.getName());

			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}
	}
	
	
	
	@AfterMethod
	public void tearDown(Method method) {
		//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		 //driver.close();
		 //driver.quit();

	}

	
	

}
