package com.bt.wlms.OrderPermission;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.CeaseDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CeasePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class withOrderPermission extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "withOrderPermission";

	private String IN_FILE = "CeaseDetails.csv";

	List<CeaseDetails> ecDetailsList = null;
	CeaseDetails beanDetails = null;
	Properties testProps = null;

	private int count = 0;
	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("withoutOrderPermission");

	public withOrderPermission() {
		PropertyConfigurator.configure(loggerPath);

	}

	/*
	 * @Rule public TestName name = new TestName();
	 */

	@BeforeMethod
	public void setUp() throws Exception {

		ecDetailsList = CSVOperation_New.readCeaseDetails(IN_FILE);

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		testProps = CommonMethods.readErrorMSGs(driver);
		if (ecDetailsList != null && ecDetailsList.size() > 0) {
			testCount = ecDetailsList.size();
		}
	}

	/**
	 * In the "Account Details" TAB click the "Cease" button to proceed with
	 * cease order
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testWithOrderPermission(Method method) throws IOException {

		try {

			logger.info(" Start Test-withOrderPermission: Start the withOrderPermission creation ");

			beanDetails = ecDetailsList.get(0);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.agentLogin(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(beanDetails.getOrderId(), "Order Number",
							CLASS_NAME, method.getName());
			String product = searchResultPageOperations
					.getProductForActiveOrder();

			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink();
			accountDetailsPageOperations.clickaccountDetailsTab(CLASS_NAME,
					method.getName());

			AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
					.clickCease(CLASS_NAME, method.getName());
			agentDetailsPageOperations.clickSameAgent();

			CeasePageOperations ceasePageOperations = agentDetailsPageOperations
					.clickNextForCease(CLASS_NAME, method.getName());

			/*
			 * ceasePageOperations.selectFutureCalendarDate(CLASS_NAME,
			 * method.getName(), CeaseDetails.getOffset());
			 */

			ceasePageOperations.selectActivateDate();
			ceasePageOperations.ceasonReason(beanDetails.getCeaseReason());

			/*OrderSummaryPageOperations orderSummaryPageOperations = ceasePageOperations
					.clickSubmit(CLASS_NAME, method.getName());
			orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

			OrderConfirmationPageOperations conform = orderSummaryPageOperations
					.confirmOrder(CLASS_NAME, method.getName());

			conform.clickComplete_Cease(CLASS_NAME, method.getName());

			String orderId = conform.getOrderId1();
			System.out.println("Order Id :" + orderId);
			accountDetailsPageOperations.checkOrderStatus(orderId, CLASS_NAME,
					method.getName());

			CommonMethods.logOut(driver, CLASS_NAME, method.getName());*/

			logger.info(" End Test - Cease_Aseet : End the Cease-Asset creation");

			try {
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"lastPageOperations" + ".png", driver, "end");
			} catch (IOException e) {
				e.printStackTrace();
			}

			logger.info(" End Test - withOrderPermission : End the withOrderPermission creation");

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do OrderPermission");

			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}

	}

	@AfterMethod
	public void tearDown() {
		// driver.close();
		// driver.quit();

	}

}
