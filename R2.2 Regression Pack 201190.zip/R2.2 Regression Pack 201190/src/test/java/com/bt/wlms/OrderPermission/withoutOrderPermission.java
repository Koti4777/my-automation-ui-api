package com.bt.wlms.OrderPermission;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.pages.EditCustomerDetailsPage;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.EditCustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class withoutOrderPermission extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "withoutOrderPermission";

	private String IN_FILE = "EditCustomerDetails.csv";

	List<AssetBeanDetails> ecDetailsList = null;
	AssetBeanDetails beanDetails = null;
	Properties testProps = null;

	private int count = 0;
	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("withoutOrderPermission");

	public withoutOrderPermission() {
		PropertyConfigurator.configure(loggerPath);

	}

	/**
	 * In the AccountDetailsPage click on "Edit Customer Account details" and
	 * perform some changes and click on "Save" button
	 * 
	 * @param method
	 * @throws IOException
	 */

	@BeforeMethod
	public void setUp() throws Exception {

		// ecDetailsList = CSVOperation_New.readAssetDetails(IN_FILE);
		ecDetailsList = CSVOperation_New.readEditCustomerDetails(IN_FILE);

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		testProps = CommonMethods.readErrorMSGs(driver);
		if (ecDetailsList != null && ecDetailsList.size() > 0) {
			testCount = ecDetailsList.size();
		}
	}

	/*
	 * 
	 * @Rule public TestName name = new TestName();
	 */
	@Test
	public void testWithoutOrderPermission(Method method) throws IOException {

		try {

			logger.info(" Start Test-withoutOrderPermission: Start the withoutOrderPermission creation ");

			beanDetails = ecDetailsList.get(0);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.agentLogin(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(beanDetails.getOrderId(), "Order Number",
							CLASS_NAME, method.getName());
			String product = searchResultPageOperations
					.getProductForActiveOrder();

			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink();
			accountDetailsPageOperations.clickaccountDetailsTab(CLASS_NAME,
					method.getName());

			EditCustomerDetailsPageOperations editCustomerDetailsPageOperations = accountDetailsPageOperations
					.clickEditCustomerAccountDetails(CLASS_NAME,
							method.getName());

			editCustomerDetailsPageOperations.fillEditwithoutDetails(
					beanDetails.getSalutation(), beanDetails.getFirstName(),
					beanDetails.getSurName(), beanDetails.getTelephoneNumber(),
					beanDetails.getMobileNumber(),
					beanDetails.getAdditionalTelephoneNumber(),
					beanDetails.getEmailAddress(), beanDetails.getPostCode(),
					beanDetails.getPremisesName(), beanDetails.getStreetName(),
					beanDetails.getTown(), beanDetails.getNotificationBy(),
					beanDetails.getCountry(), beanDetails.getNewPassword(),
					beanDetails.getConfirmPassword(), CLASS_NAME,
					method.getName());

			EditCustomerDetailsPage editDetailsPage = new EditCustomerDetailsPage(
					driver);
			accountDetailsPageOperations = editCustomerDetailsPageOperations
					.clickSave(CLASS_NAME, method.getName());

			try {
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"lastPageOperations" + ".png", driver, "end");
			} catch (IOException e) {
				e.printStackTrace();
			}

			logger.info(" End Test - withoutOrderPermission : End the withoutOrderPermission creation");

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do OrderPermission");

			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}

	}

	@AfterMethod
	public void tearDown() {
		// driver.close();
		// driver.quit();

	}

}
