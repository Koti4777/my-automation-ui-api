package com.bt.wlms.PhoneFault;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.BBAppointmentDetailsPageOperations;
import com.hqnRegression.pages.operations.BBFaultCheckerPageOperations;
import com.hqnRegression.pages.operations.BBReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CPEDiagnosticCheckReportPageOperation;
import com.hqnRegression.pages.operations.CheckDetailsPageOperations;
import com.hqnRegression.pages.operations.ContactPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.QuestionsPageOperations;
import com.hqnRegression.pages.operations.RadiusCheckPageOperation;
import com.hqnRegression.pages.operations.RaiseSpecialFaultPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Braodband_SpecialFault extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "Braodband_SpecialFault";

	private String IN_FILE = "BroadBandSpecialFault.csv";
	List<WLRFaultCareLevel> bBandSpecialFaults = new ArrayList<WLRFaultCareLevel>();
	WLRFaultCareLevel bBandSpecialFault;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Braodband_SpecialFault");

	public Braodband_SpecialFault() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		bBandSpecialFaults = CSVOperation_New.readBBandSpecialFault(IN_FILE);
		if (bBandSpecialFaults != null && bBandSpecialFaults.size() > 0) {
			testCount = bBandSpecialFaults.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * This method raise a broadband Special fault
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testCreateBbandSpecialFault(Method method) throws IOException {
		logger.info(":	start the testCreateBroadbandSpecialFault");

		while (count < testCount) {

			try {

				logger.info(" Start Test-Special Fault : Start the Create Special Fault creation ");

				bBandSpecialFault = bBandSpecialFaults.get(count);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(bBandSpecialFault.getSearchBy(),
								bBandSpecialFault.getSearchValue(), CLASS_NAME,
								method.getName());
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				accountDetailsPageOperations.clickBroadbandTab1(CLASS_NAME,
						method.getName());
				BBFaultCheckerPageOperations bbFaultCheckerPageOperations = accountDetailsPageOperations
						.clickBroadBandFaultCheckerLink(CLASS_NAME,
								method.getName());

				bbFaultCheckerPageOperations.broadBandFaultChecker(
						bBandSpecialFault.getTicketSubtypeID(),
						bBandSpecialFault.getChannelId(), method.getName(),
						CLASS_NAME);

				CPEDiagnosticCheckReportPageOperation preCheck = bbFaultCheckerPageOperations
						.clickBbContinue(CLASS_NAME, method.getName());

				RadiusCheckPageOperation radious = preCheck.clickContinue(
						CLASS_NAME, method.getName());
				ContactPageOperations contact = radious.clickContinue(
						CLASS_NAME, method.getName());

				QuestionsPageOperations questions = contact
						.clickStartConnectionCheck(CLASS_NAME, method.getName());
				CheckDetailsPageOperations check = questions.clickSubmitFaultQuestions(
						CLASS_NAME, method.getName());
				RaiseSpecialFaultPageOperations specialFault = check
						.clickRaiseSpecialFaulte(CLASS_NAME, method.getName());

				specialFault.selectCharges(bBandSpecialFault.getWaiveCharge(),
						bBandSpecialFault.getAcceptCharge(), CLASS_NAME,
						method.getName());

				BBReserveAppointmentPageOperations reserveAppointmentPageOperations = specialFault
						.clickNext(CLASS_NAME, method.getName());

				reserveAppointmentPageOperations.selectActivateDate();

				reserveAppointmentPageOperations.clickReRequestAppointment(
						CLASS_NAME, method.getName());

				reserveAppointmentPageOperations
						.selectFirstAvailableAppointmentDate();

				BBAppointmentDetailsPageOperations appointment = reserveAppointmentPageOperations
						.clickReserveAppointmentButton(CLASS_NAME,
								method.getName());

				appointment.fillAccessAvailability(bBandSpecialFault
						.getAccessAvailability());
				appointment.fillAccessNotes(bBandSpecialFault.getAccessNotes());
				appointment.fillHazardNotes(bBandSpecialFault.getHazardNotes());
				appointment.fillContactTime(bBandSpecialFault.getContactTime());

				appointment.clickSubmitSPFault(CLASS_NAME, method.getName());

				logger.info(":	end the testCreateBroadbandFault");
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to do Special Fault BroadBand Asset");
				logger.info(":	end the testCreateBroadbandFault");

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();

	}

}
