package com.bt.wlms.PhoneFault;

import java.io.IOException;
import java.lang.reflect.Method;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.TakeControl_Resolve;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.ChangePoolPageOperation;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ResolvePageOperation;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.TakeControlPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Fault_resolve extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "AccountDetails_ResolveTicket";

	private String IN_FILE = "AccountDetails_ResolveTicket.csv";
	private static Logger logger = Logger.getLogger("testFault_amend");

	List<TakeControl_Resolve> AccountDetails_ResolveTicketList = null;
	TakeControl_Resolve AccountDetails_ResolveTicket = null;

	private int testCount = 0;
	private int count = 0;

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		AccountDetails_ResolveTicketList = CSVOperation_New
				.readCPEDetails_Resolve(IN_FILE);

		if (AccountDetails_ResolveTicketList != null
				&& AccountDetails_ResolveTicketList.size() > 0) {
			testCount = AccountDetails_ResolveTicketList.size();
		}

	}

	/**
	 * this method resolve the Fault
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testFault_Resolve(Method method) throws IOException {

		logger.info(":	start the testFault_Resolve");

		try {
			AccountDetails_ResolveTicket = AccountDetails_ResolveTicketList
					.get(count);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(AccountDetails_ResolveTicket.getFoid(),
							"Order Number", CLASS_NAME, method.getName());

			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink();

			accountDetailsPageOperations.clickticketsTab(CLASS_NAME,
					method.getName());
			accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME,
					method.getName());
			String resolve = null;
			try {
				resolve = accountDetailsPageOperations.getTakeControl()
						.getText();
			} catch (Exception e) {

				e.printStackTrace();
			}

			if ("Take Control".equalsIgnoreCase(resolve)) {

				TakeControlPageOperations takeControlPageOperations = accountDetailsPageOperations
						.clickTakeControl(CLASS_NAME, method.getName());

				String name = driver.getWindowHandle();

				accountDetailsPageOperations = takeControlPageOperations
						.clickOperation(TakeControl_Resolve.getInternalNotes(),
								CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
						method.getName());
				accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME,
						method.getName());

			}

			ChangePoolPageOperation changePoolPageOperation = accountDetailsPageOperations
					.clickChangePool(CLASS_NAME, method.getName());

			changePoolPageOperation.fillTicketDetails(
					AccountDetails_ResolveTicket.getTicketType(),
					AccountDetails_ResolveTicket.getSubType(),
					AccountDetails_ResolveTicket.getPool(),
					AccountDetails_ResolveTicket.getComments(), CLASS_NAME,
					method.getName());
			changePoolPageOperation.clickAllocateButton(CLASS_NAME,
					method.getName());
			accountDetailsPageOperations.clickticketsTab(CLASS_NAME,
					method.getName());
			accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME,
					method.getName());

			ResolvePageOperation resolvePageOperations = accountDetailsPageOperations
					.clickResolve(CLASS_NAME, method.getName());

			String name2 = driver.getWindowHandle();

			resolvePageOperations.clickResolveOperation(
					TakeControl_Resolve.getInternalNotes(),
					TakeControl_Resolve.getClearCode(), CLASS_NAME,
					method.getName());
			accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
					method.getName());
			logger.info(":	End the testFault_Resolve");
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();

	}
}