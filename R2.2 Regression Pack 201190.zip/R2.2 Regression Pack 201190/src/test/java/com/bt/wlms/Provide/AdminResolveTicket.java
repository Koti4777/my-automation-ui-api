package com.bt.wlms.Provide;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.TakeControl_Resolve;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.ChangePoolPageOperation;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ResolvePageOperation;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.TakeControlPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
/**
 * 
 * @author GopiKrishnaG
 * AccountDetails_ResolveTicketPage Operation.This class is dealing with negative
 * field validation for Ticket resolve Operation. Objective of this
 * class is to achieve validation for incorrect input.
  */
public class AdminResolveTicket extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "AccountDetails_ResolveTicket";

	private String IN_FILE = "AccountDetails_ResolveTicket.csv";

	List<TakeControl_Resolve> AccountDetails_ResolveTicketList = null;
	TakeControl_Resolve AccountDetails_ResolveTicket = null;

	private int testCount = 0;
	private int count = 0;
	Properties testProps = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("ResolveTicket");
	
	public AdminResolveTicket()
	{
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		AccountDetails_ResolveTicketList = CSVOperation_New
				.readCPEDetails_Resolve(IN_FILE);

		if (AccountDetails_ResolveTicketList != null
				&& AccountDetails_ResolveTicketList.size() > 0) {
			testCount = AccountDetails_ResolveTicketList.size();
		}
		testProps = CommonMethods.readErrorMSGs(driver);
	}
/**
 * Validation for Internal Notes field.
 * @param method
 * @throws IOException
 */
	@Test
	public void testInterNotes_ResolveTicket(Method method) throws IOException {

		try {
			
			logger.info(" Start AccountDetails_ResolveTicket : testInterNotes_ResolveTicket");
			AccountDetails_ResolveTicket = AccountDetails_ResolveTicketList
					.get(0);
			

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(AccountDetails_ResolveTicket.getFoid(),
							"Order Number", CLASS_NAME, method.getName());

			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink();

			accountDetailsPageOperations.clickTicketsTab(CLASS_NAME, method
					.getName());
			accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME, method
					.getName());
			TakeControlPageOperations takeControlPageOperations = accountDetailsPageOperations
					.clickRequestControl(CLASS_NAME, method.getName());

			String name = driver.getWindowHandle();
			

			takeControlPageOperations.clickOperation(TakeControl_Resolve
					.getInternalNotes(), CLASS_NAME, method.getName());

			accountDetailsPageOperations.clickRefreshTab(CLASS_NAME, method
					.getName());
			accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME, method
					.getName());

			/*ChangePoolPageOperation changePoolPageOperation = accountDetailsPageOperations
					.clickChangePool(CLASS_NAME, method.getName());

			changePoolPageOperation.fillTicketDetails(
					AccountDetails_ResolveTicket.getTicketType(),
					AccountDetails_ResolveTicket.getSubType(),
					AccountDetails_ResolveTicket.getPool(),
					AccountDetails_ResolveTicket.getComments(), CLASS_NAME,
					method.getName());
			accountDetailsPageOperations = changePoolPageOperation
					.clickAllocateButton(CLASS_NAME, method.getName());
			accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME, method
					.getName());

			ResolvePageOperation resolvePageOperations = accountDetailsPageOperations
					.clickResolve(CLASS_NAME, method.getName());*/

		/*	String name2 = driver.getWindowHandle();
			

			resolvePageOperations.clickResolveOperation(TakeControl_Resolve
					.getInternalResolveNotes(), TakeControl_Resolve
					.getClearCode(), CLASS_NAME, method.getName());*/

			/*if ("".equalsIgnoreCase(TakeControl_Resolve
					.getInternalResolveNotes())) {
				logger.info(" Negative Field Validation :testinternalnotes_ErrorMsg");
				Assert.assertEquals(testProps.get("testinternalnotes_ErrorMsg"),
						resolvePageOperations.getClearCodeError().getText(),
						"Error message coming as differently");
			}*/

		}

		catch (Exception e) {
			e.printStackTrace();
		}
		//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		logger.info(" Start AccountDetails_ResolveTicket : testInterNotes_ResolveTicket");
	}

	

@AfterMethod
public void tearDown() {

/*	driver.close();
	driver.quit();
*/
}
}


