package com.bt.wlms.Provide;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.CeaseDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
 
public class CRQ162790_TC024 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "CRQ162790_TC004";

	private String IN_FILE = "CRQ162790_TC001.csv";
	List<CeaseDetails> bbDetailsList = null;
	CeaseDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	private int orderid = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("B2BReports");


	public CRQ162790_TC024() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readCeaseDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		

	}

	@Test
	public void testStandardprofile(Method method) throws IOException {
		
		while (count < testCount) {

			order = new Order();

			try {
				logger.info(" Start Test-testStandardprofile : Start the testStandardprofile ");

				assetBeanDetails = bbDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.searchBtoc(assetBeanDetails.getOrderId(), "Order Number","B2C",
								CLASS_NAME, method.getName());
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink();
				
				accountDetailsPageOperations.clickBroadbandUsageTab(CLASS_NAME, method.getName());
				
				
			//	CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.info(" End Test - testTopup : End the testTopup creation");

			} catch (Exception e) {
				e.printStackTrace();
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.error("Unable to testStandardprofile "
						+ assetBeanDetails.getOrderId());

			}
			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

		/*driver.close();
		driver.quit();
		logger.info(",Cease_Asset,pass");*/
	}

}
