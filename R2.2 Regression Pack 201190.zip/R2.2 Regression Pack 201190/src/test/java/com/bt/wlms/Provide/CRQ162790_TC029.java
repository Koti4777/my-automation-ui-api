

package com.bt.wlms.Provide;


import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.BroadBandUsagePageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PurchageTopUpConfirmPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.TopUpDetailsPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class CRQ162790_TC029 extends SeleniumImplementation
 {

	
	private WebDriver driver;
	public String CLASS_NAME = "CRQ162790_TC029";

	private String IN_FILE = "CRQ162790_TC029.csv";
	List<CPEDetails> orderDetailsList = new ArrayList<CPEDetails>();
	CPEDetails orderDetails;
	
	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ150025_TC014");
	
	public CRQ162790_TC029()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		
	
	
	
	@BeforeMethod
	public void setUp() throws Exception 
	{

		orderDetailsList = CSVOperation_New.readCPEDetails(IN_FILE);

		if (orderDetailsList != null && orderDetailsList.size() > 0) 
		{
			testCount = orderDetailsList.size();
		}

	
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	
	/**
	 * expand ticket tab
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testCRQ162790_TC029(Method method) throws IOException {

      
		while (count < testCount) {
			try
			{
				logger.info(" Start Test-Expand Ticket : Start the Expand Ticket ");

				orderDetails = orderDetailsList.get(count);


				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				/*SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(orderDetails.getOrderId(), "Order Number",
								CLASS_NAME, method.getName());*/
				
				
				SearchResultPageOperations searchResultPageOperations = homePageOperations

                .searchT2(orderDetails.getOrderId(),"B2C","Order Number", CLASS_NAME,

                                method.getName());


				
				/*SearchResultPageOperations searchResultPageOperations = homePageOperations
				.searchBtoc(orderDetails.getOrderId(), "Order Number","B2C",
						CLASS_NAME, method.getName());*/
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickBBTab(CLASS_NAME,

		                method.getName());
				BroadBandUsagePageOperations broadBandUsagePageOperations = accountDetailsPageOperations.clickBroadbandUsage(CLASS_NAME,
						method.getName());
				TopUpDetailsPageOperations topUpDetailsPageOperations = broadBandUsagePageOperations.clickTopUpBroadband(CLASS_NAME,method.getName());
				
				PurchageTopUpConfirmPageOperations   purchageTopUpConfirmPageOperations  = topUpDetailsPageOperations
			.clickTopUpFeeForAdditionalDataUsage(CLASS_NAME,method.getName());
				
				
				 purchageTopUpConfirmPageOperations  = topUpDetailsPageOperations
				.clickNext(CLASS_NAME,method.getName());
				
				
				purchageTopUpConfirmPageOperations.clickConfirm(CLASS_NAME,method.getName());
				 
				//purchageTopUpConfirmPageOperations.clickComplete  (CLASS_NAME,method.getName());
				
                logger.info(" End Test-Expand Ticket : End the Expand Ticket ");
                
                // CommonMethods.logOut(driver, CLASS_NAME, method.getName());
         		
			}
			catch (Exception e) {
				e.printStackTrace();
					}   
			
			logger.error("Unable to click the requestControl link" + orderDetails.getFoid());
			count++;
		}
	
   }
	@AfterMethod
	public void tearDown() {
		//driver.close();
		//driver.quit();

	}

}
	

























