package com.bt.wlms.Provide;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * 
 * @author asimks
 * 
 */

public class HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL";

	private String IN_FILE = "SOSL_WLTO_NGADetails.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	String serviceId;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL");

	public HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL()
	{
		PropertyConfigurator.configure(loggerPath);
	}

	/*
	 * @Rule public TestName name = new TestName();
	 */

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		bbDetailsList = CSVOperation_New.readAssetDetails_HQN_TC_SPC1325_S14C15_UC_0186(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
	}

	/**
	 * Objective of the method: To place a Provide order with WLTO for Business
	 * Essential NGA BB + Calls 40:10 product. To lookup address from postcode
	 * To verify the address details and opt suitable address selection To
	 * choose suitable product from the applicable product offerings To include
	 * Managed Installation Modules
	 */

	@Test
	public void testCreate_HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL(Method method) throws IOException {

		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL : Start the HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL creation ");

				assetBeanDetails = bbDetailsList.get(0);

				LoginPageOperations loginPageOperations = CMCHomePageOperations.navigateTo(driver);

				HomePageOperations homePageOperations = loginPageOperations.adminLogin(CLASS_NAME, method.getName());

				//RegisterNewServicePageOperations servicePageOperations = homePageOperations.clickBusinessCustomer();
				RegisterNewServicePageOperations servicePageOperations = homePageOperations.CreateASiteForExistingAccount();

				CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations.searchByBusinessAccountName(assetBeanDetails.getBusinessAccount(), CLASS_NAME, method.getName());

				CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations.clickBusinessAccount(assetBeanDetails.getBusinessAccount());

				LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations.clickAddSite(CLASS_NAME, method.getName());

				LineCheckResultPageOperations lineCheckResultPageOperations = null;

				if ("".equalsIgnoreCase(assetBeanDetails.getLandlinePhone())) 
				{
					AddressSelectionPageOperations addressSelectionPageOperations = lineDetailsPageOperations.createSiteWithPostCodeOnly(
							assetBeanDetails.getNewSite(), 
							assetBeanDetails.getLandlinePhone(),
							assetBeanDetails.getPostCode(), 
							assetBeanDetails.getAddressValue(), 
							assetBeanDetails.getPremisesName(),
							assetBeanDetails.getStreetName(), 
							assetBeanDetails.getTown(),
							assetBeanDetails.getCountry(),
							CLASS_NAME, method.getName());

					lineCheckResultPageOperations = addressSelectionPageOperations.clickAddressDetailsTab(CLASS_NAME, method.getName());

					lineCheckResultPageOperations = addressSelectionPageOperations.clickLinePlantInformationTab(CLASS_NAME, method.getName());

					lineCheckResultPageOperations = addressSelectionPageOperations.clickStoppedLinestab(CLASS_NAME, method.getName());

					if (assetBeanDetails.getPropositionWLTO().contains("Working Lines")) 
					{
						lineCheckResultPageOperations = addressSelectionPageOperations.clickWorkingLineTab(CLASS_NAME, method.getName());

						if (assetBeanDetails.getServiceId().contains("serviceId")|| serviceId != null || serviceId != "") 
						{
							lineCheckResultPageOperations.selectWorkingLinesByName(assetBeanDetails.getServiceId());
						}

						if (serviceId == null || serviceId == "") 
						{
							lineCheckResultPageOperations.clickWorkingLineOptions(CLASS_NAME, method.getName());
						}
					}

					else if (assetBeanDetails.getPropositionSOSL().contains("Stopped Lines")) 
					{			
						lineCheckResultPageOperations = addressSelectionPageOperations.clickStoppedLinestab(CLASS_NAME, method.getName());

						if (assetBeanDetails.getServiceId().contains("serviceId") || serviceId != null || serviceId != "") 
						{
							lineCheckResultPageOperations.selectStoppedLinesByName(assetBeanDetails.getServiceId());
						}

						if (serviceId == null || serviceId == "")
						{
							lineCheckResultPageOperations.clickStoppedLineOptions(CLASS_NAME, method.getName());
						}
					}

					lineCheckResultPageOperations = addressSelectionPageOperations.submitAddressButton(CLASS_NAME, method.getName());
				} 
				
				else 
				{
					lineCheckResultPageOperations = lineDetailsPageOperations.createSiteWithPostCodeAndPremisesDetails(
									assetBeanDetails.getNewSite(),
									assetBeanDetails.getLandlinePhone(),
									assetBeanDetails.getPostCode(),
									assetBeanDetails.getAddressValue(),
									assetBeanDetails.getPremisesName(),
									assetBeanDetails.getStreetName(),
									assetBeanDetails.getTown(),
									assetBeanDetails.getCountry(), CLASS_NAME,
									method.getName());
				}
				lineCheckResultPageOperations.selectPropositionByName(assetBeanDetails.getProposition());

				AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations.clickNext(CLASS_NAME, method.getName());

				AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations.submit(CLASS_NAME, method.getName());

				ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations.submit(CLASS_NAME, method.getName());

				productDetailsPageOperations.selectProductOffering_Asset(
						assetBeanDetails.getProposition(), 
						assetBeanDetails.getBroadbandCare(), 
						assetBeanDetails.getRouter(), 
						assetBeanDetails.getBusinessRateCard(), 
						assetBeanDetails.getCalls(), 
						assetBeanDetails.getCarelevel(),
						assetBeanDetails.getSelectcalls(),
						assetBeanDetails.getContract(), 
						assetBeanDetails.getOneOffCharge(), 
						assetBeanDetails.getRateCardDiscount(), 
						assetBeanDetails.getSalesPromotion(), 
						assetBeanDetails.getCustomerDiscount(), 
						assetBeanDetails.getPostCode(), 
						assetBeanDetails.getTitle(),
						assetBeanDetails.getFirstName(), 
						assetBeanDetails.getSurName(), 
						assetBeanDetails.getServiceId(),
						assetBeanDetails.getDdiRangeNum(),
						assetBeanDetails.getSddirangeNum(), 
						assetBeanDetails.getManagedInstall(), 
						assetBeanDetails.getBroadbandFeatures(), 
						CLASS_NAME, 
						method.getName());

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				if (productDetailsPageOperations.isHardwarepageAvailable)
				{
					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations.clickNextForHardware(CLASS_NAME, method.getName());
					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations	.clickNext(CLASS_NAME, method.getName());
				}
				
				else
				{
					appointmentManagementPageOperations = productDetailsPageOperations.clickNextForCRD(CLASS_NAME, method.getName());
				}

				appointmentManagementPageOperations.selectFutureCalendarDate(CLASS_NAME, method.getName(), 16);

				boolean isPresent = appointmentManagementPageOperations.isVoiceAppointmentButtonPresent();

				if (isPresent) 
				{
					appointmentManagementPageOperations.fillVoiceAppointmentManagementFields(assetBeanDetails.getEngineeringNotes());
					
					if (assetBeanDetails.getIncludeOutofHours().equalsIgnoreCase("yes"))
					{
						appointmentManagementPageOperations.clickOutOfHoursAppointment();
					}
					ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations.clickAvailableAppointmentButton();

					reserveAppointmentPageOperations.selectFirstAvailableAppointmentDate();

					if (assetBeanDetails.getIncludeOutofHours().equalsIgnoreCase("yes"))
					{
						if (assetBeanDetails.getAppointmentCharges().contains("Accept additional"))
						{
							reserveAppointmentPageOperations.clickAcceptAdditionalCharges();
						}
						if (assetBeanDetails.getAppointmentCharges().contains("both")) 
						{
							reserveAppointmentPageOperations.clickAcceptAdditionalCharges();
							reserveAppointmentPageOperations.getWaiveAdditionalCharges();
						} 
						else {
							reserveAppointmentPageOperations.getWaiveAdditionalCharges();
						}
					}

					appointmentManagementPageOperations = reserveAppointmentPageOperations.clickReserveAppointmentButton(CLASS_NAME, method.getName());
				}

				FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations.fillBBFTTCAppointmentManagement(CLASS_NAME, method.getName());
				fttcAvailableAppointmentsPageOperations.selectFirstAvailableAppointmentDate();
				appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations.clickReserveAppointmentButton(CLASS_NAME, method.getName());

				if (assetBeanDetails.getProposition().contains("Superfast")|| assetBeanDetails.getProposition().contains("Line"))
				{
					appointmentManagementPageOperations.fillHealthAndsafetyVeificationFields(assetBeanDetails.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(assetBeanDetails.getCommunicationBy());

				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());

				String orderId = orderConfirmationPageOperations.getOrderId();
				System.out.println("Order id is"  + orderId);

				homePageOperations = orderConfirmationPageOperations.clickCompleteOrderButton(CLASS_NAME, method.getName());
				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(orderId, "Order Number",
								CLASS_NAME, method.getName());
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink1();

				try {
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),"lastPageOperations" + ".png", driver, "end");
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
				logger.info(" End Test-HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL : Start the HQN_TC_SPC1325_S14C15_UC_0186_NGA_WLTO_SOSL creation ");

			} 
			catch (Exception e) {
				try {
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),"lastPageOperations" + ".png", driver, "end");
					} 
				catch (IOException ex) {
					ex.printStackTrace();
				}
				e.printStackTrace();
				logger.error("Unable to place the order");
			}
			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();

	}

}
