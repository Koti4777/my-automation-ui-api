package com.bt.wlms.Provide;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * 
 * @author asimks
 *
 */



public class HQN_TC_SPC1325_S14C15_UC_0282_041 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "HQN_TC_SPC1325_S14C15_UC_0282_041";

	private String IN_FILE = "NGADetails.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("HQN_TC_SPC1325_S14C15_UC_0282_041");

	public HQN_TC_SPC1325_S14C15_UC_0282_041() {
		PropertyConfigurator.configure(loggerPath);
	}

	/*
	 * @Rule public TestName name = new TestName();
	 */

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readAssetDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}

	}

	
	/**
	 * Objective of the method: 
	 * Checking Bolt-On related Charges for B2C Customer-
	 * with the Blot-on proposition - Superfast Broadband 40:2 with upstream speed
	 * bolt-on and Off Peak Calls
	 */
	
	@Test
	public void testCreate_HQN_TC_SPC1325_S14C15_UC_0282_041(Method method)
			throws IOException {

		System.out.println("method name is --->" + method.getName());

		try {

			logger.info(" Start Test-HQN_TC_SPC1325 : Start the HQN_TC_SPC1325 creation ");

			assetBeanDetails = bbDetailsList.get(7);

			driver = createBrowserInstance(BrowserType.FIREFOX);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			RegisterNewServicePageOperations servicePageOperations = homePageOperations
					.clickBusinessCustomer();

			CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
					.searchByBusinessAccountName(
							assetBeanDetails.getBusinessAccount(), CLASS_NAME,
							method.getName());

			CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
					.clickBusinessAccount(assetBeanDetails.getBusinessAccount());

			LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
					.clickAddSite(CLASS_NAME, method.getName());

			LineCheckResultPageOperations lineCheckResultPageOperations = null;

			if ("".equalsIgnoreCase(assetBeanDetails.getLandlinePhone())) {

				AddressSelectionPageOperations addressSelectionPageOperations = lineDetailsPageOperations
						.createSiteWithPostCodeOnly(
								assetBeanDetails.getNewSite(),
								assetBeanDetails.getLandlinePhone(),
								assetBeanDetails.getPostCode(),
								assetBeanDetails.getAddressValue(),
								assetBeanDetails.getPremisesName(),
								assetBeanDetails.getStreetName(),
								assetBeanDetails.getTown(),
								assetBeanDetails.getCountry(), CLASS_NAME,
								method.getName());

				lineCheckResultPageOperations = addressSelectionPageOperations
						.submitAddressButton(CLASS_NAME, method.getName());
			} else {

				lineCheckResultPageOperations = lineDetailsPageOperations
						.createSiteWithPostCodeAndPremisesDetails(
								assetBeanDetails.getNewSite(),
								assetBeanDetails.getLandlinePhone(),
								assetBeanDetails.getPostCode(),
								assetBeanDetails.getAddressValue(),
								assetBeanDetails.getPremisesName(),
								assetBeanDetails.getStreetName(),
								assetBeanDetails.getTown(),
								assetBeanDetails.getCountry(), CLASS_NAME,
								method.getName());

			}

			lineCheckResultPageOperations
					.selectPropositionByName(assetBeanDetails.getProposition());

			AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
					.clickNext(CLASS_NAME, method.getName());

			AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
					.submit(CLASS_NAME, method.getName());

			ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
					.submit(CLASS_NAME, method.getName());

			productDetailsPageOperations.selectProductOffering_Asset(
					assetBeanDetails.getProposition(),
					assetBeanDetails.getBroadbandCare(),
					assetBeanDetails.getRouter(),
					assetBeanDetails.getBusinessRateCard(),
					assetBeanDetails.getCalls(),
					assetBeanDetails.getCarelevel(),
					assetBeanDetails.getSelectcalls(),
					assetBeanDetails.getContract(),
					assetBeanDetails.getOneOffCharge(),
					assetBeanDetails.getRateCardDiscount(),
					assetBeanDetails.getSalesPromotion(),
					assetBeanDetails.getCustomerDiscount(),
					assetBeanDetails.getPostCode(),
					assetBeanDetails.getTitle(),
					assetBeanDetails.getFirstName(),
					assetBeanDetails.getSurName(),
					assetBeanDetails.getServiceId(),
					assetBeanDetails.getDdiRangeNum(),
					assetBeanDetails.getSddirangeNum(),
					assetBeanDetails.getBroadbandFeatures(),
					assetBeanDetails.getManagedInstall(), CLASS_NAME,
					method.getName());

			CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
			HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

			if (productDetailsPageOperations.isHardwarepageAvailable) {

				hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
						.clickNextForHardware(CLASS_NAME, method.getName());

				appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
						.clickNext(CLASS_NAME, method.getName());
			} else {

				appointmentManagementPageOperations = productDetailsPageOperations
						.clickNextForCRD(CLASS_NAME, method.getName());
			}

			appointmentManagementPageOperations.selectFutureCalendarDate(
					CLASS_NAME, method.getName(), 11);

			boolean isPresent = appointmentManagementPageOperations
					.isVoiceAppointmentButtonPresent();

			if (isPresent) {
				appointmentManagementPageOperations
						.fillVoiceAppointmentManagementFields(assetBeanDetails
								.getEngineeringNotes());
				if (assetBeanDetails.getIncludeOutofHours().equalsIgnoreCase(
						"yes")) {
					appointmentManagementPageOperations
							.clickOutOfHoursAppointment();
				}

				ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
						.clickAvailableAppointmentButton();

				reserveAppointmentPageOperations
						.selectFirstAvailableAppointmentDate();

				if (assetBeanDetails.getIncludeOutofHours().equalsIgnoreCase(
						"yes")) {
					if (assetBeanDetails.getAppointmentCharges().contains(
							"Accept additional")) {
						reserveAppointmentPageOperations
								.clickAcceptAdditionalCharges();
					}
					if (assetBeanDetails.getAppointmentCharges().contains(
							"both")) {
						reserveAppointmentPageOperations
								.clickAcceptAdditionalCharges();
						reserveAppointmentPageOperations
								.getWaiveAdditionalCharges();
					} else {
						reserveAppointmentPageOperations
								.getWaiveAdditionalCharges();
					}
				}

				appointmentManagementPageOperations = reserveAppointmentPageOperations
						.clickReserveAppointmentButton(CLASS_NAME,
								method.getName());
			}

			FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
					.fillBBFTTCAppointmentManagement(CLASS_NAME,
							method.getName());
			fttcAvailableAppointmentsPageOperations
					.selectFirstAvailableAppointmentDate();
			appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
					.clickReserveAppointmentButton(CLASS_NAME, method.getName());

			if (assetBeanDetails.getProposition().contains("40:2")
					|| assetBeanDetails.getProposition().contains(
							"upstream speed bolt on and Off Peak Calls")) {

				System.out
						.println("Entering into Health and Safety Verification fields");
				appointmentManagementPageOperations
						.fillHealthAndsafetyVeificationFields(assetBeanDetails
								.getHealthAndSafetyNotes());

				System.out
						.println("Clicked on Customer Reported Notes check box--Health and Safety Verification fields");
			}

			OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
					.clickNext(CLASS_NAME, method.getName());

			orderSummaryPageOperations.selectCommunication(assetBeanDetails
					.getCommunicationBy());

			orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

			try {
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"lastPageOperations" + ".png", driver, "end");
			} catch (IOException e) {
				e.printStackTrace();
			}

			logger.info(" End Test-HQN_TC_SPC1325_S14C15_UC_0282_041 : End the HQN_TC_SPC1325_S14C15_UC_0282_041 creation ");

		} catch (Exception e) {
			try {
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"lastPageOperations" + ".png", driver, "end");
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			e.printStackTrace();
			logger.error("Unable to place the order");
		}

	}

	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

}
