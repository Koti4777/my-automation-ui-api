package com.bt.wlms.PushTicket;

import java.lang.reflect.Method;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.PushTicketDetails;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PushTicketPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class BCHCPushTicket extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "PushTicket";
	
	private String IN_FILE = "PushTicket.csv";
	List<PushTicketDetails> pushTicketDetailsList = null;
	PushTicketDetails pushTicketDetails = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("HCPushTicket");
	
	public BCHCPushTicket() {
		PropertyConfigurator.configure(loggerPath);
	}
	
	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		pushTicketDetailsList = CSVOperation_New.readPushTicketDetails(IN_FILE);
	}
	
   /**
    * This method is used for "Customer Type" Field should contains  both the following values
    *  "Home Customer", "Business Customer" and "Business Customer" should be displayed as default in the "Push Ticket" screen
    * @param method
    * @throws Throwable
    */
	@Test
	public void testBCHCPushTicket(Method method) throws Throwable {

		try {
			logger.info(" Start Test-BCHCPushTicket : Start the BCHCPushTicket creation ");

			pushTicketDetails = pushTicketDetailsList.get(2);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());
			PushTicketPageOperations pushTicketPageOperations= homePageOperations
					.clickCMCToolsTab(CLASS_NAME, method.getName());

			pushTicketPageOperations.PushTicket(pushTicketDetails.getCustomerType(),pushTicketDetails.getPool(), 
					pushTicketDetails.getWithInSLA(),pushTicketDetails.getTicketsWithUpdates(),pushTicketDetails.getTicketsWithCustomerResponse(),
					CLASS_NAME, method.getName());

			
		} catch (Exception e) {
			
			//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			logger.info(" End Test - BCHCPushTicket : End the BCHCPushTicket creation");
		}
	}
	
	
	
	@AfterMethod
	public void tearDown(Method method) {
		
		 //driver.close();
		 //driver.quit();
		logger.info(",PushTicket,pass");

	}

}
