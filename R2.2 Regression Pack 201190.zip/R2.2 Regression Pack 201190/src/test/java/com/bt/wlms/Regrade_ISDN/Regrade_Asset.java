package com.bt.wlms.Regrade_ISDN;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.ConfirmDNPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegradeOrderPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Regrade_Asset extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "Regrade_Asset";

	private String IN_FILE = "RegradeDetails.csv";
	List<AssetBeanDetails> bbDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Regrade_Asset");
	
	
	public Regrade_Asset()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		bbDetailsList = CSVOperation_New.readRegradeAssetDetails(IN_FILE);

		if (bbDetailsList != null && bbDetailsList.size() > 0) {
			testCount = bbDetailsList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testRegradeOrder(Method method) throws IOException {

      System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-Regrade_Asset : Start the Regrade_Asset creation ");

				assetBeanDetails = bbDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(assetBeanDetails.getSearchValue(),assetBeanDetails.getSearchBy() ,
								CLASS_NAME, method.getName());
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				AgentDetailsPageOperations agentDetailsPageOperations;
				if (!product.contains("Line") && !product.contains("Calls")) {
					ConfirmDNPageOperations confirmDNPageOperations = accountDetailsPageOperations
							.clickRegradeForConfirmDN(CLASS_NAME,
									method.getName());
					agentDetailsPageOperations = confirmDNPageOperations
							.clickContinue(CLASS_NAME, method.getName());
				} else {
					agentDetailsPageOperations = accountDetailsPageOperations
							.clickRegrade(CLASS_NAME, method.getName());
				}
				agentDetailsPageOperations.clickSameAgent();

				LineCheckResultPageOperations lineCheckResultPageOperations = agentDetailsPageOperations
						.clickNextForRegrade(CLASS_NAME, method.getName());

				RegradeOrderPageOperations regradeOrderPageOperations = lineCheckResultPageOperations
						.clickNextforRegrade(CLASS_NAME, method.getName());
				regradeOrderPageOperations.isPriceTitlePresent(CLASS_NAME,
						method.getName());
				regradeOrderPageOperations
						.selectPropositionByName(assetBeanDetails
								.getProposition());

				ProductDetailsPageOperations productDetailsPageOperations = regradeOrderPageOperations
						.clickNext(CLASS_NAME, method.getName());
				productDetailsPageOperations.isTotalPresent(CLASS_NAME, method.getName());
				productDetailsPageOperations.selectProductOffering_Asset(
						assetBeanDetails.getProposition(),
						assetBeanDetails.getBroadbandCare(),
						assetBeanDetails.getRouter(),
						assetBeanDetails.getBusinessRateCard(),
						assetBeanDetails.getCalls(),
						assetBeanDetails.getCarelevel(),
						assetBeanDetails.getSelectcalls(),
						assetBeanDetails.getContract(),
						assetBeanDetails.getOneOffCharge(),
						assetBeanDetails.getRateCardDiscount(),
						assetBeanDetails.getSalesPromotion(),
						assetBeanDetails.getCustomerDiscount(),
						assetBeanDetails.getPostCode(),
						assetBeanDetails.getTitle(),
						assetBeanDetails.getFirstName(),
						assetBeanDetails.getSurName(),
						assetBeanDetails.getServiceId(),
						assetBeanDetails.getDdiRangeNum(),
						assetBeanDetails.getSddirangeNum(),
						assetBeanDetails.getManagedInstall(), CLASS_NAME,
						method.getName(), product);

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				if (productDetailsPageOperations.isHardwarepageAvailable) {

					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
							.clickNextForHardware(CLASS_NAME,
									method.getName());

					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
							.clickNext(CLASS_NAME, method.getName());
				} else {

					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
				}

				appointmentManagementPageOperations.selectFutureCalendarDate(
						CLASS_NAME, method.getName(), 7);

				boolean isPresent = appointmentManagementPageOperations
						.isVoiceAppointmentButtonPresent();

				if (isPresent) {
					appointmentManagementPageOperations
							.fillVoiceAppointmentManagementFields(assetBeanDetails
									.getEngineeringNotes());
					if (assetBeanDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						appointmentManagementPageOperations
								.clickOutOfHoursAppointment();
					}

					ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
							.clickAvailableAppointmentButton();

					reserveAppointmentPageOperations
							.selectFirstAvailableAppointmentDate();

					if (assetBeanDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						if (assetBeanDetails.getAppointmentCharges().contains(
								"Accept additional")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
						}
						if (assetBeanDetails.getAppointmentCharges().contains(
								"both")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						} else {
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						}
					}

					appointmentManagementPageOperations = reserveAppointmentPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());
				}

				isPresent = appointmentManagementPageOperations
						.isFTTCAppointmentButtonPresent();

				if (isPresent) {

					FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
							.fillBBFTTCAppointmentManagement(CLASS_NAME,
									method.getName());
					fttcAvailableAppointmentsPageOperations
							.selectFirstAvailableAppointmentDate();
					appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());
				}

				if (assetBeanDetails.getProposition().contains("Call")
						|| assetBeanDetails.getProposition().contains("Line")
						|| product.contains("Call") || product.contains("Line")) {

					appointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(assetBeanDetails
									.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());
				//orderSummaryPageOperations.isTotalPricePresent(CLASS_NAME, method.getName());
				orderSummaryPageOperations.selectCommunication(assetBeanDetails
						.getCommunicationBy());
				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());
				
				orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME, method.getName());

				
			//	String orderId = orderConfirmationPageOperations.getOrderId();

			//	order.setLineSiteId(assetBeanDetails.getNewSite());

			//	order.setOrdeId(orderId);
				

				
				
				logger.info(" End Test-Regrade_Asset : End the Regrade_Asset creation ");

			} catch (Exception e) {
				e.printStackTrace();
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}   logger.error("Unable to regrade the orderid " + assetBeanDetails.getOrderId());
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		//driver.close();
		//driver.quit();

	}

}
