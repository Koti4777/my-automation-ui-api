package com.bt.wlms.Regression.CRQ158780;


import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CRQ158780_L2C_Modify_6 extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "Modify_Asset";

	private String IN_FILE = "Modify_CNF_ML_AUX.csv";
	List<AssetBeanDetails> modifyList = null;
	AssetBeanDetails modifyDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Modify_Asset");
	
	public CRQ158780_L2C_Modify_6()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	
	
	/*@Rule
	public TestName name = new TestName();
*/
	@BeforeMethod
	public void setUp() throws Exception {

		modifyList = CSVOperation_New.readModify_CNF_AUX(IN_FILE);

		if (modifyList != null && modifyList.size() > 0) {
			testCount = modifyList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testModifyOrder(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				 logger.info(" Start Test-Modify_Asset : Start the Modify_Asset creation ");

				modifyDetails = modifyList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());
				

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(modifyDetails.getOrderId(), "Order Number",
								CLASS_NAME, method.getName());
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
						.clickModify(CLASS_NAME, method.getName());

				agentDetailsPageOperations.clickSameAgent();
				ProductDetailsPageOperations productDetailsPageOperations = agentDetailsPageOperations
						.clickNextForModify(CLASS_NAME, method.getName());

				productDetailsPageOperations.selectProductOffering_Modify_CNF_ML_AUX(
						product, modifyDetails.getBroadbandCare(),
						modifyDetails.getRouter(),
						modifyDetails.getBusinessRateCard(),
						modifyDetails.getCalls(), modifyDetails.getCarelevel(),
						/*modifyDetails.getCnf(),
						modifyDetails.getPrice(),*/
						modifyDetails.getSelectcalls(),
						modifyDetails.getContract(),
						modifyDetails.getOneOffCharge(),
						modifyDetails.getRateCardDiscount(),
						modifyDetails.getSalesPromotion(),
						modifyDetails.getCustomerDiscount(),
						modifyDetails.getPostCode(), modifyDetails.getTitle(),
						modifyDetails.getFirstName(),
						modifyDetails.getSurName(),
						modifyDetails.getServiceId(),
						modifyDetails.getDdiRangeNum(),
						modifyDetails.getSddirangeNum(),
						modifyDetails.getManagedInstall(), CLASS_NAME,
						method.getName(), product);
				
				
				productDetailsPageOperations.SelectCNF(modifyDetails.getCnf(), modifyDetails.getPrice(),modifyDetails.getNumber(),modifyDetails.getCnfQuantity(), CLASS_NAME, method.getName());

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				if (productDetailsPageOperations.isHardwarepageAvailable) {

					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
							.clickNextForHardware(CLASS_NAME,
									method.getName());

					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
							.clickNext(CLASS_NAME, method.getName());
				} else {

					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
				}

				appointmentManagementPageOperations.selectFutureCalendarDate(
						CLASS_NAME, method.getName(), 1);

				appointmentManagementPageOperations
						.fillEngineerNotes(modifyDetails.getEngineeringNotes());

				if (product.contains("Call") || product.contains("Line")
						|| product.contains("40:") || product.contains("ISDN") || product.contains("Business") ) {

					appointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(modifyDetails
									.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(modifyDetails
						.getCommunicationBy());

				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());

				String orderId = orderConfirmationPageOperations.getOrderId();

				accountDetailsPageOperations = orderConfirmationPageOperations
						.clickCompleteModify(CLASS_NAME, method.getName());

				accountDetailsPageOperations.checkOrderStatus(orderId,
						CLASS_NAME, method.getName());

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				 logger.info(" End Test-Modify_Asset : End the Modify_Asset creation ");

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to modify the orderid " + modifyDetails.getOrderId());
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		//driver.close();
		//driver.quit();

	}

}
