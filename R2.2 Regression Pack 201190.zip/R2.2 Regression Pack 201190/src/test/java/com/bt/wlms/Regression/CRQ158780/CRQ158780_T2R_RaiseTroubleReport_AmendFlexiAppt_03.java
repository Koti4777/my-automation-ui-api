package com.bt.wlms.Regression.CRQ158780;


import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AppointmentAndContactManagementPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.ExpeditePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineTestPageOperations;
import com.hqnRegression.pages.operations.LineTestResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PhoneLineFaultCheckerPageOperations;
import com.hqnRegression.pages.operations.PhoneLineFaultPreCheckerPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.Wlr3FaultCreatedPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class CRQ158780_T2R_RaiseTroubleReport_AmendFlexiAppt_03 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "CRQ158780_T2R_RaiseTroubleReport_AmendFlexiAppt_03";

	private String IN_FILE = "MLAuxFault.csv";
	List<WLRFaultCareLevel> mlAuxFaultCareLevelList = new ArrayList<WLRFaultCareLevel>();
	WLRFaultCareLevel mlAuxFaultCareLevel;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CRQ158780_T2R_RaiseTroubleReport_AmendFlexiAppt_03");
	
	public CRQ158780_T2R_RaiseTroubleReport_AmendFlexiAppt_03()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	

	@BeforeMethod
	public void setUp() throws Exception {
		mlAuxFaultCareLevelList = CSVOperation_New.readmlAuxFaultCareLevel(IN_FILE);
		if (mlAuxFaultCareLevelList != null && mlAuxFaultCareLevelList.size() > 0) {
			testCount = mlAuxFaultCareLevelList.size();
		}
	}

	
	public void mock_fault(Method method) throws Exception {
		mlAuxFaultCareLevel = mlAuxFaultCareLevelList.get(0);
		// Intializing IE browser to login to cvf portal to create mock
		WebDriver driverN = createBrowserInstance(BrowserType.FIREFOX);
		CommonMethods.mockFaultMLAUX(driverN, mlAuxFaultCareLevel.getNumToMock(),
				CLASS_NAME, method.getName());
		driverN.close();
	}
	

	@Test
	public void testCRQ158780_T2R_RaiseTroubleReport_AmendFlexiAppt_03(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				 logger.info(" Start Test-Fault_PhoneLine_Asset : Start the Fault_PhoneLine_Asset creation ");
				 
				// mock_fault(method);
				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				mlAuxFaultCareLevel = mlAuxFaultCareLevelList.get(count);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(mlAuxFaultCareLevel.getSearchValue(),mlAuxFaultCareLevel.getSearchBy(), CLASS_NAME,
								method.getName());

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME,
						method.getName());

				PhoneLineFaultPreCheckerPageOperations phoneLineFaultPreCheckerOperations = accountDetailsPageOperations
						.clickPhoneLineFaultCheckerLink(CLASS_NAME,
								method.getName());
				
				phoneLineFaultPreCheckerOperations.phoneLineFaultPreChecker_MLAux(
						mlAuxFaultCareLevel.getTicketSubtypeID(),
						mlAuxFaultCareLevel.getContactType(),mlAuxFaultCareLevel.getMultiLineNumber(),CLASS_NAME, method.getName());

				PhoneLineFaultCheckerPageOperations phoneLineFaultCheckerPageOperations = phoneLineFaultPreCheckerOperations
						.clickContinue(CLASS_NAME, method.getName());

				phoneLineFaultCheckerPageOperations.phoneLineFaultcheker_Question_Answer(
						mlAuxFaultCareLevel.getAnswer1(),
						mlAuxFaultCareLevel.getAnswer2(),
						mlAuxFaultCareLevel.getAnswer3(),
						mlAuxFaultCareLevel.getAnswer4(),
						mlAuxFaultCareLevel.getAnswer5(),
						mlAuxFaultCareLevel.getAnswer6(),
						mlAuxFaultCareLevel.getAnswer7());

				LineTestPageOperations lineTestOperations = phoneLineFaultCheckerPageOperations
						.clickContinue(CLASS_NAME, method.getName());

				// lineTestOperations.LineTest(wlrFaultCareLevel.getTestType());

				LineTestResultPageOperations lineTestResultPageOperations = lineTestOperations
						.clickLineTest(CLASS_NAME, method.getName());

				String lineTestResponseDetails = driver.findElement(
						By.id("responseCode")).getText();

				
				
				if(lineTestResponseDetails.equalsIgnoreCase("T008:FAULT - Dis One Leg In Network"))
				{
					logger.info("Fault Description is correct");
				}else
				{
					logger.info("Fault Description is not correct");
				}

				String BTOpenreachReports = driver.findElement(
						By.id("userActionNeededInformation")).getText();
				
				if(lineTestResponseDetails.equalsIgnoreCase("Fail"))
				{
					logger.info("BTOpenreachReports is correct");
				}else
				{
					logger.info("BTOpenreachReports is not correct");
				}

				

				AppointmentAndContactManagementPageOperations appointmentAndContactManagementPageOperations = null;
				ExpeditePageOperations expeditePageOperations = null;

				if ("yes".equalsIgnoreCase(mlAuxFaultCareLevel.getExpedite())) {

					lineTestResultPageOperations.clickExpedite();

					expeditePageOperations = lineTestResultPageOperations
							.clickNext(CLASS_NAME, method.getName());

					if ("yes".equalsIgnoreCase(mlAuxFaultCareLevel
							.getAcceptCharge())) {
						expeditePageOperations.clickAccept();
					}else{
						expeditePageOperations.clickWaives();
					}

					expeditePageOperations
							.carelevel(mlAuxFaultCareLevel.getCareLevelNumber());

					appointmentAndContactManagementPageOperations = expeditePageOperations
							.clickNext(CLASS_NAME, method.getName());

				} else {
					appointmentAndContactManagementPageOperations = lineTestResultPageOperations
							.clickNextwithoutExpedite(CLASS_NAME,
									method.getName());
				}

				appointmentAndContactManagementPageOperations
						.selectActivateDate();

				appointmentAndContactManagementPageOperations
						.selectTRChargeBand(mlAuxFaultCareLevel.getChargeBand());

				appointmentAndContactManagementPageOperations
						.fillVoiceAppointmentManagementFields(mlAuxFaultCareLevel
								.getEngNotes());

				appointmentAndContactManagementPageOperations
						.fillHealthAndsafetyVeificationFields(mlAuxFaultCareLevel
								.getHazardNotes());
				
				appointmentAndContactManagementPageOperations
				.clickIncludeFlexibleAppointments(mlAuxFaultCareLevel.getIncludeFlexibleAppointment());
				

				ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentAndContactManagementPageOperations
						.clickAvailableAppointmentButton();

				reserveAppointmentPageOperations
						.selectFirstAvailableAppointmentDate();
				
				appointmentAndContactManagementPageOperations = reserveAppointmentPageOperations
						.clickReserveAppointmentButton1(CLASS_NAME,
								method.getName());
				

				Wlr3FaultCreatedPageOperations wlr3FaultCreatedPageOperations = appointmentAndContactManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());
				accountDetailsPageOperations=	wlr3FaultCreatedPageOperations.clickNext(CLASS_NAME,
						method.getName());
				
				accountDetailsPageOperations.clickticketsTab(CLASS_NAME, method.getName());

				accountDetailsPageOperations.verifyFoidRequest(CLASS_NAME, method.getName());

				logger.info(" End Test-Fault_PhoneLine_Asset : End the Fault_PhoneLine_Asset creation ");
				
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				 
			} catch (Exception e) {
				e.printStackTrace();
				
				logger.error("Unable to do Fault PhoneLine Asset");
				
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		
		
		// driver.close(); 
		// driver.quit();
		 

	}

}
