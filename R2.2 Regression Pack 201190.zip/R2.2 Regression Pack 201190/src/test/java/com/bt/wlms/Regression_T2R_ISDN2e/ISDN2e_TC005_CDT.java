package com.bt.wlms.Regression_T2R_ISDN2e;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AppointmentAndContactManagementPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.ExpeditePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineTestPageOperations;
import com.hqnRegression.pages.operations.LineTestResultPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PhoneLineFaultCheckerPageOperations;
import com.hqnRegression.pages.operations.PhoneLineFaultPreCheckerPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.ResolvePageOperation;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.TakeControlPageOperations;
import com.hqnRegression.pages.operations.UpdateTicketPageOperations;
import com.hqnRegression.pages.operations.Wlr3FaultCreatedPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class ISDN2e_TC005_CDT extends SeleniumImplementation
{
	
	private WebDriver driver;
	private String CLASS_NAME = "ISDN2e_TC001";

	private String IN_FILE = "ISDN2ePhoneFault.csv";
	List<WLRFaultCareLevel> wlrFaultCareLevelList = new ArrayList<WLRFaultCareLevel>();
	WLRFaultCareLevel wlrFaultCareLevel;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("ISDN2e_TC001");

	public ISDN2e_TC005_CDT() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		wlrFaultCareLevelList = CSVOperation_New.readWLRFaultCareLevel(IN_FILE);
		if (wlrFaultCareLevelList != null && wlrFaultCareLevelList.size() > 0) {
			testCount = wlrFaultCareLevelList.size();
		}
	}
	
	
	public void mock_fault(Method method) throws Exception {
		wlrFaultCareLevel = wlrFaultCareLevelList.get(0);
		// Intializing IE browser to login to cvf portal to create mock
		WebDriver driverN = createBrowserInstance(BrowserType.FIREFOX);
		CommonMethods.mockFaultWApp(driverN, wlrFaultCareLevel.getNumToMock(),
				CLASS_NAME, method.getName());
		driverN.close();
	}
	

	@Test
	public void testCreatePhoneLineFault(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-Fault_PhoneLine_Asset : Start the Fault_PhoneLine_Asset creation ");

				mock_fault(method);
				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				wlrFaultCareLevel = wlrFaultCareLevelList.get(count);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(wlrFaultCareLevel.getSearchBy(),
								wlrFaultCareLevel.getSearchValue(), CLASS_NAME,
								method.getName());

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME,
						method.getName());

				PhoneLineFaultPreCheckerPageOperations phoneLineFaultPreCheckerOperations = accountDetailsPageOperations
						.clickPhoneLineFaultCheckerLink(CLASS_NAME,
								method.getName());
				
				phoneLineFaultPreCheckerOperations.phoneLineFaultPreChecker_CDT(
						wlrFaultCareLevel.getTicketSubtypeID(),
						wlrFaultCareLevel.getChannelId());

				PhoneLineFaultCheckerPageOperations phoneLineFaultCheckerPageOperations = phoneLineFaultPreCheckerOperations
						.clickContinue(CLASS_NAME, method.getName());

				phoneLineFaultCheckerPageOperations.PhoneLineFaultchecker_CDT(
						wlrFaultCareLevel.getAnswer1(),wlrFaultCareLevel.getAnswer2(),
						wlrFaultCareLevel.getAnswer3(),wlrFaultCareLevel.getAnswer4(),
						wlrFaultCareLevel.getAnswer5());

				LineTestPageOperations lineTestOperations = phoneLineFaultCheckerPageOperations
						.clickContinue(CLASS_NAME, method.getName());

				LineTestResultPageOperations lineTestResultPageOperations = lineTestOperations
						.clickLineTest(CLASS_NAME, method.getName());

				String lineTestResponseDetails = driver.findElement(
						By.id("responseCode")).getText();


				Assert.assertEquals("FLS:Line Test output is invalid: Invalid Service",

						lineTestResponseDetails,"Mocking was not done properly");
				
				driver.findElement(
						By.id("userActionNeededInformation")).sendKeys("Pass");
				
			AppointmentAndContactManagementPageOperations appointmentAndContactManagementPageOperations = null;
				ExpeditePageOperations expeditePageOperations = null;

				if ("yes".equalsIgnoreCase(wlrFaultCareLevel.getExpedite())) {

					lineTestResultPageOperations.clickExpedite();

					expeditePageOperations = lineTestResultPageOperations
							.clickNext(CLASS_NAME, method.getName());

					if ("yes".equalsIgnoreCase(wlrFaultCareLevel
							.getAcceptCharge())) {
						expeditePageOperations.clickAccept();
					} else {
						expeditePageOperations.clickWaives();
					}

					expeditePageOperations
							.carelevel(wlrFaultCareLevel.getNum());

					appointmentAndContactManagementPageOperations = expeditePageOperations
							.clickNext(CLASS_NAME, method.getName());

				} else {
					appointmentAndContactManagementPageOperations = lineTestResultPageOperations
							.clickNextwithoutExpedite(CLASS_NAME,
									method.getName());
				}

				Wlr3FaultCreatedPageOperations wlr3FaultCreatedPageOperations = appointmentAndContactManagementPageOperations
				.clickClose(CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickTicketsTab(CLASS_NAME, method
						.getName());
				accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME, method
						.getName());
				TakeControlPageOperations takeControlPageOperations = accountDetailsPageOperations
						.clickTakeControl(CLASS_NAME, method.getName());

				String name = driver.getWindowHandle();
				
				CommonMethods.doPause(5);
				takeControlPageOperations.clickOperation(wlrFaultCareLevel
						.getInternalNotes(), CLASS_NAME, method.getName());
				
                CommonMethods.doPause(5);
				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME, method
						.getName());
				
				accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME, method
						.getName());
				
															
				UpdateTicketPageOperations updateTicketPageOperations = accountDetailsPageOperations.clickupdate(
						CLASS_NAME, method.getName()); 
				
				String windw = driver.getWindowHandle();		
			
				CommonMethods.doPause(5);
				
				updateTicketPageOperations.clickUpdateLink(wlrFaultCareLevel.getInternalResolveNotes(),wlrFaultCareLevel.getClearCode(),
						CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME, method
						.getName());
				
				accountDetailsPageOperations.clickTicketsNumber(CLASS_NAME, method
						.getName());
				CommonMethods.doPause(5);
				
				ResolvePageOperation resolvePageOperation = accountDetailsPageOperations.clickResolve(CLASS_NAME, method
						.getName());
				
				
				String name1 = driver.getWindowHandle();
				
				CommonMethods.doPause(5);
				resolvePageOperation.clickResolveLink(wlrFaultCareLevel.getInternalResolveNotes(),wlrFaultCareLevel.getClearCode(),
						CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME, method
						.getName());
				
				
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				
				
			}catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to do Fault PhoneLine Asset");
				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
			}
			count++;
         }
	}
	

	@AfterMethod
	public void tearDown() {
		/*
		 * CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		 * driver.close(); 
		 * driver.quit();
		 */

	}

}