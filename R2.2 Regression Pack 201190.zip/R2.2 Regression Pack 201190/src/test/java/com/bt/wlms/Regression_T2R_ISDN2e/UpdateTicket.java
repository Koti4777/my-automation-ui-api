package com.bt.wlms.Regression_T2R_ISDN2e;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.internal.seleniumemulation.Windows;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ResolvePageOperation;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.TakeControlPageOperations;
import com.hqnRegression.pages.operations.UpdateTicketPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class UpdateTicket extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "UpdateTicket";

	private String IN_FILE = "NewTicketUpdate.csv";
	List<WLRFaultCareLevel> wlrFaultCareLevelList = new ArrayList<WLRFaultCareLevel>();
	WLRFaultCareLevel wlrFaultCareLevel;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	WebElement ticketNum = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("UpdateTicket");

	public UpdateTicket() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		wlrFaultCareLevelList = CSVOperation_New.readNewTicketUpdate(IN_FILE);
		if (wlrFaultCareLevelList != null && wlrFaultCareLevelList.size() > 0) {
			testCount = wlrFaultCareLevelList.size();
		}
	}

	@Test
	public void testUpdateTicket(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		order = new Order();

		try {

			logger.info(" Start Test-Fault_PhoneLine_Asset : Start the Fault_PhoneLine_Asset creation ");

			// mock_fault(method);
			driver = createBrowserInstance(BrowserType.FIREFOX);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			wlrFaultCareLevel = wlrFaultCareLevelList.get(count);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLoginD7(CLASS_NAME, method.getName());

			SearchResultPageOperations searchResultPageOperations = homePageOperations
					.search(wlrFaultCareLevel.getSearchBy(),
							wlrFaultCareLevel.getSearchValue(), CLASS_NAME,
							method.getName());

			AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
					.clickProductLink(CLASS_NAME, method.getName());

			accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,
					method.getName());

			/*ticketNum = driver.findElement(By.xpath("//div[@id='ticketTree"
					+ wlrFaultCareLevel.getNum() + "OPEN']/img"));
			ticketNum.click();

			TakeControlPageOperations takeControlPageOperations = accountDetailsPageOperations
					.clickTakeControl(CLASS_NAME, method.getName());

			String name = driver.getWindowHandle();

			CommonMethods.doPause(5);
			takeControlPageOperations.clickTakeControlOperation(
					wlrFaultCareLevel.getInternalNotes(),
					wlrFaultCareLevel.getContactType(), CLASS_NAME,
					method.getName());

			CommonMethods.doPause(5);*/
			accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
					method.getName());

			while (count < testCount) {

				String parentWindow = driver.getWindowHandle();

				try {
					wlrFaultCareLevel = wlrFaultCareLevelList.get(count);

					WebElement ticketNum1 = driver
							.findElement(By.xpath("//div[@id='ticketTree"
									+ wlrFaultCareLevel.getNum() + "OPEN']/img"));

					ticketNum1.click();

					UpdateTicketPageOperations updateTicketPageOperations = accountDetailsPageOperations
							.clickupdate(CLASS_NAME, method.getName());

					String windw = driver.getWindowHandle();

					CommonMethods.doPause(5);
					// use ClickUpdateLink1 method if u have SupplierTicket

					updateTicketPageOperations.clickNewUpdateLink(
							wlrFaultCareLevel.getInternalNotes(),
							wlrFaultCareLevel.getContactType(),
							wlrFaultCareLevel.getB2Links(),
							wlrFaultCareLevel.getB2BTree(),
							wlrFaultCareLevel.getB2BEmailUpdate(),
							wlrFaultCareLevel.getMessageText(),
							wlrFaultCareLevel.getEmailText(), CLASS_NAME,
							method.getName());

					accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
							method.getName());

				} catch (org.openqa.selenium.NoSuchElementException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					driver.close();
					CommonMethods.acceptAlert(driver);

				}
				driver.switchTo().window(parentWindow);
				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
						method.getName());
				count++;
			}
			WebElement ticketNum2 = driver.findElement(By
					.xpath("//div[@id='ticketTree" + wlrFaultCareLevel.getNum()
							+ "OPEN']/img"));
			ticketNum2.click();
			CommonMethods.doPause(5);

			ResolvePageOperation resolvePageOperation = accountDetailsPageOperations
					.clickResolve(CLASS_NAME, method.getName());

			String name1 = driver.getWindowHandle();

			CommonMethods.doPause(5);
			resolvePageOperation.clickNewResolveLink(
					wlrFaultCareLevel.getInternalResolveNotes(),
					wlrFaultCareLevel.getClearCode(),
					wlrFaultCareLevel.getContactType(), CLASS_NAME,
					method.getName());

			accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,
					method.getName());

			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do Fault PhoneLine Asset");
			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			// driver.close();
			// driver.quit();
		}

	}

	@AfterMethod
	public void tearDown() {
		/*
		 * CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		 * driver.close(); driver.quit();
		 */

	}
}
