package com.bt.wlms.Renumbering;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class RenumberingLine extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "RenumberingLine";

	private String IN_FILE = "Orderfrticket.csv";
	List<CPEDetails> orderDetailsList = new ArrayList<CPEDetails>();
	CPEDetails orderDetails;

	private int testCount = 0;
	private int count = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("RenumberingLine");

	@Test
	public RenumberingLine() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		orderDetailsList = CSVOperation_New.readRenumberingLineDetails(IN_FILE);

		if (orderDetailsList != null && orderDetailsList.size() > 0) {
			testCount = orderDetailsList.size();
		}

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	/**
	 * To submit for Renumbering
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testRenumberingLine(Method method) throws IOException {

		while (count < testCount) {
			try {
				logger.info("Start Test RenumberingLine");

				orderDetails = orderDetailsList.get(count);
				
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(orderDetails.getFoid(), "Order Number",
								CLASS_NAME, method.getName());
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME,
						method.getName());
				OrderSummaryPageOperations orderSummaryPageOperations = accountDetailsPageOperations
						.clickRenumberingLineLink(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
				orderSummaryPageOperations.selectCommunication(orderDetails
						.getCommunicationBy());

			OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
				.confirmOrder(CLASS_NAME, method.getName());
			

			orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
				method.getName());

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.info("End Test RenumberingLine");
			}

			catch (Exception e) {
				e.printStackTrace();
			}

			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

	//	driver.close();
	//	driver.quit();

	}

}
