package com.bt.wlms.TroubleTicketing;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class withTT extends SeleniumImplementation {

	private WebDriver driver;
	public String CLASS_NAME = "withTT";

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("withTT");

	public withTT() {
		PropertyConfigurator.configure(loggerPath);

	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	/**
	 * This method we can user for "CMC Tools" tab should be present in Homepage
	 * 
	 * @param method
	 * @throws IOException
	 */

	@Test
	public void testCreatewithTT(Method method) throws IOException {

		try {

			logger.info(" Start Test-withTT: Start the withTT creation ");

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			// Assert.assertTrue(false);
			HomePageOperations homePageOperations = loginPageOperations
					.agentLogin(CLASS_NAME, method.getName());

			try {
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"lastPageOperations" + ".png", driver, "end");
			} catch (IOException e) {
				e.printStackTrace();
			}
			logger.info(" End Test - withTT : End the withTT creation");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to do TroubleTicketing");

			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}

	}

	@AfterMethod
	public void tearDown() {
		// driver.close();
		// driver.quit();

	}

}