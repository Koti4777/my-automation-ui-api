package com.bt.wlms.cRQ13926_provide;

/**
 * 
 */

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.LIUbeans;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CSVOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * @author 605112580
 * 
 * 
 */
public class CR153926_TC004 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "CR153926_TC004";

	private String IN_FILE = "LIUselection.csv";
	List<LIUbeans> liuDetailsList = null;
	LIUbeans liuDetail = null;

	private int count = 0;
	public Order order = null;
	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("");

	public CR153926_TC004() {
		PropertyConfigurator.configure(loggerPath);
	}

	/*
	 * @Rule public TestName name = new TestName();
	 */
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		liuDetailsList = CSVOperation_New.readLIU(IN_FILE);
		order = new Order();

		if (liuDetailsList != null && liuDetailsList.size() > 0) {
			testCount = liuDetailsList.size();
		}

	}

	@Test
	public void LIUDetails(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-Create_NON_NGA_Aseet : Start the NON-NGA-Asset creation ");

				liuDetail = liuDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				// Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				RegisterNewServicePageOperations servicePageOperations = homePageOperations
						.clickBusinessCustomer();

				CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
						.searchByBusinessAccountName(
								liuDetail.getBusinessAccount(), CLASS_NAME,
								method.getName());

				CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
						.clickBusinessAccount(liuDetail.getBusinessAccount());

				LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
						.clickAddSite(CLASS_NAME, method.getName());

				LineCheckResultPageOperations lineCheckResultPageOperations = null;

				if ("".equalsIgnoreCase(liuDetail.getLandlinePhone())) {

					AddressSelectionPageOperations addressSelectionPageOperations = lineDetailsPageOperations
							.createSiteWithPostCodeOnly(liuDetail.getNewSite(),
									liuDetail.getLandlinePhone(),
									liuDetail.getPostCode(),
									liuDetail.getAddressValue(),
									liuDetail.getPremisesName(),
									liuDetail.getStreetName(),
									liuDetail.getTown(),
									liuDetail.getCountry(), CLASS_NAME,
									method.getName());

					lineCheckResultPageOperations = addressSelectionPageOperations
							.submitAddressButton(CLASS_NAME, method.getName());
				} else {

					lineCheckResultPageOperations = lineDetailsPageOperations
							.createSiteWithPostCodeAndPremisesDetails(
									liuDetail.getNewSite(),
									liuDetail.getLandlinePhone(),
									liuDetail.getPostCode(),
									liuDetail.getAddressValue(),
									liuDetail.getPremisesName(),
									liuDetail.getStreetName(),
									liuDetail.getTown(),
									liuDetail.getCountry(), CLASS_NAME,
									method.getName());

				}

				lineCheckResultPageOperations.selectPropositionByName(liuDetail
						.getProposition());

				AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
						.clickNext(CLASS_NAME, method.getName());

				AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
						.submit(CLASS_NAME, method.getName());

				ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
						.submit(CLASS_NAME, method.getName());
				
				if (liuDetail.getProposition().contains("Line")
						|| liuDetail.getProposition().startsWith("Calls")||liuDetail.getProposition().contains("Business")
						|| liuDetail.getProposition().contains("Broadband")) {
					
				productDetailsPageOperations.selectLinetype(CLASS_NAME,
						method.getName());
				productDetailsPageOperations.InstallationTypeLUI(liuDetail
						.getInstallationtype1());
				}
				if (liuDetail.getProposition().contains("ISDN")) {
					productDetailsPageOperations
							.selectISDNLineIsolationUnitRentelPrice(liuDetail
									.getISDNlineisolationunitrentalprice(),liuDetail.getQuantity_ISDN(),CLASS_NAME, method.getName());
					productDetailsPageOperations
							.selectISDNLineIsolationUnitConnectionPrice(liuDetail
									.getISDNlineisolationunitconnectionprice(),liuDetail.getQuantity_ISDN(),CLASS_NAME, method.getName());
				}
				
				productDetailsPageOperations.selectProductOffering_Asset_cr153926(
						liuDetail.getProposition(),
						liuDetail.getBroadbandCare(), liuDetail.getRouter(),
						liuDetail.getBusinessRateCard(), liuDetail.getCalls(),
						liuDetail.getCarelevel(), liuDetail.getSelectcalls(),
						liuDetail.getContract(), liuDetail.getOneOffCharge(),
						liuDetail.getRateCardDiscount(),
						liuDetail.getSalesPromotion(),
						liuDetail.getCustomerDiscount(),
						liuDetail.getPostCode(), liuDetail.getTitle(),
						liuDetail.getFirstName(), liuDetail.getSurName(),
						liuDetail.getServiceId(), liuDetail.getDdiRangeNum(),
						liuDetail.getSddirangeNum(), "", CLASS_NAME,
						method.getName(), CLASS_NAME);

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				/*
				 * if (liuDetail.getProposition().contains("Essential BB") ||
				 * (liuDetail.getProposition().contains( "Business Advanced")&&
				 * !liuDetail.getProposition().contains( "Call")) ||
				 * liuDetail.getProposition().contains("Broadband & ") ||
				 * liuDetail.getProposition() .startsWith("Broadband and") ||
				 * liuDetail.getProposition() .equals("Simply Broadband")) {
				 */
				if (productDetailsPageOperations.isHardwarepageAvailable) {

					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
							.clickNextForHardware(CLASS_NAME, method.getName());

					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
							.clickNext(CLASS_NAME, method.getName());
				} else {

					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
					
					productDetailsPageOperations.getVoiceTab().click();
					if (liuDetail.getProposition().startsWith("Line")
							|| liuDetail.getProposition().startsWith("Calls")) {
						
						productDetailsPageOperations.selectLineIsolationUnitConnectionPrice(liuDetail.getLineisolationunitconnectionprice(),CLASS_NAME, method.getName());
						productDetailsPageOperations.selectLineIsolationUnitRentelPrice(liuDetail.getLineisolationunitrentalprice(),CLASS_NAME, method.getName());
					}

					else if (liuDetail.getProposition().contains("Business")
							|| liuDetail.getProposition().contains("Broadband")) {

						productDetailsPageOperations
								.selectLineIsolationUnitConnectionPrice(liuDetail
										.getLineisolationunitconnectionprice(),CLASS_NAME, method.getName());
						productDetailsPageOperations
								.selectLineIsolationUnitRentelPrice(liuDetail
										.getLineisolationunitrentalprice(),CLASS_NAME, method.getName());
						productDetailsPageOperations
								.selectbroadbandLineIsolationUnitconnectionPrice(liuDetail
										.getBroadbandlineisolationunitconnectionprice(),CLASS_NAME, method.getName());
						productDetailsPageOperations
								.selectbroadbandlineIsolationUnitRentelPrice(liuDetail
										.getBroadbandlineisolationunitrentalprice(),CLASS_NAME, method.getName());
					} 
					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
				}
				appointmentManagementPageOperations.selectFutureCalendarDate(
						CLASS_NAME, method.getName(), 7);

				if (liuDetail.getProposition().contains(
						"Broadband and Anytime Calls")
						|| liuDetail.getProposition().contains(
								"Broadband & Anytime Calls")
						|| liuDetail.getProposition().contains(
								"Broadband and Off Peak Calls")
						|| liuDetail.getProposition().contains(
								"Broadband and Total Calls")
						|| liuDetail.getProposition().contains(
								"Business Advanced BBand")
						|| liuDetail.getProposition().contains(
								"Business Broadband and Line Rental")
						|| liuDetail.getProposition().contains(
								"Business Essential BBand")
						|| liuDetail.getProposition().contains(
								"Broadband & Anytime + Mobile Calls")
						|| liuDetail.getProposition().equalsIgnoreCase(
								"Line Rental and Calls")
						|| liuDetail.getProposition().contains(
								"Superfast Business Advanced Broadband")
						|| liuDetail.getProposition().equalsIgnoreCase(
								"Line Rental")) {
					appointmentManagementPageOperations
							.fillVoiceAppointmentManagementFields(liuDetail
									.getEngineeringNotes());
					if (liuDetail.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						appointmentManagementPageOperations
								.clickOutOfHoursAppointment();
					}

					ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
							.clickAvailableAppointmentButton();

					reserveAppointmentPageOperations
							.selectFirstAvailableAppointmentDate();

					if (liuDetail.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {

						if (liuDetail.getAppointmentCharges().contains(
								"Accept additional")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
						}
						if (liuDetail.getAppointmentCharges().contains("both")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						} else {
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						}
					}

					appointmentManagementPageOperations = reserveAppointmentPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());
				}

				if (liuDetail.getProposition().contains("40:")
						|| liuDetail.getProposition().contains(
								"Superfast Business Advanced Broadband")) {

					FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
							.fillBBFTTCAppointmentManagement(CLASS_NAME,
									method.getName());
					fttcAvailableAppointmentsPageOperations
							.selectFirstAvailableAppointmentDate();
					appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());

				}
				if (liuDetail.getProposition().contains("Call")
						|| liuDetail.getProposition().contains("Line")) {
					appointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(liuDetail
									.getHealthAndSafetyNotes());
				}

				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(liuDetail
						.getCommunicationBy());
				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());

				String orderId = orderConfirmationPageOperations.getOrderId();

				orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
						method.getName());

				// order.setLineSiteId(liuDetail.getNewSite());

				// order.setOrdeId(orderId);

				// calling save method for storing order object in CSV
				CSVOperations.saveOrders("Order.csv", order);

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.info(" End Test -  Create_NON_NGA_Aseet : End the NON-NGA-Asset creation");
				 

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to place the order");
				// CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				// driver.close();

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		// driver.quit();
		// driver.close();

	}

}
