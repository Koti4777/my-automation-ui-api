package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.ManageHistoryDetails;
import com.hqnRegression.pages.operations.AddControlPageOperation;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ManageworkPoolPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Admin_Manage_History_Edit extends SeleniumImplementation {
	private WebDriver driver;
	private String CLASS_NAME = "ManageHistoryStatus";
	
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("UserAndGroupAdmin_Asset");

	@Test
	public Admin_Manage_History_Edit() {
		PropertyConfigurator.configure(loggerPath);
	}
	
	private String IN_FILE = "ManageHistoryDetailsEdit.csv";
	List<ManageHistoryDetails> HistoryList = null;
	ManageHistoryDetails account = null;
	
	
	private int testCount = 0;
	private int count = 0;
		
	
	
	

	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		HistoryList = CSVOperation_New.readHistoryDetailsEdit(IN_FILE);
		
		if (HistoryList != null && HistoryList.size() > 0) {
			testCount = HistoryList.size();
		}

	}
	
	
	@Test
	public void testManageHistoryEdit(Method method) throws IOException {
				account = HistoryList.get(count);
		
		try {
			logger.info(" Start Test-testManageHistory : Start the testManageHistory ");
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());

			ManageworkPoolPageOperations manageworkPoolPageOperations = userAndGroupAdminPageOperations
					.clickManageStatusHistory(CLASS_NAME, method.getName());

			AddControlPageOperation addControlPageOperation = manageworkPoolPageOperations
					.clickEditLink(ManageHistoryDetails.getStatusReasonold(),CLASS_NAME, method.getName());
			
			String name = driver.getWindowHandle();
			System.out.println("window name::::::::" + name);

			addControlPageOperation.clickEditOperation(ManageHistoryDetails
					.getStatusReason(), ManageHistoryDetails.getDescription(),
					ManageHistoryDetails.getSequenceNumber(), CLASS_NAME,
					method.getName());
			 homePageOperations.clickAdmin(CLASS_NAME, method.getName());
			 userAndGroupAdminPageOperations.clickManageStatusHistory(CLASS_NAME, method.getName());
						
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
			
			@AfterMethod
			public void tearDown() {

				driver.close();
				driver.quit();

			}

		}
