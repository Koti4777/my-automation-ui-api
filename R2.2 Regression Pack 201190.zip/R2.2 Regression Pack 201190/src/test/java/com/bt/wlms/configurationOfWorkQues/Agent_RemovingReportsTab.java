package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AddNewUserDetails;
import com.hqnRegression.pages.operations.AddNewUserPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.EditTeamPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;


public class Agent_RemovingReportsTab extends SeleniumImplementation {

	private WebDriver driver;

	private String CLASS_NAME = "Agent_RemovingReportsTab";

	private String IN_FILE = "EditUserDetails.csv";
	List<AddNewUserDetails> userDetailsList ;
	AddNewUserDetails userBeanDetails ;
	
	

	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("Agent_RemovingReportsTab");

	@BeforeMethod
	public void setUp() throws Exception {

		userDetailsList = CSVOperation_New.readEditUserDetails(IN_FILE);

		if (userDetailsList != null && userDetailsList.size() > 0) {
			testCount = userDetailsList.size();
		}

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * 
	 * using this method we can Remove the Permissions of order management
	 * @param method
	 * @throws IOException
	 */

	@Test
	public void testRemovelReportingPermission(Method method)
			throws IOException {

		
		try {
			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-testRemovelReportingPermission : Start the testRemovelReportingPermission ");

			userBeanDetails = userDetailsList.get(0);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());

			EditTeamPageOperations editTeamPageOperations = userAndGroupAdminPageOperations
					.clickEditTeam(CLASS_NAME, method.getName(),
							userBeanDetails.getChooseTeam());

			editTeamPageOperations.selectReporting();

			userAndGroupAdminPageOperations = editTeamPageOperations
					.clickSaveBtn(CLASS_NAME, method.getName());

			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			driver = createBrowserInstance(BrowserType.FIREFOX);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			loginPageOperations = CMCHomePageOperations.navigateTo(driver);

			homePageOperations = loginPageOperations.agentLogin(CLASS_NAME,
					method.getName());
			
			boolean reports=false;
			reports=homePageOperations.isReportsDisplayed(CLASS_NAME, method.getName());
			
			if(reports){
				
				logger.info(" Reports Tab is visible for this User");
			}
			else{
				
				logger.info(" Reports Tab is Not Visible for this User");
			}
				
			logger.info(" End Test-testRemovelReportingPermission : End the testRemovelReportingPermission ");
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to choose Team ");

		}

	}

	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

}
