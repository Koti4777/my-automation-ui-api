package com.bt.wlms.configurationOfWorkQues;



import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.AskQuestionLinkPageOperations;
import com.hqnRegression.pages.operations.BroadbandUsageOperations;
import com.hqnRegression.pages.operations.SelectquestionPageOperations;
import com.hqnRegression.pages.operations.SelfCareConfirmPageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalHomePageOperations;
import com.hqnRegression.pages.operations.SelfCarePortalLoginOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class B2bSelfcare_CRQ162790_TC040 extends SeleniumImplementation {
                private WebDriver driver;
                private String baseUrl;

                private String CLASS_NAME = "B2cSelfcarePortal";
                
                private int testCount = 0;

            	private String loggerPath = CommonMethods.getProperty("log4j.properties");
            	private static Logger logger = Logger.getLogger("B2bSelfcare_CRQ162790_TC020");
            	public B2bSelfcare_CRQ162790_TC040() {
            		PropertyConfigurator.configure(loggerPath);
            	}

               @BeforeMethod
                public void setUp() throws Exception 
                {
                                driver = new FirefoxDriver();
                              //  baseUrl = "https://213.212.114.164/";
                                baseUrl = "https://163.164.37.104/";
                                  //baseUrl = "https://163.164.37.105/";
                                


                            //    ?https://163.164.37.104/b2bselfcare/b2b/myaccount?execution=e1s1
                                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

                }

                @Test
                public void testB2bSelfcare(Method method) throws Exception {
                           
                //	PropertyConfigurator.configure(loggerPath);
        			logger.info(" Start Test-testB2BSelfcare : Start the testB2BSelfcare ");

                	
                       
		                   SelfCarePortalLoginOperations selfCarePortalLoginOperations = 
		                		   SelfCarePortalLoginOperations.navigateTob2bscp(driver, baseUrl,CLASS_NAME, method.getName());

                          
                          SelfCarePortalHomePageOperations selfCarePortalHomePageOperations = 
                        		  selfCarePortalLoginOperations.LoginSCP(CLASS_NAME, method.getName());
                          
              			BroadbandUsageOperations broadbandUsageOperations=selfCarePortalHomePageOperations.clickBroadbandUsage(CLASS_NAME, method.getName());
            			//broadbandUsageOperations.isUnlimitedPresent(CLASS_NAME, method.getName());

                          
            
                      /*   SelfCareConfirmPageOperations selfCareConfirmPageOperations = 
                            		selectquestionPageOperations.clickSubmitButton(CLASS_NAME, method.getName());
                                
                         selfCarePortalHomePageOperations = selfCareConfirmPageOperations.clickReturnButton(CLASS_NAME, method.getName());    
                         
                         selfCarePortalLoginOperations = selfCarePortalHomePageOperations.clickLogout(CLASS_NAME, method.getName());
*/                         
                        logger.info(" End Test -  testB2BSelfcare : End the testB2BSelfcare creation");
                        CommonMethods.logOut(driver, CLASS_NAME, method.getName());
            			
            			
   
                         
                                }

                @AfterMethod
                public void tearDown() throws Exception
                {
/*                	             driver.close();
                                 driver.quit();
                                 */
                }

               
}
