package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AddTeamDetails;
import com.hqnRegression.pages.operations.AddTeamPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class UserAndGroupAdmin_AddTeam extends SeleniumImplementation {

	private WebDriver driver;

	private String CLASS_NAME = "UserAndGroupAdmin_AddTeam";

	private String IN_FILE = "AddTeamDetails.csv";
	List<AddTeamDetails> newTeamBeanDetailsList;
	AddTeamDetails newTeamBeanDetails;

	private int testCount = 0;
	private int count = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("UserAndGroupAdmin_AddTeam");


public UserAndGroupAdmin_AddTeam() {
		PropertyConfigurator.configure(loggerPath);
	}
	
	
	@BeforeMethod
	public void setUp() throws Exception {

		newTeamBeanDetailsList = CSVOperation_New
				.readAddNewTeamDetails(IN_FILE);

		if (newTeamBeanDetailsList != null && newTeamBeanDetailsList.size() > 0)

		{

			testCount = newTeamBeanDetailsList.size();

		}

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	
	/**
	 * 
	 * Creating method for AddTeam
	 *  
	 */

	@Test
	public void testUserAndGroupAdmin(Method method) throws IOException {

		System.out.println("method name is --->" + method.getName());

		try {

			// logger.info(" Start Test-UserAndGroupAdmin : Start the UserAndGroupAdmin ");

			newTeamBeanDetails = newTeamBeanDetailsList.get(0);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			// Assert.assertTrue(false);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations

			.clickAdmin(CLASS_NAME, method.getName());

			AddTeamPageOperations addTeamPageOperations = userAndGroupAdminPageOperations
					.clickCreateTeam(CLASS_NAME, method.getName());

			addTeamPageOperations.fillAddNewTeam(
					newTeamBeanDetails.getTeamName(),
					newTeamBeanDetails.getTeamDesc());
		
		  addTeamPageOperations.clickB2B(CLASS_NAME, method.getName());
		  
		  
		    /*
			 * This code is commented for Future purpose
			 */
			/*
			 * addTeamPageOperations.clickB2C(CLASS_NAME, method.getName());
			 * 
			 * addTeamPageOperations.clickB2BAndB2C(CLASS_NAME,
			 * method.getName())
			 * 
			 * 
			 */

			userAndGroupAdminPageOperations = addTeamPageOperations.clickSave(
					CLASS_NAME, method.getName());

			addTeamPageOperations = userAndGroupAdminPageOperations
					.clickCreateTeam(CLASS_NAME, method.getName());

			userAndGroupAdminPageOperations = addTeamPageOperations.clickBack(
					CLASS_NAME, method.getName());

			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		}

		catch (Exception e) {
			e.printStackTrace();

			logger.error("Unable to create TeamName ");
		}
	}
	
	
	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

	
}
