package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.EditWorkPoolPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ManageClearCodePageOperations;
import com.hqnRegression.pages.operations.ManageTicketSubTypePageOperations;
import com.hqnRegression.pages.operations.ManageTicketTypePageOperations;
import com.hqnRegression.pages.operations.ManageworkPoolPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class UserAndGroupAdmin_Asset extends SeleniumImplementation {

	private  WebDriver driver;
	private String CLASS_NAME = "UserAndGroupAdmin";

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("UserAndGroupAdmin_Asset");

	@Test
	public UserAndGroupAdmin_Asset() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	
	/**
	 * operations in user and group admin page
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testUserAndGroupAdmin(Method method) throws IOException {

		

		try {

			logger.info(" Start Test-UserAndGroupAdmin : Start the UserAndGroupAdmin ");

			
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());

			ManageworkPoolPageOperations manageworkPoolPageOperations = userAndGroupAdminPageOperations
					.clickManageWorkPools(CLASS_NAME, method.getName());

			
			manageworkPoolPageOperations.clickCMCCheckBOx2("(Credit Checking)-Completed orders");
			
			
			
			
			userAndGroupAdminPageOperations = manageworkPoolPageOperations
					.clickSaveButton(CLASS_NAME, method.getName());

			manageworkPoolPageOperations = userAndGroupAdminPageOperations
					.clickManageWorkPools(CLASS_NAME, method.getName());

			manageworkPoolPageOperations.newPoolName(CLASS_NAME,
					method.getName());

			manageworkPoolPageOperations.clickOk(CLASS_NAME, method.getName());

			userAndGroupAdminPageOperations = manageworkPoolPageOperations
					.clickCancel(CLASS_NAME, method.getName());
			
			CommonMethods.acceptAlert(driver);
			
					
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			
			logger.info("End Test UserAndGroupAdmin_Asset");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

}
