package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AddNewUserDetails;
import com.hqnRegression.pages.operations.AddNewUserPageOperations;
import com.hqnRegression.pages.operations.AddTeamPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class UserAndGroupAdmin_CreatUser_WithoutPermision extends SeleniumImplementation 
{
	private  WebDriver driver;
	private String CLASS_NAME = "UserAndGroupAdmin_CreatUser";
	private String IN_FILE = "AddNewUserDetails.csv";
	List<AddNewUserDetails> userDetailsList = null;
	AddNewUserDetails userBeanDetails = null;
	
	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("UserAndGroupAdmin_CreatUser");

	@Test
	public UserAndGroupAdmin_CreatUser_WithoutPermision() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		
		userDetailsList = CSVOperation_New.readAddNewUserDetails(IN_FILE);

		if (userDetailsList != null && userDetailsList.size() > 0) 
		{
			testCount = userDetailsList.size();
		}	

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * To create a new user with valid credentials
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void UserAndGroupAdmin_CreatUser(Method method) throws IOException {

		

		try {

			logger.info(" Start Test-UserAndGroupAdmin_CreatUser : Start the UserAndGroupAdmin_CreatUser ");
			
			userBeanDetails = userDetailsList.get(count);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());
			
				
			
			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());
			
			AddTeamPageOperations addTeamPageOperations = userAndGroupAdminPageOperations
					.clickCreateTeam(CLASS_NAME, method.getName());
			
			addTeamPageOperations.fillAddNewUser(
					userBeanDetails.getTeamName(),userBeanDetails.getTeamDesc() );
			
			
			 userAndGroupAdminPageOperations = addTeamPageOperations
			 		.clickSave(CLASS_NAME, method.getName());	


			// for create user
			 
			AddNewUserPageOperations addNewUserPageOperations = userAndGroupAdminPageOperations
					.clickCreateUser(CLASS_NAME, method.getName());
			
			addNewUserPageOperations.fillAddNewUser(
					userBeanDetails.getUserName() ,
					userBeanDetails.getPassword(),
					userBeanDetails.getFirstName(),
					userBeanDetails.getSurName(),
					userBeanDetails.getEmailAddress() );
			
		
			addNewUserPageOperations.clickAgent("agentName");
			
			
			addNewUserPageOperations.enterAgent(CLASS_NAME, method.getName());	

			
			
			userAndGroupAdminPageOperations = addNewUserPageOperations.clickSave(CLASS_NAME, method.getName());
			
				 	
			 
			CommonMethods.logOut(driver,CLASS_NAME, method.getName());
	
			driver = createBrowserInstance(BrowserType.FIREFOX);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
			 loginPageOperations = CMCHomePageOperations
			.navigateTo(driver);
			 
			  homePageOperations = loginPageOperations
				.agentLogin(CLASS_NAME, method.getName());
		
			 CommonMethods.logOut(driver,CLASS_NAME, method.getName());	
		
		
		}
		catch(Exception e)
		{
				e.printStackTrace();
		}

}
@AfterMethod
public void tearDown() {

//driver.close();
 //driver.quit();

}

}
