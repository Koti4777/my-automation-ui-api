package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.EditTeamDetails;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.EditTeamPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.pages.operations.ViewTeamPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class UserAndGroupAdmin_EditTeam extends SeleniumImplementation {

	private WebDriver driver;

	private String CLASS_NAME = "UserAndGroupAdmin_EditTeam";

	private String IN_FILE = "EditTeamDetails.csv";
	List<EditTeamDetails> editTeamBeanDetailsList;
	EditTeamDetails editTeamBeanDetails;

	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("UserAndGroupAdmin_EditTeam");


public UserAndGroupAdmin_EditTeam() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		editTeamBeanDetailsList = CSVOperation_New.readEditTeamDetails(IN_FILE);

		if (editTeamBeanDetailsList != null
				&& editTeamBeanDetailsList.size() > 0)

		{

			testCount = editTeamBeanDetailsList.size();

		}

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * using this method we can edit the team from drop down
	 * 
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testEditTeam(Method method) throws IOException {

		try {

			logger.info(" Start EditTeam : Start the Test EditTeam ");

			editTeamBeanDetails = editTeamBeanDetailsList.get(0);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());

			EditTeamPageOperations editTeamPageOperations = userAndGroupAdminPageOperations
					.clickEditTeam(CLASS_NAME, method.getName(),
							editTeamBeanDetails.getChooseTeam());

			editTeamPageOperations.fillEditTeam(
					editTeamBeanDetails.getTeamName(),
					editTeamBeanDetails.getTeamDesc());

			editTeamPageOperations.clickB2B(CLASS_NAME, method.getName());
			/*
			 * This code is commented for Future purpose
			 */
			/*
			 * editTeamPageOperations.clickB2C(CLASS_NAME, method.getName());
			 * 
			 * editTeamPageOperations.clickB2BAndB2C(CLASS_NAME,
			 * method.getName())
			 */
			userAndGroupAdminPageOperations = editTeamPageOperations
					.clickSaveBtn(CLASS_NAME, method.getName());

			/*
			 * This code is commented for Future purpose
			 */

			/*
			 * editTeamPageOperations = userAndGroupAdminPageOperations
			 * .clickEditTeam(CLASS_NAME, method.getName(),
			 * editTeamBeanDetails.getChooseTeam());
			 * 
			 * userAndGroupAdminPageOperations = editTeamPageOperations
			 * .clickCancel(CLASS_NAME, method.getName());
			 */

			String teamName=editTeamBeanDetails.getTeamName()+" (Active)";
			ViewTeamPageOperations viewTeamPageOperations = userAndGroupAdminPageOperations
					.clickViewTeam(CLASS_NAME, method.getName(),
							teamName);

			/*
			 * userAndGroupAdminPageOperations = viewTeamPageOperations
			 * .clickCancel(CLASS_NAME, method.getName());
			 */
			logger.info(" End Test EditTeam : End the Test EditTeam ");
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable to choose Team ");

		}

	}

	@AfterMethod
	public void tearDown() {

		driver.close();
		driver.quit();

	}

}
