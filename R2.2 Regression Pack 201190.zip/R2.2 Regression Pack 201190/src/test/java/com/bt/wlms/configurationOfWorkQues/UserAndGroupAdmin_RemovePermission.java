package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AddNewUserDetails;
import com.hqnRegression.beans.EditTeamDetails;
import com.hqnRegression.pages.operations.AddNewUserPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.EditTeamPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class UserAndGroupAdmin_RemovePermission extends SeleniumImplementation {

	private WebDriver driver;

	private String CLASS_NAME = "UserAndGroupAdmin_RemovePermission";

	private String IN_FILE = "EditTeamDetails.csv";
	List<EditTeamDetails> editTeamBeanDetailsList;
	EditTeamDetails editTeamBeanDetails;
	

	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger
			.getLogger("UserAndGroupAdmin_RemovePermission");

	@BeforeMethod
	public void setUp() throws Exception {
		editTeamBeanDetailsList = CSVOperation_New.readEditTeamDetails(IN_FILE);
		
		if (editTeamBeanDetailsList != null
				&& editTeamBeanDetailsList.size() > 0) {
			testCount = editTeamBeanDetailsList.size();
		}

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/**
	 * 
	 * using this method we can Remove the Permissions of order management
	 * 
	 * 
	 * 
	 * @param method
	 * 
	 * @throws IOException
	 */

	@Test
	public void testRemovelPermission(Method method) throws IOException {

		System.out.println("method name is --->" + method.getName());

		try {
			PropertyConfigurator.configure(loggerPath);
			logger.info(" Start Test-testRemovelPermission : Start the testRemovelPermission ");

			editTeamBeanDetails = editTeamBeanDetailsList.get(0);

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());
			
			//EditTeamPageOperations editTeamPageOperations = userAndGroupAdminPageOperations

			EditTeamPageOperations editTeamPageOperations = userAndGroupAdminPageOperations
					.clickEditTeam(CLASS_NAME, method.getName(),
							editTeamBeanDetails.getChooseTeam());
			
			editTeamPageOperations.selectOrderManagement();

			userAndGroupAdminPageOperations = editTeamPageOperations
					.clickSaveBtn(CLASS_NAME, method.getName());

			
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			driver = createBrowserInstance(BrowserType.FIREFOX);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

			loginPageOperations = CMCHomePageOperations.navigateTo(driver);

			homePageOperations = loginPageOperations.agentLogin(CLASS_NAME,
					method.getName());

			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@AfterMethod
	public void tearDown() {

		 driver.close();
		 driver.quit();

	}

}
