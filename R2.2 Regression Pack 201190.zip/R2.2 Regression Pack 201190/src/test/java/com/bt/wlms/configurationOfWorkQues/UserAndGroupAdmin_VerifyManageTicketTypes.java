package com.bt.wlms.configurationOfWorkQues;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.EditWorkPoolPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ManageTicketSubTypePageOperations;
import com.hqnRegression.pages.operations.ManageTicketTypePageOperations;
import com.hqnRegression.pages.operations.UserAndGroupAdminPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class UserAndGroupAdmin_VerifyManageTicketTypes extends SeleniumImplementation

 {

	private  WebDriver driver;
	private String CLASS_NAME = "UserAndGroupAdmin_VerifyManageTicketTypes";

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("UserAndGroupAdmin_VerifyManageTicketTypes");

	@Test
	public UserAndGroupAdmin_VerifyManageTicketTypes() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	
	/**
	 * operations in UserAndGroupAdmin Page to verifyManageTicketTypes
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testUserAndGroupAdmin(Method method) throws IOException {

		
		try {

			logger.info(" Start Test-UserAndGroupAdmin : Start the UserAndGroupAdmin ");

			
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			UserAndGroupAdminPageOperations userAndGroupAdminPageOperations = homePageOperations
					.clickAdmin(CLASS_NAME, method.getName());
			
			
			ManageTicketTypePageOperations manageTicketTypePageOperations = userAndGroupAdminPageOperations
					.clickManageTicketType(CLASS_NAME, method.getName());
			/*manageTicketTypePageOperations.clickcheckBox1("Complaints - EXEC (executive office");
			
			userAndGroupAdminPageOperations = manageTicketTypePageOperations.clickSave(CLASS_NAME, method.getName());
						 
			manageTicketTypePageOperations = userAndGroupAdminPageOperations
					 .clickManageTicketType(CLASS_NAME, method.getName());*/
           			
		    
			EditWorkPoolPageOperations editWorkPoolPageOperations = manageTicketTypePageOperations.clickEdit1(CLASS_NAME, method.getName());
				    			
			 editWorkPoolPageOperations.selectWorkPool(CLASS_NAME, method.getName(), "(Complaints)-Payments");
			 editWorkPoolPageOperations.clickOkBtn(CLASS_NAME, method.getName());
			
			 manageTicketTypePageOperations = editWorkPoolPageOperations.clickSaveBtn(CLASS_NAME, method.getName());
			 
			 ManageTicketSubTypePageOperations manageTicketSubTypePageOperations = manageTicketTypePageOperations.clickEdit2(CLASS_NAME, method.getName());
			 CommonMethods.acceptAlert(driver);	 
			
					
			 userAndGroupAdminPageOperations = manageTicketTypePageOperations.clickCancel(CLASS_NAME, method.getName());
			 CommonMethods.acceptAlert(driver);
			 
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@AfterMethod
	public void tearDown() {

		//driver.close();
		 //driver.quit();

	}

}
