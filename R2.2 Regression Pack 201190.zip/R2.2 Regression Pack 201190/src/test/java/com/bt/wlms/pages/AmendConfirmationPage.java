package com.bt.wlms.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmendConfirmationPage {
	
	@FindBy(name = "_eventId_submitComplete")
	private WebElement nextButton;

	public WebElement getNextButton() {
		return nextButton;
	}

	private WebDriver driver;

	public WebDriver getDriver() {
		return driver;
	}

	public AmendConfirmationPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

}
