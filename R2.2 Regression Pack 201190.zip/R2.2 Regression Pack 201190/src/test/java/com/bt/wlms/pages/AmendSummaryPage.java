package com.bt.wlms.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmendSummaryPage {

	@FindBy(name = "_eventId_submitAmendSummary")
	private WebElement submitAmendSummary;
	
	private WebDriver driver;

	public WebElement getSubmitAmendSummary() {
		return submitAmendSummary;
	}

	public WebDriver getDriver() {
		return driver;
	}
	
	public AmendSummaryPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	
	
	
	
	
	

}
