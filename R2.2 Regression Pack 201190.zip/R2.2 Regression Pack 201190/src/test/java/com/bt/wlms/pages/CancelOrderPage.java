package com.bt.wlms.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CancelOrderPage {

	@FindBy(name = "_eventId_submitCancelProductOrder")
	private WebElement ok;

	@FindBy(name = "cancelOrderReason")
	private WebElement cancelOrderReason;

	private WebDriver driver;

	public WebElement getOk() {
		return ok;
	}

	public WebElement getCancelOrderReason() {
		return cancelOrderReason;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public CancelOrderPage(WebDriver driver) {
		this.driver = driver;
	}

}
