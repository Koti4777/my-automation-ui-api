package com.bt.wlms.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EditOrderPage {

	@FindBy(id = "fttcAppointmentDetails.password")
	private WebElement password;
	@FindBy(id = "fttcAppointmentDetails.specialArrangementNotes")
	private WebElement specialArrangementNotes;

	@FindBy(id = "fttcAppointmentDetails.siteVisitNotes")
	private WebElement siteVisitNotes;

	@FindBy(id = "amend")
	private WebElement saveButton;

	@FindBy(id = "hazardNotes")
	private WebElement hazardNotes;

	@FindBy(name = "engineeringNotes")
	private WebElement engineeringNotes;

	private WebDriver driver;
	
	
	
	
	

	public WebElement getPassword() {
		return password;
	}

	public WebElement getSpecialArrangementNotes() {
		return specialArrangementNotes;
	}

	public WebElement getSiteVisitNotes() {
		return siteVisitNotes;
	}

	public WebElement getEngineeringNotes() {
		return engineeringNotes;
	}

	public WebElement getSaveButton() {
		return saveButton;
	}

	public WebElement getHazardNotes() {
		return hazardNotes;
	}

	public EditOrderPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

}
