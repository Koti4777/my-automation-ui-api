package com.bt.wlms.pages.operations;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.bt.wlms.pages.AmendConfirmationPage;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.util.CommonClass;

public class AmendConfirmationPageOperartions extends AmendConfirmationPage {

	WebDriver driver;

	public AmendConfirmationPageOperartions(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	private static Logger logger = Logger
			.getLogger("SearchResultPageOperations");
	// static String baseUrl = "http://10.213.247.145:61121/";
	static Properties testProps = null;

	/**
	 * This method clicks Next Button
	 * @param className
	 * @param methodName
	 * @return
	 */
	public AccountDetailsPageOperations clickNextButton(String className,
			String methodName) {
		
		logger.info(":    start the	clickNextButton");

		try {
			
			
			CommonClass.saveScreenshot(className, methodName, "AmendConfirmationPage"
					+ ".png", driver, "");
			
			getNextButton().click();
			
		} catch (Exception e) {

		}

		
		
		logger.info(":    end the	clickNextButton");
		
		return PageFactory.initElements(driver,
				AccountDetailsPageOperations.class);
	}

}
