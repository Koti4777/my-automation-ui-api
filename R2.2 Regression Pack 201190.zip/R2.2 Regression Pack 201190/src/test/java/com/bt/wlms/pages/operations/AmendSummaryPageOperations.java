package com.bt.wlms.pages.operations;


import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.bt.wlms.pages.AmendSummaryPage;
import com.bt.wlms.pages.operations.AmendSummaryPageOperations;
import com.bt.wlms.pages.operations.EditOrderPageOperations;
import com.hqnRegression.pages.AmendOrderPage;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
public class AmendSummaryPageOperations extends AmendSummaryPage {
	
	WebDriver driver;

	// static String baseUrl = "http://10.213.247.145:61121/";
	static Properties testProps = null;

	private static Logger logger = Logger
			.getLogger("SearchResultPageOperations");
	
	
	public AmendSummaryPageOperations(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	/**
	 * This method clicks Submit Button
	 * @param className
	 * @param methodName
	 * @return
	 */
	public AmendConfirmationPageOperartions clickSubmitButton(String className, String methodName) {
		
			logger.info(":    start	the clickSubmitButton");
		
		try {
			CommonClass.saveScreenshot(className, methodName,
					"AmendSummaryPage" + ".png", driver, "");
			
			getSubmitAmendSummary().click();
			
		} 
		catch(Exception e)
		{
		
			
		}
		
		logger.info(":    end the clickSubmitButton");
		
		return PageFactory.initElements(driver,
				AmendConfirmationPageOperartions.class);
	}
	

}
