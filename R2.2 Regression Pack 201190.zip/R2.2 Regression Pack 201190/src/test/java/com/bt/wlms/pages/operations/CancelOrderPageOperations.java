package com.bt.wlms.pages.operations;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.bt.wlms.pages.CancelOrderPage;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.util.CommonClass;

public class CancelOrderPageOperations extends CancelOrderPage {

	WebDriver driver;

	static Properties testProps = null;

	private static Logger logger = Logger
			.getLogger("CancelOrderPageOperations");

	public CancelOrderPageOperations(WebDriver driver) {

		super(driver);
		this.driver = driver;
	}

	/**
	 * This method clicks Ok Button
	 * @param className
	 * @param methodName
	 * @return
	 */

	public AccountDetailsPageOperations clickOkButton(String className,
			String methodName) {

		logger.info(":    start the clickOkButton");

		try {
			CommonClass.saveScreenshot(className, methodName,

			"CancelOrderPage" + ".png", driver, "");

		} catch (IOException e) {
			e.printStackTrace();
		}
		getOk().click();

		logger.info(":   end the  clickOkButton");

		return PageFactory.initElements(driver,
				AccountDetailsPageOperations.class);

	}

	/**
	 * This method selects the reason from  dropdownlist  to Cancel the order
	 * @param searchType
	 * @param className
	 * @param methodName
	 */

	public void selectReasonForCancelling(String searchType, String className,
			String methodName) {
		logger.info(":    start	 selecting the Reason for Cancelling");

		// getAmendOrderReason().click();

		new Select(getCancelOrderReason()).selectByVisibleText(searchType);

		logger.info(":     end selecting Reason for Cancelling");

	}

}
