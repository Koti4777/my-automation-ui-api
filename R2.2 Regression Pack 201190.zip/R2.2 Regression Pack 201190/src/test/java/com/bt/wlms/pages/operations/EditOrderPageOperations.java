package com.bt.wlms.pages.operations;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.bt.wlms.pages.EditOrderPage;
import com.hqnRegression.pages.operations.AmendOrderPageOperations;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;

public class EditOrderPageOperations extends EditOrderPage {

	WebDriver driver;

	public EditOrderPageOperations(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	private static Logger logger = Logger
			.getLogger("SearchResultPageOperations");
	// static String baseUrl = "http://10.213.247.145:61121/";
	static Properties testProps = null;

	/**
	 * This method selects the Customer Required Date from the datepicker
	 * 
	 * @param className
	 * @param methodName
	 * @param offset
	 * @return
	 * @throws IOException
	 */

	public AmendOrderPageOperations selectFutureCalendarDate_Amend(
			String className, String methodName, int offset) throws IOException {

		logger.info(":	start the selectFutureCalendarDate");

		int size = 0;

		driver.findElement(By.cssSelector("img.ui-datepicker-trigger")).click();

		CommonMethods.doPause(3);

		try {

			size = driver.findElements(By.cssSelector("a.ui-state-default"))
					.size();
			System.out.println("number of active days" + size);

			if (size <= offset) {
				size = offset - size;
				driver.findElement(
						By.cssSelector("span.ui-icon.ui-icon-circle-triangle-e"))
						.click();
				driver.findElements(By.cssSelector("a.ui-state-default"))
						.get(size).click();

			} else {

				driver.findElements(By.cssSelector("a.ui-state-default"))
						.get(offset).click();

			}

			CommonClass.saveScreenshot(className, methodName,
					"CRDAndAppointmentManagementPage" + ".png", driver, "");
		} catch (Exception e) {

			logger.error(e.getMessage());
		}

		getSaveButton().click();

		try {
			CommonClass.saveScreenshot(className, methodName, "AmendOrderPage"
					+ ".png", driver, "");
		} catch (Exception e) {

		}

		logger.info(":	end the selectFutureCalendarDate");

		return PageFactory.initElements(driver, AmendOrderPageOperations.class);

	}

	/**
	 * This method fills Password Notes , Special Notes and SiteVisit Notes
	 * 
	 * @param className
	 * @param methodName
	 * @return
	 * @throws IOException
	 */


	public AmendOrderPageOperations fillPassword_SpecialNotes_SiteVisitNotes(
			String className, String methodName) throws IOException {

		logger.info(":	start the fillPassword_SpecialNotes_SiteVisitNotes");

		getPassword().clear();
		getPassword().sendKeys("password");
		getSpecialArrangementNotes().clear();
		getSpecialArrangementNotes().sendKeys("specialarrangementnotes");
		getSiteVisitNotes().clear();
		getSiteVisitNotes().sendKeys("sitevisitnotes");

		try {
			CommonClass.saveScreenshot(className, methodName, "EditOrderPage"
					+ ".png", driver, "");
		} catch (Exception e) {

		}

		getSaveButton().click();

		try {
			CommonClass.saveScreenshot(className, methodName, "AmendOrderPage"
					+ ".png", driver, "");
		} catch (Exception e) {

		}

		logger.info(":	end the fillPassword_SpecialNotes_SiteVisitNotes");

		return PageFactory.initElements(driver, AmendOrderPageOperations.class);

	}

	/**
	 * This method fills Hazard Notes
	 * 
	 * @param className
	 * @param methodName
	 * @return
	 * @throws IOException
	 */

	public AmendOrderPageOperations fillHazardNotes(String className,
			String methodName) throws IOException {

		logger.info(":	start the fillHazardNotes");

		getHazardNotes().clear();
		getHazardNotes().sendKeys("hazardNotes");

		try {
			CommonClass.saveScreenshot(className, methodName, "EditOrderPage"
					+ ".png", driver, "");
		} catch (Exception e) {

		}

		getSaveButton().click();

		try {
			CommonClass.saveScreenshot(className, methodName, "AmendOrderPage"
					+ ".png", driver, "");
		} catch (Exception e) {

		}

		logger.info(":	end the fillHazardNotes");

		return PageFactory.initElements(driver, AmendOrderPageOperations.class);

	}

	/**
	 * This method fills Engineering Notes
	 * 
	 * @param className
	 * @param methodName
	 * @return
	 * @throws IOException
	 */
	public AmendOrderPageOperations fillEngineeringNotes(String className,
			String methodName) throws IOException {

		logger.info(":	start the fillEngineeringNotes");

		getEngineeringNotes().clear();
		getEngineeringNotes().sendKeys("Notes Engineering");

		try {
			CommonClass.saveScreenshot(className, methodName, "EditOrderPage"
					+ ".png", driver, "");
		} catch (Exception e) {

		}

		getSaveButton().click();

		try {
			CommonClass.saveScreenshot(className, methodName, "AmendOrderPage"
					+ ".png", driver, "");
		} catch (Exception e) {

		}

		logger.info(":	end the fillEngineeringNotes");

		return PageFactory.initElements(driver, AmendOrderPageOperations.class);

	}

}
