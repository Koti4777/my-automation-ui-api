package com.bt.wlms.pages.operations;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.ISDNDetails;
import com.hqnRegression.pages.ProductDetailsPage;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;

public class ProductDetailsPageOperations extends ProductDetailsPage {

	private WebDriver driver;

	private static Logger logger = Logger
			.getLogger("ProductDetailsPageOperations");

	private boolean isAnalogSet = false;
	public boolean isHardwarepageAvailable = false;
	public boolean isAnalogAvailable = true;
	
	

	public ProductDetailsPageOperations(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public void clickVoiceTab() {
		getVoiceTab().click();
	}

	public void setVoiceTab_CareLevel1() {
		driver
				.findElement(By.id("Telephony"))
				.findElement(
						By
								.xpath("//b[text()='Voice Care Level']/preceding-sibling::img[1]"))
				.click();

		WebElement td_Std = driver
				.findElement(By
						.xpath("//td[contains(.,'Standard business landline support')]"));
		td_Std.findElement(By.xpath("./input")).click();
	}

	public void setVoiceTab_CareLevel2() {
		driver
				.findElement(By.id("Telephony"))
				.findElement(
						By
								.xpath("//b[text()='Voice Care Level']/preceding-sibling::img[1]"))
				.click();

		WebElement td_Std = driver
				.findElement(By
						.xpath("//td[contains(.,'Enhanced business landline support')]"));
		td_Std.findElement(By.xpath("./input")).click();
	}

	public void setVoiceTab_CareLevel3() {
		driver
				.findElement(By.id("Telephony"))
				.findElement(
						By
								.xpath("//b[text()='Voice Care Level']/preceding-sibling::img[1]"))
				.click();

		WebElement td_Std = driver
				.findElement(By
						.xpath("//td[contains(.,'Enhanced plus business landline support')]"));
		td_Std.findElement(By.xpath("./input")).click();
	}

	// public void setVoiceTab_CareLevel4() {
	// driver.findElement(By.linkText("Voice")).click();
	// driver.findElement(By.xpath("//b[text()='Voice Care Level']/preceding-sibling::img[1]")).click();
	// driver.findElement(By.xpath("(//input[@name='PCM*PRO-E*41*BroadbandandOffPeakCalls*AnalogueVoiceAccessLin*68.1.2**VoiceCareLevel*6'])[4]")).click();
	//
	// // WebElement td_Std = driver
	// // .findElement(By
	// //
	// .xpath("//td[contains(.,'Enhanced plus business landline support')]"));
	// // td_Std.findElement(By.xpath("./input")).click();
	// }

	public void setVoiceTab_CareLevel4() {
		driver
				.findElement(By.id("Telephony"))
				.findElement(
						By
								.xpath("//b[text()='Voice Care Level']/preceding-sibling::img[1]"))
				.click();

		WebElement td_Std = driver
				.findElement(By
						.xpath("//td[contains(.,'Enhanced plus business landline support')]"));
		td_Std.findElement(By.xpath("./input")).click();
	}

	public void clickAnalogueVoiceTab() {

		logger.info(":	start the clickAnalogueVoiceTab");

		getAnalogueVoiceFeaturesTab().click();

		logger.info(":	end the clickAnalogueVoiceTab");
	}

	public void clickOtherTab() {

		logger.info(":	start the clickOtherTab");

		getOtherTab().click();

		logger.info(":	end the clickOtherTab");
	}

	public void fillMandatoryDirectoryListingFields(String title,
			String firstname, String surName) {

		logger.info(":	start the fillMandatoryDirectoryListingFields");

		new Select(getDirectoryTitle()).selectByValue(title);
		getFirstName().clear();
		getFirstName().sendKeys(firstname);
		getSurName().clear();

		getSurName().sendKeys(surName);

		logger.info(":	end the fillMandatoryDirectoryListingFields");

	}

	// TO-DO need to change this method
	public void selectB2BContractTermImgANDContract_12month() {

		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='Contract Term']/preceding-sibling::img[1]"))
				.click();

		driver.findElement(By.xpath("//input[contains(@value,'12MonthCont')]"))
				.click();
	}

	// TO-DO need to change this method
	public void selectB2BContractTermImgANDContract_18month() {

		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='Contract Term']/preceding-sibling::img[1]"))
				.click();

		driver.findElement(By.xpath("//input[contains(@value,'18MonthCont')]"))
				.click();
	}

	// TO-DO need to change this method
	public void selectOtherContractTermImgANDContract(String contractTerm) {

		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='Contract Term']/preceding-sibling::img[1]"))
				.click();
		driver.findElement(
				By.xpath("//input[contains(@value,'" + contractTerm + "')]"))
				.click();

	}

	public Object clickNext(String className, String methodName) {

		String broadBand = "";
		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
			broadBand = getBroadBandTab().getText();
			getNext().click();
			if (!"Broadband".equalsIgnoreCase(broadBand)) {
				return PageFactory.initElements(driver,
						CRDAndAppointmentManagementPageOperations.class);
			} else {
				return PageFactory.initElements(driver,
						HardwareDeliveryDetailsPageOPerations.class);
			}
		} catch (NoSuchElementException e) {
			getNext().click();
			return PageFactory.initElements(driver,
					CRDAndAppointmentManagementPageOperations.class);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public HardwareDeliveryDetailsPageOPerations clickNextForHardware(
			String className, String methodName) {

		logger.info(":	start the ProductDetailsPageOperations");

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {
			e.printStackTrace();
		}
		getNext().click();

		logger.info(":	end the ProductDetailsPageOperations");

		return PageFactory.initElements(driver,
				HardwareDeliveryDetailsPageOPerations.class);
	}

	public CRDAndAppointmentManagementPageOperations clickNextForCRD(
			String className, String methodName) {

		logger.info(":	start the ProductDetailsPageOperations");

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {
			e.printStackTrace();
		}
		getNext().click();

		CommonMethods.doPause(7);

		logger.info(":	end the ProductDetailsPageOperations");

		return PageFactory.initElements(driver,
				CRDAndAppointmentManagementPageOperations.class);
	}

	public void fillCPPostCode(String postCode, String className,
			String methodName) {

		try {

			getCpPostCode().clear();
			getCpPostCode().sendKeys(postCode);

			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {

			try {
				getCpPostCode().clear();
				getCpPostCode().sendKeys(postCode);
			} catch (Exception ex) {
				driver.findElement(By.name("PCM*B-Calls*CPPostCode")).clear();
				driver.findElement(By.name("PCM*B-Calls*CPPostCode")).sendKeys(
						postCode);
			}

		}

	}

	public void clickBusinessRateCard() {
		getVoiceTab()
				.findElement(
						By
								.xpath("//b[text()='Business Rate Card']/preceding-sibling::img[1]"))
				.click();
		try {
			driver.findElement(By.id("B-Corporate Voice")).click();
			driver.findElement(By.id("B-Small Business Voice")).click();
		} catch (Exception e) {

		}
	}

	/*
	 * public HardwareDeliveryDetailsPage clickNext(){ next.click(); return
	 * PageFactory.initElements(driver, HardwareDeliveryDetailsPage.class); }
	 */

	public void clickBusinessRateCardAndSelect() {

		logger.info(":	start the clickBusinessRateCardAndSelect");
		try {
			getVoiceTab().click();
			getVoiceTab()
					.findElement(
							By
									.xpath("//b[text()='Business Rate Card']/preceding-sibling::img[1]"))
					.click();
			WebElement td_Std = driver
					.findElement(By
							.xpath("//td[contains(.,'Small Business Voice rate card')]"));
			td_Std.findElement(By.xpath("./input")).click();

		} catch (Exception e) {

			logger.error(e.getMessage());
		}

		logger.info(":	end the clickBusinessRateCardAndSelect");
	}

	public void clickBusinessRateCardAndSelectSmallBusiness(String className,
			String methodName) {

		getVoiceTab().click();
		getVoiceTab()
				.findElement(
						By
								.xpath("//b[text()='Business Rate Card']/preceding-sibling::img[1]"))
				.click();
		try {
			driver.findElement(By.id("B-Small Business Voice")).click();
		} catch (Exception e) {
		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_smallbusiness" + ".png", driver, "");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void clickBusinessRateCardISDN() {
		getVoiceTab().click();
		getVoiceTab()
				.findElement(
						By
								.xpath("//b[text()='Business Rate Card']/preceding-sibling::img[1]"))
				.click();

		WebElement td_Std = driver.findElement(By
				.xpath("//td[contains(.,'Small Business Voice rate card')]"));
		td_Std.findElement(By.xpath("./input")).click();
	}

	public void selectProductOffering(String proposition, String postcode,
			String title, String firstname, String surName, String contract)
			throws IOException {

		CommonMethods.doPause(3);

		if (proposition.contains("Business Essential Broadband and Calls")
				|| proposition
						.contains("Business Advanced Broadband and Calls")
				|| proposition.contains("Business Broadband and Calls")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_voice(postcode);
			selectProductOffering_Other(contract);
		}

		else if (proposition
				.contains("Superfast Business Advanced Broadband, Line & Calls")
				|| proposition
						.contains("Superfast Business Advanced Broadband, Line AND Calls")) {
			clickBusinessRateCardAndSelect();
			selectProductOffering_Other(contract);
			selectProductOffering_AnalogueVoice(title, firstname, surName);
		}

		else if (proposition.contains("Superfast Business Broadband and Calls")
				|| proposition.contains("Superfast Business Broadband & Calls")) {
			selectProductOffering_voice(postcode);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Business Advanced BBand, Line & Calls")
				|| proposition
						.contains("Business Broadband, Line Rental & Calls")
				|| proposition
						.contains("Business Essential BBand, Line & Calls")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_Line_voice(title, firstname, surName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("ISDN2")) {
			selectProductOffering_ISDN(title, firstname, surName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Business Advanced BBand & Line Rental")
				|| proposition.contains("Business Broadband and Line Rental")
				|| proposition
						.contains("Business Essential BBand & Line Rental")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_Line(title, firstname, surName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Business Essential Broadband")
				|| proposition.contains("Business Advanced Broadband")
				|| proposition.contains("Business Broadband")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Broadband and Anytime Calls")
				|| proposition.contains("Broadband and Off Peak Calls")
				|| proposition.contains("Broadband and Total Calls")
				|| proposition.contains("Broadband & Anytime Calls")
				|| proposition.contains("Broadband & Off Peak Calls")
				|| proposition.contains("Broadband & Total Calls")
				|| proposition.contains("Broadband & Anytime + Mobile Calls")) {
			selectProductOffering_Line(title, firstname, surName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Line Rental and Calls")
				|| proposition.equalsIgnoreCase("Line Rental")) {
			selectProductOffering_Line_voice(title, firstname, surName);
			selectProductOffering_Other(contract);

		} else if (proposition.contains("Superfast Broadband")) {
			selectProductOffering_Line(title, firstname, surName);
			selectProductOffering_Other(contract);
		} else if (proposition.equalsIgnoreCase("Simply Broadband")) {
			selectProductOffering_Other(contract);
		}

		if (proposition.contains("Line") && !isAnalogSet) {
			selectProductOffering_Line_voice(title, firstname, surName);
		}

		if (proposition.contains("Calls Only")) {
			selectProductOffering_voice(postcode);
		}

		if (proposition.contains("Total Calls")) {
			selectProductOffering_Voice_Calls();
		}

	}

	/**
	 * @throws IOException
	 * 
	 */
	private void selectProductOffering_BroadBand(String proposition)
			throws IOException {
		getBroadBandTab().click();

		driver
				.findElement(By.id("Broadband"))
				.findElement(
						By
								.xpath("//b[text()='Broadband Care']/preceding-sibling::img[1]"))
				.click();
		if (proposition.contains("Advanced")) {
			driver
					.findElement(
							By
									.xpath("//input[contains(@value,'PremiumBroadbandCare')]"))
					.click();
		} else {
			driver
					.findElement(
							By
									.xpath("//input[contains(@value,'Broadband Care:Standard')]"))
					.click();

		}
	}

	private void selectProductOffering_voice(String postcode)
			throws IOException {

		try {
			clickBusinessRateCardAndSelect();
			getCpPostCode().clear();
			getCpPostCode().sendKeys(postcode);
		} catch (Exception e) {
			try {
				driver.findElement(By.name("PCM*B-Calls*CPPostCode")).clear();
				driver.findElement(By.name("PCM*B-Calls*CPPostCode")).sendKeys(
						postcode);
			} catch (Exception ex) {

			}
		}

	}

	private void selectProductOffering_voice(String postcode, String className,
			String methodName) throws IOException {

		try {
			clickBusinessRateCardAndSelect();
			getCpPostCode().clear();
			getCpPostCode().sendKeys(postcode);
		} catch (Exception e) {
			try {
				driver.findElement(By.name("PCM*B-Calls*CPPostCode")).clear();
				driver.findElement(By.name("PCM*B-Calls*CPPostCode")).sendKeys(
						postcode);
			} catch (Exception ex) {

			}
		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductOffering_voice" + ".png", driver, "");
		} catch (Exception e) {
		}

	}

	private void selectProductOffering_AnalogueVoice(String title,
			String firstName, String surName) throws IOException {
		try {
			getAnalogueVoiceFeaturesTab().click();
			// new Select(getDirectoryTitle()).selectByValue(title);
			getFirstName().clear();
			getFirstName().sendKeys(firstName);
			getSurName().clear();
			getSurName().sendKeys(surName);
			isAnalogSet = true;
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private void selectProductOffering_Line_voice(String title,
			String firstname, String surName) throws IOException {

		/*
		 * getVoiceTab().click(); driver.findElement(By.id("Telephony"))
		 * .findElement(
		 * By.xpath("//b[text()='Business Rate Card']/preceding-sibling::img[1]"
		 * )) .click(); driver.findElement(
		 * By.xpath("//input[contains(@value,'CorporateVoice')]")).click();
		 */

		// clickBusinessRateCardAndSelect();

		getAnalogueVoiceFeaturesTab().click();
		// new Select(getDirectoryTitle()).selectByValue(title);
		getFirstName().clear();
		getFirstName().sendKeys(firstname);
		getSurName().clear();
		getSurName().sendKeys(surName);
		isAnalogSet = true;

	}

	private void selectProductOffering_Line(String title, String firstname,
			String surName) throws IOException {

		getAnalogueVoiceFeaturesTab().click();
		new Select(getDirectoryTitle()).selectByValue(title);
		getFirstName().clear();
		getFirstName().sendKeys(firstname);
		getSurName().clear();
		getSurName().sendKeys(surName);
		isAnalogSet = true;
	}

	private void selectProductOffering_ISDN(String title, String firstname,
			String surName) throws IOException {

		getISDNVoiceFeaturesTab().click();
		new Select(getDirectoryTitle()).selectByValue(title);
		getFirstName().clear();
		getFirstName().sendKeys(firstname);
		getSurName().clear();
		getSurName().sendKeys(surName);
	}

	private void selectProductOffering_ISDN(String title, String firstname,
			String surName, String className, String methodName)
			throws IOException {

		getISDNVoiceFeaturesTab().click();
		new Select(getDirectoryTitle()).selectByValue(title);
		getFirstName().clear();
		getFirstName().sendKeys(firstname);
		getSurName().clear();
		getSurName().sendKeys(surName);

		try {
			CommonClass
					.saveScreenshot(className, methodName,
							"ProductDetailsPage_ISDN_Voicefeature" + ".png",
							driver, "");
		} catch (Exception e) {
		}
	}

	private void selectProductOffering_Other(String contract)
			throws IOException {

		getOtherTab().click();
		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='Contract Term']/preceding-sibling::img[1]"))
				.click();
		CommonMethods.doPause(2);
		if (contract != null && !"".equalsIgnoreCase(contract)) {
			try {

				if (contract.contains("12")) {
					driver.findElement(
							By.xpath("//input[contains(@value,'12Month')]"))
							.click();
				} else if (contract.contains("18")) {
					driver.findElement(
							By.xpath("//input[contains(@value,'18Month')]"))
							.click();
				} else if (contract.contains("24")) {
					driver.findElement(
							By.xpath("//input[contains(@value,'24Month')]"))
							.click();
				} else {
					driver.findElement(
							By.xpath("//td[contains(.,'" + contract
									+ "')]/input")).click();
				}
			} catch (Exception e) {
				e.printStackTrace();
				driver.findElement(
						By.xpath("//input[contains(@value,'12Month')]"))
						.click();
			}
		} else {
			driver.findElement(By.xpath("//input[contains(@value,'12Month')]"))
					.click();
		}

	}

	public void selectBroadBandRouter_forRegrade() {

		getBroadBandTab().click();
		driver
				.findElement(By.id("Broadband"))
				.findElement(
						By
								.xpath("//b[text()='Broadband Router']/preceding-sibling::img[1]"))
				.click();
		driver.findElement(
				By.xpath("//td[contains(.,'Keep existing Router')]/input"))
				.click();

	}

	public void selectBroadBandRouter_customerRouter() {

		getBroadBandTab().click();
		driver
				.findElement(By.id("Broadband"))
				.findElement(
						By
								.xpath("//b[text()='Broadband Router']/preceding-sibling::img[1]"))
				.click();
		driver.findElement(
				By.xpath("//td[contains(.,'Customer brings')]/input")).click();

	}

	public CRDAndAppointmentManagementPageOperations clickNextForRegrade(
			String className, String methodName) {

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_regrade" + ".png", driver, "");
		} catch (Exception e) {
		}

		getNext().click();

		return PageFactory.initElements(driver,
				CRDAndAppointmentManagementPageOperations.class);
	}

	public void selectProductOffering_Other_salesPromotion_3month(
			String className, String methodName) throws IOException {

		getOtherTab().click();
		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='B2B Sales Promotion']/preceding-sibling::img[1]"))
				.click();
		driver.findElement(By.xpath("//td[contains(.,'3 months')]/input"))
				.click();
		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='B2B Sales Promotion']/preceding-sibling::input[1]"))
				.click();

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_oters_3month" + ".png", driver, "");
		} catch (Exception e) {
		}

	}

	public void selectProductOffering_Other_salesPromotion_6month(
			String className, String methodName) throws IOException {

		getOtherTab().click();

		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='B2B Sales Promotion']/preceding-sibling::input[1]"))
				.click();
		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='B2B Sales Promotion']/preceding-sibling::img[1]"))
				.click();
		try {
			driver.findElement(By.xpath("//td[contains(.,'6 months')]/input"))
					.click();
			driver
					.findElement(By.id("Other"))
					.findElement(
							By
									.xpath("//b[text()='B2B Sales Promotion']/preceding-sibling::input[1]"))
					.click();

		} catch (Exception e) {

		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_oters_6month" + ".png", driver, "");
		} catch (Exception e) {
		}

	}

	public void selectProductOffering_Other_oneOffCharge(String charge,
			String className, String methodName) throws IOException {

		getOtherTab().click();
		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='One Off Charges']/preceding-sibling::img[1]"))
				.click();
		if ("".equalsIgnoreCase(charge)) {

			driver
					.findElement(By.id("Other"))
					.findElement(
							By
									.xpath("//b[text()='One Off Charges']/following::input[1]"))
					.click();

		} else {
			try {
				driver.findElement(
						By.xpath("//td[contains(.,'" + charge + "')]/input"))
						.click();
			} catch (Exception e) {

			}
		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_oters_oneoffcharge" + ".png", driver,
					"");
		} catch (Exception e) {
		}

	}

	public void selectProductOffering_Other_ISDNstdOneOffCharge(String charge,
			String className, String methodName) throws IOException {

		getOtherTab().click();
		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='ISDN2e Standard One Off Charges']/preceding-sibling::img[1]"))
				.click();
		if ("".equalsIgnoreCase(charge)) {

			driver
					.findElement(By.id("Other"))
					.findElement(
							By
									.xpath("//b[text()='One Off Charges']/following::input[1]"))
					.click();

		} else {
			try {
				driver.findElement(
						By.xpath("//td[contains(.,'" + charge + "')]/input"))
						.click();
			} catch (Exception e) {

			}
		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_oters_oneoffcharge" + ".png", driver,
					"");
		} catch (Exception e) {
		}

	}

	public void selectProductOffering_Other_customerDiscount(String discount,
			String className, String methodName) throws IOException {

		getOtherTab().click();
		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='Customer Discount']/preceding-sibling::img[1]"))
				.click();
		if ("".equalsIgnoreCase(discount)) {

			driver
					.findElement(By.id("Other"))
					.findElement(
							By
									.xpath("//b[text()='Customer Discount']/following::input[1]"))
					.click();

		} else {
			try {
				driver.findElement(
						By.xpath("//td[contains(.,'" + discount + "')]/input"))
						.click();
			} catch (Exception e) {

			}
		}

		driver
				.findElement(By.id("Other"))
				.findElement(
						By
								.xpath("//b[text()='Customer Discount']/preceding-sibling::input[1]"))
				.click();

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_oters_customerDiscount" + ".png",
					driver, "");
		} catch (Exception e) {
		}

	}

	public void selectProductOffering_Voice_AllCalls() {

		getVoiceTab().click();
		driver.findElement(By.id("Telephony")).findElement(
				By.xpath("//b[text()='Calls']/preceding-sibling::img[1]"))
				.click();

		driver.findElement(By.id("B-30% Disct 30 Countries")).click();
		driver.findElement(By.id("B-Unlimited Calls Mobile")).click();

		/*
		 * if (driver.findElement( By.name(
		 * "PCM*B2B-C-BBLC*38*BusinessAdvancedBBand,Line&amp;Calls**B-Calls*16"
		 * )) .isEnabled()) { driver.findElement( By.name(
		 * "PCM*B2B-C-BBLC*38*BusinessAdvancedBBand,Line&amp;Calls**B-Calls*16"
		 * )) .click(); }
		 * 
		 * 
		 * if (driver.findElement(By.id(
		 * "B2B-C-BBC*36*Business Advanced Broadband and Calls*B-Calls*16**B-Unlimited OffPeakCalls*8"
		 * )).isDisplayed()) { if (driver .findElement( By.id(
		 * "B2B-C-BBC*36*Business Advanced Broadband and Calls*B-Calls*16**B-Unlimited OffPeakCalls*8"
		 * )) .isEnabled()) { driver.findElement( By.id(
		 * "B2B-C-BBC*36*Business Advanced Broadband and Calls*B-Calls*16**B-Unlimited OffPeakCalls*8"
		 * )) .click(); } }
		 */
		driver.findElement(By.id("B-Unlimited Peak Calls")).click();

		// driver.findElement(By.name("PCM*Calls*CPPostCode")).sendKeys("LG3 3GN");

	}

	public void selectProductOffering_Other_CallingFeatures(String className,
			String methodName) throws IOException {

		getVoiceTab().click();
		getVoiceTab()
				.findElement(
						By
								.xpath("//b[text()='Business Calling Features']/preceding-sibling::img[1]"))
				.click();

		getVoiceTab()
				.findElement(
						By
								.xpath("//b[text()='Business Calling Features']/preceding-sibling::input[1]"))
				.click();

		driver.findElement(By.id("CF Call Waiting")).click();
		driver.findElement(By.id("CF Called Party Answer")).click();
		driver.findElement(By.id("CF Caller Display")).click();

		/*
		 * driver.findElement(By.id("Voice")) .findElement(
		 * By.xpath("//b[text()='Call Waiting']/following::input[1]")) .click();
		 * 
		 * driver.findElement(By.id("Voice")) .findElement(
		 * By.xpath("//b[text()='Called Party Answer']/following::input[1]"))
		 * .click();
		 * 
		 * driver.findElement(By.id("Voice")) .findElement(
		 * By.xpath("//b[text()='Caller Display']/following::input[1]"))
		 * .click();
		 */

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_oters_CallingFeatures" + ".png",
					driver, "");
		} catch (Exception e) {
		}
	}

	public void selectProductOffering_Voice_Calls(String className,
			String methodName) {

		getVoiceTab().click();
		getVoiceTab().findElement(
				By.xpath("//b[text()='Calls']/preceding-sibling::img[1]"))
				.click();
		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_oters_CallingFeatures" + ".png",
					driver, "");
			getAnyTimeCalls().click();
			getMins500().click();
		} catch (Exception e) {
		}

	}

	public void selectProductOffering_Voice_Calls() {

		getVoiceTab().click();
		getVoiceTab().findElement(
				By.xpath("//b[text()='Calls']/preceding-sibling::img[1]"))
				.click();
		try {
			getAnyTimeCalls().click();
			getMins500().click();
		} catch (Exception e) {
		}

	}

	public void selectProductOffering_New(String proposition, String postcode,
			String title, String firstname, String surName, String contract,
			String serviceId, String ddiRangeNum, String sddirangeNum,
			String className, String methodName) throws IOException {

		CommonMethods.doPause(3);

		if (proposition.contains("Business Essential Broadband and Calls")
				|| proposition
						.contains("Business Advanced Broadband and Calls")
				|| proposition.contains("Business Broadband and Calls")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_voice(postcode);
			selectProductOffering_Other(contract);
		}

		else if (proposition
				.contains("Superfast Business Advanced Broadband, Line & Calls")
				|| proposition
						.contains("Superfast Business Advanced Broadband, Line AND Calls")) {
			clickBusinessRateCardAndSelect();
			selectProductOffering_Other(contract);
			selectProductOffering_AnalogueVoice(title, firstname, surName);
		}

		else if (proposition.contains("Superfast Business Broadband and Calls")
				|| proposition.contains("Superfast Business Broadband & Calls")) {
			selectProductOffering_voice(postcode);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Business Advanced BBand, Line & Calls")
				|| proposition
						.contains("Business Broadband, Line Rental & Calls")
				|| proposition
						.contains("Business Essential BBand, Line & Calls")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_Line_voice(title, firstname, surName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("ISDN")) {
			selectProductOffering_ISDN_voice(proposition, serviceId,
					ddiRangeNum, sddirangeNum, className, methodName);
			selectProductOffering_ISDN(title, firstname, surName, className,
					methodName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Business Advanced BBand & Line Rental")
				|| proposition.contains("Business Broadband and Line Rental")
				|| proposition
						.contains("Business Essential BBand & Line Rental")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_Line(title, firstname, surName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Business Essential Broadband")
				|| proposition.contains("Business Advanced Broadband")
				|| proposition.contains("Business Broadband")) {
			selectProductOffering_BroadBand(proposition);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Broadband and Anytime Calls")
				|| proposition.contains("Broadband and Off Peak Calls")
				|| proposition.contains("Broadband and Total Calls")
				|| proposition.contains("Broadband & Anytime Calls")
				|| proposition.contains("Broadband & Off Peak Calls")
				|| proposition.contains("Broadband & Total Calls")) {
			selectProductOffering_Line(title, firstname, surName);
			selectProductOffering_Other(contract);
		}

		else if (proposition.contains("Line Rental and Calls")) {
			selectProductOffering_Line_voice(title, firstname, surName);
			selectProductOffering_Other(contract);

		} else if (proposition.contains("Superfast Broadband")) {
			selectProductOffering_Line(title, firstname, surName);
			selectProductOffering_Other(contract);
		}
		if (proposition.contains("Line") && !isAnalogSet) {
			selectProductOffering_Line_voice(title, firstname, surName);
		}

		if (proposition.contains("Calls Only")) {
			selectProductOffering_voice(postcode);
		}

		if (proposition.contains("Total Calls")) {
			selectProductOffering_Voice_Calls(className, methodName);
		}

	}

	private void selectProductOffering_ISDN_voice(String proposition,
			String serviceId, String ddiRangeNum, String sddirangeNum,
			String className, String methodName) throws IOException {

		getVoiceTab().click();
		clickBusinessRateCardAndSelect();

		setVoiceTab_CareLevel1();
		if (proposition.contains("ISDN2")) {
			selectProductOffering_ISDN2Voice_DDI(ddiRangeNum, sddirangeNum,
					className, methodName);

		} else {
			// selectProductOffering_ISDN30Voice_DDI(className, methodName);
			// selectProductOffering_ISDN30Voice_SNDDI(className, methodName);
			selectProductOffering_ISDN30Voice_Line(serviceId, ddiRangeNum,
					sddirangeNum, className, methodName);

		}

		// selectProductOffering_ISDN2Voice_System(className, methodName);
		try {
			CommonClass.saveScreenshot(className, methodName,
					"selectProductOffering_ISDN_voice" + ".png", driver, "");
		} catch (Exception e) {
		}

	}

	private void selectProductOffering_ISDN2Voice_DDI(String ddiRangeNum,
			String sddirangeNum, String className, String methodName) {
		/*
		 * getVoiceTab() .findElement(
		 * By.xpath("//b[text()='ISDN2 Voice Line']/preceding-sibling::img[1]"))
		 * .click();
		 */
		getIsdn2VoiceLine().click();

		if (!getIsdnDDINumbers().isSelected()) {
			getIsdnDDINumbers().click();
		}
		getDdiRangeNumbers().clear();
		getDdiRangeNumbers().sendKeys(ddiRangeNum);

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void selectProductOffering_ISDN2Voice_SNDDI(String ddiRangeNum,
			String sddirangeNum, String className, String methodName) {
		/*
		 * getVoiceTab() .findElement(
		 * By.xpath("//b[text()='ISDN2 Voice Line']/preceding-sibling::img[1]"))
		 * .click();
		 */

		if (!getIsdnSNDDINumbers().isSelected()) {
			getIsdnSNDDINumbers().click();
		}

		getSnddiRangeNumbers().clear();
		getSnddiRangeNumbers().sendKeys(sddirangeNum);

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void selectProductOffering_ISDN30Voice_Line(String serviceId,
			String ddiRangeNum, String sddirangeNum, String className,
			String methodName) {
System.out.println("I am here1");
		getIsdn30VoiceLine().click();
		System.out.println("I am here2");
		getIsdnDDINumbers().click();
		System.out.println("I am here3");
		getIsdnSNDDINumbers().click();
		System.out.println("I am here4");

		getServiceID().clear();
		getServiceID().sendKeys(serviceId);
		System.out.println("I am here 5");
		getDdiRangeNumbers().clear();
		getDdiRangeNumbers().sendKeys(ddiRangeNum);
		System.out.println("I am here 6");
		getSnddiRangeNumbers().clear();
		getSnddiRangeNumbers().sendKeys(sddirangeNum);
		System.out.println("I am here 7");
		try {
		//	getIsdn30TelOneoffCharges().click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectProductOffering_ISDN_Modify(String proposition,
			String postcode, String title, String firstname, String surName,
			String contract, String serviceId, String ddiRangeNum,
			String sddirangeNum, String className, String methodName)
			throws IOException {

		CommonMethods.doPause(3);

		if (proposition.contains("ISDN")) {

			getVoiceTab().click();
			// clickBusinessRateCardAndSelect();

			selectISDN2EStandardfeatires(className, methodName);

			if (proposition.contains("ISDN2")) {
				selectProductOffering_ISDN2Voice_DDI(ddiRangeNum, sddirangeNum,
						className, methodName);
				selectProductOffering_ISDN2Voice_SNDDI(ddiRangeNum,
						sddirangeNum, className, methodName);
			} else {
				selectProductOffering_ISDN30Voice_Line(serviceId, ddiRangeNum,
						sddirangeNum, className, methodName);
			}
			selectProductOffering_Other(contract);
		}

	}

	private void selectISDN2EStandardfeatires(String className,
			String methodName) {

		getVoiceTab()
				.findElement(
						By
								.xpath("//b[text()='ISDN2e Standard Features']/preceding-sibling::img[1]"))
				.click();

		driver.findElement(By.id("CF WDA AdminCall Fwd-busy")).click();
		driver.findElement(By.id("CF WDAAdminCall Fwd-norep")).click();
		driver.findElement(By.id("CF WDA Call Defelction")).click();
		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * This method makes us to select options in ProductOffering page
	 * 
	 * @param proposition
	 * @param broadBandCare
	 * @param router
	 * @param businessRateCard
	 * @param calls
	 * @param carelevel
	 * @param selectcalls
	 * @param contract
	 * @param oneOffCharge
	 * @param rateCardDiscount
	 * @param salesPromotion
	 * @param customerDiscount
	 * @param postcode
	 * @param title
	 * @param firstName1
	 * @param surName1
	 * @param serviceId
	 * @param ddiRangeNum
	 * @param sddirangeNum
	 * @param managedInstall
	 * @param className
	 * @param methodName
	 * @throws IOException
	 */

	public void selectProductOffering_Asset(
			String proposition,
			String broadBandCare, 
			String router, 
			String businessRateCard,
			String calls, 
			String carelevel, 
			String selectcalls,
			String contract,
			String oneOffCharge, 
			String rateCardDiscount,
			String salesPromotion, 
			String customerDiscount, 
			String postcode,
			String title, 
			String firstName, 
			String surName, 
			String serviceId,
			String ddiRangeNum, 
			String sddirangeNum, 
			String managedInstall,
			String broadbandFeature, 
			String className, 
			String methodName)
			throws IOException {

		logger.info(":	start the selectProductOffering_Asset");

		CommonMethods.doPause(10);

		System.out.println("first nameeeeee:::::::::" + firstName);
		System.out.println("surnameeeee:::::::::" + surName);

		if (proposition.contains("Broadband") || proposition.contains("BB")
				|| proposition.contains("40:")) {

			if (!"".equals(broadBandCare)) {
				selectProductOffering_BroadBand_Care(proposition,
						broadBandCare, className, methodName);
			}
			if (!"".equals(router)) {
				selectProductOffering_BroadBand_BroadBandRouter(router,
						className, methodName);
			}

			System.out
					.println("I have come to check Enchance String in the Manage Installed");
			if (!"".equals(managedInstall)) {
				selectProductOffering_Broadband_ManagedInstall(managedInstall,
						className, methodName);
				System.out
						.println("Now I have to go in search of selectProductOffering_Broadband_ManagedInstall method");

			}

			/*
			 * if (managedInstall.contains(
			 * "NGA Install Plus 2 [inc. Router, PC and two additional devices]"
			 * )) {
			 * 
			 * selectProductOffering_BroadBand_ManageInstallBoltOn(
			 * managedInstall, className, methodName); System.out.println(
			 * "Now I have to go in search of selectProductOffering_BroadBand_ManageInstallBoltOn method"
			 * ); }
			 */

			/*** added by asim **/

			if (!"".equals(broadbandFeature)) {
				selectProductOffering_Broadband_Features(broadbandFeature,
						className, methodName);
			}
		}

		if (proposition.contains("Line") || proposition.contains("Call")) {

			if (proposition.contains("Business Essential Broadband and Calls")
					|| proposition
							.contains("Business Advanced Broadband and Calls")
					|| proposition.contains("Business Broadband and Calls")
					|| proposition
							.contains("Superfast Business Broadband and Calls")
					|| proposition
							.contains("Superfast Business Broadband & Calls")
					|| proposition.contains("Calls Only")) {

				if (!"".equals(postcode) && !proposition.contains("Line")) {
					selectProductOffering_voice(postcode, className, methodName);
					isAnalogAvailable = false;

				}

			}

			if (!"".equals(businessRateCard) && isAnalogAvailable) {
				selectProductOffering_Voice_BusinessRateCard(businessRateCard,
						className, methodName);
			}

			if (!"".equals(carelevel) && isAnalogAvailable) {
				selectProductOffering_Voice_VoiceCarelevel(carelevel,
						className, methodName);
			}

			logger.info(":	end the selectProductOffering_Asset");
		}

		if (proposition.contains("ISDN")) {

			if (!"".equals(businessRateCard)) {
				selectProductOffering_Voice_BusinessRateCard(businessRateCard,
						className, methodName);
			} else {
				clickBusinessRateCardAndSelect();
			}

			if (!"".equals(carelevel) && isAnalogAvailable) {
				selectProductOffering_Voice_VoiceCarelevel(carelevel,
						className, methodName);
			} else {
				setVoiceTab_CareLevel1();
			}
			
		 
			

			selectProductOffering_ISDNVoice(proposition, serviceId,
					ddiRangeNum, sddirangeNum, className, methodName);
			selectProductOffering_ISDN(title, firstName, surName, className,
					methodName);
			// selectProductOffering_Other(contract, className, methodName);
		}

		if (proposition.contains("Line") || proposition.contains("Call")) {
			selectProductOffering_AnalogueVoice(title, firstName, surName,
					className, methodName);
		}

		selectProductOffering_Other_Contract(contract, className, methodName);
		if (!"".equals(oneOffCharge)) {
			selectProductOffering_Other_OneOffCharges(oneOffCharge, className,
					methodName);
		}
		if (!"".equals(rateCardDiscount)) {
			selectProductOffering_Other_RateCardDiscount(rateCardDiscount,
					className, methodName);
		}
		if (!"".equals(customerDiscount)) {
			selectProductOffering_Other_CustomerDiscount(customerDiscount,
					className, methodName);
		}
		if (!"".equals(salesPromotion)) {
			selectProductOffering_Other_B2BSalesPromotion(salesPromotion,
					className, methodName);
		}

	}
	
	// added by gopikrishna
	/**
	 * This method makes us to select options in ProductOffering page
	 * 
	 * @param proposition
	 * @param broadBandCare
	 * @param router
	 * @param businessRateCard
	 * @param calls
	 * @param carelevel
	 * @param rentalCharge
	 * @param selectcalls
	 * @param contract
	 * @param oneOffCharge
	 * @param rateCardDiscount
	 * @param salesPromotion
	 * @param customerDiscount
	 * @param postcode
	 * @param title
	 * @param firstName1
	 * @param surName1
	 * @param serviceId
	 * @param ddiRangeNum
	 * @param sddirangeNum
	 * @param managedInstall
	 * @param className
	 * @param methodName
	 * @throws IOException
	 */
	public void selectProductOffering_Monthly(String proposition,
			String broadBandCare, String router, String businessRateCard,
			String calls, String carelevel,String rentalCharge,String ISDN30OneCharges, String selectcalls,
			String contract, String oneOffCharge, String rateCardDiscount,
			String salesPromotion, String customerDiscount, String postcode,
			String title, String firstName, String surName, String serviceId,
			String ddiRangeNum, String sddirangeNum, String managedInstall,

			String broadbandFeature, String className, String methodName)
			throws IOException {

		logger.info(":	start the selectProductOffering_Asset");

		CommonMethods.doPause(10);

		System.out.println("first nameeeeee:::::::::" + firstName);
		System.out.println("surnameeeee:::::::::" + surName);

		if (proposition.contains("Broadband") || proposition.contains("BB")
				|| proposition.contains("40:")) {

			if (!"".equals(broadBandCare)) {
				selectProductOffering_BroadBand_Care(proposition,
						broadBandCare, className, methodName);
			}
			if (!"".equals(router)) {
				selectProductOffering_BroadBand_BroadBandRouter(router,
						className, methodName);
			}

			System.out
					.println("I have come to check Enchance String in the Manage Installed");
			if (!"".equals(managedInstall)) {
				selectProductOffering_Broadband_ManagedInstall(managedInstall,
						className, methodName);
				System.out
						.println("Now I have to go in search of selectProductOffering_Broadband_ManagedInstall method");

			}

			/*
			 * if (managedInstall.contains(
			 * "NGA Install Plus 2 [inc. Router, PC and two additional devices]"
			 * )) {
			 * 
			 * selectProductOffering_BroadBand_ManageInstallBoltOn(
			 * managedInstall, className, methodName); System.out.println(
			 * "Now I have to go in search of selectProductOffering_BroadBand_ManageInstallBoltOn method"
			 * ); }
			 */

			/*** added by asim **/

			if (!"".equals(broadbandFeature)) {
				selectProductOffering_Broadband_Features(broadbandFeature,
						className, methodName);
			}
		}

		if (proposition.contains("Line") || proposition.contains("Call")) {

			if (proposition.contains("Business Essential Broadband and Calls")
					|| proposition
							.contains("Business Advanced Broadband and Calls")
					|| proposition.contains("Business Broadband and Calls")
					|| proposition
							.contains("Superfast Business Broadband and Calls")
					|| proposition
							.contains("Superfast Business Broadband & Calls")
					|| proposition.contains("Calls Only")) {

				if (!"".equals(postcode) && !proposition.contains("Line")) {
					selectProductOffering_voice(postcode, className, methodName);
					isAnalogAvailable = false;

				}

			}

			if (!"".equals(businessRateCard) && isAnalogAvailable) {
				selectProductOffering_Voice_BusinessRateCard(businessRateCard,
						className, methodName);
			}

			if (!"".equals(carelevel) && isAnalogAvailable) {
				selectProductOffering_Voice_VoiceCarelevel(carelevel,
						className, methodName);
			}

			logger.info(":	end the selectProductOffering_Asset");
		}

		if (proposition.contains("ISDN")) {

			if (!"".equals(businessRateCard)) {
				selectProductOffering_Voice_BusinessRateCard(businessRateCard,
						className, methodName);
			} else {
				clickBusinessRateCardAndSelect();
			}

			if (!"".equals(carelevel) && isAnalogAvailable) {
				selectProductOffering_Voice_VoiceCarelevel(carelevel,
						className, methodName);
			} else {
				setVoiceTab_CareLevel1();
			}
			
			// added by gopi
			
			
			if (!"".equals(rentalCharge) && isAnalogAvailable) {
				selectProductOffering_Voice_RentalCharge(rentalCharge,
						className, methodName);
			} 
			if (!"".equals(ISDN30OneCharges) && isAnalogAvailable) {
				selectProductOffering_Voice_oneofCharge(ISDN30OneCharges,
						className, methodName);
			}

			selectProductOffering_ISDNVoice(proposition, serviceId,
					ddiRangeNum, sddirangeNum, className, methodName);
			selectProductOffering_ISDN(title, firstName, surName, className,
					methodName);
			// selectProductOffering_Other(contract, className, methodName);
		}

		if (proposition.contains("Line") || proposition.contains("Call")) {
			selectProductOffering_AnalogueVoice(title, firstName, surName,
					className, methodName);
		}

		selectProductOffering_Other_Contract(contract, className, methodName);
		if (!"".equals(oneOffCharge)) {
			selectProductOffering_Other_OneOffCharges(oneOffCharge, className,
					methodName);
		}
		if (!"".equals(rateCardDiscount)) {
			selectProductOffering_Other_RateCardDiscount(rateCardDiscount,
					className, methodName);
		}
		if (!"".equals(customerDiscount)) {
			selectProductOffering_Other_CustomerDiscount(customerDiscount,
					className, methodName);
		}
		if (!"".equals(salesPromotion)) {
			selectProductOffering_Other_B2BSalesPromotion(salesPromotion,
					className, methodName);
		}

	}

	/**
	 * @throws IOException
	 * 
	 */
	private void selectProductOffering_BroadBand_Care(String proposition,
			String broadBandCare, String className, String methodName)
			throws IOException {
		getBroadBandTab().click();

		getBroadBandCare().click();

		try {
			if (broadBandCare.contains("Premium")) {
				getPremiumBroadBandCare().click();
			} else if (broadBandCare.contains("Standard")) {
				getStandardBroadBandCare().click();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		CommonClass.saveScreenshot(className, methodName,
				"ProductDetailsPage_BroadBand_Care" + ".png", driver, "");

	}

	public void selectProductOffering_BroadBand_BroadBandRouter(String router,
			String className, String methodName) {

		getBroadBandTab().click();
		try {
			getBroadBandRouter().click();
			if (router.contains("Customer")) {
				getCustomerBringsOwnRouter().click();
				isHardwarepageAvailable = false;
				System.out.println("isHardwarepageAvailable"
						+ isHardwarepageAvailable);

			} else if (router.contains("Orange")) {
				getOrangeBusinessRouter().click();
				isHardwarepageAvailable = true;
				System.out.println("isHardwarepageAvailable"
						+ isHardwarepageAvailable);
			} else if (router.contains("wireless router")) {
				driver.findElement(
						By.xpath("//td[contains(.,'" + router + "')]/input"))
						.click();
				isHardwarepageAvailable = true;
			} else {
				driver.findElement(
						By.xpath("//td[contains(.,'" + router + "')]/input"))
						.click();
			}
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_BroadBand_BroadBandRouter" + ".png",
					driver, "");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void selectProductOffering_Other_Contract(String contract,
			String className, String methodName) throws IOException {

		getOtherTab().click();
		try {
			getContractTerm().click();
			CommonMethods.doPause(2);
			if (contract != null && !"".equalsIgnoreCase(contract)) {
				try {

					if (contract.contains("12")) {
						getContractTerm_12().click();
					} else if (contract.contains("18")) {
						getContractTerm_18().click();
					} else if (contract.contains("24")) {
						getContractTerm_24().click();
					} else {
						driver.findElement(
								By.xpath("//td[contains(.,'" + contract
										+ "')]/input")).click();
					}
				} catch (Exception e) {
					e.printStackTrace();
					getContractTerm_12().click();
				}
			} else {
				getContractTerm_12().click();
			}
		} catch (Exception ex) {

		}

		CommonClass.saveScreenshot(className, methodName,
				"ProductDetailsPage_Other_Contract" + ".png", driver, "");

	}

	public void selectProductOffering_Other_OneOffCharges(String oneOff,
			String className, String methodName) {
		try {
			getOtherTab().click();
			getOneOffCharges().click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + oneOff + "')]/input"))
					.click();
			CommonMethods.doPause(5);
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Other_OneOffCharges" + ".png", driver,
					"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectProductOffering_Other_RateCardDiscount(String discount,
			String className, String methodName) {
		try {
			getOtherTab().click();
			getRateCardDiscount().click();
			getRateCardDiscount_button().click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + discount + "')]/input"))
					.click();
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Other_RateCardDiscount" + ".png",
					driver, "");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectProductOffering_Other_CustomerDiscount(String discount,
			String className, String methodName) {
		try {
			getOtherTab().click();
			getCustomerDiscount().click();
			getCustomerDiscount_button().click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + discount + "')]/input"))
					.click();
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Other_CustomerDiscount" + ".png",
					driver, "");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectProductOffering_Other_B2BSalesPromotion(
			String salesPromotion, String className, String methodName) {

		try {
			getOtherTab().click();
			getB2bSalesPromotion().click();
			getB2bSalesPromotion_button().click();
			driver.findElement(
					By
							.xpath("//td[contains(.,'" + salesPromotion
									+ "')]/input")).click();
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Other_B2BSalesPromotion" + ".png",
					driver, "");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*******************Modified by Asim******************************************/
	public void selectProductOffering_Voice_VoiceCarelevel(String careLevel,
			String className, String methodName) {
		try {
			getVoiceTab().click();
			getVoiceCareLevel().click();
		//	driver.findElement(By.name("PCM*B2B-D-I30*21*ISDN30*ISDN30VoiceLine*43**VoiceCareLevel*13")).click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + careLevel + "')]/input"))
					.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Voice_VoiceCarelevel" + ".png", driver,
					"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	// added by gopikrishna
	
	
	public void selectProductOffering_Voice_RentalCharge(String RentalCharge,
			String className, String methodName) {
		try {
			getVoiceTab().click();
			getMonthlyRental().click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + RentalCharge + "')]/input"))
					.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			CommonClass.saveScreenshot(className, methodName,
					"selectProductOffering_Voice_RentalCharge" + ".png", driver,
					"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void selectProductOffering_Voice_oneofCharge(String ISDN30OneCharges,
			String className, String methodName) {
		try {
			getVoiceTab().click();
			getISDN30Oneofcharge().click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + ISDN30OneCharges + "')]/input"))
					.click();

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			CommonClass.saveScreenshot(className, methodName,
					"selectProductOffering_Voice_ISDN30OneCharges" + ".png", driver,
					"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public void selectProductOffering_Voice_BusinessRateCard(
			String businessRateCard, String className, String methodName) {
		try {
			getVoiceTab().click();
			getBusinessRateCard().click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + businessRateCard
							+ "')]/input")).click();
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Voice_BusinessRateCard" + ".png",
					driver, "");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectProductOffering_Broadband_ManagedInstall(
			String managedInstall, String className, String methodName)
			throws IOException {

		System.out
				.println("Entering into Enhanced Managed Install for Broadband tab Link Text");
		try {
			//getBroadBandTab().click();
			//getManagedInstallImg().click();
			//getManagedInstall().click();
			
			/*driver.findElement(By.xpath("//b[text()='Managed Install']/preceding-sibling::img[1]")).click();
			driver.findElement(By.id("B-NGA Managed Inst")).click();*/
			
			 /* System.out.println("entering into Broadband Features Img operation");
			  driver.findElement(By.id("B-NGA Managed Inst")) .findElement(
			  By.xpath("//td[contains(.,'Managed Install')]/following-sibling::td[2]/following::a")).click();
			  System.out.println("Managed Install Img got clicked");*/
			 
		  
			System.out.println("Entering to click getManagedInstallNGA() method ");
			
			driver.findElement(By.id("Broadband")).findElement(By.xpath("//b[text()='Managed install']/preceding-sibling::img[1]"))
			.click();
			
			
			
			driver.findElement(By.xpath("//td[contains(.,'Enhanced Managed Install Plus 1 [inc. Router, PC and one additional device]  (�0.00) ]')]/input")).click();
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_ManagedInstalledNGA" + ".png", driver,
					"");

		} catch (Exception e) {
			e.printStackTrace();
			/*driver.findElement(
					By.xpath("//td[contains(.,'Enhanced Managed Install [inc. Router and 1 PC]')]/input"))
					.click();*/

			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_ManagedInstalledEnhanced" + ".png",
					driver, "");
		}

		System.out.println("getManagedInstallNGA() method got clicked");

		/*
		 * driver.findElement( By.xpath("//td[contains(.,'" + managedInstall +
		 * "')]/input")) .click();
		 */

		/*
		 * System.out.println("Entered into Try block for Enchanced");
		 * 
		 * if (managedInstall.contains("Enhanced Managed Install")) {
		 * 
		 * System.out.println(
		 * "In search of Enhanced String for Enhanced Managed Install");
		 * 
		 * driver.findElement( By.xpath("//td[contains(.,'" + managedInstall +
		 * "')]/input")) .click(); // getManagedInstall3().click();
		 * System.out.println("getManagedInstall3() method got clicked");
		 * 
		 * }
		 * 
		 * 
		 * 
		 * else if (managedInstall.contains("NGA Install") ) {
		 * System.out.println
		 * ("In search of NGA string from Managed Install String");
		 * driver.findElement( By.xpath("//td[contains(.,'" + managedInstall +
		 * "')]/input")) .click(); //getManagedInstallNGA().click();
		 * 
		 * System.out.println("getManagedInstallNGA() method got clicked" ); }
		 */

		/*
		 * if (managedInstall.contains("NGA Install Plus 2") ||
		 * managedInstall.contains ("Enhanced Managed Install Plus 1"))
		 * 
		 * 
		 * {
		 * 
		 * System.out.println(
		 * "In search of Enhanced String for Enhanced Managed Install");
		 * 
		 * driver.findElement( By.xpath("//td[contains(.,'" + managedInstall +
		 * "')]/input")) .click();
		 * 
		 * }
		 */

		/*
		 * getManagedInstall().click();
		 * 
		 * System.out
		 * .println("Entering into Enhanced Managed Install 3rd operation");
		 * 
		 * getManagedInstall3().click(); System.out
		 * .println("Clicked on Enhanced Managed Install 3rd  operation");
		 */
		/*
		 * System.out
		 * .println("Entering into Enhanced Managed Install 3rd operation"); if
		 * (managedInstall.contains("Enhanced")) { getManagedInstall3().click();
		 * System.out
		 * .println("Clicked on Enhanced Managed Install 3rd  operation"); }
		 */

		/*
		 * if (managedInstall.contains("NGA")) { //
		 * getManagedInstallNGA().click(); driver.findElement(By.xpath(
		 * "//td[contains(.,'NGA Install Plus 2 [inc. Router, PC and two additional devices]')]/input"
		 * )) .click(); System.out
		 * .println("Clicked on Enhanced Managed Install NGA operation"); }
		 */
		/*
		 * if (managedInstall.contains("Enhanced")) { driver.findElement(
		 * By.xpath(
		 * "//td[contains(.,'Enhanced Managed Install Plus 1 [inc. Router, PC and one additional device]')]/input"
		 * )) .click(); }
		 * 
		 * if (managedInstall.contains("NGA")) { driver.findElement( By.xpath(
		 * "//td[contains(.,'NGA Install Plus 2 [inc. Router, PC and two additional devices]')]/input"
		 * )) .click(); }
		 */

		/*
		 * if (managedInstall.contains("NGA")) {
		 * //getManagedInstallNGA().click();
		 * 
		 * }
		 */

		/*
		 * else if(managedInstall.contains("Enhanced")) {
		 * getManagedInstall3().click(); }
		 */

		/*
		 * else { driver.findElement( By.xpath(
		 * "//td[contains(.,'Enhanced Managed Install Plus 2 [inc. Router, PC and two additional devices]')]/input"
		 * )) .click(); System.out
		 * .println("entering into Enhanced Managed Installoperation");
		 * 
		 * 
		 * driver.findElement( By.xpath("//td[contains(.,'" + managedInstall +
		 * "')]/input")) .click(); }
		 */

		/*
		 * CommonClass.saveScreenshot(className, methodName,
		 * "ProductDetailsPage_Broadband_managedinstall" + ".png", driver, "");
		 */

	}

	/******** added by Asim for Managed Install Bolt on Operation ******/

	/*
	 * public void selectProductOffering_BroadBand_ManageInstallBoltOn( String
	 * managedInstall, String className, String methodName) { System.out
	 * .println
	 * ("Entering into NGA Managed Install for Broadband tab Link Text");
	 * 
	 * getBroadBandTab().click();
	 * 
	 * try {
	 * 
	 * // getBroadBandTab().click(); getManagedInstallImg().click();
	 * getManagedInstall().click();
	 * 
	 * System.out .println("Entering into NGA Managed Install 3rd operation");
	 * 
	 * getManagedInstallNGA().click();
	 * System.out.println("Clicked on NGA Managed Install 3rd  operation");
	 * 
	 * 
	 * else if (managedInstall.contains("wireless router")) {
	 * driver.findElement( By.xpath("//td[contains(.,'" + router + "')]/input"))
	 * .click(); isHardwarepageAvailable = true; } else { driver.findElement(
	 * By.xpath("//td[contains(.,'" + router + "')]/input")) .click(); }
	 * 
	 * CommonClass.saveScreenshot(className, methodName,
	 * "ProductDetailsPage_BroadBand_BroadBandRouter" + ".png", driver, ""); }
	 * catch (Exception e) { e.printStackTrace(); }
	 * 
	 * }
	 */

	/*** added by asim for Broadband features **/
	public void selectProductOffering_Broadband_Features(
			String broadbandFeature, String className, String methodName) {
		try {

			// getBroadBandTab().click();
			// getBroadbandFeaturesImg().click();
			// getBroadbandFeatures().click();

			// getBroadBandTab().click();
			System.out
					.println("entering into Broadband Features Img operation");
			driver
					.findElement(By.id("Broadband"))
					.findElement(
							By
									.xpath("//b[text()='Broadband Features']/preceding-sibling::img[1]"))
					.click();
			System.out.println("Broadband Features Img got clicked");

			System.out.println("entering into dynamic IP operation");

			driver
					.findElement(
							By.xpath("//td[contains(.,'dynamic IP')]/input"))
					.click();

			System.out.println("Dynamic IP address got clicked...");

			/*
			 * driver.findElement( By.xpath("//td[contains(.,'" +
			 * broadbandFeature + "')]/input")).click();
			 * 
			 * CommonClass.saveScreenshot(className, methodName,
			 * "ProductDetailsPage_Broadband_Features" + ".png", driver, "");
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void selectProductOffering_AnalogueVoice(String title,
			String firstName, String surName, String className,
			String methodName) throws IOException {
		try {

			getAnalogueVoiceFeaturesTab().click();

			System.out.println("first nameeeeeessssss:::::::::" + firstName);
			System.out.println("surnameeeeessssssssss:::::::::" + surName);
			System.out.println("titlessssssss:::::::::" + title);

			System.out.println("Entering into Title text field");
			new Select(getDirectoryTitle()).selectByValue(title);
			System.out
					.println("Found success in Entering data into Title text field");

			/*
			 * System.out.println("Entering into Title text field"); if
			 * (!"".equalsIgnoreCase(title)) {
			 * 
			 * new Select(getDirectoryTitle()).selectByVisibleText(title); }
			 * System
			 * .out.println("Found success in Entering data into Title text field"
			 * );
			 */

			System.out.println("Entering into First name text field");
			getFirstName().clear();
			System.out
					.println("Found success in Entering data into First name text field");
			getFirstName().sendKeys(firstName);

			getSurName().clear();
			System.out.println("Entering into Sur name text field");
			getSurName().sendKeys(surName);
			System.out
					.println("Found success in Entering data into Sur name text field");

			isAnalogSet = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Voice_VoiceCarelevel" + ".png", driver,
					"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void selectProductOffering_ISDNVoice(String proposition,
			String serviceId, String ddiRangeNum, String sddirangeNum,
			String className, String methodName) throws IOException {

		if (proposition.contains("ISDN2")) {

			clickISDN2eStandardFeaturesSelect();
			selectProductOffering_ISDN2Voice_DDI(ddiRangeNum, sddirangeNum,
					className, methodName);
		} else {

			if (proposition.contains("ISDN 30 DASS")) {

				selectISDN30DASSFeatures();

				selectProductOffering_ISDN30Voice_Line(serviceId, ddiRangeNum,
						sddirangeNum, className, methodName);
				

			}

			else {

				selectISDN30Features();
				selectProductOffering_ISDN30Voice_Line_30ETSI(serviceId,
						ddiRangeNum, sddirangeNum, className, methodName);
			}

		} // selectProductOffering_ISDN2Voice_System(className, methodName);
		try {
			CommonClass.saveScreenshot(className, methodName,
					"selectProductOffering_ISDN_voice" + ".png", driver, "");
		} catch (Exception e) {

		}

	}

	public void clickCalculatePriceButton(String className, String methodName) {

		logger.info(":	start the clickCalculatePriceButton");

		try {

			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png",

					driver, "");

		} catch (Exception e) {

		}

		getcalculatePriceButton().click();

		logger.info(":	end the clickCalculatePriceButton");

		CommonMethods.doPause(3);

	}

	// Added by Tirumal
	public void selectProductOffering_ISDN30Voice_Line_30ETSI(String serviceId,
			String ddiRangeNum, String sddirangeNum, String className,
			String methodName) {
		getIsdn30VoiceLine().click();
		getIsdnDDINumbers().click();
		getIsdnSNDDINumbers().click();

		//getServiceID30ETSI().clear();
		
		driver.findElement(
				By.name("PCM*ISDN30VoiceLine*ServiceID")).sendKeys(serviceId);
		//getServiceID30ETSI().sendKeys(serviceId);
		getDdiRangeNumbers().clear();
		getDdiRangeNumbers().sendKeys(ddiRangeNum);
		getSnddiRangeNumbers().clear();
		getSnddiRangeNumbers().sendKeys(sddirangeNum);
		try {
			getIsdn30TelOneoffCharges().click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage" + ".png", driver, "");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * to select ISDN2e standard feature
	 */
	public void clickISDN2eStandardFeaturesSelect() {

		logger.info(":     start the clickISDN2eStandardFeaturesSelect");
		try {
			getVoiceTab().click();
			getVoiceTab()
					.findElement(
							By
									.xpath("//b[text()='ISDN2e Standard Features']/preceding-sibling::img[1]"))
					.click();
			WebElement td_Std = driver
					.findElement(By
							.xpath("//td[contains(.,'Admin Controlled Selective Call Barring - SOCB International, National And PRS')]"));
			td_Std.findElement(By.xpath("./input")).click();
			CommonMethods.doPause(5);

		} catch (Exception e) {

			logger.error(e.getMessage());
		}

		logger.info(":      end the clickISDN2eStandardFeaturesSelect");
	}

	/**
	 * to select ISDN30DASS feature
	 */
	public void selectISDN30DASSFeatures() {

		logger.info(":     start the selectISDN30DASSFeatures");
		try {
			getVoiceTab().click();
			getVoiceTab()
					.findElement(
							By
									.xpath("//b[text()='B-ISDN30 DASS Features']/preceding-sibling::img[1]"))
					.click();

			CommonMethods.doPause(15);

			WebElement td_Std = driver
					.findElement(By
							.xpath("//td[contains(.,'Admin Controlled Selective Call Barring - SOCB International, National And PRS')]"));
			td_Std.findElement(By.xpath("./input")).click();

		} catch (Exception e) {

			logger.error(e.getMessage());
		}

		logger.info(":      end the selectISDN30DASSFeatures");
	}

	/**
	 * to select ISDN30 feature
	 */
	public void selectISDN30Features() {

		logger.info(":     start the selectISDN30Features");
		try {
			getVoiceTab().click();
			getVoiceTab()
					.findElement(
							By
									.xpath("//b[text()='ISDN30 Features']/preceding-sibling::img[1]"))
					.click();
			WebElement td_Std = driver
					.findElement(By
							.xpath("//td[contains(.,'Admin Controlled Selective Call Barring - SOCB International, National And PRS')]"));
			td_Std.findElement(By.xpath("./input")).click();

		} catch (Exception e) {

			logger.error(e.getMessage());
		}

		logger.info(":      end the selectISDN30Features");
	}

	/**
	 * This method checks the Total Price in Product Details Page
	 * 
	 * @param className
	 * @param methodName
	 * @return
	 */
	public boolean isTotalPresent(String className, String methodName) {
		logger.info(":	Start of the TotalTitlePresent");
		boolean isPresent = false;

		try {
			CommonClass.saveScreenshot(className, methodName,
					"Product details Page" + ".png", driver, "");
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			isPresent = getTotalTitle().getText().contains("Total : �");
			
			if (isPresent) {
				logger.info("Total Price Present");
			} else {
				logger.info("Total Price Not Present");
			}

		} catch (Exception e) {
			// TODO: handle exception
			isPresent = false;
		}

		logger.info(":	end of the TotalTitlePresent");
		return isPresent;
	}

        
	public void selectProductOffering_Asset_Sprint4(String proposition,
			String broadBandCare, String router, String businessRateCard,
			String calls, String carelevel, String selectcalls,
			String contract, String oneOffCharge, String rateCardDiscount,
			String salesPromotion, String customerDiscount, String postcode,
			String title, String firstName, String surName, String serviceId,
			String ddiRangeNum, String sddirangeNum, String managedInstall,
			String broadbandFeature, String className, String methodName,
			String quantityVoiceCareLevel, String quantityISDN2eSystem,
			String quantityContractTerm) throws IOException {

		logger.info(":       start the selectProductOffering_Asset");

		CommonMethods.doPause(10);

		System.out.println("first nameeeeee:::::::::" + firstName);
		System.out.println("surnameeeee:::::::::" + surName);

		if (proposition.contains("Broadband") || proposition.contains("BB")
				|| proposition.contains("40:")) {

			if (!"".equals(broadBandCare)) {
				selectProductOffering_BroadBand_Care(proposition,
						broadBandCare, className, methodName);
			}
			if (!"".equals(router)) {
				selectProductOffering_BroadBand_BroadBandRouter(router,
						className, methodName);
			}

			System.out
					.println("I have come to check Enchance String in the Manage Installed");
			if (!"".equals(managedInstall)) {
				selectProductOffering_Broadband_ManagedInstall(managedInstall,
						className, methodName);
				System.out
						.println("Now I have to go in search of selectProductOffering_Broadband_ManagedInstall method");

			}

			/*
			 * if (managedInstall.contains(
			 * "NGA Install Plus 2 [inc. Router, PC and two additional devices]"
			 * )) {
			 * 
			 * selectProductOffering_BroadBand_ManageInstallBoltOn(
			 * managedInstall, className, methodName); System.out.println(
			 * "Now I have to go in search of selectProductOffering_BroadBand_ManageInstallBoltOn method"
			 * ); }
			 */

			/*** added by asim **/

			if (!"".equals(broadbandFeature)) {
				selectProductOffering_Broadband_Features(broadbandFeature,
						className, methodName);
			}
		}

		if (proposition.contains("Line") || proposition.contains("Call")) {

			if (proposition.contains("Business Essential Broadband and Calls")
					|| proposition
							.contains("Business Advanced Broadband and Calls")
					|| proposition.contains("Business Broadband and Calls")
					|| proposition
							.contains("Superfast Business Broadband and Calls")
					|| proposition
							.contains("Superfast Business Broadband & Calls")
					|| proposition.contains("Calls Only")) {

				if (!"".equals(postcode) && !proposition.contains("Line")) {
					selectProductOffering_voice(postcode, className, methodName);
					isAnalogAvailable = false;

				}

			}

			if (!"".equals(businessRateCard) && isAnalogAvailable) {
				selectProductOffering_Voice_BusinessRateCard(businessRateCard,
						className, methodName);
			}

			if (!"".equals(carelevel) && isAnalogAvailable) {
				selectProductOffering_Voice_VoiceCarelevel(carelevel,
						className, methodName);
			}

			logger.info(":       end the selectProductOffering_Asset");
		}

		if (proposition.contains("ISDN")) {

			if (!"".equals(businessRateCard)) {
				selectProductOffering_Voice_BusinessRateCard(businessRateCard,
						className, methodName);
			} else {
				clickBusinessRateCardAndSelect();
			}

			if (!"".equals(carelevel)) {
				// Added for Sprint4
				if (proposition.contains("ISDN2e System")) {
					System.out
							.println("entered:::::::::::::::::::::::::::::::");
					selectProductOffering_Voice_VoiceCarelevel_Sprint4(
							carelevel, quantityVoiceCareLevel,
							quantityISDN2eSystem, className, methodName);

				} else {
					selectProductOffering_Voice_VoiceCarelevel(carelevel,
							className, methodName);
				}
			} else {
				setVoiceTab_CareLevel1();
			}

			if (proposition.contains("ISDN2e System")) {
				new Select(driver.findElement(By.xpath("//td[contains(.,'"
						+ "ISDN2e System" + "')]/following::select[1]")))
						.selectByVisibleText(quantityISDN2eSystem);
			}
			selectProductOffering_ISDNVoice(proposition, serviceId,
					ddiRangeNum, sddirangeNum, className, methodName);
			selectProductOffering_ISDN(title, firstName, surName, className,
					methodName);
			
			
			// selectProductOffering_Other(contract, className, methodName);
		}

		if (proposition.contains("ISDN2e")) {
			selectProductOffering_Other_Contract_Sprint4(contract,
					quantityContractTerm, className, methodName);
		} else {
			selectProductOffering_Other_Contract(contract, className,
					methodName);
		}

		if (!"".equals(oneOffCharge)) {
			selectProductOffering_Other_OneOffCharges(oneOffCharge, className,
					methodName);
		}
		if (!"".equals(rateCardDiscount)) {
			selectProductOffering_Other_RateCardDiscount(rateCardDiscount,
					className, methodName);
		}
	}

	private void selectProductOffering_Other_Contract_Sprint4(String contract,
			String quantityContractTerm, String className, String methodName)
			throws IOException {

		getOtherTab().click();
		try {
			getContractTerm().click();
			CommonMethods.doPause(2);
			if (contract != null && !"".equalsIgnoreCase(contract)) {
				try {

					driver.findElement(
							By.xpath("//td[contains(.,'" + contract
									+ "')]/input")).click();
					if (contract.contains("with charge")) {
						new Select(driver.findElement(By
								.xpath("//td[contains(.,'" + "with charge"
										+ "')]/following::select[1]")))
								.selectByVisibleText(quantityContractTerm);
					} else if (contract.contains("free")) {
						new Select(driver.findElement(By
								.xpath("//td[contains(.,'" + "free"
										+ "')]/following::select[1]")))
								.selectByVisibleText(quantityContractTerm);
					} else if (contract.contains("cost price")) {
						new Select(driver.findElement(By
								.xpath("//td[contains(.,'" + "cost price"
										+ "')]/following::select[1]")))
								.selectByVisibleText(quantityContractTerm);
					}

				} catch (Exception e) {
					e.printStackTrace();

				}
			} else {
				getContractTerm_12().click();
			}
		} catch (Exception ex) {

		}

		CommonClass.saveScreenshot(className, methodName,
				"ProductDetailsPage_Other_Contract" + ".png", driver, "");
	}
	
	
	
//added by Subhani
	/*public�void�selectProductOffering_ISDN30Voice_Line_30ETSI_Modify(
������� ������� ��������String className, String methodName, String proposition,
������� ������� ��������String carelevel) {
������� ��������if�(proposition.contains("ISDN 30 ETSI")) {
������� ������� ��������System.out.println("entered:::::::::::::::::::::::::::::::");
������� ������� ��������selectProductOffering_Voice_VoiceCarelevel_Modify(carelevel,
������� ������� ������� ������� ��������className, methodName);
������� ��������}�else�{
������� ������� ��������selectProductOffering_Voice_VoiceCarelevel(carelevel, className,
������� ������� ������� ������� ��������methodName);
������� ��������}
��������}*/


	public void selectProductOffering_Voice_VoiceCarelevel_Sprint4(
			String careLevel, String quantityVoiceCareLevel,
			String quantityISDN2eSystem, String className, String methodName) {
		try {
			getVoiceTab().click();
			getVoiceCareLevel().click();
			driver.findElement(
					By.xpath("//td[contains(.,'" + careLevel + "')]/input"))
					.click();

			System.out.println("tirmuallllllllllllllllllllllllllll");

			if (careLevel.contains("Standard business landline support")) {
				// new
				// Select(getQuantity_VoiceCareLevel()).selectByVisibleText(quantityVoiceCareLevel);

				System.out.println("************************"
						+ driver.findElement(
								By.xpath("//td[contains(.,'" + careLevel
										+ "')]/following::select[1]"))
								.getText());

				new Select(driver.findElement(By.xpath("//td[contains(.,'"
						+ careLevel + "')]/following::select[1]")))
						.selectByVisibleText(quantityVoiceCareLevel);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			CommonClass.saveScreenshot(className, methodName,
					"ProductDetailsPage_Voice_VoiceCarelevel" + ".png", driver,
					"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}






/******************************************Sprint 5 added by Asim*****************************************/
	



public void selectProductOffering_Asset_Sprint5(
		String proposition,
		String broadBandCare, 
		String router, 
		String businessRateCard,
		String calls, 
		String carelevel, 
		String rentalCharge,
		String selectcalls,
		String contract,
		String oneOffCharge,
		String rateCardDiscount,
		String salesPromotion,
		String customerDiscount,
		String postcode,
		String title,
		String firstName,
		String surName,
		String serviceId,
		String ddiRangeNum,
		String sddirangeNum,
		String managedInstall,
		String broadbandFeature,
		String className,
		String methodName,
		String quantityVoiceCareLevel,
		String quantityISDN2eSystem,
		String quantityContractTerm) throws IOException {
	
	


	logger.info(":       start the selectProductOffering_Asset");

	CommonMethods.doPause(10);

	System.out.println("first nameeeeee:::::::::" + firstName);
	System.out.println("surnameeeee:::::::::" + surName);

	if (proposition.contains("Broadband") || proposition.contains("BB")
			|| proposition.contains("40:")) {

		if (!"".equals(broadBandCare)) {
			selectProductOffering_BroadBand_Care(proposition,
					broadBandCare, className, methodName);
		}
		if (!"".equals(router)) {
			selectProductOffering_BroadBand_BroadBandRouter(router,
					className, methodName);
		}

		System.out
				.println("I have come to check Enchance String in the Manage Installed");
		if (!"".equals(managedInstall)) {
			selectProductOffering_Broadband_ManagedInstall(managedInstall,
					className, methodName);
			System.out
					.println("Now I have to go in search of selectProductOffering_Broadband_ManagedInstall method");

		}

		/*
		 * if (managedInstall.contains(
		 * "NGA Install Plus 2 [inc. Router, PC and two additional devices]"
		 * )) {
		 * 
		 * selectProductOffering_BroadBand_ManageInstallBoltOn(
		 * managedInstall, className, methodName); System.out.println(
		 * "Now I have to go in search of selectProductOffering_BroadBand_ManageInstallBoltOn method"
		 * ); }
		 */

		/*** added by asim **/

		if (!"".equals(broadbandFeature)) {
			selectProductOffering_Broadband_Features(broadbandFeature,
					className, methodName);
		}
	}

	if (proposition.contains("Line") || proposition.contains("Call")) {

		if (proposition.contains("Business Essential Broadband and Calls")
				|| proposition
						.contains("Business Advanced Broadband and Calls")
				|| proposition.contains("Business Broadband and Calls")
				|| proposition
						.contains("Superfast Business Broadband and Calls")
				|| proposition
						.contains("Superfast Business Broadband & Calls")
				|| proposition.contains("Calls Only")) {

			if (!"".equals(postcode) && !proposition.contains("Line")) {
				selectProductOffering_voice(postcode, className, methodName);
				isAnalogAvailable = false;

			}

		}

		if (!"".equals(businessRateCard) && isAnalogAvailable) {
			selectProductOffering_Voice_BusinessRateCard(businessRateCard,
					className, methodName);
		}

		if (!"".equals(carelevel) && isAnalogAvailable) {
			selectProductOffering_Voice_VoiceCarelevel(carelevel,
					className, methodName);
		}

		logger.info(":       end the selectProductOffering_Asset");
	}

	if (proposition.contains("ISDN")) {

		if (!"".equals(businessRateCard)) {
			selectProductOffering_Voice_BusinessRateCard(businessRateCard,
					className, methodName);
		} else {
			clickBusinessRateCardAndSelect();
		}

		if (!"".equals(carelevel)) {
			// Added for Sprint4
			if (proposition.contains("ISDN2e System")) {
				System.out
						.println("entered:::::::::::::::::::::::::::::::");
				selectProductOffering_Voice_VoiceCarelevel_Sprint4(
						carelevel, quantityVoiceCareLevel,
						quantityISDN2eSystem, className, methodName);

			} else {
				selectProductOffering_Voice_VoiceCarelevel(carelevel,
						className, methodName);
			}
		} else {
			setVoiceTab_CareLevel1();
		}

		if (proposition.contains("ISDN2e System")) {
			new Select(driver.findElement(By.xpath("//td[contains(.,'"
					+ "ISDN2e System" + "')]/following::select[1]")))
					.selectByVisibleText(quantityISDN2eSystem);
		}
		
		if (proposition.contains("ISDN2")) {

			clickISDN2eStandardFeaturesSelect();
			selectProductOffering_ISDN2Voice_DDI(ddiRangeNum, sddirangeNum,
					className, methodName);
		} else {

			if (proposition.contains("ISDN 30 DASS")|| (proposition.contains("ISDN 30 ETSI"))) {

				selectISDN30DASSFeatures();

				selectProductOffering_ISDN30Voice_Line(serviceId, ddiRangeNum,
						sddirangeNum, className, methodName);
				selectProductOffering_ISDN(title, firstName, surName, className,
						methodName);

			}

			else {

				selectISDN30Features();
				selectProductOffering_ISDN30Voice_Line_30ETSI(serviceId,
						ddiRangeNum, sddirangeNum, className, methodName);
				selectProductOffering_ISDN(title, firstName, surName, className,
						methodName);
			}
		/*selectProductOffering_ISDNVoice(proposition, serviceId,
				ddiRangeNum, sddirangeNum, className, methodName);
		selectProductOffering_ISDN(title, firstName, surName, className,
				methodName);*/
		// selectProductOffering_Other(contract, className, methodName);
	}

	if (proposition.contains("ISDN2e")) {
		selectProductOffering_Other_Contract_Sprint4(contract,
				quantityContractTerm, className, methodName);
	} else {
		selectProductOffering_Other_Contract(contract, className,
				methodName);
	}

	if (!"".equals(oneOffCharge)) {
		selectProductOffering_Other_OneOffCharges(oneOffCharge, className,
				methodName);
	}
	if (!"".equals(rateCardDiscount)) {
		selectProductOffering_Other_RateCardDiscount(rateCardDiscount,
				className, methodName);
	}


	logger.info(":       start the selectProductOffering_Asset");

	CommonMethods.doPause(10);

	

	if (proposition.contains("Broadband") || proposition.contains("BB")
			|| proposition.contains("40:")) {

		if (!"".equals(broadBandCare)) {
			selectProductOffering_BroadBand_Care(proposition,
					broadBandCare, className, methodName);
		}
		if (!"".equals(router)) {
			selectProductOffering_BroadBand_BroadBandRouter(router,
					className, methodName);
		}

		System.out
				.println("I have come to check Enchance String in the Manage Installed");
		if (!"".equals(managedInstall)) {
			selectProductOffering_Broadband_ManagedInstall(managedInstall,
					className, methodName);
			System.out
					.println("Now I have to go in search of selectProductOffering_Broadband_ManagedInstall method");

		}

		

		/*** added by asim **/

		if (!"".equals(broadbandFeature)) {
			selectProductOffering_Broadband_Features(broadbandFeature,
					className, methodName);
		}
	}

	if (proposition.contains("Line") || proposition.contains("Call")) {

		if (proposition.contains("Business Essential Broadband and Calls")
				|| proposition
						.contains("Business Advanced Broadband and Calls")
				|| proposition.contains("Business Broadband and Calls")
				|| proposition
						.contains("Superfast Business Broadband and Calls")
				|| proposition
						.contains("Superfast Business Broadband & Calls")
				|| proposition.contains("Calls Only")) {

			if (!"".equals(postcode) && !proposition.contains("Line")) {
				selectProductOffering_voice(postcode, className, methodName);
				isAnalogAvailable = false;

			}

		}

		if (!"".equals(businessRateCard) && isAnalogAvailable) {
			selectProductOffering_Voice_BusinessRateCard(businessRateCard,
					className, methodName);
		}

		if (!"".equals(carelevel) && isAnalogAvailable) {
			selectProductOffering_Voice_VoiceCarelevel(carelevel,
					className, methodName);
		}

		logger.info(":       end the selectProductOffering_Asset");
	}

	if (proposition.contains("ISDN")) {

		if (!"".equals(businessRateCard)) {
			selectProductOffering_Voice_BusinessRateCard(businessRateCard,
					className, methodName);
		} else {
			clickBusinessRateCardAndSelect();
		}

		if (!"".equals(carelevel)) {
			// Added for Sprint5
			if (proposition.contains("ISDN2e System")) {
				System.out
						.println("entered:::::::::::::::::::::::::::::::");
				selectProductOffering_Voice_VoiceCarelevel_Sprint4(
						carelevel, quantityVoiceCareLevel,
						quantityISDN2eSystem, className, methodName);

			} else {
				selectProductOffering_Voice_VoiceCarelevel(carelevel,
						className, methodName);
			}
		} else {
			setVoiceTab_CareLevel1();
		}

		/*if (proposition.contains("ISDN2e System")) {
			new Select(driver.findElement(By.xpath("//td[contains(.,'"
					+ "ISDN2e System" + "')]/following::select[1]")))
					.selectByVisibleText(quantityISDN2eSystem);
		}
		selectProductOffering_ISDNVoice(proposition, serviceId,
				ddiRangeNum, sddirangeNum, className, methodName);
		selectProductOffering_ISDN(title, firstName, surName, className,
				methodName);*/
		// selectProductOffering_Other(contract, className, methodName);
	}

	if (proposition.contains("ISDN2e")) {
		selectProductOffering_Other_Contract_Sprint5(contract,
				quantityContractTerm, className, methodName);
	} else {
		selectProductOffering_Other_Contract(contract, className,
				methodName);
	}

	if (!"".equals(oneOffCharge)) {
		selectProductOffering_Other_OneOffCharges(oneOffCharge, className,
				methodName);
	}
	if (!"".equals(rateCardDiscount)) {
		selectProductOffering_Other_RateCardDiscount(rateCardDiscount,
				className, methodName);
	}
	
	if (proposition.contains("ISDN 30 ETSI")){
	
		selectProductOffering_ISDN30ETSI_MonthlyRental_Charge_Sprint5(rentalCharge,
				className, methodName);
		selectProductOffering_ISDN30DASS_ISDN30_One_off_Charges_Sprint5(rentalCharge,
				className, methodName);
		
	}
		else if (proposition.contains("ISDN 30 DASS")) {
			selectProductOffering_ISDN30DASS_MonthlyRental_Charge_Sprint5(rentalCharge,
					className, methodName);
			selectProductOffering_ISDN30DASS_ISDN30_One_off_Charges_Sprint5(rentalCharge,
					className, methodName);

		}

	}
	
	}
public void selectProductOffering_ISDN30DASS_ISDN30_One_off_Charges_Sprint5(String rentalCharge,
		String className, String methodName) {
	try {
		System.out.println("I am here 8");
		getVoiceTab().click();
		System.out.println("I am here 9");
		driver.findElement(By.xpath("//b[text()='ISDN30 One off Charges']/preceding-sibling::img[1]")).click();
		System.out.println("I am here 10");

		System.out.println("I am here 11");
		driver.findElement(By.id("Conv ISDN30DASSe0-60 DP S")).isDisplayed();
		System.out.println("I am here 12");
		driver.findElement(By.id("Conv ISDN30DASSe0-60 NC S")).isDisplayed();
		System.out.println("I am here 13");

		System.out.println("I am here 14");
	
		driver.findElement(By.id("Conv ISDN30DASSe 61+")).isDisplayed();
		System.out.println("I am here 15");
		driver.findElement(By.id("Conv ISDN30DASSe 61+ CP")).isDisplayed();
		System.out.println("I am here 16");
		driver.findElement(By.id("Conv ISDN30DASSe 61+ NC")).isDisplayed();
		System.out.println("I am here 17");

		System.out.println("I am here 18");
		driver.findElement(By.id("Conv ISDN30DASSe 61+")).click();
		System.out.println("I am here 19");
		
		System.out.println("I am here 20");
		System.out.println("Going to verify whether Conversion Charges are present or not");
		isConversionChargesPresent(className,methodName);
		System.out.println("Verification of Conversion Charges are present or not operation is completed");
		System.out.println("I am here 21");

	

		
	} catch (Exception e) {
		e.printStackTrace();
	}
	try {
		CommonClass.saveScreenshot(className, methodName,
				"selectProductOffering_Voice_RentalCharge" + ".png", driver,
				"");
	} catch (Exception e) {
		e.printStackTrace();
	}
}


public void selectProductOffering_ISDN30DASS_MonthlyRental_Charge_Sprint5(String rentalCharge,
		String className, String methodName) {
	try {
		getVoiceTab().click();
		driver.findElement(By.xpath("//b[text()='ISDN30 Monthly Rental Charge']/preceding-sibling::img[1]")).click();
		driver.findElement(By.id("WS ISDN30 OutOfArea S")).click();
	} catch (Exception e) {
		e.printStackTrace();
	}
	try {
		CommonClass.saveScreenshot(className, methodName,
				"selectProductOffering_Voice_RentalCharge" + ".png", driver,
				"");
	} catch (Exception e) {
		e.printStackTrace();
	}
}

	
	public void selectProductOffering_ISDN30ETSI_MonthlyRental_Charge_Sprint5(String rentalCharge,
			String className, String methodName) {
		try {
			System.out.println("ISDN30ETSI_MonthlyRental_Charge_Sprint5  COME");
			getVoiceTab().click();
			System.out.println("ISDN30ETSI_MonthlyRental_Charge_Sprint5  Voice Tab Click");
			
			
			

			driver.findElement(By.xpath("//b[text()='ISDN30 Monthly Rental Charge']/preceding-sibling::img[1]")).click();

			System.out.println("ISDN30ETSI_MonthlyRental_Charge_Sprint5  Image Click");
			
			

			driver.findElement(By.id("WS ISDN30 OutOfArea S")).click();
			System.out.println("ISDN30ETSI_MonthlyRental_Charge_Sprint5  Rental Charge Click");

		
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			CommonClass.saveScreenshot(className, methodName,
					"selectProductOffering_Voice_RentalCharge" + ".png", driver,
					"");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
private void selectProductOffering_Other_Contract_Sprint5(String contract,
		String quantityContractTerm, String className, String methodName)
		throws IOException {

	getOtherTab().click();
	try {
		getContractTerm().click();
		CommonMethods.doPause(2);
		if (contract != null && !"".equalsIgnoreCase(contract)) {
			try {

				driver.findElement(
						By.xpath("//td[contains(.,'" + contract
								+ "')]/input")).click();
				if (contract.contains("with charge")) {
					new Select(driver.findElement(By
							.xpath("//td[contains(.,'" + "with charge"
									+ "')]/following::select[1]")))
							.selectByVisibleText(quantityContractTerm);
				} else if (contract.contains("free")) {
					new Select(driver.findElement(By
							.xpath("//td[contains(.,'" + "free"
									+ "')]/following::select[1]")))
							.selectByVisibleText(quantityContractTerm);
				} else if (contract.contains("cost price")) {
					new Select(driver.findElement(By
							.xpath("//td[contains(.,'" + "cost price"
									+ "')]/following::select[1]")))
							.selectByVisibleText(quantityContractTerm);
				}

			} catch (Exception e) {
				e.printStackTrace();

			}
		} else {
			getContractTerm_12().click();
		}
	} catch (Exception ex) {

	}

	CommonClass.saveScreenshot(className, methodName,
			"ProductDetailsPage_Other_Contract" + ".png", driver, "");
}

public boolean isConversionChargesPresent( String className,String methodName) {
	logger.info(": Validating Conversion Charges");
	System.out.println(": Initiating Validation of Conversion Charges");

	boolean isPresent = false;
	
	try {
		CommonClass.saveScreenshot(className, methodName, "ProductOfferingPage_ISDN30 OneOff_Charges"
				+ ".png", driver, "");
	} catch (IOException e) {
		e.printStackTrace();
	}
	try{
		
		isPresent = getConversionCharges1().isDisplayed();
		logger.info(" Convert ISDN30 DASS to ISDN30e (61+)  is present: True ");
		isPresent = getConversionCharges2().isDisplayed();
		logger.info(" Convert ISDN30 DASS to ISDN30e (61+)  is present: True ");
		isPresent = getConversionCharges3().isDisplayed();
		logger.info(" Convert ISDN30 DASS to ISDN30e  is present: True ");
		isPresent = getConversionCharges4().isDisplayed();
		logger.info(" Convert ISDN30 DASS to ISDN30e is present: True ");
		isPresent = getConversionCharges5().isDisplayed();		
		logger.info("Convert ISDN30 DASS to ISDN30e (61+)  S is present: True ");
		
	}catch (Exception e) {
		// TODO: handle exception
		isPresent = false;
		logger.info(" Desired Conversion charges are not Present for ISDN 30 DASS Order : False ");

	}

	logger.info(":	Verification of Conversion Charges Validation is completed Successfully ");
	return isPresent;

	
}





public void selectProductOffering_Voice_VoiceCarelevel_Sprint5(
		String careLevel, String quantityVoiceCareLevel,
		String quantityISDN2eSystem, String className, String methodName) {
	try {
		getVoiceTab().click();
		getVoiceCareLevel().click();
		driver.findElement(
				By.xpath("//td[contains(.,'" + careLevel + "')]/input"))
				.click();

		System.out.println("tirmuallllllllllllllllllllllllllll");

		if (careLevel.contains("Standard business landline support")) {
			// new
			// Select(getQuantity_VoiceCareLevel()).selectByVisibleText(quantityVoiceCareLevel);

			System.out.println("************************"
					+ driver.findElement(
							By.xpath("//td[contains(.,'" + careLevel
									+ "')]/following::select[1]"))
							.getText());

			new Select(driver.findElement(By.xpath("//td[contains(.,'"
					+ careLevel + "')]/following::select[1]")))
					.selectByVisibleText(quantityVoiceCareLevel);

		}

	} catch (Exception e) {
		e.printStackTrace();
	}
	try {
		CommonClass.saveScreenshot(className, methodName,
				"ProductDetailsPage_Voice_VoiceCarelevel" + ".png", driver,
				"");
	} catch (Exception e) {
		e.printStackTrace();
	}
}

}



