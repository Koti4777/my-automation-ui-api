package com.bt.wlms.reports;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.ReportDetails;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.DownloadNGAReportsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ReportsPageOperations;
import com.hqnRegression.util.CSVOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class B2CReports extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "B2CReports";

	private String IN_FILE = "B2CReports.csv";
	List<ReportDetails> reportDetailsList = null;
	ReportDetails reportDetails = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("B2CReports");

	B2CReports() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		reportDetailsList = CSVOperations.readReportDetails(IN_FILE);
	}

	/**
	 * This method will download B2C Daily, Weekly and Monthly Reports
	 * 
	 * @param method
	 * @throws Throwable
	 */
	@Test
	public void testB2CReport(Method method) throws Throwable {

		try {
			logger.info(" Start Test-B2CReport : Start the B2C Download Reports Operation ");
			reportDetails = reportDetailsList.get(0);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			ReportsPageOperations reportsPageOperations = homePageOperations
					.clickReportsTab(CLASS_NAME, method.getName());

			DownloadNGAReportsPageOperations downloadB2BReportsPageOperations = reportsPageOperations
					.clickB2CReports1();
			downloadB2BReportsPageOperations.downloadB2CReports(
					reportDetails.getReportName(),
					reportDetails.getReportSchedule(),
					reportDetails.getFrom_year(),
					reportDetails.getFrom_month(), reportDetails.getFrom_day(),
					reportDetails.getYear(), reportDetails.getMonth(),
					reportDetails.getDay(), CLASS_NAME, method.getName());
			logger.info(" End Test-B2CReport : Start the B2C Download Reports Operation ");
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			logger.error("Unable to download B2C Reports "
					+ reportDetails.getReportName());
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}
	}

	/**
	 * This method will close the connection
	 * 
	 * @param method
	 */

	@AfterMethod
	public void tearDown(Method method) {
		CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		driver.close();
		driver.quit();

	}

}
