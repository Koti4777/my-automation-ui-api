package com.bt.wlms.reports;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.ReportDetails;
import com.hqnRegression.beans.ReportsBeansList;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.DownloadNGAReportsPageOperations;
import com.hqnRegression.pages.operations.DownloadReportsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.ReportsPageOperations;

import com.hqnRegression.util.CSVOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class BillingReports extends SeleniumImplementation{
	
	
	private int testCount = 0;
	private int count = 0;
	Properties testProps = null;
	
	

	private WebDriver driver;
	public String CLASS_NAME = "HQN_S14C10_MIS_TS_001";

	private String IN_FILE = "BillReports.csv";
	List<ReportDetails> reportDetailsList = null;
	ReportDetails reportDetails = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("BillReports");
	
	

	BillingReports() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		reportDetailsList = CSVOperations.readReportDetails(IN_FILE);
	}

	/**
	 * This method will download B2B Daily, Weekly and Monthly Reports
	 * 
	 * @param method
	 * @throws Throwable
	 */
	@Test
	public void testBillingReports(Method method) throws Throwable {

		try {
			logger.info(" Start Test-Billing Report : Start the Billing Download Reports Operation ");
			
			reportDetails = reportDetailsList.get(0);
			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);
			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			ReportsPageOperations reportsPageOperations = homePageOperations

			.clickReportsTab(CLASS_NAME, method.getName());

			DownloadNGAReportsPageOperations downloadB2BReportsPageOperations = reportsPageOperations
					.clickBillingReports();
			downloadB2BReportsPageOperations.DownloadBillingReports(
					reportDetails.getReportName(),
					reportDetails.getReportSchedule(),
					reportDetails.getFrom_year(),
					reportDetails.getFrom_month(), 
					reportDetails.getFrom_day(),
					reportDetails.getYear(), 
					reportDetails.getMonth(),
					reportDetails.getDay(), 
					CLASS_NAME, 
					method.getName());
			
			logger.info(" End Test-Billing Report : Start the Billing Download Reports Operation ");

			CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		} catch (Exception e) {
			logger.error("Unable to download Billing Reports " + reportDetails.getReportName());
			CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		}
	}

	/**
	 * This method will close the connection
	 * 
	 * @param method
	 */
	@AfterMethod
	public void tearDown(Method method) {

		 driver.close();
		 driver.quit();

	}

}