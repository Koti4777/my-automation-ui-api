package com.bt.wlms.searchBox;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class B2B_Customer extends SeleniumImplementation{

	private WebDriver driver;
	private String CLASS_NAME = "B2B_Customers";

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("B2B_Customers");

	public B2B_Customer() {
		PropertyConfigurator.configure(loggerPath);
	}

	/*
	 * @Rule public TestName name = new TestName();
	 */
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
   /**
    * 
    * @param method
    * @throws IOException
    */
	@Test
	public void testB2B_Customers(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		try {

			logger.info(" Start the test : B2B_Customers searching ");

			LoginPageOperations loginPageOperations = CMCHomePageOperations
					.navigateTo(driver);

			HomePageOperations homePageOperations = loginPageOperations
					.adminLogin(CLASS_NAME, method.getName());

			homePageOperations.isCustomertypePresent(CLASS_NAME,
					method.getName());

			homePageOperations.searchBoxFunctioningB2BorB2C("1816",
					"Order Number", CLASS_NAME, method.getName());
			homePageOperations.searchBoxFunctioningB2BorB2C("3658",
					"Order Number", CLASS_NAME, method.getName());

			logger.info(" end the test  : B2B_Customers searching ");

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Unable searching the B2B_Customers ");
			// CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			// driver.close();

		}

	}

	@AfterMethod
	public void tearDown() {

		// driver.quit();
		// driver.close();

	}

	
	
}
