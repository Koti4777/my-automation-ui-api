package com.bt.wlms.searchBox;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class B2BandB2C_Customers extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "B2BandB2C_Customers";

	private String IN_FILE = "B2BandB2C_Customers.csv";
	List<AssetBeanDetails> b2bandB2CList = null;
	AssetBeanDetails b2bandB2CDetails = null;

	//private int count = 0;
	//public Order order = null;
	//private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("B2BandB2C_Customers");

	public B2BandB2C_Customers() {
		PropertyConfigurator.configure(loggerPath);
	}

	/*
	 * @Rule public TestName name = new TestName();
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testB2BandB2C_Customers(Method method) throws IOException {
	
			try {

				logger.info(" Start testB2BandB2C_Customers ");

			//	b2bandB2CDetails = b2bandB2CList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				homePageOperations.isPresent_customerType(CLASS_NAME,
						method.getName());
				homePageOperations.isPresent_SearchType(CLASS_NAME,
						method.getName());

				SearchResultPageOperations searchResultPageOperations = 
				homePageOperations
						.searchBoxFunctioningB2BandB2C("1816", "Order Number", "B2B",
								CLASS_NAME, method.getName());
				homePageOperations
						.searchBoxFunctioningB2BandB2C("1816", "Order Number", "B2B",
								CLASS_NAME, method.getName());
				homePageOperations.searchBoxFunctioningB2BandB2C("1816", "Surname",
						"B2B", CLASS_NAME, method.getName());
				homePageOperations.searchBoxFunctioningB2BandB2C("3658",
						"Mobile Number", "B2C", CLASS_NAME, method.getName());
				
				homePageOperations.searchBoxFunctioningB2BandB2C("3658", "Order Number",
						"B2C", CLASS_NAME, method.getName());
				homePageOperations.searchBoxFunctioningB2BandB2C("02053226427",
						"Mobile Number", "B2C", CLASS_NAME, method.getName());
				homePageOperations.searchBoxFunctioningB2BandB2C("3658",
						"Mobile Number", "B2C", CLASS_NAME, method.getName());
				homePageOperations.searchBoxFunctioningB2BandB2C("02453225998",
						"Mobile Number", "B2B", CLASS_NAME, method.getName());


				logger.info(" end testB2BandB2C_Customers ");
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to testB2BandB2C_Customers");
				// CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				// driver.close();

			}

	}

	@AfterMethod
	public void tearDown() {

		// driver.quit();
		// driver.close();

	}

}
