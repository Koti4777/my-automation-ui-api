package com.bt.wlms.searchBox;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class B2C_Customer extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "B2C_Customer";


	List<AssetBeanDetails> b2cList = null;
	AssetBeanDetails b2cDetails = null;

	public Order order = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("B2C_Customer");

	public B2C_Customer() {
		PropertyConfigurator.configure(loggerPath);
	}

	
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testB2BandB2C_Customers(Method method) throws IOException {

			try {

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				homePageOperations.isCustomertypePresent(CLASS_NAME, method
						.getName());

				homePageOperations.searchBoxFunctioningB2BorB2C("3658",
						"Order Number", CLASS_NAME, method.getName());
				homePageOperations.searchBoxFunctioningB2BorB2C("1816",
						"Order Number", CLASS_NAME, method.getName());

				logger.info(" end the test  : B2C_Customers searching ");

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to place the order");
				// CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				// driver.close();

			}

	}

	@AfterMethod
	public void tearDown() {

		// driver.quit();
		// driver.close();

	}

}
