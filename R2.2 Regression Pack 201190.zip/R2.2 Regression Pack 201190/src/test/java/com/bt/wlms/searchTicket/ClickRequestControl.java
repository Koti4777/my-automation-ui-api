package com.bt.wlms.searchTicket;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.pages.operations.TakeControlPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class ClickRequestControl extends SeleniumImplementation
{
	
	
	
	private WebDriver driver;
	public String CLASS_NAME = "ClickRequestControl";

	private String IN_FILE = "TicketrefNUmber.csv";
	List<CPEDetails> orderDetailsList = new ArrayList<CPEDetails>();
	CPEDetails orderDetails;
	
	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("ClickRequestControl");
	
	public ClickRequestControl()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		
	
	
	
	@BeforeMethod
	public void setUp() throws Exception 
	{

		orderDetailsList = CSVOperation_New.readCPEDetails(IN_FILE);

		if (orderDetailsList != null && orderDetailsList.size() > 0) 
		{
			testCount = orderDetailsList.size();
		}

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	
	/**
	 * expand ticket tab and click requestControl
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testTakeControl(Method method) throws IOException {

      
		while (count < testCount) 
		{
			try
		
			{
				logger.info(" Start Test-Take Control : Start the Take Control ");

				orderDetails = orderDetailsList.get(count);


				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(orderDetails.getTicketNumber(), "Ticket Reference Number",
								CLASS_NAME, method.getName());
				String product = searchResultPageOperations.getProductForActiveOrder();
						
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickticketsTab(CLASS_NAME,method.getName());

                 accountDetailsPageOperations.verifyFoidRequest(CLASS_NAME,method.getName());
                 accountDetailsPageOperations.takeControl(CLASS_NAME, method.getName());
                 
                 CommonMethods.doPause(30);
                /* String name = driver.getWindowHandle();*/
                 
                /*TakeControlPageOperations takeControlPageOperations=null;
                 
                 takeControlPageOperations.clickOperation("Notes", CLASS_NAME, method.getName());
                */
                 logger.info("End Test-Take Control : End the Take Control");
                
                // CommonMethods.logOut(driver, CLASS_NAME, method.getName());
         		
			}
			
			catch (Exception e) 
			{
				e.printStackTrace();
					
			}   
			
			
			count++;
		}
	
   }
	@AfterMethod
	public void tearDown() 
	{
		/*driver.close();
		driver.quit();*/

	}

}
