package com.bt.wlms.searchTicket;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.hqnRegression.util.SeleniumImplementation.BrowserType;

public class SearchTicket extends SeleniumImplementation
 {

	
	private WebDriver driver;
	public String CLASS_NAME = "SearchTicket";

	private String IN_FILE = "Orderfrticket.csv";
	List<CPEDetails> orderDetailsList = new ArrayList<CPEDetails>();
	CPEDetails orderDetails;
	
	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("SearchTicket");
	
	public SearchTicket()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		
	
	
	
	@BeforeMethod
	public void setUp() throws Exception 
	{

		orderDetailsList = CSVOperation_New.readCPEDetails(IN_FILE);

		if (orderDetailsList != null && orderDetailsList.size() > 0) 
		{
			testCount = orderDetailsList.size();
		}

	
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	
	
	/**
	 * expand ticket tab
	 * @param method
	 * @throws IOException
	 */
	@Test
	public void testExpandTicket(Method method) throws IOException {

      
		while (count < testCount) {
			try
			{
				logger.info(" Start Test-Expand Ticket : Start the Expand Ticket ");

				orderDetails = orderDetailsList.get(count);


				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				

				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(orderDetails.getFoid(), "Order Number",
								CLASS_NAME, method.getName());
				String product = searchResultPageOperations
						.getProductForActiveOrder();

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				
				accountDetailsPageOperations.clickticketsTab(CLASS_NAME,

                        method.getName());

                 accountDetailsPageOperations.verifyFoidRequest(CLASS_NAME,

                        method.getName());
                 
                 logger.info(" End Test-Expand Ticket : End the Expand Ticket ");
                
                 CommonMethods.logOut(driver, CLASS_NAME, method.getName());
         		
			}
			catch (Exception e) {
				e.printStackTrace();
					}   
			
			logger.error("Unable to click the requestControl link" + orderDetails.getFoid());
			count++;
		}
	
   }
	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();

	}

}
	
