/**
 * 
 */
package com.hqnRegression.HomeMoveR20;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.BroadBandDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * @author Pankaj
 * 
 */
public class HQN_LLTC_HomeMove_Provide extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "HQN_LLTC_HomeMove_Provide";

	private String IN_FILE = "HQN_LLTC_HomeMove_Provide.csv";
	List<BroadBandDetails> bbDetailsList = null;
	BroadBandDetails broadBandDetails = null;

	private int count = 0;
	public Order order = null;

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		bbDetailsList = CSVOperation_New.readBroadBandDetails(IN_FILE);
		order = new Order();

	}

	@Test
	public void testHQN_RS_TC14_Provide(Method method) throws IOException {

		System.out.println("method name is --->"+method.getName());
		broadBandDetails = bbDetailsList.get(0);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		RegisterNewServicePageOperations servicePageOperations = homePageOperations
				.clickBusinessCustomer();
		
		CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
				  .searchByBusinessAccountName(broadBandDetails
				     .getBusinessAccount(),CLASS_NAME, method.getName());

		CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
				.clickBusinessAccount(broadBandDetails.getBusinessAccount());

		LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
				.clickAddSite(CLASS_NAME, method.getName());

		LineCheckResultPageOperations lineCheckResultPageOperations = lineDetailsPageOperations
				.createSiteWithPostCodeAndPremisesDetails(
						broadBandDetails.getNewSite(),
						broadBandDetails.getLandlinePhone(),
						broadBandDetails.getPostCode(),
						broadBandDetails.getAddressValue(),
						broadBandDetails.getPremisesName(),
						broadBandDetails.getStreetName(),
						broadBandDetails.getTown(),
						broadBandDetails.getCountry(), CLASS_NAME,
						method.getName());

		lineCheckResultPageOperations.selectPropositionByName(broadBandDetails
				.getProposition());

		AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
				.clickNext(CLASS_NAME, method.getName());

		AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
				.submit(CLASS_NAME, method.getName());

		ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
				.submit(CLASS_NAME, method.getName());

		productDetailsPageOperations.selectProductOffering(
				broadBandDetails.getProposition(),
				broadBandDetails.getPostCode(), broadBandDetails.getTitle(),
				broadBandDetails.getFirstName(), broadBandDetails.getSurName(),
				broadBandDetails.getContract());

		productDetailsPageOperations
				.clickBusinessRateCardAndSelectSmallBusiness(CLASS_NAME,
						method.getName());

		productDetailsPageOperations.selectProductOffering_Voice_AllCalls();

		HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
				.clickNextForHardware(CLASS_NAME, method.getName());

		CRDAndAppointmentManagementPageOperations crdAndAppointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
				.clickNext(CLASS_NAME, method.getName());

		crdAndAppointmentManagementPageOperations.selectActivateDate();

/*		crdAndAppointmentManagementPageOperations
				.fillVoiceAppointmentManagementFields(broadBandDetails
						.getEngineeringNotes());

		crdAndAppointmentManagementPageOperations
				.fillHealthAndsafetyVeificationFields(broadBandDetails
						.getHealthAndSafetyNotes());

		ReserveAppointmentPageOperations reserveAppointmentPageOperations = crdAndAppointmentManagementPageOperations
				.clickAvailableAppointmentButton();

		reserveAppointmentPageOperations.clickReRequestAppointment();

		reserveAppointmentPageOperations.selectFirstAvailableAppointmentDate();

		crdAndAppointmentManagementPageOperations = reserveAppointmentPageOperations
				.clickReserveAppointmentButton(CLASS_NAME, name.getMethodName());
*/
		OrderSummaryPageOperations orderSummaryPageOperations = crdAndAppointmentManagementPageOperations
				.clickNext(CLASS_NAME, method.getName());
		
		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
		
		OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
				.confirmOrder(CLASS_NAME, method.getName());

		orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
				method.getName());

	}


	@AfterMethod
	public void tearDown(Method method) {
	CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		driver.close();

	}

}
