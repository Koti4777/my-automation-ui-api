package com.hqnRegression.HomeMoveR20;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.BroadBandDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CeasePageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LocationMovePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class HQN_TS_HM_011 extends SeleniumImplementation
{
	private WebDriver driver;
	private String CLASS_NAME = "HQN_TS_HM_011";

	private String IN_FILE = "HQN_TS_HM_011.csv";
	List<BroadBandDetails> bbDetailsList = null;
	BroadBandDetails broadBandDetails = null;

	public Order order = null;

	/*@Rule
	public TestName name = new TestName();
*/
	@BeforeMethod
	public void setUp() throws Exception
	{

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		bbDetailsList = CSVOperation_New.readBroadBandDetails(IN_FILE);
		order = new Order();

	}
	
	
	@Test
	public void test_HQN_TC_HM_011(Method method) throws IOException
	{
		// House Move      ----  impacted by open defect CR-9521 & CR-9478
		//houseMove();


		// First Cease the order
		ceaseOrder(method);
		
		// Do New Provide
		provideOrder(method);


	}


	private void houseMove(Method method) throws IOException {
		broadBandDetails = bbDetailsList.get(0);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(broadBandDetails.getOrderId(), "Order Number",
						CLASS_NAME, method.getName());
		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
				.clickProductLink();

		LocationMovePageOperations locationMovePageOperations = accountDetailsPageOperations
				.clickPremisesMove(CLASS_NAME, method.getName());
	}


	private void provideOrder(Method method) throws IOException {
		broadBandDetails = bbDetailsList.get(2);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		RegisterNewServicePageOperations servicePageOperations = homePageOperations
				.clickBusinessCustomer();

		CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
				  .searchByBusinessAccountName(broadBandDetails
				     .getBusinessAccount(),CLASS_NAME, method.getName());

		CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
				.clickBusinessAccount(broadBandDetails.getBusinessAccount());

		LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
				.clickAddSite(CLASS_NAME, method.getName());

		LineCheckResultPageOperations lineCheckResultPageOperations = lineDetailsPageOperations
				.createSiteWithPostCodeAndPremisesDetails(
						broadBandDetails.getNewSite(),
						broadBandDetails.getLandlinePhone(),
						broadBandDetails.getPostCode(),
						broadBandDetails.getAddressValue(),
						broadBandDetails.getPremisesName(),
						broadBandDetails.getStreetName(),
						broadBandDetails.getTown(),
						broadBandDetails.getCountry(), CLASS_NAME,
						method.getName());

		lineCheckResultPageOperations.selectPropositionByName(broadBandDetails
				.getProposition());

		AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
				.clickNext(CLASS_NAME,method.getName());

		AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
				.submit(CLASS_NAME, method.getName());

		ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
				.submit(CLASS_NAME, method.getName());

		productDetailsPageOperations.selectProductOffering(
				broadBandDetails.getProposition(),
				broadBandDetails.getPostCode(), broadBandDetails.getTitle(),
				broadBandDetails.getFirstName(), broadBandDetails.getSurName(),
				broadBandDetails.getContract());

		HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = productDetailsPageOperations.clickNextForHardware(CLASS_NAME, method.getName());
		
		CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations.clickNext(CLASS_NAME, method.getName());
		
		appointmentManagementPageOperations.selectActivateDate();

		if (broadBandDetails.getProposition().contains(
				"Broadband and Anytime Calls")
				|| broadBandDetails.getProposition().contains(
						"Broadband and Off Peak Calls")
				|| broadBandDetails.getProposition().contains(
						"Broadband and Total Calls")
				|| broadBandDetails.getProposition().contains(
						"Business Advanced BBand")
				|| broadBandDetails.getProposition().contains(
						"Business Broadband and Line Rental")
				|| broadBandDetails.getProposition().contains(
						"Business Essential BBand")) {
			appointmentManagementPageOperations
					.fillVoiceAppointmentManagementFields(broadBandDetails
							.getEngineeringNotes());

			ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
					.clickAvailableAppointmentButton();

			reserveAppointmentPageOperations
					.selectFirstAvailableAppointmentDate();
			appointmentManagementPageOperations = reserveAppointmentPageOperations
					.clickReserveAppointmentButton(CLASS_NAME,
							method.getName());
		}

		if (broadBandDetails.getProposition().contains("40:")) {

			FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
					.fillBBFTTCAppointmentManagement(CLASS_NAME,
							method.getName());
			fttcAvailableAppointmentsPageOperations
					.selectFirstAvailableAppointmentDate();
			appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
					.clickReserveAppointmentButton(CLASS_NAME,
							method.getName());

		}

		appointmentManagementPageOperations
				.fillHealthAndsafetyVeificationFields(broadBandDetails
						.getHealthAndSafetyNotes());
		OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
				.clickNext(CLASS_NAME, method.getName());

		orderSummaryPageOperations.selectCommunication(broadBandDetails
				.getCommunicationBy());
		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

		/*OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
				.confirmOrder(CLASS_NAME, name.getMethodName());

		String orderId = orderConfirmationPageOperations.getOrderId();

		if (broadBandDetails.getProposition().contains("Broadband")) {
			order.setBbSiteId(broadBandDetails.getNewSite());
		} else {
			order.setLineSiteId(broadBandDetails.getNewSite());
		}
		order.setOrdeId(orderId);

		// calling save method for storing order object in CSV
		CSVOperations.saveOrders("Order.csv", order);

		orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
				name.getMethodName());
		*/
	}


	private void ceaseOrder(Method method) throws IOException {
		broadBandDetails = bbDetailsList.get(1);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(broadBandDetails.getOrderId(), "Order Number",
						CLASS_NAME, method.getName());
		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
				.clickProductLink();

		AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
				.clickCease(CLASS_NAME,method.getName());
		agentDetailsPageOperations.clickSameAgent();

		CeasePageOperations ceasePageOperations = agentDetailsPageOperations
				.clickNextForCease(CLASS_NAME, method.getName());
		ceasePageOperations.selectActivateDate();
		OrderSummaryPageOperations orderSummaryPageOperations = ceasePageOperations
				.clickSubmit(CLASS_NAME, method.getName());
		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

		OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations.confirmCease(CLASS_NAME, method.getName());
		
		agentDetailsPageOperations = orderConfirmationPageOperations.clickCompleteCease(CLASS_NAME, method.getName());
		//accountDetailsPageOperations = orderConfirmationPageOperations.clickCompleteCease(CLASS_NAME, method.getName());
		
		agentDetailsPageOperations.verifyCease(CLASS_NAME, method.getName());
	}

	
	@AfterMethod
	public void tearDown(Method method) {
		CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		driver.close();

	}

}
