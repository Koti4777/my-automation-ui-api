package com.hqnRegression.assets;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.supercsv.cellprocessor.constraint.StrMinMax;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.BBCareLevel4;
import com.hqnRegression.beans.BroadBandDetails;
import com.hqnRegression.beans.BusinessAccountDetails;
import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.beans.CeaseDetails;
import com.hqnRegression.beans.CreateTicket;
import com.hqnRegression.beans.CreditCardDetails;
import com.hqnRegression.beans.HomeMoveDetails;
import com.hqnRegression.beans.ISDNDetails;
import com.hqnRegression.beans.ISDN_NewDetails;
import com.hqnRegression.beans.LineDetails;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.nga.beans.AppointmentDetails;

/**
 * @author 605002580
 * 
 */
public class CSVOperation_New {

	public static final CellProcessor[] BusinessAccount_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] CreateTicket_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] BroadBandDetails_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] LineDetails_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] CreditCardDetails_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] Appointment_CellProcessor = new CellProcessor[] { new StrMinMax(
			0, 100) };

	public static final CellProcessor[] WLRFaultCareLevel_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] BBCareLevel4_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] ISDNDetails_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] CPEDetails_CellProcessor = new CellProcessor[] { new StrMinMax(
			0, 100) };

	public static final CellProcessor[] Asset_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] CeaseDetails_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] HomeMoveDetails_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] ISDN_New_CellProcessor = new CellProcessor[] {
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100) };

	public static final CellProcessor[] Modify_R20_CellProcessor = new CellProcessor[] {

			new StrMinMax(0, 100), new StrMinMax(0, 100), 
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100), new StrMinMax(0, 100),
			new StrMinMax(0, 100),new StrMinMax(0, 100)};

	public static List<BusinessAccountDetails> readBusinessAccountDetails(
			String fileName) {

		ICsvBeanReader inFile = null;
		List<BusinessAccountDetails> businessAcountList = new ArrayList<BusinessAccountDetails>();
		BusinessAccountDetails businessAcount;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((businessAcount = inFile.read(BusinessAccountDetails.class,
					header, BusinessAccount_CellProcessor)) != null) {
				businessAcountList.add(businessAcount);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return businessAcountList;

	}

	public static List<LineDetails> readLineDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<LineDetails> lineDetailsList = new ArrayList<LineDetails>();
		LineDetails lineDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((lineDetails = inFile.read(LineDetails.class, header,
					LineDetails_CellProcessor)) != null) {
				lineDetailsList.add(lineDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return lineDetailsList;

	}

	public static List<BroadBandDetails> readBroadBandDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<BroadBandDetails> broadBandDetailsList = new ArrayList<BroadBandDetails>();
		BroadBandDetails broadBandDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((broadBandDetails = inFile.read(BroadBandDetails.class,
					header, BroadBandDetails_CellProcessor)) != null) {
				broadBandDetailsList.add(broadBandDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return broadBandDetailsList;

	}

	public static List<AppointmentDetails> readAppointmentDetails(
			String fileName) {

		ICsvBeanReader inFile = null;
		List<AppointmentDetails> appointmentDetailsList = new ArrayList<AppointmentDetails>();
		AppointmentDetails appointmentDetail;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((appointmentDetail = inFile.read(AppointmentDetails.class,
					header, Appointment_CellProcessor)) != null) {
				appointmentDetailsList.add(appointmentDetail);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return appointmentDetailsList;

	}

	public static List<WLRFaultCareLevel> readWLRFaultCareLevel(String fileName) {

		ICsvBeanReader inFile = null;
		List<WLRFaultCareLevel> wlrFaultCareLevelList = new ArrayList<WLRFaultCareLevel>();
		WLRFaultCareLevel wlrFaultCareLevel;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((wlrFaultCareLevel = inFile.read(WLRFaultCareLevel.class,
					header, WLRFaultCareLevel_CellProcessor)) != null) {
				wlrFaultCareLevelList.add(wlrFaultCareLevel);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return wlrFaultCareLevelList;

	}

	public static List<CreditCardDetails> readCreditCardDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<CreditCardDetails> creditCardDetailsList = new ArrayList<CreditCardDetails>();
		CreditCardDetails creditCardDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((creditCardDetails = inFile.read(CreditCardDetails.class,
					header, CreditCardDetails_CellProcessor)) != null) {
				creditCardDetailsList.add(creditCardDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return creditCardDetailsList;

	}

	public static List<BBCareLevel4> readBBCareLevel4(String fileName) {

		ICsvBeanReader inFile = null;
		List<BBCareLevel4> bBCareLevel4List = new ArrayList<BBCareLevel4>();
		BBCareLevel4 bbCareLevel4;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((bbCareLevel4 = inFile.read(BBCareLevel4.class, header,
					BBCareLevel4_CellProcessor)) != null) {
				bBCareLevel4List.add(bbCareLevel4);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return bBCareLevel4List;

	}

	public static List<ISDNDetails> readISDNDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<ISDNDetails> isdnDetailsList = new ArrayList<ISDNDetails>();
		ISDNDetails isdnDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((isdnDetails = inFile.read(ISDNDetails.class, header,
					ISDNDetails_CellProcessor)) != null) {
				isdnDetailsList.add(isdnDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return isdnDetailsList;

	}

	public static List<CPEDetails> readCPEDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<CPEDetails> cpeDetailsList = new ArrayList<CPEDetails>();
		CPEDetails cpeDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((cpeDetails = inFile.read(CPEDetails.class, header,
					CPEDetails_CellProcessor)) != null) {
				cpeDetailsList.add(cpeDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return cpeDetailsList;

	}

	public static List<AssetBeanDetails> readAssetDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<AssetBeanDetails> assetDetailsList = new ArrayList<AssetBeanDetails>();
		AssetBeanDetails assetDetail;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((assetDetail = inFile.read(AssetBeanDetails.class, header,
					Asset_CellProcessor)) != null) {
				assetDetailsList.add(assetDetail);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return assetDetailsList;

	}

	public static List<CreateTicket> readCreateTicket(String fileName) {

		ICsvBeanReader inFile = null;
		List<CreateTicket> createTicketList = new ArrayList<CreateTicket>();
		CreateTicket createTicket;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((createTicket = inFile.read(CreateTicket.class, header,
					CreateTicket_CellProcessor)) != null) {
				createTicketList.add(createTicket);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return createTicketList;

	}

	public static List<CeaseDetails> readCeaseDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<CeaseDetails> ceaseDetailsList = new ArrayList<CeaseDetails>();
		CeaseDetails ceaseDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((ceaseDetails = inFile.read(CeaseDetails.class, header,
					CeaseDetails_CellProcessor)) != null) {
				ceaseDetailsList.add(ceaseDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return ceaseDetailsList;

	}

	public static List<HomeMoveDetails> readHomeMoveDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<HomeMoveDetails> homeMoveDetailsList = new ArrayList<HomeMoveDetails>();
		HomeMoveDetails homeMoveDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((homeMoveDetails = inFile.read(HomeMoveDetails.class,
					header, HomeMoveDetails_CellProcessor)) != null) {
				homeMoveDetailsList.add(homeMoveDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return homeMoveDetailsList;

	}

	public static List<ISDN_NewDetails> readISDNNewDetails(String fileName) {

		ICsvBeanReader inFile = null;
		List<ISDN_NewDetails> isdnDetailsList = new ArrayList<ISDN_NewDetails>();
		ISDN_NewDetails isdnDetails;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((isdnDetails = inFile.read(ISDN_NewDetails.class, header,
					ISDN_New_CellProcessor)) != null) {
				isdnDetailsList.add(isdnDetails);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return isdnDetailsList;

	}

	public static List<AssetBeanDetails>modify_R20Details(String fileName) {

		ICsvBeanReader inFile = null;
		List<AssetBeanDetails> assetDetailsList = new ArrayList<AssetBeanDetails>();
		AssetBeanDetails assetDetail;

		try {

			// Creating BeanReader object by passing csv file name and

			inFile = new CsvBeanReader(new FileReader(fileName),
					CsvPreference.EXCEL_PREFERENCE);

			// reading header
			final String[] header = inFile.getCSVHeader(true);

			// reading the beans and adding to list
			while ((assetDetail = inFile.read(AssetBeanDetails.class, header,
					Modify_R20_CellProcessor)) != null) {
				assetDetailsList.add(assetDetail);
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				inFile.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return assetDetailsList;

	}

	

}