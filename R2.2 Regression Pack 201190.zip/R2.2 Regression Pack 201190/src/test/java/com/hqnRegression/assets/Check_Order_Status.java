package com.hqnRegression.assets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Check_Order_Status extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "Check_Order_Status";

	private String IN_FILE = "OrderStatus.csv";
	List<CPEDetails> orderDetailsList = new ArrayList<CPEDetails>();
	CPEDetails orderDetails;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Check_Order_Status");
	
	public Check_Order_Status()
	{
		PropertyConfigurator.configure(loggerPath);
	}
	
	
/*
	@Rule
	public TestName name = new TestName();
*/
	@BeforeMethod
	public void setUp() throws Exception {

		orderDetailsList = CSVOperation_New.readCPEDetails(IN_FILE);

		if (orderDetailsList != null && orderDetailsList.size() > 0) {
			testCount = orderDetailsList.size();
		}

	}

	@Test
	public void testCheckOrderStatus(Method method) throws IOException {
		
System.out.println("method name is --->"+method.getName());
		
		//Assert.assertTrue(false);

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-Check_Order_Status : Start the Check_Order_Status creation ");

				orderDetails = orderDetailsList.get(count);

				driver = createBrowserInstance(BrowserType.FIREFOX);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				 
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(orderDetails.getFoid(), "Order Number",
								CLASS_NAME, method.getName());
				
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLinkForPendingOrder(CLASS_NAME,
								method.getName());
				
				
				
				/* accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME,
								method.getName());*/

				accountDetailsPageOperations.checkOrderStatus(
						orderDetails.getFoid(), CLASS_NAME,
						method.getName());
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				logger.info(" End Test-Check_Order_Status : End the Check_Order_Status creation ");
				
				} catch (IOException e) {
				e.printStackTrace();

		    	logger.error("Unable to do Check_Order_Status for the orderid " + orderDetails.getFoid());
				
			}
			
			count++;
		}
	}

	@AfterMethod
	public void tearDown() {

		/* driver.close();
		 driver.quit();*/

	}
}
