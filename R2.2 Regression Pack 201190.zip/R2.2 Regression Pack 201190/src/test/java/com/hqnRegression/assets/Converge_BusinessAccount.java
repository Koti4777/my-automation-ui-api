/**
 * 
 */
package com.hqnRegression.assets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.hqnRegression.beans.BroadBandDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.EditCustomerDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * @author 605112580
 * 
 */
public class Converge_BusinessAccount extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "Converge_BusinessAccount";

	private String IN_FILE = "Converge.csv";
	List<BroadBandDetails> bbDetailsList = null;
	BroadBandDetails broadBandDetails = null;

	private int count = 0;
	public Order order = null;
	

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Converge_BusinessAccount");
	

	public Converge_BusinessAccount()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 


	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		bbDetailsList = CSVOperation_New.readBroadBandDetails(IN_FILE);
		order = new Order();

	}

	@Test
	public void testConverge(Method method) throws IOException {
		

System.out.println("method name is --->"+method.getName());
		
		//Assert.assertTrue(false);

		
		logger.info(" Start Test-Converge_BusinessAccount : Start the Converge_BusinessAccount creation ");
		

		broadBandDetails = bbDetailsList.get(1);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		
		//Assert.assertTrue(false);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(broadBandDetails.getBusinessAccount(), "Company Name",
						CLASS_NAME, method.getName());

		CustomerDetailsPageOperations customerDetailsPageOperations = searchResultPageOperations
				.clickProductLinkForAccount(CLASS_NAME, method.getName());
		EditCustomerDetailsPageOperations editCustomerDetailsPageOperations = customerDetailsPageOperations
				.clickCustomerAccouctEdit(
						broadBandDetails.getBusinessAccount(), CLASS_NAME,
						method.getName());
		if("".equalsIgnoreCase(""))
		{
		   editCustomerDetailsPageOperations.clearMobileAccountnumebr();
		}
		else
		{
			editCustomerDetailsPageOperations.fillMobileAccountnumebr("");
		}
		editCustomerDetailsPageOperations.clickSave(CLASS_NAME,
				method.getName());
		
		logger.info(" End Test-Converge_BusinessAccount : End the Converge_BusinessAccount creation ");

		
	}

	@AfterMethod
	public void tearDown() {
		//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		driver.close();
		driver.quit();

	}

}
