/**
 * 
 */
package com.hqnRegression.assets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.AssetBeanDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AddNewAddressPageOperation;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.FTTCAvailableAppointmentsPageOperations;
import com.hqnRegression.pages.operations.HardwareDeliveryDetailsPageOPerations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CSVOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * @author 605112580
 * 
 * 
 */
public class Create_Bronge_NON_NGA_Asset extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "Create_NON_NGA_Aseet";

	private String IN_FILE = "Create_Bronge_NON_NGA_Asset.csv";
	List<AssetBeanDetails> assetDetailsList = null;
	AssetBeanDetails assetBeanDetails = null;

	private int count = 0;
	public Order order = null;
	private int testCount = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Create_NON_NGA_Aseet");

	public Create_Bronge_NON_NGA_Asset() {
		PropertyConfigurator.configure(loggerPath);
	}

	/*
	 * @Rule public TestName name = new TestName();
	 */
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		assetDetailsList = CSVOperation_New.readAssetDetailsML(IN_FILE);
		order = new Order();

		if (assetDetailsList != null && assetDetailsList.size() > 0) {
			testCount = assetDetailsList.size();
		}

	}

	@Test
	public void testCreate_NON_NGA_Aseet(Method method) throws IOException {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			order = new Order();

			try {

				logger.info(" Start Test-Create_NON_NGA_Aseet : Start the NON-NGA-Asset creation ");

				assetBeanDetails = assetDetailsList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				// Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				RegisterNewServicePageOperations servicePageOperations = homePageOperations
						.clickBusinessCustomer();

				CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
						.searchByBusinessAccountName(
								assetBeanDetails.getBusinessAccount(),
								CLASS_NAME, method.getName());

				CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
						.clickBusinessAccount(assetBeanDetails
								.getBusinessAccount());

				LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
						.clickAddSite(CLASS_NAME, method.getName());

				AddNewAddressPageOperation addNewAddressPageOperation = lineDetailsPageOperations
						.createSiteWithPostCodeOnlyBronge(
								assetBeanDetails.getNewSite(),
								assetBeanDetails.getLandlinePhone(),
								assetBeanDetails.getPostCode(), CLASS_NAME,
								method.getName());

				LineCheckResultPageOperations lineCheckResultPageOperations = addNewAddressPageOperation
						.newAddressSelecting(
								assetBeanDetails.getPremisesName(),
								assetBeanDetails.getStreetName(),
								assetBeanDetails.getTown(),
								assetBeanDetails.getCounty(),
								assetBeanDetails.getPostCode(), CLASS_NAME,
								method.getName());

				lineCheckResultPageOperations
						.selectPropositionByName(assetBeanDetails
								.getProposition());

				AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
						.clickNext(CLASS_NAME, method.getName());

				AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
						.submit(CLASS_NAME, method.getName());

				ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
						.submit(CLASS_NAME, method.getName());

				productDetailsPageOperations.selectProductOffering_Asset(
						assetBeanDetails.getProposition(),
						assetBeanDetails.getBroadbandCare(),
						assetBeanDetails.getRouter(),
						assetBeanDetails.getBusinessRateCard(),
						assetBeanDetails.getCalls(),
						assetBeanDetails.getCarelevel(),
						assetBeanDetails.getSelectcalls(),
						assetBeanDetails.getContract(),
						assetBeanDetails.getOneOffCharge(),
						assetBeanDetails.getRateCardDiscount(),
						assetBeanDetails.getSalesPromotion(),
						assetBeanDetails.getCustomerDiscount(),
						assetBeanDetails.getPostCode(),
						assetBeanDetails.getTitle(),
						assetBeanDetails.getFirstName(),
						assetBeanDetails.getSurName(),
						assetBeanDetails.getServiceId(),
						assetBeanDetails.getDdiRangeNum(),
						assetBeanDetails.getSddirangeNum(),
						assetBeanDetails.getManagedInstall(),
						assetBeanDetails.getBroadbandFeatures(),
						method.getName(), CLASS_NAME);

				CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;
				HardwareDeliveryDetailsPageOPerations hardwareDeliveryDetailsPageOperations = null;

				/*
				 * if
				 * (assetBeanDetails.getProposition().contains("Essential BB")
				 * || (assetBeanDetails.getProposition().contains(
				 * "Business Advanced")&&
				 * !assetBeanDetails.getProposition().contains( "Call")) ||
				 * assetBeanDetails.getProposition().contains("Broadband & ") ||
				 * assetBeanDetails.getProposition()
				 * .startsWith("Broadband and") ||
				 * assetBeanDetails.getProposition()
				 * .equals("Simply Broadband")) {
				 */
				if (productDetailsPageOperations.isHardwarepageAvailable) {

					hardwareDeliveryDetailsPageOperations = productDetailsPageOperations
							.clickNextForHardware(CLASS_NAME, method.getName());

					appointmentManagementPageOperations = hardwareDeliveryDetailsPageOperations
							.clickNext(CLASS_NAME, method.getName());
				} else {

					appointmentManagementPageOperations = productDetailsPageOperations
							.clickNextForCRD(CLASS_NAME, method.getName());
				}

				appointmentManagementPageOperations.selectFutureCalendarDate(
						CLASS_NAME, method.getName(), 18);

				if (assetBeanDetails.getProposition().contains(
						"Broadband and Anytime Calls")
						|| assetBeanDetails.getProposition().contains(
								"Broadband & Anytime Calls")
						|| assetBeanDetails.getProposition().contains(
								"Broadband and Off Peak Calls")
						|| assetBeanDetails.getProposition().contains(
								"Broadband and Total Calls")
						|| assetBeanDetails.getProposition().contains(
								"Business Advanced BBand")
						|| assetBeanDetails.getProposition().contains(
								"Business Broadband and Line Rental")
						|| assetBeanDetails.getProposition().contains(
								"Business Essential BBand")
						|| assetBeanDetails.getProposition().contains(
								"Broadband & Anytime + Mobile Calls")
						|| assetBeanDetails.getProposition().equalsIgnoreCase(
								"Line Rental and Calls")
						|| assetBeanDetails.getProposition().contains(
								"Superfast Business Advanced Broadband")
						|| assetBeanDetails.getProposition().equalsIgnoreCase(
								"Line Rental")) {
					appointmentManagementPageOperations
							.fillVoiceAppointmentManagementFields(assetBeanDetails
									.getEngineeringNotes());
					if (assetBeanDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						appointmentManagementPageOperations
								.clickOutOfHoursAppointment();
					}

					ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
							.clickAvailableAppointmentButton();

					reserveAppointmentPageOperations
							.selectFirstAvailableAppointmentDate();

					if (assetBeanDetails.getIncludeOutofHours()
							.equalsIgnoreCase("yes")) {
						if (assetBeanDetails.getAppointmentCharges().contains(
								"Accept additional")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
						}
						if (assetBeanDetails.getAppointmentCharges().contains(
								"both")) {
							reserveAppointmentPageOperations
									.clickAcceptAdditionalCharges();
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						} else {
							reserveAppointmentPageOperations
									.getWaiveAdditionalCharges();
						}
					}

					appointmentManagementPageOperations = reserveAppointmentPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());
				}

				if (assetBeanDetails.getProposition().contains("40:")
						|| assetBeanDetails.getProposition().contains(
								"Superfast Business Advanced Broadband")) {

					FTTCAvailableAppointmentsPageOperations fttcAvailableAppointmentsPageOperations = appointmentManagementPageOperations
							.fillBBFTTCAppointmentManagement(CLASS_NAME,
									method.getName());
					fttcAvailableAppointmentsPageOperations
							.selectFirstAvailableAppointmentDate();
					appointmentManagementPageOperations = fttcAvailableAppointmentsPageOperations
							.clickReserveAppointmentButton(CLASS_NAME,
									method.getName());

				}
				if (assetBeanDetails.getProposition().contains("Call")
						|| assetBeanDetails.getProposition().contains("Line")) {
					appointmentManagementPageOperations
							.fillHealthAndsafetyVeificationFields(assetBeanDetails
									.getHealthAndSafetyNotes());
				}
				OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
						.clickNext(CLASS_NAME, method.getName());

				orderSummaryPageOperations.selectCommunication(assetBeanDetails
						.getCommunicationBy());
				orderSummaryPageOperations.selectTermsAndConditionsCheckBox();

				OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
						.confirmOrder(CLASS_NAME, method.getName());

				String orderId = orderConfirmationPageOperations.getOrderId();

				orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
						method.getName());

				// order.setLineSiteId(assetBeanDetails.getNewSite());

				// order.setOrdeId(orderId);

				// calling save method for storing order object in CSV
				CSVOperations.saveOrders("Order.csv", order);

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());

				logger.info(" End Test -  Create_NON_NGA_Aseet : End the NON-NGA-Asset creation");

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to place the order");

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		// driver.quit();
		// driver.close();

	}

}
