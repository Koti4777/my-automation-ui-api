/**
 * 
 */
package com.hqnRegression.assets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.bt.wlms.pages.operations.AmendConfirmationPageOperartions;
import com.bt.wlms.pages.operations.AmendSummaryPageOperations;
import com.bt.wlms.pages.operations.EditOrderPageOperations;
import com.hqnRegression.beans.Bbband;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AmendOrderPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Create_ISDN_DASS_Amend extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "Create_ISDN_DASS_Amend";

	private String IN_FILE = "ISDNAmend.csv";
	List<Bbband> BbandList = new ArrayList<Bbband>();
	Bbband band;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Create_ISDN_DASS_Amend");
	
	public Create_ISDN_DASS_Amend()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 
	

	@BeforeMethod
	public void setUp() throws Exception {
		BbandList = CSVOperation_New.readBroadbandfaultcheck(IN_FILE);
		if (BbandList != null && BbandList.size() > 0) {
			testCount = BbandList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	


	
	
     /**
      * using this method we can click the"Broadband" TAB and check whether 
           "Broadband Fault Checker"are the hyperlink are not be present
      * @param method
      * @throws IOException
      */
    
     
    @Test
	    public void testCreateBroadbandFault(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-Create_ISDN_DASS_Amend : Start the Create_ISDN_DASS_Amend creation");

				band = BbandList.get(count);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(band.getSearchBy(),
								band.getSearchValue(), CLASS_NAME,
								method.getName());
				
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLinkForPendingOrder(CLASS_NAME,
								method.getName());
				
				AmendOrderPageOperations amendOrderPageOperations = accountDetailsPageOperations
						.clickAmendOrderLink(CLASS_NAME, method.getName());

				amendOrderPageOperations.selectReasonForAmending(
						"Change in requirements", CLASS_NAME, method.getName());

				EditOrderPageOperations editOrderPageOperations = amendOrderPageOperations
						.clickEditForCustomerRequiredDate_Amend(CLASS_NAME,
								method.getName());

				amendOrderPageOperations = editOrderPageOperations
						.selectFutureCalendarDate_Amend(CLASS_NAME,
								method.getName(), 1);
				
				AmendSummaryPageOperations amendSummaryPageOperations= amendOrderPageOperations.clickAmendOrderButton(CLASS_NAME,
						method.getName());
				
				AmendConfirmationPageOperartions amendConfirmationPageOperartions =amendSummaryPageOperations.clickSubmitButton(CLASS_NAME,
						method.getName());
				
				accountDetailsPageOperations = amendConfirmationPageOperartions.clickNextButton(CLASS_NAME,
						method.getName());
				
				accountDetailsPageOperations.clickTicketsTab(CLASS_NAME,method.getName());
				accountDetailsPageOperations.clickRefreshTab(CLASS_NAME,method.getName());

				
			}
			catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to do Fault BroadBand Asset"); 

				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				logger.info(" End Test - Create_ISDN_DASS_Amend : End the Create_ISDN_DASS_Amend-Asset creation");

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		//driver.close();
		//driver.quit();

	}

}
