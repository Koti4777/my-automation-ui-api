package com.hqnRegression.assets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.LineDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.CustomerNamesPageOperations;
import com.hqnRegression.pages.operations.CustomerSitesPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LineCheckResultPageOperations;
import com.hqnRegression.pages.operations.LineDetailsPageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.RegisterNewServicePageOperations;
import com.hqnRegression.pages.operations.ReserveAppointmentPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CSVOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Create_LRO extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "LRO_Test";

	private String IN_FILE = "LineDetails.csv";
	List<LineDetails> lineDetailsList = null;
	LineDetails lineDetails = null;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Create_LRO");
	

	public Create_LRO()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 

	/*@Rule public TestName name = new TestName();*/
	
	@BeforeMethod
	public void setUp() throws Exception {
		

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		lineDetailsList = CSVOperation_New.readLineDetails(IN_FILE);

		if (lineDetailsList != null && lineDetailsList.size() > 0) {
			testCount = lineDetailsList.size();
		}

	}

	@Test
	public void testCreateLineOrder(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-Create_LRO : Start the Create_LRO creation ");

				lineDetails = lineDetailsList.get(0);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);
		//Assert.assertTrue(false);
		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		RegisterNewServicePageOperations servicePageOperations = homePageOperations
				.clickBusinessCustomer();

		CustomerNamesPageOperations customerNamesPageOperations = servicePageOperations
				.searchByBusinessAccountName(lineDetails.getBusinessAccount(),CLASS_NAME, method.getName());

		CustomerSitesPageOperations customerSitesPageOperations = customerNamesPageOperations
				.clickBusinessAccount(lineDetails.getBusinessAccount());

		LineDetailsPageOperations lineDetailsPageOperations = customerSitesPageOperations
				.clickAddSite(CLASS_NAME, method.getName());

		AddressSelectionPageOperations addressSelectionPageOperations = lineDetailsPageOperations
				.createSiteWithPostCodeOnly(lineDetails.getNewSite(), "",
						lineDetails.getPostCode(),
						lineDetails.getAddressValue(),
						lineDetails.getPremisesName(),
						lineDetails.getStreetName(), lineDetails.getTown(),
						lineDetails.getCountry(), CLASS_NAME,
						method.getName());
		LineCheckResultPageOperations lineCheckResultPageOperations = addressSelectionPageOperations
				.submitAddressButton(CLASS_NAME, method.getName());

		// lineCheckResultPageOperations.getLineRental().click();

		lineCheckResultPageOperations.selectPropositionByName(lineDetails
				.getProposition());

		AssignSiteContactPageOperations assignSiteContactPageOperations = lineCheckResultPageOperations
				.clickNext(CLASS_NAME, method.getName());

		AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
				.submit(CLASS_NAME, method.getName());

		ProductDetailsPageOperations productDetailsPageOperations = assignUserContactPageOperations
				.submit(CLASS_NAME, method.getName());

		productDetailsPageOperations.clickAnalogueVoiceTab();
		productDetailsPageOperations.fillMandatoryDirectoryListingFields(
				lineDetails.getTitle(), lineDetails.getFirstName(),
				lineDetails.getSurName());

		productDetailsPageOperations.clickOtherTab();
		productDetailsPageOperations
				.selectOtherContractTermImgANDContract(lineDetails
						.getContract());
		if (lineDetails.getProposition().contains("Call")) {
			productDetailsPageOperations.clickBusinessRateCardAndSelect();
		}

		CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = (CRDAndAppointmentManagementPageOperations) productDetailsPageOperations
				.clickNext(CLASS_NAME, method.getName());

		appointmentManagementPageOperations.selectActivateDate();
		appointmentManagementPageOperations
				.fillVoiceAppointmentManagementFields(lineDetails
						.getEngineeringNotes());

		ReserveAppointmentPageOperations reserveAppointmentPageOperations = appointmentManagementPageOperations
				.clickAvailableAppointmentButton();

		reserveAppointmentPageOperations.selectFirstAvailableAppointmentDate();
		appointmentManagementPageOperations = reserveAppointmentPageOperations
				.clickReserveAppointmentButton(CLASS_NAME, method.getName());
		appointmentManagementPageOperations
				.fillHealthAndsafetyVeificationFields(lineDetails
						.getHealthAndSafetyNotes());
		OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
				.clickNext(CLASS_NAME, method.getName());

		orderSummaryPageOperations.selectCommunication(lineDetails
				.getCommunicationBy());
		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
		OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
				.confirmOrder(CLASS_NAME, method.getName());

		String orderId = orderConfirmationPageOperations.getOrderId();

		order.setLineSiteId(lineDetails.getNewSite());
		order.setOrdeId(orderId);
		order.setBbSiteId("");

		// calling save method for storing order object in CSV
		CSVOperations.saveOrders("Order.csv", order);

		orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
				method.getName());

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				logger.info(" End Test-Create_LRO : End the Create_LRO creation ");


			} catch (Exception e) {
				// TODO: handle exception
				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {

		/*
		 * try { CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
		 * "lastPageOperations" + ".png", driver, "end"); } catch (IOException
		 * e) { e.printStackTrace(); }
		 */
		// driver.findElement(By.id("user-logout")).click();
		driver.close();
		driver.quit();

	}

}
