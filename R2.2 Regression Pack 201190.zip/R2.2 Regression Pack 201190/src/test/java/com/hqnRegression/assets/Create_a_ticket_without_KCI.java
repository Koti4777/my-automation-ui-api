package com.hqnRegression.assets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.CreateTicket;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Create_a_ticket_without_KCI extends SeleniumImplementation {

	private WebDriver driver;
	
	public String CLASS_NAME = "Create_a_ticket_without_KCI";

	private String IN_FILE = "Create_ticket.csv";
	List<CreateTicket> createList = null;
	CreateTicket createTicket = null;

	private int testCount = 0;
	private int count = 0;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Create_a_ticket_without_KCI");

	
	public Create_a_ticket_without_KCI()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 


	/*@Rule
	public TestName name = new TestName();
*/
	@BeforeMethod
	public void setUp() throws Exception {

		createList = CSVOperation_New.readCreateTicket(IN_FILE);

		if (createList != null && createList.size() > 0) {
			testCount = createList.size();
			System.out.println(testCount);
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void testCreateTicket(Method method) throws IOException {

System.out.println("method name is --->"+method.getName());
		
		//Assert.assertTrue(false);

		while (count < testCount) {

			try {
				

			      logger.info(" Start Test-Create_a_ticket_without_KCI : Start the Create_a_ticket_without_KCI  creation ");

				createTicket = createList.get(count);

				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(createTicket.getOrderid(), "Order Number",
								CLASS_NAME, method.getName());

				Set<String> windows = driver.getWindowHandles();
				System.out.println("sssssssssssspppppppppp" + windows.size());

				Iterator<String> it = windows.iterator();
				String names = null;
				String firstName = null;

				while (it.hasNext()) {
					firstName = it.next();
					System.out.println("namesnames000000000000" + names);
				}

				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());

				accountDetailsPageOperations.clickticketsTab(CLASS_NAME,
						method.getName());

				accountDetailsPageOperations.getInitiateTicket().click();
				CommonMethods.doPause(6);

				accountDetailsPageOperations = accountDetailsPageOperations
						.fillTicketDetails(createTicket.getTickettype(),
								createTicket.getTicketsubtype(),
								createTicket.getPool(),
								createTicket.getContacttype(),
								createTicket.getNotes(), CLASS_NAME,
								method.getName());

				driver.switchTo().window(firstName);

				CommonMethods.logOut(driver, CLASS_NAME, method.getName());
				
				  logger.info(" End Test-Create_a_ticket_without_KCI : End the Create_a_ticket_without_KCI  creation ");
			}

			catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to create a ticket the orderid " + createTicket.getOrderid());
			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();
		logger.info(",Create_a_ticket_without_KCI,pass");
	}
}
