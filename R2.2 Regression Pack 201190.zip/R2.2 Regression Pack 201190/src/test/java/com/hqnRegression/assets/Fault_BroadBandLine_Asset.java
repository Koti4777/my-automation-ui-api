package com.hqnRegression.assets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.WLRFaultCareLevel;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.BBFaultCheckerPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CPEDiagnosticCheckReportPageOperation;
import com.hqnRegression.pages.operations.CheckDetailsPageOperations;
import com.hqnRegression.pages.operations.ContactPageOperations;
import com.hqnRegression.pages.operations.FaultTicketReferenceDetailsPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.PreCheckPageOperations;
import com.hqnRegression.pages.operations.QuestionsPageOperations;
import com.hqnRegression.pages.operations.RadiusCheckPageOperation;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class Fault_BroadBandLine_Asset extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "Fault_BroadBand";

	private String IN_FILE = "BroadBandFault.csv";
	List<WLRFaultCareLevel> wlrFaultCareLevelList = new ArrayList<WLRFaultCareLevel>();
	WLRFaultCareLevel wlrFaultCareLevel;

	private int testCount = 0;
	private int count = 0;
	public Order order = null;
	
	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("Fault_BroadBandLine_Asset");
	
	public Fault_BroadBandLine_Asset()
	{
		PropertyConfigurator.configure(loggerPath);
	}
		 
	

	@BeforeMethod
	public void setUp() throws Exception {
		wlrFaultCareLevelList = CSVOperation_New.readWLRFaultCareLevel(IN_FILE);
		if (wlrFaultCareLevelList != null && wlrFaultCareLevelList.size() > 0) {
			testCount = wlrFaultCareLevelList.size();
		}
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
/*
	@Rule
	public TestName name = new TestName();
*/
	@Test
	public void testCreateBroadbandFault(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());

		while (count < testCount) {

			order = new Order();

			try {
				
				logger.info(" Start Test-Fault_BroadBandLine_Asset : Start the Fault_BroadBandLine_Asset creation ");

				wlrFaultCareLevel = wlrFaultCareLevelList.get(count);
				LoginPageOperations loginPageOperations = CMCHomePageOperations
						.navigateTo(driver);
				//Assert.assertTrue(false);
				HomePageOperations homePageOperations = loginPageOperations
						.adminLogin(CLASS_NAME, method.getName());

				SearchResultPageOperations searchResultPageOperations = homePageOperations
						.search(wlrFaultCareLevel.getSearchBy(),
								wlrFaultCareLevel.getSearchValue(), CLASS_NAME,
								method.getName());
				AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
						.clickProductLink(CLASS_NAME, method.getName());
				accountDetailsPageOperations.clickBroadbandTab(CLASS_NAME,
						method.getName());
				BBFaultCheckerPageOperations bbFaultCheckerPageOperations = accountDetailsPageOperations
						.clickBroadBandFaultCheckerLink(CLASS_NAME,
								method.getName());
				PreCheckPageOperations preCheckPageOperations = bbFaultCheckerPageOperations
						.clickContinue(CLASS_NAME, method.getName());
				preCheckPageOperations.PreCheck(CLASS_NAME,
						method.getName(),
						wlrFaultCareLevel.getTicketSubtypeID(),
						wlrFaultCareLevel.getChannelId());

				CPEDiagnosticCheckReportPageOperation cpeDiagnosticCheckReportPageOperation = preCheckPageOperations
						.clickContinue(CLASS_NAME, method.getName());
				RadiusCheckPageOperation radiusCheckPageOperation = cpeDiagnosticCheckReportPageOperation
						.clickContinue(CLASS_NAME, method.getName());
				ContactPageOperations contactPageOperations = radiusCheckPageOperation
						.clickContinue(CLASS_NAME, method.getName());
				QuestionsPageOperations questionsPageOperations = contactPageOperations
						.clickStartConnectionCheck(CLASS_NAME,
								method.getName());

				questionsPageOperations.clickContinueAndselectQuestions("Yes",
						"Continue", "Yes", "No", CLASS_NAME,
						method.getName());

				CheckDetailsPageOperations checkDetailsPageOperations = questionsPageOperations
						.clickContinue(CLASS_NAME, method.getName());
				FaultTicketReferenceDetailsPageOperations faultTicketReferenceDetailsPageOperations = checkDetailsPageOperations
						.clickContinue(CLASS_NAME, method.getName());
				faultTicketReferenceDetailsPageOperations.clickClose(
						CLASS_NAME, method.getName());
				
				logger.info(" End Test-Fault_BroadBandLine_Asset : End the Fault_BroadBandLine_Asset creation ");

				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Unable to do Fault BroadBand Asset");

				//CommonMethods.logOut(driver, CLASS_NAME, method.getName());

			}
			count++;
		}

	}

	@AfterMethod
	public void tearDown() {
		//driver.close();
		//driver.quit();

	}

}
