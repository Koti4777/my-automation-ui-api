package com.hqnRegression.assets;

import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.LornDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class LORNAutomation extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "LORNAutomation";

	private static InputStream inputStream;
	private static Properties testProps;
	private String IN_FILE = "LornDetails.csv";
	List<LornDetails> lornDetailsList = null;
	LornDetails lornDetails = null;

	private int testCount = 0;

	private int count = 0;
	public Order order = null;
	private String baseUrl;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("LORNAutomation");

	public LORNAutomation() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);

		lornDetailsList = CSVOperation_New.readLornDetails(IN_FILE);

		if (lornDetailsList != null && lornDetailsList.size() > 0) {
			testCount = lornDetailsList.size();
		}

		inputStream = new FileInputStream(
				"./src/test/resources/com/hqnRegression/login-wlr3.properties");
		testProps = new Properties();
		testProps.load(inputStream);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testLornCreate(Method method) throws Exception {
		System.out.println("method name is --->" + method.getName());

		while (count < testCount) {

			logger
					.info(" Start Test-LORNAutomation : Start the LORNAutomation creation ");

			lornDetails = lornDetailsList.get(count);

			driver.get(testProps.getProperty("baseUrl")
					+ "/faces/jsp/CPLogin.jsp");

			driver.get(testProps.getProperty("baseUrl")
					+ "/faces/jsp/CPLogin.jsp");
			driver.findElement(By.id("j_id_id2:loginusername")).clear();
			driver.findElement(By.id("j_id_id2:loginusername")).sendKeys(
					testProps.getProperty("username"));
			driver.findElement(By.id("j_id_id2:loginpassword")).clear();
			driver.findElement(By.id("j_id_id2:loginpassword")).sendKeys(
					testProps.getProperty("password"));

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
					"LoginPage" + ".png", driver, "Start");

			driver.findElement(By.id("j_id_id2:submit")).click();

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
					"LoginPage" + ".png", driver, "");

			new Select(driver.findElement(By.id("cpportal:submittingcp")))
					.selectByVisibleText(lornDetails.getSubmiitingCP());

			new Select(driver.findElement(By.id("cpportal:eventType")))
					.selectByVisibleText("Setup a Linked Order Query");

			new Select(driver.findElement(By.id("cpportal:event")))
					.selectByVisibleText("Create a Linked Order Reference");

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(), "LornPage"
					+ ".png", driver, "");

			CommonMethods.doPause(2);

			driver.findElement(By.id("itemstable:0:itemstabletextbox")).clear();
			driver.findElement(By.id("itemstable:0:itemstabletextbox"))
					.sendKeys(lornDetails.getLandlinePhone());
			driver.findElement(By.id("itemstable:1:itemstabletextbox")).clear();
			driver.findElement(By.id("itemstable:1:itemstabletextbox"))
					.sendKeys(lornDetails.getPostCode());
			new Select(driver.findElement(By
					.id("itemstable:2:itemstabledropdown")))
					.selectByVisibleText("1 - Single Matched Order");
			new Select(driver.findElement(By
					.id("itemstable:3:itemstabledropdown")))
					.selectByVisibleText("Yes");
			new Select(driver.findElement(By
					.id("itemstable:4:itemstabledropdown")))
					.selectByVisibleText("1 - Single Matched Order");
			new Select(driver.findElement(By
					.id("itemstable:5:itemstabledropdown")))
					.selectByVisibleText("Yes");

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(), "LornPage"
					+ ".png", driver, "");

			driver.findElement(By.name("itemstable:j_idt51")).click();

			List<WebElement> tackindIdWebelements = driver.findElements(By
					.xpath("//label[contains(.,'Tracking ID:')]"));

			String lornTrackID = null;
			int indx1 = 0;
			int indx2 = 0;

			for (WebElement element : tackindIdWebelements) {
				lornTrackID = element.getText();

				indx1 = lornTrackID.indexOf("Tracking ID:") + 13;
				indx2 = indx1 + 5;

				lornTrackID = lornTrackID.substring(indx1, indx2);

				logger
						.info(" LORNAutomation : lorn generation Tracking id ::::::::"
								+ lornTrackID);
				break;
			}

			CommonMethods.doPause(300);

			driver.get(driver.getCurrentUrl());

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(), "LornPage"
					+ ".png", driver, "");

			WebElement element = driver.findElement(By
					.xpath("//label[contains(.,'" + lornTrackID + "')]"));

			WebElement ele = element.findElement(By
					.xpath("../following-sibling::td[1]/label[1]"));

			String lorn_id = ele.getText();

			indx1 = 0;
			indx2 = 0;

			if (lorn_id != null) {

				indx1 = lorn_id.indexOf("MM");

				if (indx1 != 0) {
					indx2 = indx1 + 10;
					lorn_id = lorn_id.substring(indx1, indx2);
				}
			}

			System.out.println("lornGeneration Id" + lorn_id);

			logger
					.info(" End Test-LORNAutomation : End the LORNAutomation creation ");

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(), "LornPage"
					+ ".png", driver, "End");

			count++;
		}

	}

	@AfterMethod
	public void tearDown() throws Exception {
		// driver.quit();

	}

}
