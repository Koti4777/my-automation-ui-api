package com.hqnRegression.assets;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.Order;
import com.hqnRegression.beans.SMPFFackingBeanDetails;
import com.hqnRegression.beans.WLR3Details;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;
import com.singularity.beans.SingularityBeanDetails;
import com.singularity.operations.CustomerDetailsPageOperations;
import com.singularity.operations.LoginPageOperations;
import com.singularity.operations.SearchResultsPageOperations;
import com.singularity.operations.SummaryPageOperations;

public class SMPFFackingAutomation extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "SMPFFackingAutomation";
	private static InputStream inputStream;
	private static Properties testProps;

	private String IN_FILE = "SMPFFacking.csv";
	List<SMPFFackingBeanDetails> smpfFackingDetailsList = null;
	SMPFFackingBeanDetails smpfFackingBeanDetails = null;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("SMPFFackingAutomation");
	private int testCount = 0;
	private int count = 0;
	public Order order = null;

	public SMPFFackingAutomation() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setup() {
		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		smpfFackingDetailsList = CSVOperation_New
				.readSMPFFackingDetails(IN_FILE);
		if (smpfFackingDetailsList != null && smpfFackingDetailsList.size() > 0) {
			testCount = smpfFackingDetailsList.size();
		}

		try {
			inputStream = new FileInputStream(
					"./src/test/resources/com/hqnRegression/login-wlr3.properties");
			testProps = new Properties();
			testProps.load(inputStream);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testProvideService(Method method) throws Exception {
		// System.out.println("method name is --->" + method.getName());
		smpfFackingBeanDetails = smpfFackingDetailsList.get(0);

		LoginPageOperations loginPageOperations = LoginPageOperations
				.navigateTo(driver);

		// CommonMethods.doPause(20);

		SearchResultsPageOperations searchpageoperations = loginPageOperations
				.login(CLASS_NAME, method.getName());

		SummaryPageOperations summarypageoperations = searchpageoperations
				.searchDetails(smpfFackingBeanDetails.getCustomerName(),
						CLASS_NAME, method.getName());
		CommonMethods.doPause(20);

		summarypageoperations.clickDetails(CLASS_NAME, method.getName());

		WLR3Details wlr3Details = summarypageoperations
				.fetchSMPFFackingDetails(CLASS_NAME, method.getName());
		CommonMethods.doPause(20);

		try {

			logger.info("WLR3Automation : Start the WLR3Automation progression ");

			driver = createBrowserInstance(BrowserType.FIREFOX);

			driver.get(testProps.getProperty("baseUrl")
					+ "/faces/jsp/CPLogin.jsp");
			driver.manage().window().maximize();
			driver.findElement(By.id("j_id_id2:loginusername")).clear();
			driver.findElement(By.id("j_id_id2:loginusername")).sendKeys(
					testProps.getProperty("username"));
			driver.findElement(By.id("j_id_id2:loginpassword")).clear();
			driver.findElement(By.id("j_id_id2:loginpassword")).sendKeys(
					testProps.getProperty("password"));

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
					"LoginPage" + ".png", driver, "Start");

			driver.findElement(By.id("j_id_id2:submit")).click();

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
					"CVFHomepage" + ".png", driver, "");

			new Select(driver.findElement(By.id("cpportal:submittingcp")))
					.selectByVisibleText(smpfFackingBeanDetails
							.getSubmiitingCP());
			new Select(driver.findElement(By.id("cpportal:eventType")))
					.selectByVisibleText("Create an asset");
			new Select(driver.findElement(By.id("cpportal:event")))
					.selectByVisibleText("LLU - Create Tie Cable Asset");

			logger.info(" WLR3Automation : Fill MPF Tie Cable details ");

			new Select(driver.findElement(By
					.id("itemstable:0:itemstabledropdown")))
					.selectByVisibleText("Other CP");
			new Select(driver.findElement(By
					.id("itemstable:1:itemstabledropdown")))
					.selectByVisibleText("MPF Tie Cable");
			new Select(driver.findElement(By
					.id("itemstable:2:itemstabledropdown")))
					.selectByVisibleText(wlr3Details.getCssDistrictCode()
							+ wlr3Details.getExchangeCode());
			
			if ("STALB".equalsIgnoreCase(wlr3Details.getCssDistrictCode()
					+ wlr3Details.getExchangeCode())){
				new Select(driver.findElement(By
						.id("itemstable:3:itemstabledropdown")))
						.selectByVisibleText("21CN");
			}else{
				new Select(driver.findElement(By
						.id("itemstable:3:itemstabledropdown")))
						.selectByVisibleText("20C");
			}
			CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
					"MPF Tie Cable operations" + ".png", driver, "");

			driver.findElement(By.name("itemstable:j_idt51")).click();

			List<WebElement> tackindIdWebelements = driver.findElements(By
					.xpath("//label[contains(.,'Tracking ID:')]"));

			String mpfTrackID = null;
			int indx1 = 0;
			int indx2 = 0;

			for (WebElement element : tackindIdWebelements) {
				mpfTrackID = element.getText();

				indx1 = mpfTrackID.indexOf("Tracking ID:") + 13;
				indx2 = indx1 + 5;

				mpfTrackID = mpfTrackID.substring(indx1, indx2);

				logger.info(" WLR3Automation : MPF Tie Cable Tracking id ::::::::"
						+ mpfTrackID);
				break;
			}

			CommonMethods.doPause(300);
			driver.get(driver.getCurrentUrl());

			CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
					"MPF Tie Cable operations" + ".png", driver, "");

			WebElement element = driver.findElement(By
					.xpath("//label[contains(.,'" + mpfTrackID + "')]"));

			WebElement ele = element.findElement(By
					.xpath("../following-sibling::td[1]/label[1]"));

			String mpf_id = ele.getText();

			indx1 = 0;
			indx2 = 0;

			if (mpf_id != null) {

				indx1 = mpf_id.indexOf("LLU");

				if (indx1 != 0) {
					indx2 = indx1 + 10;
					mpf_id = mpf_id.substring(indx1, indx2);
				}
			}

			// Check the MPF Tie Cable id
			if (mpf_id != null) {

				logger.info(" WLR3Automation : MPF Tie Cable id ::::::::"
						+ mpf_id);

				new Select(driver.findElement(By.id("cpportal:eventType")))
						.selectByVisibleText("Create an asset");
				new Select(driver.findElement(By.id("cpportal:event")))
						.selectByVisibleText("LLU - Create Tie Cable Asset");

				logger.info(" WLR3Automation : Fill the PSTN Tie Cable details ");

				new Select(driver.findElement(By
						.id("itemstable:0:itemstabledropdown")))
						.selectByVisibleText("Other CP");
				new Select(driver.findElement(By
						.id("itemstable:1:itemstabledropdown")))
						.selectByVisibleText("PSTN Tie Cable");
				new Select(driver.findElement(By
						.id("itemstable:2:itemstabledropdown")))
						.selectByVisibleText(wlr3Details.getCssDistrictCode()
								+ wlr3Details.getExchangeCode());

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"PSTN Tie Cable operations" + ".png", driver, "");

				driver.findElement(By.name("itemstable:j_idt51")).click();

				tackindIdWebelements = driver.findElements(By
						.xpath("//label[contains(.,'Tracking ID:')]"));

				String pstnTrackID = null;

				for (WebElement element2 : tackindIdWebelements) {
					pstnTrackID = element2.getText();
					indx1 = pstnTrackID.indexOf("Tracking ID:") + 13;
					indx2 = indx1 + 5;

					pstnTrackID = pstnTrackID.substring(indx1, indx2);

					logger.info(" WLR3Automation : PSTN Tie Cable Tracking id ::::::::"
							+ pstnTrackID);
					break;
				}

				CommonMethods.doPause(300);
				driver.get(driver.getCurrentUrl());

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"PSTN Tie Cable operations" + ".png", driver, "");

				element = driver.findElement(By.xpath("//label[contains(.,'"
						+ pstnTrackID + "')]"));

				ele = element.findElement(By
						.xpath("../following-sibling::td[1]/label[1]"));

				String pstn_id = ele.getText();

				indx1 = 0;
				indx2 = 0;

				if (pstn_id != null) {
					indx1 = pstn_id.indexOf("LLU");
					if (indx1 != 0) {
						indx2 = indx1 + 10;
						pstn_id = pstn_id.substring(indx1, indx2);
					}
				}

				// Check the PSTN Tie Cable id
				if (pstn_id != null) {

					logger.info(" WLR3Automation : PSTN Tie Cable id ::::::::"
							+ pstn_id);

					new Select(driver.findElement(By.id("cpportal:eventType")))
							.selectByVisibleText("Create an asset");
					new Select(driver.findElement(By.id("cpportal:event")))
							.selectByVisibleText("LLU - Create SMPF Asset for Other CP with LOR");

					logger.info("WLR3Automation : Fill the SMPF Asset details ");

					driver.findElement(By.id("itemstable:0:itemstabletextbox"))
							.clear();
					driver.findElement(By.id("itemstable:0:itemstabletextbox"))
							.sendKeys(wlr3Details.getAddressValue());
					driver.findElement(By.id("itemstable:1:itemstabletextbox"))
							.clear();
					driver.findElement(By.id("itemstable:1:itemstabletextbox"))
							.sendKeys(smpfFackingBeanDetails.getPostCode());
					driver.findElement(By.id("itemstable:3:itemstabletextbox"))
							.clear();
					driver.findElement(By.id("itemstable:3:itemstabletextbox"))
							.sendKeys(pstn_id);
					driver.findElement(By.id("itemstable:4:itemstabletextbox"))
							.clear();
					driver.findElement(By.id("itemstable:4:itemstabletextbox"))
							.sendKeys("001");
					driver.findElement(By.id("itemstable:5:itemstabletextbox"))
							.clear();
					driver.findElement(By.id("itemstable:5:itemstabletextbox"))
							.sendKeys(mpf_id);
					driver.findElement(By.id("itemstable:6:itemstabletextbox"))
							.clear();
					driver.findElement(By.id("itemstable:6:itemstabletextbox"))
							.sendKeys("001");
					new Select(driver.findElement(By
							.id("itemstable:7:itemstabledropdown")))
							.selectByVisibleText(wlr3Details
									.getCssDistrictCode()
									+ wlr3Details.getExchangeCode());
					driver.findElement(By.id("itemstable:8:itemstabletextbox"))
							.clear();
					driver.findElement(By.id("itemstable:8:itemstabletextbox"))
							.sendKeys(wlr3Details.getLinkedSMPFReference());

					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"SMPF Asset operations" + ".png", driver, "");

					driver.findElement(By.name("itemstable:j_idt51")).click();

					tackindIdWebelements = driver.findElements(By
							.xpath("//label[contains(.,'Tracking ID:')]"));

					String smPFTrackID = null;

					for (WebElement element2 : tackindIdWebelements) {
						smPFTrackID = element2.getText();
						indx1 = smPFTrackID.indexOf("Tracking ID:") + 13;
						indx2 = indx1 + 5;

						smPFTrackID = smPFTrackID.substring(indx1, indx2);

						logger.info(" WLR3Automation : SMPF Tracking id Tracking id ::::::::"
								+ smPFTrackID);

						break;
					}

					CommonMethods.doPause(300);
					driver.get(driver.getCurrentUrl());

					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"SMPF Asset operations" + ".png", driver, "End");

					element = driver
							.findElement(By.xpath("//label[contains(.,'"
									+ smPFTrackID + "')]"));

					ele = element.findElement(By
							.xpath("../following-sibling::td[1]/label[1]"));

					String smpf_id = ele.getText();

					indx1 = smpf_id.indexOf("1-");
					indx2 = indx1 + 12;

					smpf_id = smpf_id.substring(indx1, indx2);

					logger.info(" WLR3Automation : SMPF order reference ::::::::"
							+ smpf_id);

					logger.info("WLR3Automation : End the WLR3Automation progression ");

				}

			}

		} catch (Exception e) {
			try {
				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"lastPageOperations" + ".png", driver, "end");
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			e.printStackTrace();
			logger.error("Unable to do the WLR3 progression");
		}

		 //CommonMethods.logOut(driver, CLASS_NAME, method.getName());

		 logger.info(" End Test -  Singularity : End the Singularity creation");

	}

	@AfterMethod
	public void tearDown() {
		//driver.quit();
		//driver.close();
	}
}
