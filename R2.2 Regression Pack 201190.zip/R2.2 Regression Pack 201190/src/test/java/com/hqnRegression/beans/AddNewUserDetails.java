package com.hqnRegression.beans;

public class AddNewUserDetails {
	private String teamName ;
	private String teamDesc ;
	private String userName ;	
	private String password;	
	private String firstName;		
	private String surName; 		
	private String emailAddress;
	private String agentName;
	private String chooseTeam;

	public String getChooseTeam() {
		return chooseTeam;
	}
	public void setChooseTeam(String chooseTeam) {
		this.chooseTeam = chooseTeam;
	}
	
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getTeamDesc() {
		return teamDesc;
	}
	public void setTeamDesc(String teamDesc) {
		this.teamDesc = teamDesc;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	} 
	
	private String postCode;
	private String addressValue;
	private String town;
	private String country;
	private String premisesName;
	private String streetName;
	private String moveOnDiffDate;
	private String phoneNumber;
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getAddressValue() {
		return addressValue;
	}
	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPremisesName() {
		return premisesName;
	}
	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getMoveOnDiffDate() {
		return moveOnDiffDate;
	}
	public void setMoveOnDiffDate(String moveOnDiffDate) {
		this.moveOnDiffDate = moveOnDiffDate;
	}
	
	private String questionNotes;
	private String questionRelatedTo;

	public String getQuestionNotes() {
		return questionNotes;
	}
	public void setQuestionNotes(String questionNotes) {
		this.questionNotes = questionNotes;
	}
	public String getQuestionRelatedTo() {
		return questionRelatedTo;
	}
	public void setQuestionRelatedTo(String questionRelatedTo) {
		this.questionRelatedTo = questionRelatedTo;
	}

}
