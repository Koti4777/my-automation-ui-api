package com.hqnRegression.beans;

public class AddTeamDetails {
	private String teamName;

	private String teamDesc;
	
	private String customerType;
	
	private String permission;

	private String B2B;

	private String B2C;

	private String B2BAndB2C;

	private String Save;

	private String Back;

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getTeamDesc() {
		return teamDesc;
	}

	public void setTeamDesc(String teamDesc) {
		this.teamDesc = teamDesc;
	}

	public String getB2B() {
		return B2B;
	}

	public void setB2B(String b2b) {
		B2B = b2b;
	}

	public String getB2C() {
		return B2C;
	}

	public void setB2C(String b2c) {
		B2C = b2c;
	}

	public String getB2BAndB2C() {
		return B2BAndB2C;
	}

	public void setB2BAndB2C(String b2bAndB2C) {
		B2BAndB2C = b2bAndB2C;
	}

	public void setSave(String save) {
		Save = save;
	}

	public String getSave() {
		return Save;
	}

	public String getBack() {
		return Back;
	}

	public void setBack(String back) {
		Back = back;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getPermission() {
		return permission;
	}

	public void setPermission(String permission) {
		this.permission = permission;
	}
	
	

}
