package com.hqnRegression.beans;

public class AlternativeContact {

	
	private String title;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getForeName() {
		return foreName;
	}
	public void setForeName(String foreName) {
		this.foreName = foreName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getTelephoneNum() {
		return telephoneNum;
	}
	public void setTelephoneNum(String telephoneNum) {
		this.telephoneNum = telephoneNum;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public String getAddtionalTelephoneNum() {
		return addtionalTelephoneNum;
	}
	public void setAddtionalTelephoneNum(String addtionalTelephoneNum) {
		this.addtionalTelephoneNum = addtionalTelephoneNum;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getPremisesNameNum() {
		return premisesNameNum;
	}
	public void setPremisesNameNum(String premisesNameNum) {
		this.premisesNameNum = premisesNameNum;
	}
	private String foreName;
	private String surName;
	private String telephoneNum;
	private String mobileNum;
	private String addtionalTelephoneNum;
	private String emailAddress;
	private String postCode;
	private String premisesNameNum;
	
	
	
	
	

	
	
	

}
