package com.hqnRegression.beans;

public class AssetBeanDetails {

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getConverged() {
		return converged;
	}

	public void setConverged(String converged) {
		this.converged = converged;
	}

	public String getBillingAccountNumber() {
		return billingAccountNumber;
	}

	public void setBillingAccountNumber(String billingAccountNumber) {
		this.billingAccountNumber = billingAccountNumber;
	}

	private String businessAccount;
	private String newSite;
	private String landlinePhone;
	private String postCode;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String proposition;
	private String router;
	private String businessRateCard;
	private String calls;
	private String carelevel;
	private String selectcalls;
	private String contract;
	private String oneOffCharge;
	private String rateCardDiscount;
	private String salesPromotion;
	private String customerDiscount;
	private String includeOutofHours;
	private String appointmentCharges;
	private String title;
	private String firstName;
	private String surName;
	private String engineeringNotes;
	private String healthAndSafetyNotes;
	private String communicationBy;
	private String communicationBy2;
	private String communicationBy3;
	private String communicationBy4;
	private String orderId;
	private String broadbandCare;
	private String serviceId;
	private String ddiRangeNum;
	private String keepExistingNumber;
	private String ceaseReason;
	private String customerId;
	
	private String waiveETCReason;

	private String customerType;

    private String converged;

	private String billingAccountNumber;
	private String cnf;
	private String price;
	private String Release;
	private String number;
	private String cnfQuantity;
	private String county;
	
	private String searchByName;
	private String deliveryContact;
	private String macId;
	
	
	
	
	

public String getMacId() {
		return macId;
	}

	public void setMacId(String macId) {
		this.macId = macId;
	}

public String getDeliveryContact() {
		return deliveryContact;
	}

	public void setDeliveryContact(String deliveryContact) {
		this.deliveryContact = deliveryContact;
	}

public String getSearchByName() {
		return searchByName;
	}

	public void setSearchByName(String searchByName) {
		this.searchByName = searchByName;
	}

public String getCounty() {
		return county;
	}


public void setCounty(String county) {
	this.county = county;
}

public String getCommunicationBy2() {
			return communicationBy2;
		}

		public void setCommunicationBy2(String communicationBy2) {
			this.communicationBy2 = communicationBy2;
		}

		public String getCommunicationBy3() {
			return communicationBy3;
		}

		public void setCommunicationBy3(String communicationBy3) {
			this.communicationBy3 = communicationBy3;
		}

		public String getCommunicationBy4() {
			return communicationBy4;
		}

		public void setCommunicationBy4(String communicationBy4) {
			this.communicationBy4 = communicationBy4;
		}

	private String callingFeatures;

	

		public String getCnfQuantity() {
		return cnfQuantity;
	}

	public void setCnfQuantity(String cnfQuantity) {
		this.cnfQuantity = cnfQuantity;
	}

		public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

		public String getRelease() {
		return Release;
	}

	public void setRelease(String release) {
		Release = release;
	}

		public String getCnf() {
		return cnf;
	}

	public void setCnf(String cnf) {
		this.cnf = cnf;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}





	public String getCallingFeatures() {
		return callingFeatures;
	}

	public void setCallingFeatures(String callingFeatures) {
		this.callingFeatures = callingFeatures;
	}

	public String getWaiveETCReason() {
		return waiveETCReason;
	}

	public void setWaiveETCReason(String waiveETCReason) {
		this.waiveETCReason = waiveETCReason;
	}

		private String quantityContractTerm;
	
	public String getQuantityContractTerm() {
		return quantityContractTerm;
	}

	public void setQuantityContractTerm(String quantityContractTerm) {
		this.quantityContractTerm = quantityContractTerm;
	}

	private String quantityVoiceISDN;


	public String getQuantityVoiceISDN() {
		return quantityVoiceISDN;
	}

	public void setQuantityVoiceISDN(String quantityVoiceISDN) {
		this.quantityVoiceISDN = quantityVoiceISDN;
	}

	
	//added for applydunning option
	
	private String dPIIProfiles;

	public String getDPIIProfiles() {
		return dPIIProfiles;
	}

	public void setDPIIProfiles(String dPIIProfiles) {
		this.dPIIProfiles = dPIIProfiles;
	}

	private String mobileAccountNumber;
	private String propositionWLTO;
	private String propositionSOSL;


	private String mobileNum;
	private String phoneNum;
	private String additionalContacNum;
	private String notificationBy;
	
	private String rentalCharge;
	
	private String ISDN30OneCharges;

    private String macCode;


    private String contractTerm;


    
    private String subtype;
    private String contracttype;
    private String multilinenumber;
    




	private String quantity;
	private String isdnFeaturePrice;
	private String quantity_ISDN;
	private String quantity_MLLine;
	
	public String getQuantity_MLLine() {
		return quantity_MLLine;
	}

	public void setQuantity_MLLine(String quantity_MLLine) {
		this.quantity_MLLine = quantity_MLLine;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	private String currentInstallationAddressPostCode;

	public String getCurrentInstallationAddressPostCode() {
		return currentInstallationAddressPostCode;
	}

	public void setCurrentInstallationAddressPostCode(
			String currentInstallationAddressPostCode) {
		this.currentInstallationAddressPostCode = currentInstallationAddressPostCode;
	}

	public String getIsdn2eStandaradFeatures() {
		return isdn2eStandaradFeatures;
	}

	public void setIsdn2eStandaradFeatures(String isdn2eStandaradFeatures) {
		this.isdn2eStandaradFeatures = isdn2eStandaradFeatures;
	}

	private String isdn2eStandaradFeatures;

	private String cancelReason;

	public String getCancelReason() {
		return cancelReason;
	}


	
	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

;
	private String istallation;
	private String lineisolation;
	private String linetype;
	
	public String getLinetype() {
		return linetype;
	}

	public void setLinetype(String lineType) {
		this.linetype = lineType;
	}

	public String getMacCode() {
		return macCode;
	}

	public void setMacCode(String macCode) {
		this.macCode = macCode;
	}

	public String getIstallation() {
		return istallation;
	}

	public void setIstallation(String istallation) {
		this.istallation = istallation;
	}

	public String getLineisolation() {
		return lineisolation;
	}

	public void setLineisolation(String lineisolation) {
		this.lineisolation = lineisolation;
	}

	public String getISDN30OneCharges() {
		return ISDN30OneCharges;
	}

	public void setISDN30OneCharges(String iSDN30OneCharges) {
		ISDN30OneCharges = iSDN30OneCharges;
	}

	public String getRentalCharge() {
		return rentalCharge;
	}

	public void setRentalCharge(String rentalCharge) {
		this.rentalCharge = rentalCharge;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCeaseReason() {
		return ceaseReason;
	}

	public void setCeaseReason(String ceaseReason) {
		this.ceaseReason = ceaseReason;
	}

	private String moveOnDiffDate;
	private String applyCeaseCharges;

	private String searchBy;
	private String searchValue;

	private String existingSite;

	private String broadbandFeatures;

	private String newPassword;
	private String confirmPassword;

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	private String siteName;

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getBroadbandFeatures() {
		return broadbandFeatures;
	}

	public void setBroadbandFeatures(String broadbandFeatures) {
		this.broadbandFeatures = broadbandFeatures;
	}

	public String getExistingSite() {
		return existingSite;
	}

	public void setExistingSite(String existingSite) {
		this.existingSite = existingSite;
	}

	public String getSearchBy() {
		return searchBy;
	}

	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public String getApplyCeaseCharges() {
		return applyCeaseCharges;
	}

	public void setApplyCeaseCharges(String applyCeaseCharges) {
		this.applyCeaseCharges = applyCeaseCharges;
	}

	public String getMoveOnDiffDate() {
		return moveOnDiffDate;
	}

	public void setMoveOnDiffDate(String moveOnDiffDate) {
		this.moveOnDiffDate = moveOnDiffDate;
	}

	public String getKeepExistingNumber() {
		return keepExistingNumber;
	}

	public void setKeepExistingNumber(String keepExisting) {
		this.keepExistingNumber = keepExisting;
	}

	private String sddirangeNum;

	/* PortinNumber newly added to AssetBeanDetails */
	private String portNumber;

	private String managedInstall;

	private String customerRequiredDate;

	private String appointmentRequired;

	private String reserveAppointmentButton;

	/************** Adding fields for AlternativeContactDetailsPageOperation **************************/

	private String salutation;
	private String forename;
	private String telephoneNumber;
	private String mobileNumber;
	private String additionalTelephoneNumber;
	private String emailAddress;
	private String dob;

	/**************************************************************************************************/

	private String quantity_VoiceCarelevel;
	private String quantity_ContractTerm;
	private String quantity_ISDN2eSystem;
	private String mlAuxVoiceLine;
	private String carelevelQuantity;
	
	public String getdPIIProfiles() {
		return dPIIProfiles;
	}

	public void setdPIIProfiles(String dPIIProfiles) {
		this.dPIIProfiles = dPIIProfiles;
	}

	public String getCarelevelQuantity() {
		return carelevelQuantity;
	}

	public void setCarelevelQuantity(String carelevelQuantity) {
		this.carelevelQuantity = carelevelQuantity;
	}

	public String getMlAuxVoiceLine() {
		return mlAuxVoiceLine;
	}

	public void setMlAuxVoiceLine(String mlAuxVoiceLine) {
		this.mlAuxVoiceLine = mlAuxVoiceLine;
	}

	public String getQuantity_VoiceCarelevel() {
		return quantity_VoiceCarelevel;
	}

	public void setQuantity_VoiceCarelevel(String quantityVoiceCarelevel) {
		quantity_VoiceCarelevel = quantityVoiceCarelevel;
	}

	public String getQuantity_ContractTerm() {
		return quantity_ContractTerm;
	}

	public void setQuantity_ContractTerm(String quantityContractTerm) {
		quantity_ContractTerm = quantityContractTerm;
	}

	public String getQuantity_ISDN2eSystem() {
		return quantity_ISDN2eSystem;
	}

	public void setQuantity_ISDN2eSystem(String quantityISDN2eSystem) {
		quantity_ISDN2eSystem = quantityISDN2eSystem;
	}

	public String getReserveAppointmentButton() {
		return reserveAppointmentButton;
	}

	public void setReserveAppointmentButton(String reserveAppointmentButton) {
		this.reserveAppointmentButton = reserveAppointmentButton;
	}

	public String getAppointmentRequired() {
		return appointmentRequired;
	}

	public void setAppointmentRequired(String appointmentRequired) {
		this.appointmentRequired = appointmentRequired;
	}

	public String getCustomerRequiredDate() {
		return customerRequiredDate;
	}

	public void setCustomerRequiredDate(String customerRequiredDate) {
		this.customerRequiredDate = customerRequiredDate;
	}

	public String getBusinessAccount() {
		return businessAccount;
	}

	public void setBusinessAccount(String businessAccount) {
		this.businessAccount = businessAccount;
	}

	public String getNewSite() {
		return newSite;
	}

	public void setNewSite(String newSite) {
		this.newSite = newSite;
	}

	public String getLandlinePhone() {
		return landlinePhone;
	}

	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getAddressValue() {
		return addressValue;
	}

	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}

	public String getPremisesName() {
		return premisesName;
	}

	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProposition() {
		return proposition;
	}

	public void setProposition(String proposition) {
		this.proposition = proposition;
	}

	public String getRouter() {
		return router;
	}

	public void setRouter(String router) {
		this.router = router;
	}

	public String getBusinessRateCard() {
		return businessRateCard;
	}

	public void setBusinessRateCard(String businessRateCard) {
		this.businessRateCard = businessRateCard;
	}

	public String getCalls() {
		return calls;
	}

	public void setCalls(String calls) {
		this.calls = calls;
	}

	public String getCarelevel() {
		return carelevel;
	}

	public void setCarelevel(String carelevel) {
		this.carelevel = carelevel;
	}

	public String getSelectcalls() {
		return selectcalls;
	}

	public void setSelectcalls(String selectcalls) {
		this.selectcalls = selectcalls;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getOneOffCharge() {
		return oneOffCharge;
	}

	public void setOneOffCharge(String oneOffCharge) {
		this.oneOffCharge = oneOffCharge;
	}

	public String getRateCardDiscount() {
		return rateCardDiscount;
	}

	public void setRateCardDiscount(String rateCardDiscount) {
		this.rateCardDiscount = rateCardDiscount;
	}

	public String getSalesPromotion() {
		return salesPromotion;
	}

	public void setSalesPromotion(String salesPromotion) {
		this.salesPromotion = salesPromotion;
	}

	public String getCustomerDiscount() {
		return customerDiscount;
	}

	public void setCustomerDiscount(String customerDiscount) {
		this.customerDiscount = customerDiscount;
	}

	public String getIncludeOutofHours() {
		return includeOutofHours;
	}

	public void setIncludeOutofHours(String includeOutofHours) {
		this.includeOutofHours = includeOutofHours;
	}

	public String getAppointmentCharges() {
		return appointmentCharges;
	}

	public void setAppointmentCharges(String appointmentCharges) {
		this.appointmentCharges = appointmentCharges;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getEngineeringNotes() {
		return engineeringNotes;
	}

	public void setEngineeringNotes(String engineeringNotes) {
		this.engineeringNotes = engineeringNotes;
	}

	public String getHealthAndSafetyNotes() {
		return healthAndSafetyNotes;
	}

	public void setHealthAndSafetyNotes(String healthAndSafetyNotes) {
		this.healthAndSafetyNotes = healthAndSafetyNotes;
	}

	public String getCommunicationBy() {
		return communicationBy;
	}

	public void setCommunicationBy(String communicationBy) {
		this.communicationBy = communicationBy;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getBroadbandCare() {
		return broadbandCare;
	}

	public void setBroadbandCare(String broadbandCare) {
		this.broadbandCare = broadbandCare;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getDdiRangeNum() {
		return ddiRangeNum;
	}

	public void setDdiRangeNum(String ddiRangeNum) {
		this.ddiRangeNum = ddiRangeNum;
	}

	public String getSddirangeNum() {
		return sddirangeNum;
	}

	public void setSddirangeNum(String sddirangeNum) {
		this.sddirangeNum = sddirangeNum;
	}

	public String getManagedInstall() {
		return managedInstall;
	}

	public void setManagedInstall(String managedInstall) {
		this.managedInstall = managedInstall;
	}

	public String getPortNumber() {
		return portNumber;
	}

	public void setPortNumber(String portNumber) {
		this.portNumber = portNumber;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAdditionalTelephoneNumber() {
		return additionalTelephoneNumber;
	}

	public void setAdditionalTelephoneNumber(String additionalTelephoneNumber) {
		this.additionalTelephoneNumber = additionalTelephoneNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	/*** Cancel Transfer Out page **/
	private String reason;
	private String orderReference;

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getOrderReference() {
		return orderReference;
	}

	public void setOrderReference(String orderReference) {
		this.orderReference = orderReference;
	}



	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getAdditionalContacNum() {
		return additionalContacNum;
	}

	public void setAdditionalContacNum(String additionalContacNum) {
		this.additionalContacNum = additionalContacNum;
	}

	public String getNotificationBy() {
		return notificationBy;
	}

	public void setNotificationBy(String notificationBy) {
		this.notificationBy = notificationBy;
	}

	public String getMobileAccountNumber() {
		return mobileAccountNumber;
	}

	public void setMobileAccountNumber(String mobileAccountNumber) {
		this.mobileAccountNumber = mobileAccountNumber;
	}

	public void setPropositionWLTO(String propositionWLTO) {
		this.propositionWLTO = propositionWLTO;
	}

	public String getPropositionWLTO() {
		return propositionWLTO;
	}

	public void setPropositionSOSL(String propositionSOSL) {
		this.propositionSOSL = propositionSOSL;
	}

	public String getPropositionSOSL() {
		return propositionSOSL;
	}


	public void setContractTerm(String contractTerm) {
		this.contractTerm = contractTerm;
	}

    
	public String getSubtype() {
		return subtype;
	}

	public String getContractTerm() {
		return contractTerm;
	}



	
	
	private String  debtManagementOutgoingCallsBarred;
	
	public String getDebtManagementOutgoingCallsBarred() {
		return debtManagementOutgoingCallsBarred;
	}


	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}


	public String getContracttype() {
		return contracttype;
	}

	public void setContracttype(String contracttype) {
		this.contracttype = contracttype;
	}

	public String getMultilinenumber() {
		return multilinenumber;
	}

	public void setMultilinenumber(String multilinenumber) {
		this.multilinenumber = multilinenumber;
	}


	public void setDebtManagementOutgoingCallsBarred(
			String debtManagementOutgoingCallsBarred) {
		this.debtManagementOutgoingCallsBarred = debtManagementOutgoingCallsBarred;
	}
	
	private String quantity_DDIRangeNumbers;
	public String getQuantity_DDIRangeNumbers() {
		return quantity_DDIRangeNumbers;
	}



	public void setQuantity_DDIRangeNumbers(String quantity_DDIRangeNumbers) {
		this.quantity_DDIRangeNumbers = quantity_DDIRangeNumbers;
	}



	public String getQuantity_SNDDIRangeNumbers() {
		return quantity_SNDDIRangeNumbers;
	}



	public void setQuantity_SNDDIRangeNumbers(String quantity_SNDDIRangeNumbers) {
		this.quantity_SNDDIRangeNumbers = quantity_SNDDIRangeNumbers;
	}

	private String quantity_SNDDIRangeNumbers;
	
	public String getQuantity_ISDN() {
		return quantity_ISDN;
	}

	public void setQuantity_ISDN(String quantity_ISDN) {
		this.quantity_ISDN = quantity_ISDN;
	}
	

	private String userName;

private String companyRegistrationNumber;
	private String customerSegmentation;
	private String vatNumber;
	
	public String getVatNumber() {
		return vatNumber;
	}



	public String getUserName() {
		return userName;
	}

	public void setVatNumber(String vatNumber) {
		this.vatNumber = vatNumber;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	private String orderType;

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	
	
	private String customerName;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	



	public String getCompanyRegistrationNumber() {
		return companyRegistrationNumber;
	}

	public void setCompanyRegistrationNumber(String companyRegistrationNumber) {
		this.companyRegistrationNumber = companyRegistrationNumber;
	}

	public String getCustomerSegmentation() {
		return customerSegmentation;
	}

	public void setCustomerSegmentation(String customerSegmentation) {
		this.customerSegmentation = customerSegmentation;
	}
	
	private String companyName;
	
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	private String b2bSingletonMigration;

	public String getB2bSingletonMigration() {
		return b2bSingletonMigration;
	}

	public void setB2bSingletonMigration(String b2bSingletonMigration) {
		this.b2bSingletonMigration = b2bSingletonMigration;
	}

	
	private String amendReason;

	public String getAmendReason() {
		return amendReason;
	}

	public void setAmendReason(String amendReason) {
		this.amendReason = amendReason;
	}
	
	private String isdnNewChannelContract;

	public String getIsdnNewChannelContract() {
		return isdnNewChannelContract;
	}

	public void setIsdnNewChannelContract(String isdnNewChannelContract) {
		this.isdnNewChannelContract = isdnNewChannelContract;
	}

	private String isdnFeature;

	public String getIsdnFeature() {
		return isdnFeature;
	}

	public void setIsdnFeature(String isdnFeature) {
		this.isdnFeature = isdnFeature;
	}
	
	public String getIsdnFeaturePrice() {
		return isdnFeaturePrice;
	}

	public void setIsdnFeaturePrice(String isdnFeaturePrice) {
		this.isdnFeaturePrice = isdnFeaturePrice;
	}
	
	private String hazardNotes;
	

    public String getHazardNotes() {
		return hazardNotes;
	}

	public void setHazardNotes(String hazardNotes) {
		this.hazardNotes = hazardNotes;
	}

	
	
	private String cPEaddressValue;
	private String cPEpremisesName;
	private String cPEstreetName;
	private String cPEtown;
	private String cPEcountry;
	private String cPEpostCode;
	

	public String getCPEpostCode() {
		return cPEpostCode;
	}

	public void setCPEpostCode(String cPEpostCode) {
		this.cPEpostCode = cPEpostCode;
	}

	public String getCPEaddressValue() {
		return cPEaddressValue;
	}

	public void setCPEaddressValue(String cPEaddressValue) {
		this.cPEaddressValue = cPEaddressValue;
	}

	public String getCPEpremisesName() {
		return cPEpremisesName;
	}

	public void setCPEpremisesName(String cPEpremisesName) {
		this.cPEpremisesName = cPEpremisesName;
	}

	public String getCPEstreetName() {
		return cPEstreetName;
	}

	public void setCPEstreetName(String cPEstreetName) {
		this.cPEstreetName = cPEstreetName;
	}

	public String getCPEtown() {
		return cPEtown;
	}

	public void setCPEtown(String cPEtown) {
		this.cPEtown = cPEtown;
	}

	public String getCPEcountry() {
		return cPEcountry;
	}

	public void setCPEcountry(String cPEcountry) {
		this.cPEcountry = cPEcountry;
	}

	
	private String staggeredAppointment;

	public String getStaggeredAppointment() {
			return staggeredAppointment;
		}

		public void setStaggeredAppointment(String staggeredAppointment) {
			this.staggeredAppointment = staggeredAppointment;
		}
		private String ticketType;
		private String subType;
		private String contactType;





		public String getTicketType() {
			return ticketType;
		}

		public void setTicketType(String ticketType) {
			this.ticketType = ticketType;
		}

		public String getSubType() {
			return subType;
		}

		public void setSubType(String subType) {
			this.subType = subType;
		}

		public String getContactType() {
			return contactType;
		}

		public void setContactType(String contactType) {
			this.contactType = contactType;
		}
		
}
