package com.hqnRegression.beans;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

	public class B2BSelfCareBean {
     private String accountHolderName;
     private String sortCode;
     private String accountNumber;
     
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getSortCode() {
		return sortCode;
	}
	public void setSortCode(String sortCode) {
		this.sortCode = sortCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

}
