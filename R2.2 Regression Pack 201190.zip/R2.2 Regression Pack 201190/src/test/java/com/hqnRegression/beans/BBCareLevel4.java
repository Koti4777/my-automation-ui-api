package com.hqnRegression.beans;

public class BBCareLevel4 {

	private String searchBy;
	private String SearchValue;
	private String ticketSubtypeID;
	private String channelId;
	private String answer1;
	private String answer2;
	private String answer3;
	private String testType;	
	private String Num;
	private String EngNotes;
	private String HazardNotes;
	private String chargeBand;
	
	public String getChargeBand() {
		return chargeBand;
	}
	public void setChargeBand(String chargeBand) {
		this.chargeBand = chargeBand;
	}
	public String getSearchBy() {
		return searchBy;
	}
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
	public String getSearchValue() {
		return SearchValue;
	}
	public void setSearchValue(String searchValue) {
		SearchValue = searchValue;
	}
	public String getTicketSubtypeID() {
		return ticketSubtypeID;
	}
	public void setTicketSubtypeID(String ticketSubtypeID) {
		this.ticketSubtypeID = ticketSubtypeID;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getAnswer2() {
		return answer2;
	}
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	public String getAnswer3() {
		return answer3;
	}
	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}
	public String getTestType() {
		return testType;
	}
	public void setTestType(String testType) {
		this.testType = testType;
	}
	
	public String getNum() {
		return Num;
	}
	public void setNum(String num) {
		Num = num;
	}
	public String getEngNotes() {
		return EngNotes;
	}
	public void setEngNotes(String engNotes) {
		EngNotes = engNotes;
	}
	public String getHazardNotes() {
		return HazardNotes;
	}
	public void setHazardNotes(String hazardNotes) {
		HazardNotes = hazardNotes;
	}
	

	
	
	

	

}

