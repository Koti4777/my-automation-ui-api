package com.hqnRegression.beans;

public class BBandStatusHistoryDetails {
		private String orderId;
		private String activeStatus;
		private String suspendedStatus;
	    private String ceasedStatus;
	    private String customerType;
		
		public String getOrderId() {
			return orderId;
		}
		public void setOrderId(String orderId) {
			this.orderId = orderId;
		}
		public String getActiveStatus() {
			return activeStatus;
		}
		public void setActiveStatus(String activeStatus) {
			this.activeStatus = activeStatus;
		}
		public String getSuspendedStatus() {
			return suspendedStatus;
		}
		public void setSuspendedStatus(String suspendedStatus) {
			this.suspendedStatus = suspendedStatus;
		}
		public String getCeasedStatus() {
			return ceasedStatus;
		}
		public void setCeasedStatus(String ceasedStatus) {
			this.ceasedStatus = ceasedStatus;
		}
		public String getCustomerType() {
			return customerType;
		}
		public void setCustomerType(String customerType) {
			this.customerType = customerType;
		}
}
