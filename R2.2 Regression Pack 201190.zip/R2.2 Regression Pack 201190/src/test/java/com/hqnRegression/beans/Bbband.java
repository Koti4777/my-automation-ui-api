package com.hqnRegression.beans;

public class Bbband {
	private String searchBy;
	private String orderid;
	private String SearchValue;
	private String businessAccount;
	private String newSite;
	private String landlinePhone;
	private String postCode;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String proposition;
	
	
	
	
	public String getNewSite() {
		return newSite;
	}
	public void setNewSite(String newSite) {
		this.newSite = newSite;
	}
	public String getLandlinePhone() {
		return landlinePhone;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getAddressValue() {
		return addressValue;
	}
	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}
	public String getPremisesName() {
		return premisesName;
	}
	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getProposition() {
		return proposition;
	}
	public void setProposition(String proposition) {
		this.proposition = proposition;
	}
	public String getBusinessAccount() {
		return businessAccount;
	}
	public void setBusinessAccount(String businessAccount) {
		this.businessAccount = businessAccount;
	}
	public String getSearchBy() {
		return searchBy;
	}
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
	public String getSearchValue() {
		return SearchValue;
	}
	public void setSearchValue(String searchValue) {
		SearchValue = searchValue;
	}

}
