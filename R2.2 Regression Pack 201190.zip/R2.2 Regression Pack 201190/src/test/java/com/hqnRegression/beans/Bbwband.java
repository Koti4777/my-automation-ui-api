package com.hqnRegression.beans;

public class Bbwband {
	private String searchBy;
	private String SearchValue;
	public String getSearchBy() {
		return searchBy;
	}
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
	public String getSearchValue() {
		return SearchValue;
	}
	public void setSearchValue(String searchValue) {
		SearchValue = searchValue;
	}

}
