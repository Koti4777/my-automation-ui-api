package com.hqnRegression.beans;

public class BusinessAccount {

	private String name;
	private String customerSubtype;
	private String postCode;
	private String foreName;
	private String surName;
	private String phoneNum;
	private String mobileNum;
	private String lastName;
	private String firstname;
	private String passWord;
	private String securityKey;
	
	
	
	private String card;
	private String creditName;
	private String creditCardNumber;
	private String cMonth;
	private String cVYear;
	private String cEMonth;
	private String cEYear;
	private String creditCv;
	private String billType;
	
	//added for existing phone number creating customer site
	private String existingPhoneNum;
	
	private String convergedAccountNo;
	private String vatRegNo;
	
	private String addressValue;
	private String macCode;

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getForeName() {
		return foreName;
	}
	public void setForeName(String foreName) {
		this.foreName = foreName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getSecurityKey() {
		return securityKey;
	}
	public void setSecurityKey(String securityKey) {
		this.securityKey = securityKey;
	}
	public String getCard() {
		return card;
	}
	public void setCard(String card) {
		this.card = card;
	}
	public String getCreditName() {
		return creditName;
	}
	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}
	public String getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public String getCMonth() {
		return cMonth;
	}
	public void setCMonth(String cMonth) {
		this.cMonth = cMonth;
	}
	public String getCVYear() {
		return cVYear;
	}
	public void setCVYear(String cVYear) {
		this.cVYear = cVYear;
	}
	public String getCEMonth() {
		return cEMonth;
	}
	public void setCEMonth(String cEMonth) {
		this.cEMonth = cEMonth;
	}
	public String getCEYear() {
		return cEYear;
	}
	public void setCEYear(String cEYear) {
		this.cEYear = cEYear;
	}
	public String getCreditCv() {
		return creditCv;
	}
	public void setCreditCv(String creditCv) {
		this.creditCv = creditCv;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public String getCustomerSubtype() {
		return customerSubtype;
	}
	public void setCustomerSubtype(String customerSubtype) {
		this.customerSubtype = customerSubtype;
	}
	public String getExistingPhoneNum() {
		return existingPhoneNum;
	}
	public void setExistingPhoneNum(String existingPhoneNum) {
		this.existingPhoneNum = existingPhoneNum;
	}
	public String getcMonth() {
		return cMonth;
	}
	public void setcMonth(String cMonth) {
		this.cMonth = cMonth;
	}
	public String getcVYear() {
		return cVYear;
	}
	public void setcVYear(String cVYear) {
		this.cVYear = cVYear;
	}
	public String getcEMonth() {
		return cEMonth;
	}
	public void setcEMonth(String cEMonth) {
		this.cEMonth = cEMonth;
	}
	public String getcEYear() {
		return cEYear;
	}
	public void setcEYear(String cEYear) {
		this.cEYear = cEYear;
	}
	public String getConvergedAccountNo() {
		return convergedAccountNo;
	}
	public void setConvergedAccountNo(String convergedAccountNo) {
		this.convergedAccountNo = convergedAccountNo;
	}
	public String getVatRegNo() {
		return vatRegNo;
	}
	public void setVatRegNo(String vatRegNo) {
		this.vatRegNo = vatRegNo;
	}
	public String getAddressValue() {
		return addressValue;
	}
	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}
	public String getMacCode() {
		return macCode;
	}
	public void setMacCode(String macCode) {
		this.macCode = macCode;
	}

}
