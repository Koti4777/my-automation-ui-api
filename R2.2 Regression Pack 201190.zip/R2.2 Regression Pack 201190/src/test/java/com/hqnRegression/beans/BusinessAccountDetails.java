package com.hqnRegression.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BusinessAccountDetails {
	
	private String companyName;
	private String companyRegistrationNo;
	private String segmentation;
	private String mobileAccNo;
	private String vatNo;
	private String title;
	private String firstName;
	private String surName;
	private String phoneNo;
	private String mobileNo;
	private String additionalContactNo;
	private String emailAddress;
	private String postCode;
	private String premisesName;
	private String streetName;
	private String town;
	private String county;
	private String notification;
	
	
	private String emailFirstName;
	private	String emailLastName;
	private String passWord;
	private	String confirmPassword;
	private String securityKey;
	private String securityConfirmPassword;
	
	//Bacs billtype
	private String billRequiredDate;
	private String billType;
	
	//added for different details
	private String paymentMethod;
	private String accountHolderName;
	private String sortCode;
	private String accountNumber;
	private String creditCardType;
	
	
	

	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyRegistrationNo() {
		return companyRegistrationNo;
	}
	public void setCompanyRegistrationNo(String companyRegistrationNo) {
		this.companyRegistrationNo = companyRegistrationNo;
	}
	public String getSegmentation() {
		return segmentation;
	}
	public void setSegmentation(String segmentation) {
		this.segmentation = segmentation;
	}
	public String getMobileAccNo() {
		return mobileAccNo;
	}
	public void setMobileAccNo(String mobileAccNo) {
		this.mobileAccNo = mobileAccNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAdditionalContactNo() {
		return additionalContactNo;
	}
	public void setAdditionalContactNo(String additionalContactNo) {
		this.additionalContactNo = additionalContactNo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getPremisesName() {
		return premisesName;
	}
	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getNotification() {
		return notification;
	}
	public void setNotification(String notification) {
		this.notification = notification;
	}
	public String getEmailFirstName() {
		return emailFirstName;
	}
	public void setEmailFirstName(String emailFirstName) {
		this.emailFirstName = emailFirstName;
	}
	public String getEmailLastName() {
		return emailLastName;
	}
	public void setEmailLastName(String emailLastName) {
		this.emailLastName = emailLastName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getSecurityKey() {
		return securityKey;
	}
	public void setSecurityKey(String securityKey) {
		this.securityKey = securityKey;
	}
	public String getSecurityConfirmPassword() {
		return securityConfirmPassword;
	}
	public void setSecurityConfirmPassword(String securityConfirmPassword) {
		this.securityConfirmPassword = securityConfirmPassword;
	}
	public String getBillRequiredDate() {
		return billRequiredDate;
	}
	public void setBillRequiredDate(String billRequiredDate) {
		this.billRequiredDate = billRequiredDate;
	}
	public String getBillType() {
		return billType;
	}
	public void setBillType(String billType) {
		this.billType = billType;
	}
	public String getVatNo() {
		return vatNo;
	}
	public void setVatNo(String vatNo) {
		this.vatNo = vatNo;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getSortCode() {
		return sortCode;
	}
	public void setSortCode(String sortCode) {
		this.sortCode = sortCode;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCreditCardType() {
		return creditCardType;
	}
	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	
	
		
	
	
	
	

}

