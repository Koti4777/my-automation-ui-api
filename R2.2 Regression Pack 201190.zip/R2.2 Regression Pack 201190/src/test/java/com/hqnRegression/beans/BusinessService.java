package com.hqnRegression.beans;

public class BusinessService {

	private String directoryNumber;
	private String postcode;
	private String premisesNumber;
	private String streetName;
	private String town;
	private String proposition;
	private String County;
	
	public String getCounty() {
		return County;
	}
	public void setCounty(String county) {
		County = county;
	}
	public String getDirectoryNumber() {
		return directoryNumber;
	}
	public void setDirectoryNumber(String directoryNumber) {
		this.directoryNumber = directoryNumber;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getPremisesNumber() {
		return premisesNumber;
	}
	public void setPremisesNumber(String premisesNumber) {
		this.premisesNumber = premisesNumber;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getProposition() {
		return proposition;
	}
	public void setProposition(String proposition) {
		this.proposition = proposition;
	}
	
	
}