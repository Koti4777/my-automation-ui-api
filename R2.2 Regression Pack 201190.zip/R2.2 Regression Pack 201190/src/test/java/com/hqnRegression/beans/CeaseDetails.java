package com.hqnRegression.beans;

public class CeaseDetails {
	
	private String orderId;
	private String ceaseReason;
	private String offset;
    private String companyName;
private String serviceID;
	
	
	public String getServiceID() {
		return serviceID;
	}
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCeaseReason() {
		return ceaseReason;
	}
	public void setCeaseReason(String ceaseReason) {
		this.ceaseReason = ceaseReason;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}

}
