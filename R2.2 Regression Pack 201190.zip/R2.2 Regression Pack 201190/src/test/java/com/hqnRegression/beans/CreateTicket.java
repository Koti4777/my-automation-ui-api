package com.hqnRegression.beans;

public class CreateTicket {
	private String orderid;
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	private String tickettype;
	private String ticketsubtype;
	private String pool;
	private String contacttype;
	private String notes;
	public String getTickettype() {
		return tickettype;
	}
	public void setTickettype(String tickettype) {
		this.tickettype = tickettype;
	}
	public String getTicketsubtype() {
		return ticketsubtype;
	}
	public void setTicketsubtype(String ticketsubtype) {
		this.ticketsubtype = ticketsubtype;
	}
	public String getPool() {
		return pool;
	}
	public void setPool(String pool) {
		this.pool = pool;
	}
	public String getContacttype() {
		return contacttype;
	}
	public void setContacttype(String contacttype) {
		this.contacttype = contacttype;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}


}
