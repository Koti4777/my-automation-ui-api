package com.hqnRegression.beans;

public class CreditCardDetails {
	
	private String cardType;
	private String name;
	private String cardNumber;
	private String validFromMonth;
	private String validFromYear;
	private String expiryDateMonth;
	private String expiryDateYear;
	private String issueNumber;
	private String cv2;
	// added for credit card
	private String cardName;
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getValidFromMonth() {
		return validFromMonth;
	}
	public void setValidFromMonth(String validFromMonth) {
		this.validFromMonth = validFromMonth;
	}
	public String getValidFromYear() {
		return validFromYear;
	}
	public void setValidFromYear(String validFromYear) {
		this.validFromYear = validFromYear;
	}
	public String getExpiryDateMonth() {
		return expiryDateMonth;
	}
	public void setExpiryDateMonth(String expiryDateMonth) {
		this.expiryDateMonth = expiryDateMonth;
	}
	public String getExpiryDateYear() {
		return expiryDateYear;
	}
	public void setExpiryDateYear(String expiryDateYear) {
		this.expiryDateYear = expiryDateYear;
	}
	public String getIssueNumber() {
		return issueNumber;
	}
	public void setIssueNumber(String issueNumber) {
		this.issueNumber = issueNumber;
	}
	public String getCv2() {
		return cv2;
	}
	public void setCv2(String cv2) {
		this.cv2 = cv2;
	}
	
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

}
