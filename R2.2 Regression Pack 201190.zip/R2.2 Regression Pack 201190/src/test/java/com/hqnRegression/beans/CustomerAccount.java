package com.hqnRegression.beans;

public class CustomerAccount {
	
	

}
