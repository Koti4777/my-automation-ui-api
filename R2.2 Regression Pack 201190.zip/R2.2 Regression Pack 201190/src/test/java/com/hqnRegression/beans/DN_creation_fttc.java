package com.hqnRegression.beans;

public class DN_creation_fttc {


		public String postCode;
		public String addressValue;
		public String linkedSMPFReference;
		public String cssDistrictCode;
		public String exchangeCode;
		public String submiitingCP;
		public String customerName;
		public String dN;
		public String appointmentReference;
		public String noOfPstnOrders;
		public String setPstnMatchedOrderFlag;
		public String noOfLluOrders;
		public String setLluMatchedOrderFlag;
		public String directoryNumber;
		public String exchange;
		public String carePackage;
		public String linkedOrderRef;
		public String geaServiceId;
		public String product;
		public String network;
		
		
		
		

		
		public String eventType;
		public String event;
		public String addressKey;
		public String productType;
		public String carelevel;
		public String lineType;
		public String cNF;

		public String getNoOfPstnOrders() {
			return noOfPstnOrders;
		}
		public void setNoOfPstnOrders(String noOfPstnOrders) {
			this.noOfPstnOrders = noOfPstnOrders;
		}
		public String getSetPstnMatchedOrderFlag() {
			return setPstnMatchedOrderFlag;
		}
		public void setSetPstnMatchedOrderFlag(String setPstnMatchedOrderFlag) {
			this.setPstnMatchedOrderFlag = setPstnMatchedOrderFlag;
		}
		public String getNoOfLluOrders() {
			return noOfLluOrders;
		}
		public void setNoOfLluOrders(String noOfLluOrders) {
			this.noOfLluOrders = noOfLluOrders;
		}
		public String getSetLluMatchedOrderFlag() {
			return setLluMatchedOrderFlag;
		}
		public void setSetLluMatchedOrderFlag(String setLluMatchedOrderFlag) {
			this.setLluMatchedOrderFlag = setLluMatchedOrderFlag;
		}
		public String phoneNumber;
		public String date;

		public String getEventType() {
			return eventType;
		}
		public void setEventType(String eventType) {
			this.eventType = eventType;
		}

		public String getEvent() {
			return event;
		}

		public void setEvent(String event) {
			this.event = event;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}

		
		public String getAddressKey() {
			return addressKey;
		}
		public void setAddressKey(String addressKey) {
			this.addressKey = addressKey;
		}
		public String getProductType() {
			return productType;
		}
		public void setProductType(String productType) {
			this.productType = productType;
		}
		public String getCarelevel() {
			return carelevel;
		}
		public void setCarelevel(String carelevel) {
			this.carelevel = carelevel;
		}
		public String getLineType() {
			return lineType;
		}
		public void setLineType(String lineType) {
			this.lineType = lineType;
		}
		public String getCNF() {
			return cNF;
		}
		public void setCNF(String cNF) {
			this.cNF = cNF;
		}

		public String getSubmiitingCP() {
			return submiitingCP;
		}

		public void setSubmiitingCP(String submiitingCP) {
			this.submiitingCP = submiitingCP;
		}

		public String getPostCode() {
			return postCode;
		}

		public void setPostCode(String postCode) {
			this.postCode = postCode;
		}

		public String getAddressValue() {
			return addressValue;
		}

		public void setAddressValue(String addressValue) {
			this.addressValue = addressValue;
		}

		public String getLinkedSMPFReference() {
			return linkedSMPFReference;
		}

		public void setLinkedSMPFReference(String linkedSMPFReference) {
			this.linkedSMPFReference = linkedSMPFReference;
		}

		public String getCssDistrictCode() {
			return cssDistrictCode;
		}

		public void setCssDistrictCode(String cssDistrictCode) {
			this.cssDistrictCode = cssDistrictCode;
		}

		public String getExchangeCode() {
			return exchangeCode;
		}

		public void setExchangeCode(String exchangeCode) {
			this.exchangeCode = exchangeCode;
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public String getdN() {
			return dN;
		}
		public void setdN(String dN) {
			this.dN = dN;
		}
		public String getAppointmentReference() {
			return appointmentReference;
		}
		public void setAppointmentReference(String appointmentReference) {
			this.appointmentReference = appointmentReference;
		}
		public String getDirectoryNumber() {
			return directoryNumber;
		}
		public void setDirectoryNumber(String directoryNumber) {
			this.directoryNumber = directoryNumber;
		}
		public String getExchange() {
			return exchange;
		}
		public void setExchange(String exchange) {
			this.exchange = exchange;
		}
		public String getCarePackage() {
			return carePackage;
		}
		public void setCarePackage(String carePackage) {
			this.carePackage = carePackage;
		}
		public String getLinkedOrderRef() {
			return linkedOrderRef;
		}
		public void setLinkedOrderRef(String linkedOrderRef) {
			this.linkedOrderRef = linkedOrderRef;
		}
		public String getGeaServiceId() {
			return geaServiceId;
		}
		public void setGeaServiceId(String geaServiceId) {
			this.geaServiceId = geaServiceId;
		}
		public String getProduct() {
			return product;
		}
		public void setProduct(String product) {
			this.product = product;
		}
		public String getMdfSiteId() {
			return mdfSiteId;
		}
		public void setMdfSiteId(String mdfSiteId) {
			this.mdfSiteId = mdfSiteId;
		}
		public String mdfSiteId;
		public String getNetwork() {
			return network;
		}
		public void setNetwork(String network) {
			this.network = network;
		}
		
	}



