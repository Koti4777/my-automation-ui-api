package com.hqnRegression.beans;

public class EditOrderException_JeopardyTriggerTimesBean 
{
	private String provideIPstreamAcceptance;
	private String provideWBCAcceptance;
	private String provideRADIUSCompleted;
	private String provideCPECompleted;
	
	private String migrationIPstreamAcceptance;
	//private String MigrationIPstreamCompleted;
	private String migrationWBCAcceptance;
	//private String MigrationWBCCompleted;
	private String migrationRADIUSCompleted;
	private String migrationCPECompleted;
	
	private String migrationOLOIPstreamAcceptance;
	private String migrationOLOWBCAcceptance;
	private String migrationOLORADIUSCompleted;
	private String migrationOLOCPECompleted;
	
	private String transferWLR3a0logueAcceptance;
	//private String TransferWLR3a0logueCompleted;
	private String transferWCLIAcceptance;
	//private String TransferWCLICompleted;
	
	private String startWLR3a0logueAcceptance;
	//private String StartWLR3a0logueCompleted;
	private String startWCLIAcceptance;
	//private String StartWCLICompleted;
	
	private String takeoverWLR3a0logueAcceptance;
	//private String takeoverWLR3a0logueCompleted;
	private String takeoverWCLIAcceptance;
	//private String takeoverWCLICompleted;
	
	private String newlineWLR3a0logueAcceptance;
	//private String NewlineWLR3a0logueCompleted;
	private String newlineWCLIAcceptance;
	//private String NewlineWCLICompleted;
	
	private String mPFconversionWLR3a0logueAcceptance;
	//private String MPFconversionWLR3a0logueCompleted;
	private String mPFconversionWCLIAcceptance;
	//private String MPFconversionWCLICompleted;
	
	private String provideWLR3a0logueAcceptance1;
	//private String provideWLR3a0logueCompleted;
	private String provideWCLIAcceptance1;
	//private String provideWCLICompleted;
	
	private String provideIPstreamAcceptance1;
	private String provideWBCAcceptance1;
	private String provideRADIUSCompleted1;
	private String provideCPECompleted1;
	
	private String bTWWLR3a0logueAcceptance;
	private String bTWWCLIAcceptance; 
	
	private String bTWIPstreamAcceptance;
	private String bTWWBCAcceptance;
	private String bTWRADIUSCompleted;
	private String bTWCPECompleted;
	
	private String oLOCPWLR3a0logueAcceptance;
	private String oLOCPWCLIAcceptance;
	
	private String oLOCPIPstreamAcceptance;
	private String oLOCPWBCAcceptance;
	private String oLOCPRADIUSCompleted;
	private String oLOCPCPECompleted;
	
	private String startsimWLR3a0logueAcceptance;
	private String startsimWCLIAcceptance;
	
	private String startsimIPstreamAcceptance;
	private String startsimWBCAcceptance;
	private String startsimRADIUSCompleted;
	private String startsimCPECompleted;
	
	private String wLTsimWLR3a0logueAcceptance;
	private String wLTsimWCLIAcceptance;
	
	private String wLTsimIPstreamAcceptance;
	private String wLTsimWBCAcceptance;
	private String wLTsimRADIUSCompleted;
	private String wLTsimCPECompleted;
	
	private String newlinesimWLR3a0logueAcceptance;
	private String newlinesimWCLIAcceptance;
	
	private String newlinesimIPstreamAcceptance;
	private String newlinesimWBCAcceptance;
	private String newlinesimRADIUSCompleted;
	private String newlinesimCPECompleted;
	
	private String mPFsimWLR3a0logueAcceptance;
	private String mPFsimWCLIAcceptance;
	
	private String mPFsimIPstreamAcceptance;
	private String mPFsimWBCAcceptance;
	private String mPFsimRADIUSCompleted;
	private String mPFsimCPECompleted;
	
	private String lineTransferWLR3a0logueAcceptance;
	private String lineTransferWCLIAcceptance;
	
	private String lineTransferIPstreamAcceptance;
	private String lineTransferWBCOrderAcceptance;
	private String lineTransferRADIUSOrderCompleted;
	private String lineTransferCPEOrderCompleted;
	
	private String bTWBBIPstreamAcceptance;
	private String bTWBBWBCOrderAcceptance;
	private String bTWBBRADIUSOrderCompleted;
	private String bTWBBCPEOrderCompleted;
	
	private String oLOCPSMPFIPstreamAcceptance;
	private String oLOCPSMPFWBCOrderAcceptance;
	private String oLOCPSMPFRADIUSOrderCompleted;
	private String oLOCPSMPFCPEOrderCompleted;
	
	private String solusbroadbandProvideCPECompleted;
	private String lineBroadbandProvideCPECompleted;
	
	public String getProvideIPstreamAcceptance() {
		return provideIPstreamAcceptance;
	}
	public void setProvideIPstreamAcceptance(String provideIPstreamAcceptance) {
		this.provideIPstreamAcceptance = provideIPstreamAcceptance;
	}
	public String getProvideWBCAcceptance() {
		return provideWBCAcceptance;
	}
	public void setProvideWBCAcceptance(String provideWBCAcceptance) {
		this.provideWBCAcceptance = provideWBCAcceptance;
	}
	public String getProvideRADIUSCompleted() {
		return provideRADIUSCompleted;
	}
	public void setProvideRADIUSCompleted(String provideRADIUSCompleted) {
		this.provideRADIUSCompleted = provideRADIUSCompleted;
	}
	public String getProvideCPECompleted() {
		return provideCPECompleted;
	}
	public void setProvideCPECompleted(String provideCPECompleted) {
		this.provideCPECompleted = provideCPECompleted;
	}
	public String getMigrationIPstreamAcceptance() {
		return migrationIPstreamAcceptance;
	}
	public void setMigrationIPstreamAcceptance(String migrationIPstreamAcceptance) {
		this.migrationIPstreamAcceptance = migrationIPstreamAcceptance;
	}
	public String getMigrationWBCAcceptance() {
		return migrationWBCAcceptance;
	}
	public void setMigrationWBCAcceptance(String migrationWBCAcceptance) {
		this.migrationWBCAcceptance = migrationWBCAcceptance;
	}
	public String getMigrationRADIUSCompleted() {
		return migrationRADIUSCompleted;
	}
	public void setMigrationRADIUSCompleted(String migrationRADIUSCompleted) {
		this.migrationRADIUSCompleted = migrationRADIUSCompleted;
	}
	public String getMigrationCPECompleted() {
		return migrationCPECompleted;
	}
	public void setMigrationCPECompleted(String migrationCPECompleted) {
		this.migrationCPECompleted = migrationCPECompleted;
	}
	public String getMigrationOLOIPstreamAcceptance() {
		return migrationOLOIPstreamAcceptance;
	}
	public void setMigrationOLOIPstreamAcceptance(
			String migrationOLOIPstreamAcceptance) {
		this.migrationOLOIPstreamAcceptance = migrationOLOIPstreamAcceptance;
	}
	public String getMigrationOLOWBCAcceptance() {
		return migrationOLOWBCAcceptance;
	}
	public void setMigrationOLOWBCAcceptance(String migrationOLOWBCAcceptance) {
		this.migrationOLOWBCAcceptance = migrationOLOWBCAcceptance;
	}
	public String getMigrationOLORADIUSCompleted() {
		return migrationOLORADIUSCompleted;
	}
	public void setMigrationOLORADIUSCompleted(String migrationOLORADIUSCompleted) {
		this.migrationOLORADIUSCompleted = migrationOLORADIUSCompleted;
	}
	public String getMigrationOLOCPECompleted() {
		return migrationOLOCPECompleted;
	}
	public void setMigrationOLOCPECompleted(String migrationOLOCPECompleted) {
		this.migrationOLOCPECompleted = migrationOLOCPECompleted;
	}
	public String getTransferWLR3a0logueAcceptance() {
		return transferWLR3a0logueAcceptance;
	}
	public void setTransferWLR3a0logueAcceptance(
			String transferWLR3a0logueAcceptance) {
		this.transferWLR3a0logueAcceptance = transferWLR3a0logueAcceptance;
	}
	public String getTransferWCLIAcceptance() {
		return transferWCLIAcceptance;
	}
	public void setTransferWCLIAcceptance(String transferWCLIAcceptance) {
		this.transferWCLIAcceptance = transferWCLIAcceptance;
	}
	public String getStartWLR3a0logueAcceptance() {
		return startWLR3a0logueAcceptance;
	}
	public void setStartWLR3a0logueAcceptance(String startWLR3a0logueAcceptance) {
		this.startWLR3a0logueAcceptance = startWLR3a0logueAcceptance;
	}
	public String getStartWCLIAcceptance() {
		return startWCLIAcceptance;
	}
	public void setStartWCLIAcceptance(String startWCLIAcceptance) {
		this.startWCLIAcceptance = startWCLIAcceptance;
	}
	public String getTakeoverWLR3a0logueAcceptance() {
		return takeoverWLR3a0logueAcceptance;
	}
	public void setTakeoverWLR3a0logueAcceptance(
			String takeoverWLR3a0logueAcceptance) {
		this.takeoverWLR3a0logueAcceptance = takeoverWLR3a0logueAcceptance;
	}
	public String getTakeoverWCLIAcceptance() {
		return takeoverWCLIAcceptance;
	}
	public void setTakeoverWCLIAcceptance(String takeoverWCLIAcceptance) {
		this.takeoverWCLIAcceptance = takeoverWCLIAcceptance;
	}
	public String getNewlineWLR3a0logueAcceptance() {
		return newlineWLR3a0logueAcceptance;
	}
	public void setNewlineWLR3a0logueAcceptance(String newlineWLR3a0logueAcceptance) {
		this.newlineWLR3a0logueAcceptance = newlineWLR3a0logueAcceptance;
	}
	public String getNewlineWCLIAcceptance() {
		return newlineWCLIAcceptance;
	}
	public void setNewlineWCLIAcceptance(String newlineWCLIAcceptance) {
		this.newlineWCLIAcceptance = newlineWCLIAcceptance;
	}
	public String getMPFconversionWLR3a0logueAcceptance() {
		return mPFconversionWLR3a0logueAcceptance;
	}
	public void setMPFconversionWLR3a0logueAcceptance(
			String mPFconversionWLR3a0logueAcceptance) {
		this.mPFconversionWLR3a0logueAcceptance = mPFconversionWLR3a0logueAcceptance;
	}
	public String getMPFconversionWCLIAcceptance() {
		return mPFconversionWCLIAcceptance;
	}
	public void setMPFconversionWCLIAcceptance(String mPFconversionWCLIAcceptance) {
		this.mPFconversionWCLIAcceptance = mPFconversionWCLIAcceptance;
	}
	public String getProvideWLR3a0logueAcceptance1() {
		return provideWLR3a0logueAcceptance1;
	}
	public void setProvideWLR3a0logueAcceptance1(
			String provideWLR3a0logueAcceptance1) {
		this.provideWLR3a0logueAcceptance1 = provideWLR3a0logueAcceptance1;
	}
	public String getProvideWCLIAcceptance1() {
		return provideWCLIAcceptance1;
	}
	public void setProvideWCLIAcceptance1(String provideWCLIAcceptance1) {
		this.provideWCLIAcceptance1 = provideWCLIAcceptance1;
	}
	public String getProvideIPstreamAcceptance1() {
		return provideIPstreamAcceptance1;
	}
	public void setProvideIPstreamAcceptance1(String provideIPstreamAcceptance1) {
		this.provideIPstreamAcceptance1 = provideIPstreamAcceptance1;
	}
	public String getProvideWBCAcceptance1() {
		return provideWBCAcceptance1;
	}
	public void setProvideWBCAcceptance1(String provideWBCAcceptance1) {
		this.provideWBCAcceptance1 = provideWBCAcceptance1;
	}
	public String getProvideRADIUSCompleted1() {
		return provideRADIUSCompleted1;
	}
	public void setProvideRADIUSCompleted1(String provideRADIUSCompleted1) {
		this.provideRADIUSCompleted1 = provideRADIUSCompleted1;
	}
	public String getProvideCPECompleted1() {
		return provideCPECompleted1;
	}
	public void setProvideCPECompleted1(String provideCPECompleted1) {
		this.provideCPECompleted1 = provideCPECompleted1;
	}
	public String getBTWWLR3a0logueAcceptance() {
		return bTWWLR3a0logueAcceptance;
	}
	public void setBTWWLR3a0logueAcceptance(String bTWWLR3a0logueAcceptance) {
		this.bTWWLR3a0logueAcceptance = bTWWLR3a0logueAcceptance;
	}
	public String getBTWWCLIAcceptance() {
		return bTWWCLIAcceptance;
	}
	public void setBTWWCLIAcceptance(String bTWWCLIAcceptance) {
		this.bTWWCLIAcceptance = bTWWCLIAcceptance;
	}
	public String getBTWIPstreamAcceptance() {
		return bTWIPstreamAcceptance;
	}
	public void setBTWIPstreamAcceptance(String bTWIPstreamAcceptance) {
		this.bTWIPstreamAcceptance = bTWIPstreamAcceptance;
	}
	public String getBTWWBCAcceptance() {
		return bTWWBCAcceptance;
	}
	public void setBTWWBCAcceptance(String bTWWBCAcceptance) {
		this.bTWWBCAcceptance = bTWWBCAcceptance;
	}
	public String getBTWRADIUSCompleted() {
		return bTWRADIUSCompleted;
	}
	public void setBTWRADIUSCompleted(String bTWRADIUSCompleted) {
		this.bTWRADIUSCompleted = bTWRADIUSCompleted;
	}
	public String getBTWCPECompleted() {
		return bTWCPECompleted;
	}
	public void setBTWCPECompleted(String bTWCPECompleted) {
		this.bTWCPECompleted = bTWCPECompleted;
	}
	public String getOLOCPWLR3a0logueAcceptance() {
		return oLOCPWLR3a0logueAcceptance;
	}
	public void setOLOCPWLR3a0logueAcceptance(String oLOCPWLR3a0logueAcceptance) {
		this.oLOCPWLR3a0logueAcceptance = oLOCPWLR3a0logueAcceptance;
	}
	public String getOLOCPWCLIAcceptance() {
		return oLOCPWCLIAcceptance;
	}
	public void setOLOCPWCLIAcceptance(String oLOCPWCLIAcceptance) {
		this.oLOCPWCLIAcceptance = oLOCPWCLIAcceptance;
	}
	public String getOLOCPIPstreamAcceptance() {
		return oLOCPIPstreamAcceptance;
	}
	public void setOLOCPIPstreamAcceptance(String oLOCPIPstreamAcceptance) {
		this.oLOCPIPstreamAcceptance = oLOCPIPstreamAcceptance;
	}
	public String getOLOCPWBCAcceptance() {
		return oLOCPWBCAcceptance;
	}
	public void setOLOCPWBCAcceptance(String oLOCPWBCAcceptance) {
		this.oLOCPWBCAcceptance = oLOCPWBCAcceptance;
	}
	public String getOLOCPRADIUSCompleted() {
		return oLOCPRADIUSCompleted;
	}
	public void setOLOCPRADIUSCompleted(String oLOCPRADIUSCompleted) {
		this.oLOCPRADIUSCompleted = oLOCPRADIUSCompleted;
	}
	public String getOLOCPCPECompleted() {
		return oLOCPCPECompleted;
	}
	public void setOLOCPCPECompleted(String oLOCPCPECompleted) {
		this.oLOCPCPECompleted = oLOCPCPECompleted;
	}
	public String getStartsimWLR3a0logueAcceptance() {
		return startsimWLR3a0logueAcceptance;
	}
	public void setStartsimWLR3a0logueAcceptance(
			String startsimWLR3a0logueAcceptance) {
		this.startsimWLR3a0logueAcceptance = startsimWLR3a0logueAcceptance;
	}
	public String getStartsimWCLIAcceptance() {
		return startsimWCLIAcceptance;
	}
	public void setStartsimWCLIAcceptance(String startsimWCLIAcceptance) {
		this.startsimWCLIAcceptance = startsimWCLIAcceptance;
	}
	public String getStartsimIPstreamAcceptance() {
		return startsimIPstreamAcceptance;
	}
	public void setStartsimIPstreamAcceptance(String startsimIPstreamAcceptance) {
		this.startsimIPstreamAcceptance = startsimIPstreamAcceptance;
	}
	public String getStartsimWBCAcceptance() {
		return startsimWBCAcceptance;
	}
	public void setStartsimWBCAcceptance(String startsimWBCAcceptance) {
		this.startsimWBCAcceptance = startsimWBCAcceptance;
	}
	public String getStartsimRADIUSCompleted() {
		return startsimRADIUSCompleted;
	}
	public void setStartsimRADIUSCompleted(String startsimRADIUSCompleted) {
		this.startsimRADIUSCompleted = startsimRADIUSCompleted;
	}
	public String getStartsimCPECompleted() {
		return startsimCPECompleted;
	}
	public void setStartsimCPECompleted(String startsimCPECompleted) {
		this.startsimCPECompleted = startsimCPECompleted;
	}
	public String getWLTsimWLR3a0logueAcceptance() {
		return wLTsimWLR3a0logueAcceptance;
	}
	public void setWLTsimWLR3a0logueAcceptance(String wLTsimWLR3a0logueAcceptance) {
		this.wLTsimWLR3a0logueAcceptance = wLTsimWLR3a0logueAcceptance;
	}
	public String getWLTsimWCLIAcceptance() {
		return wLTsimWCLIAcceptance;
	}
	public void setWLTsimWCLIAcceptance(String wLTsimWCLIAcceptance) {
		this.wLTsimWCLIAcceptance = wLTsimWCLIAcceptance;
	}
	public String getWLTsimIPstreamAcceptance() {
		return wLTsimIPstreamAcceptance;
	}
	public void setWLTsimIPstreamAcceptance(String wLTsimIPstreamAcceptance) {
		this.wLTsimIPstreamAcceptance = wLTsimIPstreamAcceptance;
	}
	public String getWLTsimWBCAcceptance() {
		return wLTsimWBCAcceptance;
	}
	public void setWLTsimWBCAcceptance(String wLTsimWBCAcceptance) {
		this.wLTsimWBCAcceptance = wLTsimWBCAcceptance;
	}
	public String getWLTsimRADIUSCompleted() {
		return wLTsimRADIUSCompleted;
	}
	public void setWLTsimRADIUSCompleted(String wLTsimRADIUSCompleted) {
		this.wLTsimRADIUSCompleted = wLTsimRADIUSCompleted;
	}
	public String getWLTsimCPECompleted() {
		return wLTsimCPECompleted;
	}
	public void setWLTsimCPECompleted(String wLTsimCPECompleted) {
		this.wLTsimCPECompleted = wLTsimCPECompleted;
	}
	public String getNewlinesimWLR3a0logueAcceptance() {
		return newlinesimWLR3a0logueAcceptance;
	}
	public void setNewlinesimWLR3a0logueAcceptance(
			String newlinesimWLR3a0logueAcceptance) {
		this.newlinesimWLR3a0logueAcceptance = newlinesimWLR3a0logueAcceptance;
	}
	public String getNewlinesimWCLIAcceptance() {
		return newlinesimWCLIAcceptance;
	}
	public void setNewlinesimWCLIAcceptance(String newlinesimWCLIAcceptance) {
		this.newlinesimWCLIAcceptance = newlinesimWCLIAcceptance;
	}
	public String getNewlinesimIPstreamAcceptance() {
		return newlinesimIPstreamAcceptance;
	}
	public void setNewlinesimIPstreamAcceptance(String newlinesimIPstreamAcceptance) {
		this.newlinesimIPstreamAcceptance = newlinesimIPstreamAcceptance;
	}
	public String getNewlinesimWBCAcceptance() {
		return newlinesimWBCAcceptance;
	}
	public void setNewlinesimWBCAcceptance(String newlinesimWBCAcceptance) {
		this.newlinesimWBCAcceptance = newlinesimWBCAcceptance;
	}
	public String getNewlinesimRADIUSCompleted() {
		return newlinesimRADIUSCompleted;
	}
	public void setNewlinesimRADIUSCompleted(String newlinesimRADIUSCompleted) {
		this.newlinesimRADIUSCompleted = newlinesimRADIUSCompleted;
	}
	public String getNewlinesimCPECompleted() {
		return newlinesimCPECompleted;
	}
	public void setNewlinesimCPECompleted(String newlinesimCPECompleted) {
		this.newlinesimCPECompleted = newlinesimCPECompleted;
	}
	public String getMPFsimWLR3a0logueAcceptance() {
		return mPFsimWLR3a0logueAcceptance;
	}
	public void setMPFsimWLR3a0logueAcceptance(String mPFsimWLR3a0logueAcceptance) {
		this.mPFsimWLR3a0logueAcceptance = mPFsimWLR3a0logueAcceptance;
	}
	public String getMPFsimWCLIAcceptance() {
		return mPFsimWCLIAcceptance;
	}
	public void setMPFsimWCLIAcceptance(String mPFsimWCLIAcceptance) {
		this.mPFsimWCLIAcceptance = mPFsimWCLIAcceptance;
	}
	public String getMPFsimIPstreamAcceptance() {
		return mPFsimIPstreamAcceptance;
	}
	public void setMPFsimIPstreamAcceptance(String mPFsimIPstreamAcceptance) {
		this.mPFsimIPstreamAcceptance = mPFsimIPstreamAcceptance;
	}
	public String getMPFsimWBCAcceptance() {
		return mPFsimWBCAcceptance;
	}
	public void setMPFsimWBCAcceptance(String mPFsimWBCAcceptance) {
		this.mPFsimWBCAcceptance = mPFsimWBCAcceptance;
	}
	public String getMPFsimRADIUSCompleted() {
		return mPFsimRADIUSCompleted;
	}
	public void setMPFsimRADIUSCompleted(String mPFsimRADIUSCompleted) {
		this.mPFsimRADIUSCompleted = mPFsimRADIUSCompleted;
	}
	public String getMPFsimCPECompleted() {
		return mPFsimCPECompleted;
	}
	public void setMPFsimCPECompleted(String mPFsimCPECompleted) {
		this.mPFsimCPECompleted = mPFsimCPECompleted;
	}
	public String getLineTransferWLR3a0logueAcceptance() {
		return lineTransferWLR3a0logueAcceptance;
	}
	public void setLineTransferWLR3a0logueAcceptance(
			String lineTransferWLR3a0logueAcceptance) {
		this.lineTransferWLR3a0logueAcceptance = lineTransferWLR3a0logueAcceptance;
	}
	public String getLineTransferWCLIAcceptance() {
		return lineTransferWCLIAcceptance;
	}
	public void setLineTransferWCLIAcceptance(String lineTransferWCLIAcceptance) {
		this.lineTransferWCLIAcceptance = lineTransferWCLIAcceptance;
	}
	public String getLineTransferIPstreamAcceptance() {
		return lineTransferIPstreamAcceptance;
	}
	public void setLineTransferIPstreamAcceptance(
			String lineTransferIPstreamAcceptance) {
		this.lineTransferIPstreamAcceptance = lineTransferIPstreamAcceptance;
	}
	public String getLineTransferWBCOrderAcceptance() {
		return lineTransferWBCOrderAcceptance;
	}
	public void setLineTransferWBCOrderAcceptance(
			String lineTransferWBCOrderAcceptance) {
		this.lineTransferWBCOrderAcceptance = lineTransferWBCOrderAcceptance;
	}
	public String getLineTransferRADIUSOrderCompleted() {
		return lineTransferRADIUSOrderCompleted;
	}
	public void setLineTransferRADIUSOrderCompleted(
			String lineTransferRADIUSOrderCompleted) {
		this.lineTransferRADIUSOrderCompleted = lineTransferRADIUSOrderCompleted;
	}
	public String getLineTransferCPEOrderCompleted() {
		return lineTransferCPEOrderCompleted;
	}
	public void setLineTransferCPEOrderCompleted(
			String lineTransferCPEOrderCompleted) {
		this.lineTransferCPEOrderCompleted = lineTransferCPEOrderCompleted;
	}
	public String getBTWBBIPstreamAcceptance() {
		return bTWBBIPstreamAcceptance;
	}
	public void setBTWBBIPstreamAcceptance(String bTWBBIPstreamAcceptance) {
		this.bTWBBIPstreamAcceptance = bTWBBIPstreamAcceptance;
	}
	public String getBTWBBWBCOrderAcceptance() {
		return bTWBBWBCOrderAcceptance;
	}
	public void setBTWBBWBCOrderAcceptance(String bTWBBWBCOrderAcceptance) {
		this.bTWBBWBCOrderAcceptance = bTWBBWBCOrderAcceptance;
	}
	public String getBTWBBRADIUSOrderCompleted() {
		return bTWBBRADIUSOrderCompleted;
	}
	public void setBTWBBRADIUSOrderCompleted(String bTWBBRADIUSOrderCompleted) {
		this.bTWBBRADIUSOrderCompleted = bTWBBRADIUSOrderCompleted;
	}
	public String getBTWBBCPEOrderCompleted() {
		return bTWBBCPEOrderCompleted;
	}
	public void setBTWBBCPEOrderCompleted(String bTWBBCPEOrderCompleted) {
		this.bTWBBCPEOrderCompleted = bTWBBCPEOrderCompleted;
	}
	public String getOLOCPSMPFIPstreamAcceptance() {
		return oLOCPSMPFIPstreamAcceptance;
	}
	public void setOLOCPSMPFIPstreamAcceptance(String oLOCPSMPFIPstreamAcceptance) {
		this.oLOCPSMPFIPstreamAcceptance = oLOCPSMPFIPstreamAcceptance;
	}
	public String getOLOCPSMPFWBCOrderAcceptance() {
		return oLOCPSMPFWBCOrderAcceptance;
	}
	public void setOLOCPSMPFWBCOrderAcceptance(String oLOCPSMPFWBCOrderAcceptance) {
		this.oLOCPSMPFWBCOrderAcceptance = oLOCPSMPFWBCOrderAcceptance;
	}
	public String getOLOCPSMPFRADIUSOrderCompleted() {
		return oLOCPSMPFRADIUSOrderCompleted;
	}
	public void setOLOCPSMPFRADIUSOrderCompleted(
			String oLOCPSMPFRADIUSOrderCompleted) {
		this.oLOCPSMPFRADIUSOrderCompleted = oLOCPSMPFRADIUSOrderCompleted;
	}
	public String getOLOCPSMPFCPEOrderCompleted() {
		return oLOCPSMPFCPEOrderCompleted;
	}
	public void setOLOCPSMPFCPEOrderCompleted(String oLOCPSMPFCPEOrderCompleted) {
		this.oLOCPSMPFCPEOrderCompleted = oLOCPSMPFCPEOrderCompleted;
	}
	public String getSolusbroadbandProvideCPECompleted() {
		return solusbroadbandProvideCPECompleted;
	}
	public void setSolusbroadbandProvideCPECompleted(
			String solusbroadbandProvideCPECompleted) {
		this.solusbroadbandProvideCPECompleted = solusbroadbandProvideCPECompleted;
	}
	public String getLineBroadbandProvideCPECompleted() {
		return lineBroadbandProvideCPECompleted;
	}
	public void setLineBroadbandProvideCPECompleted(
			String lineBroadbandProvideCPECompleted) {
		this.lineBroadbandProvideCPECompleted = lineBroadbandProvideCPECompleted;
	}
		
	
}
