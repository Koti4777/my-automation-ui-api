package com.hqnRegression.beans;

public class EditOrderTicketBean {
	private String transferLineTicketing1 ;	
	private String transferLineTicketing2;	
	private String newLine1;		
	private String newLine2; 		
	private String bB1; 		
	private String bB2;		
	private String bBOnly1; 		
	private String bBOnly2; 	 	
	private String cPENotOrdered1; 		
	private String cPENotOrdered2; 		
	private String cPENotDispatched1; 		
	private String cPENotDispatched2; 		
	private String calls1; 	
	private String calls2;
	
	
	public String getTransferLineTicketing1() {
		return transferLineTicketing1;
	}
	public void setTransferLineTicketing1(String transferLineTicketing1) {
		this.transferLineTicketing1 = transferLineTicketing1;
	}
	public String getTransferLineTicketing2() {
		return transferLineTicketing2;
	}
	public void setTransferLineTicketing2(String transferLineTicketing2) {
		this.transferLineTicketing2 = transferLineTicketing2;
	}
	public String getNewLine1() {
		return newLine1;
	}
	public void setNewLine1(String newLine1) {
		this.newLine1 = newLine1;
	}
	public String getNewLine2() {
		return newLine2;
	}
	public void setNewLine2(String newLine2) {
		this.newLine2 = newLine2;
	}
	public String getBB1() {
		return bB1;
	}
	public void setBB1(String bB1) {
		this.bB1 = bB1;
	}
	public String getBB2() {
		return bB2;
	}
	public void setBB2(String bB2) {
		this.bB2 = bB2;
	}
	public String getBBOnly1() {
		return bBOnly1;
	}
	public void setBBOnly1(String bBOnly1) {
		this.bBOnly1 = bBOnly1;
	}
	public String getBBOnly2() {
		return bBOnly2;
	}
	public void setBBOnly2(String bBOnly2) {
		this.bBOnly2 = bBOnly2;
	}
	public String getCPENotOrdered1() {
		return cPENotOrdered1;
	}
	public void setCPENotOrdered1(String cPENotOrdered1) {
		this.cPENotOrdered1 = cPENotOrdered1;
	}
	public String getCPENotOrdered2() {
		return cPENotOrdered2;
	}
	public void setCPENotOrdered2(String cPENotOrdered2) {
		this.cPENotOrdered2 = cPENotOrdered2;
	}
	public String getCPENotDispatched1() {
		return cPENotDispatched1;
	}
	public void setCPENotDispatched1(String cPENotDispatched1) {
		this.cPENotDispatched1 = cPENotDispatched1;
	}
	public String getCPENotDispatched2() {
		return cPENotDispatched2;
	}
	public void setCPENotDispatched2(String cPENotDispatched2) {
		this.cPENotDispatched2 = cPENotDispatched2;
	}
	public String getCalls1() {
		return calls1;
	}
	public void setCalls1(String calls1) {
		this.calls1 = calls1;
	}
	
	public String getCalls2() {
		return calls2;
	}
	public void setCalls2(String calls2) {
		this.calls2 = calls2;
	}
	


}
