package com.hqnRegression.beans;

public class EditTicketActivityGateTimes 
{
	private String bBReception;
	private String bBDiagnose;
	private String bBFix;
	private String bBClear;
	private String bBSLA;
	
	private String emailTouchRespond;
	private String emailClear;
	private String emailSLA;
	
	private String enhancedBBReception;
	private String enhancedBBDiagnose;
	private String enhancedBBFix;
	private String enhancedBBClear;
	private String enhancedBBSLA;
	
	private String enhancedLineReception;
	private String enhancedLineDiagnose;
	private String enhancedLineFix;
	private String enhancedLineClear;
	private String enhancedLineSLA;
	
	private String nonAppointedBBReception;
	private String nonAppointedBBDiagnose;
	private String nonAppointedBBFix;
	private String nonAppointedBBClear;
	private String nonAppointedBBSLA;
	
	private String nonAppointedLineReception;
	private String nonAppointedLineDiagnose;
	private String nonAppointedLineFix;
	private String nonAppointedLineClear;
	private String nonAppointedLineSLA;
	
	private String whiteEmailTouchRespond;
	private String whiteEmailClear;
	private String whiteEmailSLA;
	
	public String getBBReception() {
		return bBReception;
	}
	public void setBBReception(String bBReception) {
		this.bBReception = bBReception;
	}
	public String getBBDiagnose() {
		return bBDiagnose;
	}
	public void setBBDiagnose(String bBDiagnose) {
		this.bBDiagnose = bBDiagnose;
	}
	public String getBBFix() {
		return bBFix;
	}
	public void setBBFix(String bBFix) {
		this.bBFix = bBFix;
	}
	public String getBBClear() {
		return bBClear;
	}
	public void setBBClear(String bBClear) {
		this.bBClear = bBClear;
	}
	public String getBBSLA() {
		return bBSLA;
	}
	public void setBBSLA(String bBSLA) {
		this.bBSLA = bBSLA;
	}
	public String getEmailTouchRespond() {
		return emailTouchRespond;
	}
	public void setEmailTouchRespond(String emailTouchRespond) {
		this.emailTouchRespond = emailTouchRespond;
	}
	public String getEmailClear() {
		return emailClear;
	}
	public void setEmailClear(String emailClear) {
		this.emailClear = emailClear;
	}
	public String getEmailSLA() {
		return emailSLA;
	}
	public void setEmailSLA(String emailSLA) {
		this.emailSLA = emailSLA;
	}
	public String getEnhancedBBReception() {
		return enhancedBBReception;
	}
	public void setEnhancedBBReception(String enhancedBBReception) {
		this.enhancedBBReception = enhancedBBReception;
	}
	public String getEnhancedBBDiagnose() {
		return enhancedBBDiagnose;
	}
	public void setEnhancedBBDiagnose(String enhancedBBDiagnose) {
		this.enhancedBBDiagnose = enhancedBBDiagnose;
	}
	public String getEnhancedBBFix() {
		return enhancedBBFix;
	}
	public void setEnhancedBBFix(String enhancedBBFix) {
		this.enhancedBBFix = enhancedBBFix;
	}
	public String getEnhancedBBClear() {
		return enhancedBBClear;
	}
	public void setEnhancedBBClear(String enhancedBBClear) {
		this.enhancedBBClear = enhancedBBClear;
	}
	public String getEnhancedBBSLA() {
		return enhancedBBSLA;
	}
	public void setEnhancedBBSLA(String enhancedBBSLA) {
		this.enhancedBBSLA = enhancedBBSLA;
	}
	public String getEnhancedLineReception() {
		return enhancedLineReception;
	}
	public void setEnhancedLineReception(String enhancedLineReception) {
		this.enhancedLineReception = enhancedLineReception;
	}
	public String getEnhancedLineDiagnose() {
		return enhancedLineDiagnose;
	}
	public void setEnhancedLineDiagnose(String enhancedLineDiagnose) {
		this.enhancedLineDiagnose = enhancedLineDiagnose;
	}
	public String getEnhancedLineFix() {
		return enhancedLineFix;
	}
	public void setEnhancedLineFix(String enhancedLineFix) {
		this.enhancedLineFix = enhancedLineFix;
	}
	public String getEnhancedLineClear() {
		return enhancedLineClear;
	}
	public void setEnhancedLineClear(String enhancedLineClear) {
		this.enhancedLineClear = enhancedLineClear;
	}
	public String getEnhancedLineSLA() {
		return enhancedLineSLA;
	}
	public void setEnhancedLineSLA(String enhancedLineSLA) {
		this.enhancedLineSLA = enhancedLineSLA;
	}
	public String getNonAppointedBBReception() {
		return nonAppointedBBReception;
	}
	public void setNonAppointedBBReception(String nonAppointedBBReception) {
		this.nonAppointedBBReception = nonAppointedBBReception;
	}
	public String getNonAppointedBBDiagnose() {
		return nonAppointedBBDiagnose;
	}
	public void setNonAppointedBBDiagnose(String nonAppointedBBDiagnose) {
		this.nonAppointedBBDiagnose = nonAppointedBBDiagnose;
	}
	public String getNonAppointedBBFix() {
		return nonAppointedBBFix;
	}
	public void setNonAppointedBBFix(String nonAppointedBBFix) {
		this.nonAppointedBBFix = nonAppointedBBFix;
	}
	public String getNonAppointedBBClear() {
		return nonAppointedBBClear;
	}
	public void setNonAppointedBBClear(String nonAppointedBBClear) {
		this.nonAppointedBBClear = nonAppointedBBClear;
	}
	public String getNonAppointedBBSLA() {
		return nonAppointedBBSLA;
	}
	public void setNonAppointedBBSLA(String nonAppointedBBSLA) {
		this.nonAppointedBBSLA = nonAppointedBBSLA;
	}
	public String getNonAppointedLineReception() {
		return nonAppointedLineReception;
	}
	public void setNonAppointedLineReception(String nonAppointedLineReception) {
		this.nonAppointedLineReception = nonAppointedLineReception;
	}
	public String getNonAppointedLineDiagnose() {
		return nonAppointedLineDiagnose;
	}
	public void setNonAppointedLineDiagnose(String nonAppointedLineDiagnose) {
		this.nonAppointedLineDiagnose = nonAppointedLineDiagnose;
	}
	public String getNonAppointedLineFix() {
		return nonAppointedLineFix;
	}
	public void setNonAppointedLineFix(String nonAppointedLineFix) {
		this.nonAppointedLineFix = nonAppointedLineFix;
	}
	public String getNonAppointedLineClear() {
		return nonAppointedLineClear;
	}
	public void setNonAppointedLineClear(String nonAppointedLineClear) {
		this.nonAppointedLineClear = nonAppointedLineClear;
	}
	public String getNonAppointedLineSLA() {
		return nonAppointedLineSLA;
	}
	public void setNonAppointedLineSLA(String nonAppointedLineSLA) {
		this.nonAppointedLineSLA = nonAppointedLineSLA;
	}
	public String getWhiteEmailTouchRespond() {
		return whiteEmailTouchRespond;
	}
	public void setWhiteEmailTouchRespond(String whiteEmailTouchRespond) {
		this.whiteEmailTouchRespond = whiteEmailTouchRespond;
	}
	public String getWhiteEmailClear() {
		return whiteEmailClear;
	}
	public void setWhiteEmailClear(String whiteEmailClear) {
		this.whiteEmailClear = whiteEmailClear;
	}
	public String getWhiteEmailSLA() {
		return whiteEmailSLA;
	}
	public void setWhiteEmailSLA(String whiteEmailSLA) {
		this.whiteEmailSLA = whiteEmailSLA;
	}
	
	
	
}
