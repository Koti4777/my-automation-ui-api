/**
 * 
 */
package com.hqnRegression.beans;

/**
 * @author mchandrasekhar
 *
 */
public class FetchOrderDBDetails {
	
	
	private String orderId;
	private String fullFillmentOrderId;
	private String statusId21CN;
	private String statusId20CN;
	private String batchId;
	private String wlr3Foid;
	private String wlr3FOStatusId;
	private String wlr3BatchId;
	private String wcliFoid;
	private String wcliFOStatusId;
	private String wcliBatchId;
	private String cpeFoid;
	private String cpeFOStatusId;
	private String cpeBatchId;
	private String tmFoid;
	private String tmFOStatusId;
	private String tmBatchId;
	private String radiusFoid;
	private String radiusFOStatusId;
	private String radiusBatchId;
	private String landlinePhone;
	private String buyersId;
	private String currentStatus;
	private String productName;
	private String nadKey;
	private String appointReference;
	private String appointmentDate;
	private String appointmentTimeSlot;
	
	public String getNadKey() {
		return nadKey;
	}
	public void setNadKey(String nadKey) {
		this.nadKey = nadKey;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getAppointReference() {
		return appointReference;
	}
	public void setAppointReference(String appointReference) {
		this.appointReference = appointReference;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getAppointmentTimeSlot() {
		return appointmentTimeSlot;
	}
	public void setAppointmentTimeSlot(String appointmentTimeSlot) {
		this.appointmentTimeSlot = appointmentTimeSlot;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getFullFillmentOrderId() {
		return fullFillmentOrderId;
	}
	public void setFullFillmentOrderId(String fullFillmentOrderId) {
		this.fullFillmentOrderId = fullFillmentOrderId;
	}
	public String getStatusId21CN() {
		return statusId21CN;
	}
	public void setStatusId21CN(String statusId21CN) {
		this.statusId21CN = statusId21CN;
	}
	public String getStatusId20CN() {
		return statusId20CN;
	}
	public void setStatusId20CN(String statusId20CN) {
		this.statusId20CN = statusId20CN;
	}
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public String getWlr3Foid() {
		return wlr3Foid;
	}
	public void setWlr3Foid(String wlr3Foid) {
		this.wlr3Foid = wlr3Foid;
	}
	public String getWlr3FOStatusId() {
		return wlr3FOStatusId;
	}
	public void setWlr3FOStatusId(String wlr3foStatusId) {
		wlr3FOStatusId = wlr3foStatusId;
	}
	public String getWlr3BatchId() {
		return wlr3BatchId;
	}
	public void setWlr3BatchId(String wlr3BatchId) {
		this.wlr3BatchId = wlr3BatchId;
	}
	public String getWcliFoid() {
		return wcliFoid;
	}
	public void setWcliFoid(String wcliFoid) {
		this.wcliFoid = wcliFoid;
	}
	public String getWcliFOStatusId() {
		return wcliFOStatusId;
	}
	public void setWcliFOStatusId(String wcliFOStatusId) {
		this.wcliFOStatusId = wcliFOStatusId;
	}
	public String getWcliBatchId() {
		return wcliBatchId;
	}
	public void setWcliBatchId(String wcliBatchId) {
		this.wcliBatchId = wcliBatchId;
	}
	public String getCpeFoid() {
		return cpeFoid;
	}
	public void setCpeFoid(String cpeFoid) {
		this.cpeFoid = cpeFoid;
	}
	public String getCpeFOStatusId() {
		return cpeFOStatusId;
	}
	public void setCpeFOStatusId(String cpeFOStatusId) {
		this.cpeFOStatusId = cpeFOStatusId;
	}
	public String getCpeBatchId() {
		return cpeBatchId;
	}
	public void setCpeBatchId(String cpeBatchId) {
		this.cpeBatchId = cpeBatchId;
	}
	public String getTmFoid() {
		return tmFoid;
	}
	public void setTmFoid(String tmFoid) {
		this.tmFoid = tmFoid;
	}
	public String getTmFOStatusId() {
		return tmFOStatusId;
	}
	public void setTmFOStatusId(String tmFOStatusId) {
		this.tmFOStatusId = tmFOStatusId;
	}
	public String getTmBatchId() {
		return tmBatchId;
	}
	public void setTmBatchId(String tmBatchId) {
		this.tmBatchId = tmBatchId;
	}
	public String getRadiusFoid() {
		return radiusFoid;
	}
	public void setRadiusFoid(String radiusFoid) {
		this.radiusFoid = radiusFoid;
	}
	public String getRadiusFOStatusId() {
		return radiusFOStatusId;
	}
	public void setRadiusFOStatusId(String radiusFOStatusId) {
		this.radiusFOStatusId = radiusFOStatusId;
	}
	public String getRadiusBatchId() {
		return radiusBatchId;
	}
	public void setRadiusBatchId(String radiusBatchId) {
		this.radiusBatchId = radiusBatchId;
	}
	public String getLandlinePhone() {
		return landlinePhone;
	}
	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}
	public String getBuyersId() {
		return buyersId;
	}
	public void setBuyersId(String buyersId) {
		this.buyersId = buyersId;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}
	
	
		
}
