package com.hqnRegression.beans;

public class HomeMoveDetails {
	
	private String businessAccount;
	private String newSite;
	private String postCode;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String keepExistingNumber;
	private String moveOnDiffDate;
	private String applyCeaseCharges;
	private String managedInstall;
	private String includeOutofHours;
	private String appointmentCharges;
	private String engineeringNotes;
	private String healthAndSafetyNotes;
	private String orderId;
	private String communicationBy;
	private String lorn;
	private String companyName;
	private String landlinePhone;
	
	
	private String praposition;
	private String title;
	private String surName;
	private String firstName;
	private String businessRateCard;
	private String upsellPSTN;
	private String customerType;
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getLorn() {
		return lorn;
	}
	public void setLorn(String lorn) {
		this.lorn = lorn;
	}
	public String getBusinessAccount() {
		return businessAccount;
	}
	public void setBusinessAccount(String businessAccount) {
		this.businessAccount = businessAccount;
	}
	public String getNewSite() {
		return newSite;
	}
	public void setNewSite(String newSite) {
		this.newSite = newSite;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getAddressValue() {
		return addressValue;
	}
	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}
	public String getPremisesName() {
		return premisesName;
	}
	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getKeepExistingNumber() {
		return keepExistingNumber;
	}
	public void setKeepExistingNumber(String keepExistingNumber) {
		this.keepExistingNumber = keepExistingNumber;
	}
	public String getMoveOnDiffDate() {
		return moveOnDiffDate;
	}
	public void setMoveOnDiffDate(String moveOnDiffDate) {
		this.moveOnDiffDate = moveOnDiffDate;
	}
	public String getApplyCeaseCharges() {
		return applyCeaseCharges;
	}
	public void setApplyCeaseCharges(String applyCeaseCharges) {
		this.applyCeaseCharges = applyCeaseCharges;
	}
	public String getManagedInstall() {
		return managedInstall;
	}
	public void setManagedInstall(String managedInstall) {
		this.managedInstall = managedInstall;
	}
	public String getIncludeOutofHours() {
		return includeOutofHours;
	}
	public void setIncludeOutofHours(String includeOutofHours) {
		this.includeOutofHours = includeOutofHours;
	}
	public String getAppointmentCharges() {
		return appointmentCharges;
	}
	public void setAppointmentCharges(String appointmentCharges) {
		this.appointmentCharges = appointmentCharges;
	}
	public String getEngineeringNotes() {
		return engineeringNotes;
	}
	public void setEngineeringNotes(String engineeringNotes) {
		this.engineeringNotes = engineeringNotes;
	}
	public String getHealthAndSafetyNotes() {
		return healthAndSafetyNotes;
	}
	public void setHealthAndSafetyNotes(String healthAndSafetyNotes) {
		this.healthAndSafetyNotes = healthAndSafetyNotes;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCommunicationBy() {
		return communicationBy;
	}
	public void setCommunicationBy(String communicationBy) {
		this.communicationBy = communicationBy;
	}
	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}
	public String getLandlinePhone() {
		return landlinePhone;
	}
	
	
	
	public String getPraposition() {
		return praposition;
	}
	public void setPraposition(String praposition) {
		this.praposition = praposition;
	}
	

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getBusinessRateCard() {
		return businessRateCard;
	}
	public void setBusinessRateCard(String businessRateCard) {
		this.businessRateCard = businessRateCard;
	}
	public String getUpsellPSTN() {
		return upsellPSTN;
	}
	public void setUpsellPSTN(String upsellPSTN) {
		this.upsellPSTN = upsellPSTN;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	

}
