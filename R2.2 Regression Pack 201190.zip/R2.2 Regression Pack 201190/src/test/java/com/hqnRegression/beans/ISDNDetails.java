package com.hqnRegression.beans;

public class ISDNDetails {

	private String businessAccount;
	private String newSite;
	private String landlinePhone;
	private String postCode;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String proposition;
	private String title;
	private String firstName;
	private String surName;
	private String serviceID;
	private String ddiRangenum;
	private String snddiRangeNum;
	private String communicationBy;
	
	//newly added
	private String orderId;
	private String contract;
	private String keepExistingNumber;
	
	

	public String getBusinessAccount() {
		return businessAccount;
	}

	public void setBusinessAccount(String businessAccount) {
		this.businessAccount = businessAccount;
	}

	public String getNewSite() {
		return newSite;
	}

	public void setNewSite(String newSite) {
		this.newSite = newSite;
	}

	public String getLandlinePhone() {
		return landlinePhone;
	}

	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPremisesName() {
		return premisesName;
	}

	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProposition() {
		return proposition;
	}

	public void setProposition(String proposition) {
		this.proposition = proposition;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}


	public String getCommunicationBy() {
		return communicationBy;
	}

	public void setCommunicationBy(String communicationBy) {
		this.communicationBy = communicationBy;
	}

	public String getAddressValue() {
		return addressValue;
	}

	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getServiceID() {
		return serviceID;
	}

	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}

	public String getDdiRangenum() {
		return ddiRangenum;
	}

	public void setDdiRangenum(String ddiRangenum) {
		this.ddiRangenum = ddiRangenum;
	}

	public String getSnddiRangeNum() {
		return snddiRangeNum;
	}

	public void setSnddiRangeNum(String snddiRangeNum) {
		this.snddiRangeNum = snddiRangeNum;
	}

	public void setKeepExistingNumber(String keepExistingNumber) {
		this.keepExistingNumber = keepExistingNumber;
	}

	public String getKeepExistingNumber() {
		return keepExistingNumber;
	}

}
