package com.hqnRegression.beans;

public class ISDN_NewDetails {
	
	private String businessAccount;
	private String newSite;
	private String landlinePhone;
	private String postCode;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String proposition;
	
	private String businessRateCard;
	private String carelevel;
	private String isdnDassFeatures;
	private String customerControlledDiversion;
	private String isdnMonthlyRentalCharge;
	private String isdnOneOffCharge;
	
	private String contract;
	private String genericOneOffCharge;
	private String rateCardDiscount;
	private String title;
	private String firstName;
	private String surName;
	private String serviceID;
	private String ddiRangenum;
	private String snddiRangeNum;
	private String communicationBy;
	
	
	public String getBusinessAccount() {
		return businessAccount;
	}
	public void setBusinessAccount(String businessAccount) {
		this.businessAccount = businessAccount;
	}
	public String getNewSite() {
		return newSite;
	}
	public void setNewSite(String newSite) {
		this.newSite = newSite;
	}
	public String getLandlinePhone() {
		return landlinePhone;
	}
	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getAddressValue() {
		return addressValue;
	}
	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}
	public String getPremisesName() {
		return premisesName;
	}
	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getProposition() {
		return proposition;
	}
	public void setProposition(String proposition) {
		this.proposition = proposition;
	}
	public String getBusinessRateCard() {
		return businessRateCard;
	}
	public void setBusinessRateCard(String businessRateCard) {
		this.businessRateCard = businessRateCard;
	}
	public String getCarelevel() {
		return carelevel;
	}
	public void setCarelevel(String carelevel) {
		this.carelevel = carelevel;
	}
	public String getIsdnDassFeatures() {
		return isdnDassFeatures;
	}
	public void setIsdnDassFeatures(String isdnDassFeatures) {
		this.isdnDassFeatures = isdnDassFeatures;
	}
	public String getCustomerControlledDiversion() {
		return customerControlledDiversion;
	}
	public void setCustomerControlledDiversion(String customerControlledDiversion) {
		this.customerControlledDiversion = customerControlledDiversion;
	}
	public String getIsdnMonthlyRentalCharge() {
		return isdnMonthlyRentalCharge;
	}
	public void setIsdnMonthlyRentalCharge(String isdnMonthlyRentalCharge) {
		this.isdnMonthlyRentalCharge = isdnMonthlyRentalCharge;
	}
	public String getIsdnOneOffCharge() {
		return isdnOneOffCharge;
	}
	public void setIsdnOneOffCharge(String isdnOneOffCharge) {
		this.isdnOneOffCharge = isdnOneOffCharge;
	}
	public String getContract() {
		return contract;
	}
	public void setContract(String contract) {
		this.contract = contract;
	}
	public String getGenericOneOffCharge() {
		return genericOneOffCharge;
	}
	public void setGenericOneOffCharge(String genericOneOffCharge) {
		this.genericOneOffCharge = genericOneOffCharge;
	}
	public String getRateCardDiscount() {
		return rateCardDiscount;
	}
	public void setRateCardDiscount(String rateCardDiscount) {
		this.rateCardDiscount = rateCardDiscount;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getServiceID() {
		return serviceID;
	}
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}
	public String getDdiRangenum() {
		return ddiRangenum;
	}
	public void setDdiRangenum(String ddiRangenum) {
		this.ddiRangenum = ddiRangenum;
	}
	public String getSnddiRangeNum() {
		return snddiRangeNum;
	}
	public void setSnddiRangeNum(String snddiRangeNum) {
		this.snddiRangeNum = snddiRangeNum;
	}
	public String getCommunicationBy() {
		return communicationBy;
	}
	public void setCommunicationBy(String communicationBy) {
		this.communicationBy = communicationBy;
	}


}
