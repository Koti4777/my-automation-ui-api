package com.hqnRegression.beans;

public class LIUbeans {
	private String businessAccount;
	private String newSite;
	private String landlinePhone;
	private String postCode;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String proposition;
	private String router;
	private String businessRateCard;
	private String lineisolationunitrentalprice;
	private String broadbandlineisolationunitconnectionprice;
	private String broadbandlineisolationunitrentalprice;
	private String calls;
	private String lineisolationunitconnectionprice;
	private String ISDNlineisolationunitrentalprice;
	private String ISDNlineisolationunitconnectionprice;
    private String quantity;
    private String quantity_ISDN;
    private String AdminControlledSelectiveCallNationalInternational;

	private String selectcalls;
	private String contract;
	private String oneOffCharge;
	private String rateCardDiscount;
	private String salesPromotion;
	private String customerDiscount;
	private String includeOutofHours;
	private String appointmentCharges;
	private String title;
	private String firstName;
	private String surName;
	private String engineeringNotes;
	private String healthAndSafetyNotes;
	private String communicationBy;
	private String orderId;
	private String broadbandCare;
	private String serviceId;
	private String ddiRangeNum;
	private String keepExistingNumber;
	private String ceaseReason;
	private String customerId;

	private String mobileAccountNumber;
	private String propositionWLTO;
	private String propositionSOSL;
	private String carelevel;

	private String mobileNum;
	private String phoneNum;
	private String additionalContacNum;
	private String notificationBy;
	private String SddirangeNum;
	private String installationtype1;
	private String managedInstall;
	
	public String getManagedInstall() {
		return managedInstall;
	}

	public void setManagedInstall(String managedInstall) {
		this.managedInstall = managedInstall;
	}

	public String getInstallationtype1() {
		return installationtype1;
	}

	public void setInstallationtype1(String installationtype1) {
		this.installationtype1 = installationtype1;
	}

	public String getSddirangeNum() {
		return SddirangeNum;
	}

	public void setSddirangeNum(String sddirangeNum) {
		SddirangeNum = sddirangeNum;
	}

	private String rentalCharge;
	
	private String ISDN30OneCharges;

	public String getBusinessAccount() {
		return businessAccount;
	}

	
	public String getLineisolationunitconnectionprice() {
		return lineisolationunitconnectionprice;
	}

	public void setLineisolationunitconnectionprice(
			String lineisolationunitconnectionprice) {
		this.lineisolationunitconnectionprice = lineisolationunitconnectionprice;
	}

	public String getBroadbandlineisolationunitconnectionprice() {
		return broadbandlineisolationunitconnectionprice;
	}

	public void setBroadbandlineisolationunitconnectionprice(
			String broadbandlineisolationunitconnectionprice) {
		this.broadbandlineisolationunitconnectionprice = broadbandlineisolationunitconnectionprice;
	}
	public String getISDNlineisolationunitrentalprice() {
		return ISDNlineisolationunitrentalprice;
	}

	public void setISDNlineisolationunitrentalprice(
			String iSDNlineisolationunitrentalprice) {
		ISDNlineisolationunitrentalprice = iSDNlineisolationunitrentalprice;
	}

	public String getISDNlineisolationunitconnectionprice() {
		return ISDNlineisolationunitconnectionprice;
	}

	public void setISDNlineisolationunitconnectionprice(
			String iSDNlineisolationunitconnectionprice) {
		ISDNlineisolationunitconnectionprice = iSDNlineisolationunitconnectionprice;
	}
	public String getBroadbandlineisolationunitrentalprice() {
		return broadbandlineisolationunitrentalprice;
	}

	public void setBroadbandlineisolationunitrentalprice(
			String broadbandlineisolationunitrentalprice) {
		this.broadbandlineisolationunitrentalprice = broadbandlineisolationunitrentalprice;
	}

	public void setBusinessAccount(String businessAccount) {
		this.businessAccount = businessAccount;
	}

	public String getNewSite() {
		return newSite;
	}
	public String getLineisolationunitrentalprice() {
		return lineisolationunitrentalprice;
	}

	public void setLineisolationunitrentalprice(String lineisolationunitrentalprice) {
		this.lineisolationunitrentalprice = lineisolationunitrentalprice;
	}


	public void setNewSite(String newSite) {
		this.newSite = newSite;
	}

	public String getLandlinePhone() {
		return landlinePhone;
	}

	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getAddressValue() {
		return addressValue;
	}

	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}

	public String getPremisesName() {
		return premisesName;
	}

	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getProposition() {
		return proposition;
	}

	public void setProposition(String proposition) {
		this.proposition = proposition;
	}

	public String getRouter() {
		return router;
	}

	public void setRouter(String router) {
		this.router = router;
	}

	public String getBusinessRateCard() {
		return businessRateCard;
	}

	public void setBusinessRateCard(String businessRateCard) {
		this.businessRateCard = businessRateCard;
	}

	public String getCalls() {
		return calls;
	}

	public void setCalls(String calls) {
		this.calls = calls;
	}

	public String getCarelevel() {
		return carelevel;
	}

	public void setCarelevel(String carelevel) {
		this.carelevel = carelevel;
	}

	public String getSelectcalls() {
		return selectcalls;
	}

	
	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}


	public void setSelectcalls(String selectcalls) {
		this.selectcalls = selectcalls;
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = contract;
	}

	public String getOneOffCharge() {
		return oneOffCharge;
	}

	public void setOneOffCharge(String oneOffCharge) {
		this.oneOffCharge = oneOffCharge;
	}

	public String getRateCardDiscount() {
		return rateCardDiscount;
	}

	public void setRateCardDiscount(String rateCardDiscount) {
		this.rateCardDiscount = rateCardDiscount;
	}

	public String getSalesPromotion() {
		return salesPromotion;
	}

	public void setSalesPromotion(String salesPromotion) {
		this.salesPromotion = salesPromotion;
	}

	public String getCustomerDiscount() {
		return customerDiscount;
	}

	public void setCustomerDiscount(String customerDiscount) {
		this.customerDiscount = customerDiscount;
	}

	public String getIncludeOutofHours() {
		return includeOutofHours;
	}

	public void setIncludeOutofHours(String includeOutofHours) {
		this.includeOutofHours = includeOutofHours;
	}

	public String getAppointmentCharges() {
		return appointmentCharges;
	}

	public void setAppointmentCharges(String appointmentCharges) {
		this.appointmentCharges = appointmentCharges;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getEngineeringNotes() {
		return engineeringNotes;
	}

	public void setEngineeringNotes(String engineeringNotes) {
		this.engineeringNotes = engineeringNotes;
	}

	public String getHealthAndSafetyNotes() {
		return healthAndSafetyNotes;
	}

	public void setHealthAndSafetyNotes(String healthAndSafetyNotes) {
		this.healthAndSafetyNotes = healthAndSafetyNotes;
	}

	public String getCommunicationBy() {
		return communicationBy;
	}

	public void setCommunicationBy(String communicationBy) {
		this.communicationBy = communicationBy;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getBroadbandCare() {
		return broadbandCare;
	}

	public void setBroadbandCare(String broadbandCare) {
		this.broadbandCare = broadbandCare;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getDdiRangeNum() {
		return ddiRangeNum;
	}

	public void setDdiRangeNum(String ddiRangeNum) {
		this.ddiRangeNum = ddiRangeNum;
	}

	public String getKeepExistingNumber() {
		return keepExistingNumber;
	}

	public void setKeepExistingNumber(String keepExistingNumber) {
		this.keepExistingNumber = keepExistingNumber;
	}

	public String getCeaseReason() {
		return ceaseReason;
	}

	public void setCeaseReason(String ceaseReason) {
		this.ceaseReason = ceaseReason;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMobileAccountNumber() {
		return mobileAccountNumber;
	}

	public void setMobileAccountNumber(String mobileAccountNumber) {
		this.mobileAccountNumber = mobileAccountNumber;
	}

	public String getPropositionWLTO() {
		return propositionWLTO;
	}

	public void setPropositionWLTO(String propositionWLTO) {
		this.propositionWLTO = propositionWLTO;
	}

	public String getPropositionSOSL() {
		return propositionSOSL;
	}

	public void setPropositionSOSL(String propositionSOSL) {
		this.propositionSOSL = propositionSOSL;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getAdditionalContacNum() {
		return additionalContacNum;
	}

	public void setAdditionalContacNum(String additionalContacNum) {
		this.additionalContacNum = additionalContacNum;
	}

	public String getNotificationBy() {
		return notificationBy;
	}

	public void setNotificationBy(String notificationBy) {
		this.notificationBy = notificationBy;
	}

	public String getRentalCharge() {
		return rentalCharge;
	}

	public void setRentalCharge(String rentalCharge) {
		this.rentalCharge = rentalCharge;
	}

	public String getISDN30OneCharges() {
		return ISDN30OneCharges;
	}

	public void setISDN30OneCharges(String iSDN30OneCharges) {
		ISDN30OneCharges = iSDN30OneCharges;
	}
	
	public String getQuantity_ISDN() {
		return quantity_ISDN;
	}

	public void setQuantity_ISDN(String quantity_ISDN) {
		this.quantity_ISDN = quantity_ISDN;
	}

	public String getAdminControlledSelectiveCallNationalInternational() {
		return AdminControlledSelectiveCallNationalInternational;
	}

	public void setAdminControlledSelectiveCallNationalInternational(
			String adminControlledSelectiveCallNationalInternational) {
		AdminControlledSelectiveCallNationalInternational = adminControlledSelectiveCallNationalInternational;
	}


	
}
