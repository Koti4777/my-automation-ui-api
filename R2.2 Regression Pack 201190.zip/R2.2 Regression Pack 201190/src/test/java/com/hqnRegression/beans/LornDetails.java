package com.hqnRegression.beans;

public class LornDetails {
	
	private String postCode;
	private String landlinePhone;
	public String submiitingCP;
	
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getLandlinePhone() {
		return landlinePhone;
	}
	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}
	public String getSubmiitingCP() {
		return submiitingCP;
	}
	public void setSubmiitingCP(String submiitingCP) {
		this.submiitingCP = submiitingCP;
	}
	
	
	
	
	
}
