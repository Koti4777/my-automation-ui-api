package com.hqnRegression.beans;

public class MacoutDetails {
	
	private String foid;

	public String getFoid() {
		return foid;
	}

	public void setFoid(String foid) {
		this.foid = foid;
	}

}
