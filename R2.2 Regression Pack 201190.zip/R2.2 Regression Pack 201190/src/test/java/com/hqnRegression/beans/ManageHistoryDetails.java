package com.hqnRegression.beans;

public class ManageHistoryDetails {
	private static String StatusReason;
	private static String Description;
	private static String SequenceNumber;
	private static String StatusReasonold;

	public static String getStatusReasonold() {
		return StatusReasonold;
	}
	public static void setStatusReasonold(String statusReasonold) {
		StatusReasonold = statusReasonold;
	}
	public static String getStatusReason() {
		return StatusReason;
	}
	public static void setStatusReason(String statusReason) {
		StatusReason = statusReason;
	}
	public static String getDescription() {
		return Description;
	}
	public static void setDescription(String description) {
		Description = description;
	}
	public static String getSequenceNumber() {
		return SequenceNumber;
	}
	public static void setSequenceNumber(String sequenceNumber) {
		SequenceNumber = sequenceNumber;
	}

	
}
