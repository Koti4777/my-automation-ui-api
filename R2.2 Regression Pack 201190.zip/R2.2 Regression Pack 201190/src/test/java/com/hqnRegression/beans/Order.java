package com.hqnRegression.beans;

public class Order {
	
	private String lineSiteId;
	private String bbSiteId;
	private String ordeId;
	public String getLineSiteId() {
		return lineSiteId;
	}
	public void setLineSiteId(String lineSiteId) {
		this.lineSiteId = lineSiteId;
	}
	public String getBbSiteId() {
		return bbSiteId;
	}
	public void setBbSiteId(String bbSiteId) {
		this.bbSiteId = bbSiteId;
	}
	public String getOrdeId() {
		return ordeId;
	}
	public void setOrdeId(String ordeId) {
		this.ordeId = ordeId;
	}
	
}
