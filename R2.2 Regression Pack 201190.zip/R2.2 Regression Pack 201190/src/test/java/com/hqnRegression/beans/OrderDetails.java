/**
 * 
 */
package com.hqnRegression.beans;

/**
 * @author mchandrasekhar
 *
 */
public class OrderDetails {

	public String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
}
