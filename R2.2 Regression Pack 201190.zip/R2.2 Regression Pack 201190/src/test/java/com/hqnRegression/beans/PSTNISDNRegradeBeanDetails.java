package com.hqnRegression.beans;

public class PSTNISDNRegradeBeanDetails {
	private String businessAccount;
	private String newSite;
	private String landlinePhone;
	private String postCode;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String proposition;
	private String router;
	private String businessRateCard;
	private String calls;
	private String quantity_ISDN;
	private String quantity;

	private String selectcalls;
	private String contract;
	private String oneOffCharge;
	private String rateCardDiscount;
	private String salesPromotion;
	private String customerDiscount;
	private String includeOutofHours;
	private String appointmentCharges;
	private String title;
	private String firstName;
	private String surName;
	private String engineeringNotes;
	private String healthAndSafetyNotes;
	private String communicationBy;
	private String orderId;
	private String broadbandCare;
	private String serviceId;
	private String ddiRangeNum;
	private String keepExistingNumber;
	
	private String customerId;
	private String carelevel;
	private String SddirangeNum;
	private String installationtype1;
	private String managedInstall;
	
	private String quantity_VoiceCarelevel;
	private String quantity_ContractTerm;
	private String quantity_ISDN2eSystem;
	private String AdminControlledSelectiveCallNationalInternational;
	private String isdn2teloneoffcharges;
	private String wlroneoffcharges;
	private String waiveETCReason;
	private String isdnnewchannelconnection;
	
	public String getBusinessAccount() {
		return businessAccount;
	}
	public void setBusinessAccount(String businessAccount) {
		this.businessAccount = businessAccount;
	}
	public String getNewSite() {
		return newSite;
	}
	public void setNewSite(String newSite) {
		this.newSite = newSite;
	}
	public String getLandlinePhone() {
		return landlinePhone;
	}
	public void setLandlinePhone(String landlinePhone) {
		this.landlinePhone = landlinePhone;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getAddressValue() {
		return addressValue;
	}
	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}
	public String getPremisesName() {
		return premisesName;
	}
	public void setPremisesName(String premisesName) {
		this.premisesName = premisesName;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getProposition() {
		return proposition;
	}
	public void setProposition(String proposition) {
		this.proposition = proposition;
	}
	public String getRouter() {
		return router;
	}
	public void setRouter(String router) {
		this.router = router;
	}
	public String getBusinessRateCard() {
		return businessRateCard;
	}
	public void setBusinessRateCard(String businessRateCard) {
		this.businessRateCard = businessRateCard;
	}
	public String getCalls() {
		return calls;
	}
	public void setCalls(String calls) {
		this.calls = calls;
	}
	public String getQuantity_ISDN() {
		return quantity_ISDN;
	}
	public void setQuantity_ISDN(String quantity_ISDN) {
		this.quantity_ISDN = quantity_ISDN;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getSelectcalls() {
		return selectcalls;
	}
	public void setSelectcalls(String selectcalls) {
		this.selectcalls = selectcalls;
	}
	public String getContract() {
		return contract;
	}
	public void setContract(String contract) {
		this.contract = contract;
	}
	public String getOneOffCharge() {
		return oneOffCharge;
	}
	public void setOneOffCharge(String oneOffCharge) {
		this.oneOffCharge = oneOffCharge;
	}
	public String getRateCardDiscount() {
		return rateCardDiscount;
	}
	public void setRateCardDiscount(String rateCardDiscount) {
		this.rateCardDiscount = rateCardDiscount;
	}
	public String getSalesPromotion() {
		return salesPromotion;
	}
	public void setSalesPromotion(String salesPromotion) {
		this.salesPromotion = salesPromotion;
	}
	public String getCustomerDiscount() {
		return customerDiscount;
	}
	public void setCustomerDiscount(String customerDiscount) {
		this.customerDiscount = customerDiscount;
	}
	public String getIncludeOutofHours() {
		return includeOutofHours;
	}
	public void setIncludeOutofHours(String includeOutofHours) {
		this.includeOutofHours = includeOutofHours;
	}
	public String getAppointmentCharges() {
		return appointmentCharges;
	}
	public void setAppointmentCharges(String appointmentCharges) {
		this.appointmentCharges = appointmentCharges;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getEngineeringNotes() {
		return engineeringNotes;
	}
	public void setEngineeringNotes(String engineeringNotes) {
		this.engineeringNotes = engineeringNotes;
	}
	public String getHealthAndSafetyNotes() {
		return healthAndSafetyNotes;
	}
	public void setHealthAndSafetyNotes(String healthAndSafetyNotes) {
		this.healthAndSafetyNotes = healthAndSafetyNotes;
	}
	public String getCommunicationBy() {
		return communicationBy;
	}
	public void setCommunicationBy(String communicationBy) {
		this.communicationBy = communicationBy;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getBroadbandCare() {
		return broadbandCare;
	}
	public void setBroadbandCare(String broadbandCare) {
		this.broadbandCare = broadbandCare;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getDdiRangeNum() {
		return ddiRangeNum;
	}
	public void setDdiRangeNum(String ddiRangeNum) {
		this.ddiRangeNum = ddiRangeNum;
	}
	public String getKeepExistingNumber() {
		return keepExistingNumber;
	}
	public void setKeepExistingNumber(String keepExistingNumber) {
		this.keepExistingNumber = keepExistingNumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCarelevel() {
		return carelevel;
	}
	public void setCarelevel(String carelevel) {
		this.carelevel = carelevel;
	}
	public String getSddirangeNum() {
		return SddirangeNum;
	}
	public void setSddirangeNum(String sddirangeNum) {
		SddirangeNum = sddirangeNum;
	}
	public String getInstallationtype1() {
		return installationtype1;
	}
	public void setInstallationtype1(String installationtype1) {
		this.installationtype1 = installationtype1;
	}
	public String getManagedInstall() {
		return managedInstall;
	}
	public void setManagedInstall(String managedInstall) {
		this.managedInstall = managedInstall;
	}
	public String getQuantity_VoiceCarelevel() {
		return quantity_VoiceCarelevel;
	}
	public void setQuantity_VoiceCarelevel(String quantity_VoiceCarelevel) {
		this.quantity_VoiceCarelevel = quantity_VoiceCarelevel;
	}
	public String getQuantity_ContractTerm() {
		return quantity_ContractTerm;
	}
	public void setQuantity_ContractTerm(String quantity_ContractTerm) {
		this.quantity_ContractTerm = quantity_ContractTerm;
	}
	public String getQuantity_ISDN2eSystem() {
		return quantity_ISDN2eSystem;
	}
	public void setQuantity_ISDN2eSystem(String quantity_ISDN2eSystem) {
		this.quantity_ISDN2eSystem = quantity_ISDN2eSystem;
	}
	public String getAdminControlledSelectiveCallNationalInternational() {
		return AdminControlledSelectiveCallNationalInternational;
	}
	public void setAdminControlledSelectiveCallNationalInternational(
			String adminControlledSelectiveCallNationalInternational) {
		AdminControlledSelectiveCallNationalInternational = adminControlledSelectiveCallNationalInternational;
	}
	public String getIsdn2teloneoffcharges() {
		return isdn2teloneoffcharges;
	}
	public void setIsdn2teloneoffcharges(String isdn2teloneoffcharges) {
		this.isdn2teloneoffcharges = isdn2teloneoffcharges;
	}
	public String getWlroneoffcharges() {
		return wlroneoffcharges;
	}
	public void setWlroneoffcharges(String wlroneoffcharges) {
		this.wlroneoffcharges = wlroneoffcharges;
	}
	public String getWaiveETCReason() {
		return waiveETCReason;
	}
	public void setWaiveETCReason(String waiveETCReason) {
		this.waiveETCReason = waiveETCReason;
	}
	public String getIsdnnewchannelconnection() {
		return isdnnewchannelconnection;
	}
	public void setIsdnnewchannelconnection(String isdnnewchannelconnection) {
		this.isdnnewchannelconnection = isdnnewchannelconnection;
	}
	
}
