package com.hqnRegression.beans;

public class PhoneLineFault {

	private String ticketsubtype;
	private String channelid;
	private String options;
	private String options2;
	private String testtype;
	public String getTicketsubtype() {
		return ticketsubtype;
	}
	public String getChannelid() {
		return channelid;
	}
	public String getOptions() {
		return options;
	}
	public String getOptions2() {
		return options2;
	}
	public String getTesttype() {
		return testtype;
	}
	public void setTicketsubtype(String ticketsubtype) {
		this.ticketsubtype = ticketsubtype;
	}
	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public void setOptions2(String options2) {
		this.options2 = options2;
	}
	public void setTesttype(String testtype) {
		this.testtype = testtype;
	}
		

}
