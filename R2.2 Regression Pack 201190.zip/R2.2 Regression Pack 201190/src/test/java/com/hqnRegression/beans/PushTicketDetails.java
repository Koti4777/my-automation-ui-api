package com.hqnRegression.beans;

public class PushTicketDetails {

	private String customerType;
	private String pool;
	private String withInSLA;
	private String ticketsWithUpdates;
	private String ticketsWithCustomerResponse;
	public String getTicketsWithUpdates() {
		return ticketsWithUpdates;
	}
	public void setTicketsWithUpdates(String ticketsWithUpdates) {
		this.ticketsWithUpdates = ticketsWithUpdates;
	}
	public String getTicketsWithCustomerResponse() {
		return ticketsWithCustomerResponse;
	}
	public void setTicketsWithCustomerResponse(String ticketsWithCustomerResponse) {
		this.ticketsWithCustomerResponse = ticketsWithCustomerResponse;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getPool() {
		return pool;
	}
	public void setPool(String pool) {
		this.pool = pool;
	}
	public String getWithInSLA() {
		return withInSLA;
	}
	public void setWithInSLA(String withInSLA) {
		this.withInSLA = withInSLA;
	}
	
	
}
