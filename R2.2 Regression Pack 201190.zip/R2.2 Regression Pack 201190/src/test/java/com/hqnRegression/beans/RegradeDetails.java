package com.hqnRegression.beans;

public class RegradeDetails {

}
