package com.hqnRegression.beans;

public class ReportDetails {

	private String reportName;
	private String reportSchedule;
	private String from_year;
	private String from_month;
	private String from_day;
	private String year;
	private String month;
	private String day;
	
	
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	
	public String getReportSchedule() {
		return reportSchedule;
	}
	public void setReportSchedule(String reportSchedule) {
		this.reportSchedule = reportSchedule;
	}
	public String getFrom_year() {
		return from_year;
	}
	public void setFrom_year(String from_year) {
		this.from_year = from_year;
	}
	public String getFrom_month() {
		return from_month;
	}
	public void setFrom_month(String from_month) {
		this.from_month = from_month;
	}
	public String getFrom_day() {
		return from_day;
	}
	public void setFrom_day(String from_day) {
		this.from_day = from_day;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	
}
