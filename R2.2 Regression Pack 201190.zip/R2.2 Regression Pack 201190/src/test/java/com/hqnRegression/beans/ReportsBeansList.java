package com.hqnRegression.beans;

public class ReportsBeansList {
	private String NameField;
	private String Schedule;
	private String Month;
	private String year;
	private String date;
	private String Monthly;
	private String yeardly;
	private String datedly;
	public String getMonthly() {
		return Monthly;
	}
	public void setMonthly(String monthly) {
		Monthly = monthly;
	}
	public String getYeardly() {
		return yeardly;
	}
	public void setYeardly(String yeardly) {
		this.yeardly = yeardly;
	}
	public String getDatedly() {
		return datedly;
	}
	public void setDatedly(String datedly) {
		this.datedly = datedly;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getNameField() {
		return NameField;
	}
	public void setNameField(String nameField) {
		NameField = nameField;
	}
	public String getSchedule() {
		return Schedule;
	}
	public void setSchedule(String schedule) {
		Schedule = schedule;
	}
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		Month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	

}
