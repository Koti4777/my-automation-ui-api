package com.hqnRegression.beans;

public class SMPFFackingBeanDetails 
{
	private String customerName;
	public String submiitingCP;
	public String postCode;
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getSubmiitingCP() {
		return submiitingCP;
	}
	public void setSubmiitingCP(String submiitingCP) {
		this.submiitingCP = submiitingCP;
	}
	
}
