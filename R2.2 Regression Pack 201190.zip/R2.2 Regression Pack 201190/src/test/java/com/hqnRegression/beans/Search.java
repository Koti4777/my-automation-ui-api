package com.hqnRegression.beans;

public class Search {
	
	private String searchBy;
	private String searchWith;
	private String sno;
	
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSearchBy() {
		return searchBy;
	}
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
	public String getSearchWith() {
		return searchWith;
	}
	public void setSearchWith(String searchWith) {
		this.searchWith = searchWith;
	}

}
