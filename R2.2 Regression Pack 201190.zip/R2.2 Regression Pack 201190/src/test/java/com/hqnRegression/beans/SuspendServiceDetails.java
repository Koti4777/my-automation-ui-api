package com.hqnRegression.beans;

public class SuspendServiceDetails {
	
	private String orderId;
	public String customerType;
	public String Reason;
	public String Complete;
	public String getComplete() {
		return Complete;
	}
	public void setComplete(String complete) {
		Complete = complete;
	}
	public String getReason() {
		return Reason;
	}
	public void setReason(String reason) {
		Reason = reason;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	

}
