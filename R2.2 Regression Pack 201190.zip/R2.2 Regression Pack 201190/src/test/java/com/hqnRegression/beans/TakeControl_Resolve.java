package com.hqnRegression.beans;

public class TakeControl_Resolve {

	private String foid;
	private static String internalNotes;
	private static String internalResolveNotes;

	private String ticketType;
	private String comments;

	private String subType;
	private String pool;
	public static String clearCode;
	public static String amendreason;
	public static String accessnotes;
	public static String notes;
	public static String hazardnotes;
	public static String accessAvailablitynotes;
	public static String TCRbrand;
	public static String IncludeOutofHours;
	public static String reasonCode;

	public static String getReasonCode() {
		return reasonCode;
	}

	public static void setReasonCode(String reasonCode) {
		TakeControl_Resolve.reasonCode = reasonCode;
	}

	public static String getIncludeOutofHours() {
		return IncludeOutofHours;
	}

	public static void setIncludeOutofHours(String includeOutofHours) {
		IncludeOutofHours = includeOutofHours;
	}

	public String getTCRbrand() {
		return TCRbrand;
	}

	public String getAmendreason() {
		return amendreason;
	}

	public void setAmendreason(String amendreason) {
		this.amendreason = amendreason;
	}

	public void setTCRbrand(String tCRbrand) {
		TCRbrand = tCRbrand;
	}

	public String getAccessAvailablitynotes() {
		return accessAvailablitynotes;
	}

	public void setAccessAvailablitynotes(String accessAvailablitynotes) {
		this.accessAvailablitynotes = accessAvailablitynotes;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getHazardnotes() {
		return hazardnotes;
	}

	public void setHazardnotes(String hazardnotes) {
		this.hazardnotes = hazardnotes;
	}

	public String getAccessnotes() {
		return accessnotes;
	}

	public void setAccessnotes(String accessnotes) {
		this.accessnotes = accessnotes;
	}

	public static String getClearCode() {
		return clearCode;
	}

	public void setClearCode(String clearCode) {
		this.clearCode = clearCode;
	}

	public String getPool() {
		return pool;
	}

	public void setPool(String pool) {
		this.pool = pool;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getTicketType() {
		return ticketType;
	}

	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public static String getInternalNotes() {
		return internalNotes;
	}

	public void setInternalNotes(String internalNotes) {
		this.internalNotes = internalNotes;
	}

	public static String getInternalResolveNotes() {
		return internalResolveNotes;
	}

	public static void setInternalResolveNotes(String internalResolveNotes) {
		TakeControl_Resolve.internalResolveNotes = internalResolveNotes;
	}

	public String getFoid() {
		return foid;
	}

	public void setFoid(String foid) {
		this.foid = foid;
	}

}
