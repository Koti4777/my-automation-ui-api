package com.hqnRegression.beans;

public class TicketBeanDetails {

	private String orderId;
	private String addressValue;
	private String premisesName;
	private String streetName;
	private String town;
	private String country;
	private String proposition;
	
	
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
}
