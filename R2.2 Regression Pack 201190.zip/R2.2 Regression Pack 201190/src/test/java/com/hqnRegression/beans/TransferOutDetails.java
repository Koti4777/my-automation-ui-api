package com.hqnRegression.beans;

/**
 * @author rsravani
 *
 */


public class TransferOutDetails {
	public String submiitingCP;
	
	public String eventType;
	
	public String event;
	
	public String serviceId;
	
	public String productType;
	
	public String addressValue;
	
	public String postCode; 
	
	public String lineType;
	
	private String orderId;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSubmiitingCP() {
		return submiitingCP;
	}

	public void setSubmiitingCP(String submiitingCP) {
		this.submiitingCP = submiitingCP;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getAddressValue() {
		return addressValue;
	}

	public void setAddressValue(String addressValue) {
		this.addressValue = addressValue;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getLineType() {
		return lineType;
	}

	public void setLineType(String lineType) {
		this.lineType = lineType;
	}
	
	
	

}
