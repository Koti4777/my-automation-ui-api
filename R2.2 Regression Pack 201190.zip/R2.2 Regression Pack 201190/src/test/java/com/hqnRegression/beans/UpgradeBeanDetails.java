package com.hqnRegression.beans;

public class UpgradeBeanDetails {
	private String praposition;
	private String router;
	private String carelevel;
	private String engineeringNotes;
	private String healthAndSafetyNotes;
	private String contract;
	private String communicationBy;
	private String cnfFeature;
	private String calls;
	private String voiceCarelevel;
	
	
	public String getPraposition() {
		return praposition;
	}
	public void setPraposition(String praposition) {
		this.praposition = praposition;
	}
	public String getRouter() {
		return router;
	}
	public void setRouter(String router) {
		this.router = router;
	}
	public String getCarelevel() {
		return carelevel;
	}
	public void setCarelevel(String carelevel) {
		this.carelevel = carelevel;
	}
	public String getEngineeringNotes() {
		return engineeringNotes;
	}
	public void setEngineeringNotes(String engineeringNotes) {
		this.engineeringNotes = engineeringNotes;
	}
	public String getHealthAndSafetyNotes() {
		return healthAndSafetyNotes;
	}
	public void setHealthAndSafetyNotes(String healthAndSafetyNotes) {
		this.healthAndSafetyNotes = healthAndSafetyNotes;
	}
	public String getContract() {
		return contract;
	}
	public void setContract(String contract) {
		this.contract = contract;
	}
	public String getCommunicationBy() {
		return communicationBy;
	}
	public void setCommunicationBy(String communicationBy) {
		this.communicationBy = communicationBy;
	}
	public String getCnfFeature() {
		return cnfFeature;
	}
	public void setCnfFeature(String cnfFeature) {
		this.cnfFeature = cnfFeature;
	}
	public String getCalls() {
		return calls;
	}
	public void setCalls(String calls) {
		this.calls = calls;
	}
	public String getVoiceCarelevel() {
		return voiceCarelevel;
	}
	public void setVoiceCarelevel(String voiceCarelevel) {
		this.voiceCarelevel = voiceCarelevel;
	}
	
	
	

}
