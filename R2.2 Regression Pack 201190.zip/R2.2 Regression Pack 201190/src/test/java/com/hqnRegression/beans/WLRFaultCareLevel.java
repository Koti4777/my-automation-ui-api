package com.hqnRegression.beans;

public class WLRFaultCareLevel {

	private String searchBy;
	private String SearchValue;
	private String ticketSubtypeID;
	private String channelId;
	private String answer1;
	private String answer2;
	private String answer3;
	private String answer4;
	private String answer5;
	private String answer6;
	private String answer7;
	private String answer8;
	private String answer9;
	private String answer10;
	private String answer11;
	
	private String testType;	
	private String Num;
	private String EngNotes;
	private String HazardNotes;
	private String chargeBand;
	private String numToMock;
	private String expedite;
	private String acceptCharge;
	private String waiveCharge;
	private String outofhours;
	private String appointmentCharges;
	private String internalNotes;
	private String internalResolveNotes;
	private String clearCode;
	
	private String accessAvailability;
	private String accessNotes;
	private String contactTime;
	
	public String getClearCode() {
		return clearCode;
	}
	public void setClearCode(String clearCode) {
		this.clearCode = clearCode;
	}
	public String getInternalNotes() {
		return internalNotes;
	}
	public void setInternalNotes(String internalNotes) {
		this.internalNotes = internalNotes;
	}
	public String getInternalResolveNotes() {
		return internalResolveNotes;
	}
	public void setInternalResolveNotes(String internalResolveNotes) {
		this.internalResolveNotes = internalResolveNotes;
	}
	
	public String getAppointmentCharges() {
		return appointmentCharges;
	}
	public void setAppointmentCharges(String appointmentCharges) {
		this.appointmentCharges = appointmentCharges;
	}
	public String getOutofhours() {
		return outofhours;
	}
	public void setOutofhours(String outofhours) {
		this.outofhours = outofhours;
	}
	private String saturday;
	
	
	public String getSaturday() {
		return saturday;
	}
	public void setSaturday(String saturday) {
		this.saturday = saturday;
	}
	public String getChargeBand() {
		return chargeBand;
	}
	public void setChargeBand(String chargeBand) {
		this.chargeBand = chargeBand;
	}
	public String getSearchBy() {
		return searchBy;
	}
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
	public String getSearchValue() {
		return SearchValue;
	}
	public void setSearchValue(String searchValue) {
		SearchValue = searchValue;
	}
	public String getTicketSubtypeID() {
		return ticketSubtypeID;
	}
	public void setTicketSubtypeID(String ticketSubtypeID) {
		this.ticketSubtypeID = ticketSubtypeID;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getAnswer1() {
		return answer1;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getAnswer2() {
		return answer2;
	}
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	public String getAnswer3() {
		return answer3;
	}
	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}
	public String getAnswer4() {
		return answer4;
	}
	public void setAnswer4(String answer4) {
		this.answer4 = answer4;
	}
	public String getAnswer5() {
		return answer5;
	}
	public void setAnswer5(String answer5) {
		this.answer5 = answer5;
	}
	public String getAnswer6() {
		return answer6;
	}
	public void setAnswer6(String answer6) {
		this.answer6 = answer6;
	}
	public String getAnswer7() {
		return answer7;
	}
	public void setAnswer7(String answer7) {
		this.answer7 = answer7;
	}
	public String getAnswer8() {
		return answer8;
	}
	public void setAnswer8(String answer8) {
		this.answer8 = answer8;
	}
	public String getAnswer9() {
		return answer9;
	}
	public void setAnswer9(String answer9) {
		this.answer9 = answer9;
	}
	public String getAnswer10() {
		return answer10;
	}
	public void setAnswer10(String answer10) {
		this.answer10 = answer10;
	}
	public String getAnswer11() {
		return answer11;
	}
	public void setAnswer11(String answer11) {
		this.answer11 = answer11;
	}
	public String getTestType() {
		return testType;
	}
	public void setTestType(String testType) {
		this.testType = testType;
	}
	
	public String getNum() {
		return Num;
	}
	public void setNum(String num) {
		Num = num;
	}
	public String getEngNotes() {
		return EngNotes;
	}
	public void setEngNotes(String engNotes) {
		EngNotes = engNotes;
	}
	public String getHazardNotes() {
		return HazardNotes;
	}
	public void setHazardNotes(String hazardNotes) {
		HazardNotes = hazardNotes;
	}
	public String getNumToMock() {
		return numToMock;
	}
	public void setNumToMock(String numToMock) {
		this.numToMock = numToMock;
	}
	public String getExpedite() {
		return expedite;
	}
	public void setExpedite(String expedite) {
		this.expedite = expedite;
	}
	public String getAcceptCharge() {
		return acceptCharge;
	}
	public void setAcceptCharge(String acceptCharge) {
		this.acceptCharge = acceptCharge;
	}
	public String getWaiveCharge() {
		return waiveCharge;
	}
	public void setWaiveCharge(String waiveCharge) {
		this.waiveCharge = waiveCharge;
	}
	
	private String contactType;
	public String getContactType() {
		return contactType;
	}
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	public String getMultiLineNumber() {
		return multiLineNumber;
	}
	public void setMultiLineNumber(String multiLineNumber) {
		this.multiLineNumber = multiLineNumber;
	}
	private String multiLineNumber;
	
	private String careLevelNumber;

	public String getCareLevelNumber() {
		return careLevelNumber;
	}
	public void setCareLevelNumber(String careLevelNumber) {
		this.careLevelNumber = careLevelNumber;
	}

	private String includeFlexibleAppointment;

	public String getIncludeFlexibleAppointment() {
		return includeFlexibleAppointment;
	}
	public void setIncludeFlexibleAppointment(String includeFlexibleAppointment) {
		this.includeFlexibleAppointment = includeFlexibleAppointment;
	}
	public String getAccessAvailability() {
		return accessAvailability;
	}
	public void setAccessAvailability(String accessAvailability) {
		this.accessAvailability = accessAvailability;
	}
	public String getAccessNotes() {
		return accessNotes;
	}
	public void setAccessNotes(String accessNotes) {
		this.accessNotes = accessNotes;
	}
	public String getContactTime() {
		return contactTime;
	}
	public void setContactTime(String contactTime) {
		this.contactTime = contactTime;
	}
	private String b2Links;
	private String b2BTree;
	private String b2BEmailUpdate;
	private String messageText;
	private String emailText;
	
	public String getMessageText() {
		return messageText;
	}
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	public String getEmailText() {
		return emailText;
	}
	public void setEmailText(String emailText) {
		this.emailText = emailText;
	}
	public String getB2BTree() {
		return b2BTree;
	}
	public void setB2BTree(String b2bTree) {
		b2BTree = b2bTree;
	}
	public String getB2Links() {
		return b2Links;
	}
	public void setB2Links(String b2Links) {
		this.b2Links = b2Links;
	}
	public String getB2BEmailUpdate() {
		return b2BEmailUpdate;
	}
	public void setB2BEmailUpdate(String b2bEmailUpdate) {
		b2BEmailUpdate = b2bEmailUpdate;
	}
	

	

}

