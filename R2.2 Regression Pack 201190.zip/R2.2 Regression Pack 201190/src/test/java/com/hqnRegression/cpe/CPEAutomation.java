package com.hqnRegression.cpe;

import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.CPEDetails;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonClass;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class CPEAutomation extends SeleniumImplementation {
	private WebDriver driver;
	public String CLASS_NAME = "CPEAutomation";
	private static InputStream inputStream;
	private static Properties testProps;

	private String IN_FILE = "CPE.csv";
	List<CPEDetails> cpeDetailsList = new ArrayList<CPEDetails>();
	CPEDetails cpeDetails;

	private int testCount = 0;
	private int count = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CPEAutomation");

	public CPEAutomation() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setUp() throws Exception {
		driver = createBrowserInstance(BrowserType.FIREFOX);

		cpeDetailsList = CSVOperation_New.readCPEDetails(IN_FILE);
		if (cpeDetailsList != null && cpeDetailsList.size() > 0) {
			testCount = cpeDetailsList.size();
		}

		inputStream = new FileInputStream(
				"./src/test/resources/com/hqnRegression/login-cpe.properties");
		testProps = new Properties();
		testProps.load(inputStream);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testCPEAutomation(Method method) throws Exception {

		while (count < testCount) {

			logger.info("CPEAutomation : Start the CPEAutomation progression ");

			try {
				cpeDetails = cpeDetailsList.get(count);

				driver.get(testProps.getProperty("baseUrl")
						+ "logicaee/agent_login.asp");
				driver.findElement(By.id("chrusername")).clear();
				driver.findElement(By.id("chrusername")).sendKeys(
						testProps.getProperty("username"));
				driver.findElement(By.id("chrpassword")).clear();
				driver.findElement(By.id("chrpassword")).sendKeys(
						testProps.getProperty("password"));

				CommonClass
						.saveScreenshot(CLASS_NAME, method.getName(),
								"NET LYNK GROUP Portal Login" + ".png", driver,
								"Start");

				logger
						.info("CPEAutomation : Enter into the NET LYNK GROUP :: Logica (EE Devel) Portal Login");

				driver.findElement(By.xpath("//a[contains(text(),'Login')]"))
						.click();

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"Net Lynk Tracking Portal" + ".png", driver, "");

				driver
						.get(testProps.getProperty("baseUrl")
								+ "logicaee/isp_track.asp?PARENT_MENU=Order Management");

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"Orange Order Tracking" + ".png", driver, "");

				logger
						.info("CPEAutomation : Enter into the Orange Order Tracking login page");

				driver.findElement(By.name("idOrder")).clear();
				driver.findElement(By.name("idOrder")).sendKeys(
						cpeDetails.getFoid());
				new Select(driver.findElement(By.name("idPlatform")))
						.selectByVisibleText(cpeDetails.getInstance());

				CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
						"Orange Order Tracking 1" + ".png", driver, "");

				logger
						.info("CPEAutomation : After filling the tracking details");

				driver.findElement(By.linkText("Track Order")).click();

				if (cpeDetails.getDbStatus().equalsIgnoreCase("6")) {

					logger
							.info("CPEAutomation : Enter into the Orange Order Reference");

					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"Orange Order Reference 2" + ".png", driver, "");

					driver.findElement(By.linkText("Add Event")).click();

					logger
							.info("CPEAutomation : After done the Released for Dispatched");
					CommonMethods.doPause(5);
					
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"Orange Order Reference 3" + ".png", driver, "");

				} else if (cpeDetails.getDbStatus().equalsIgnoreCase("7")) {
					// After CPE Reached to 7

					logger
							.info("CPEAutomation : Enter into the Orange Order Reference");
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"Orange Order Reference 2" + ".png", driver, "");

					new Select(driver.findElement(By.name("idEvent")))
							.selectByVisibleText("Dispatched");
					
					driver.findElement(By.name("MACAddress")).clear();
					driver.findElement(By.name("MACAddress")).sendKeys(
							cpeDetails.getMacAddress());
					
					driver.findElement(By.linkText("Add Event")).click();

					logger.info("CPEAutomation : After done the Dispatched");
					CommonMethods.doPause(5);
					
					CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
							"Orange Order Reference 3" + ".png", driver, "");
				}

			} catch (Exception e) {
				System.out.println(e);
				e.printStackTrace();
			}
			count++;
		}

		CommonClass.saveScreenshot(CLASS_NAME, method.getName(),
				"NET LYNK GROUP Portal Login" + ".png",
				driver, "End");

		logger.info("CPEAutomation : End the CPEAutomation progression ");

	}

	@AfterMethod
	public void tearDown() throws Exception {
		driver.close();
		driver.quit();
	}

}
