/**
 * 
 */
package com.hqnRegression.db;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.FetchOrderDBDetails;
import com.hqnRegression.beans.OrderDetails;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * @author mchandrasekhar
 * 
 */
public class CheckDBOrderStatus extends SeleniumImplementation {

	private static InputStream inputStream;
	private static Properties testProps;
	private String IN_FILE = "OrderDetails.csv";
	List<OrderDetails> orderDetailsList = new ArrayList<OrderDetails>();
	OrderDetails orderDetails;

	Connection connection;

	private int testCount = 0;
	private int count = 0;

	private String loggerPath = CommonMethods.getProperty("log4j.properties");
	private static Logger logger = Logger.getLogger("CheckDBOrderStatus");

	public CheckDBOrderStatus() {
		PropertyConfigurator.configure(loggerPath);
	}

	@BeforeMethod
	public void setup() throws Exception {

		orderDetailsList = CSVOperation_New.readOrderDetails(IN_FILE);
		if (orderDetailsList != null && orderDetailsList.size() > 0) {
			testCount = orderDetailsList.size();
		}

		inputStream = new FileInputStream(
				"./src/test/resources/com/hqnRegression/db-connection.properties");
		testProps = new Properties();
		testProps.load(inputStream);
	}

	@Test
	public void checkDBOrderStatus(Method method) throws IOException {

		try {

			/*
			 * Runtime runtime = Runtime.getRuntime(); Process proc =
			 * runtime.exec(testProps.getProperty("batchFile"));
			 * 
			 * Thread.currentThread(); Thread.sleep(10000);
			 */

			logger
					.info("CheckDBOrderStatus : Start the checkDBOrderStatus process");

			Class.forName(testProps.getProperty("driver"));

			connection = DriverManager.getConnection(testProps
					.getProperty("url"), testProps.getProperty("username"),
					testProps.getProperty("password"));

			logger.info("CheckDBOrderStatus : DataBase connected");

			Statement statement = connection.createStatement();

			logger.info("CheckDBOrderStatus : create the statement");

			List<FetchOrderDBDetails> fetchOrderDBDetailsList = new ArrayList<FetchOrderDBDetails>();

			FetchOrderDBDetails fetchOrderDBDetails = null;

			while (count < testCount) {

				orderDetails = orderDetailsList.get(count);

				String query = testProps.getProperty("fforQuery");

				query = query.replaceAll("orderId", orderDetails.getOrderId());

				ResultSet resultSet = statement.executeQuery(query);

				logger.info("CheckDBOrderStatus : execute the query" + query);

				fetchOrderDBDetails = new FetchOrderDBDetails();

				setDefaultValues(fetchOrderDBDetails);

				fetchOrderDBDetails.setOrderId(orderDetails.getOrderId());

				while (resultSet.next()) {

					if (resultSet.getString("target").equalsIgnoreCase("20CN")) {
						
						fetchOrderDBDetails.setFullFillmentOrderId(resultSet
								.getString("fulfilment_order_id"));
						fetchOrderDBDetails.setStatusId20CN(resultSet
								.getString("fulfilment_order_status_id"));
						fetchOrderDBDetails.setBuyersId(resultSet
								.getString("supplier_batch_id"));

						if (resultSet.getString("supplier_batch_id") == null){
							fetchOrderDBDetails.setBatchId("Not Generated");
							fetchOrderDBDetails.setBuyersId("Not Generated");
						}else{
							fetchOrderDBDetails.setBatchId(resultSet
									.getString("supplier_batch_id"));
							fetchOrderDBDetails.setBuyersId(resultSet
									.getString("supplier_batch_id"));
						}

					} else if (resultSet.getString("target").equalsIgnoreCase(
							"21CN")) {
						fetchOrderDBDetails.setFullFillmentOrderId(resultSet
								.getString("fulfilment_order_id"));
						fetchOrderDBDetails.setStatusId21CN(resultSet
								.getString("fulfilment_order_status_id"));
						fetchOrderDBDetails.setBuyersId(resultSet
								.getString("fulfilment_order_id"));

						if (resultSet.getString("supplier_batch_id") == null)
							fetchOrderDBDetails.setBatchId("Not Generated");
						else
							fetchOrderDBDetails.setBatchId(resultSet
									.getString("supplier_batch_id"));

					} else if (resultSet.getString("target").equalsIgnoreCase(
							"WLR3")) {
						fetchOrderDBDetails.setWlr3Foid(resultSet
								.getString("fulfilment_order_id"));
						fetchOrderDBDetails.setWlr3FOStatusId(resultSet
								.getString("fulfilment_order_status_id"));

						if (resultSet.getString("supplier_batch_id") == null)
							fetchOrderDBDetails.setWlr3BatchId("Not Generated");
						else
							fetchOrderDBDetails.setWlr3BatchId(resultSet
									.getString("supplier_batch_id"));

					} else if (resultSet.getString("target").equalsIgnoreCase(
							"WCLI")) {
						fetchOrderDBDetails.setWcliFoid(resultSet
								.getString("fulfilment_order_id"));
						fetchOrderDBDetails.setWcliFOStatusId(resultSet
								.getString("fulfilment_order_status_id"));
						fetchOrderDBDetails.setWcliBatchId(resultSet
								.getString("supplier_batch_id"));

						if (resultSet.getString("supplier_batch_id") == null)
							fetchOrderDBDetails.setWcliBatchId("Not Generated");
						else
							fetchOrderDBDetails.setWcliBatchId(resultSet
									.getString("supplier_batch_id"));

					} else if (resultSet.getString("target").equalsIgnoreCase(
							"CPE")) {
						fetchOrderDBDetails.setCpeFoid(resultSet
								.getString("fulfilment_order_id"));
						fetchOrderDBDetails.setCpeFOStatusId(resultSet
								.getString("fulfilment_order_status_id"));
						fetchOrderDBDetails.setCpeBatchId(resultSet
								.getString("supplier_batch_id"));

						if (resultSet.getString("supplier_batch_id") == null)
							fetchOrderDBDetails.setCpeBatchId("Not Generated");
						else
							fetchOrderDBDetails.setCpeBatchId(resultSet
									.getString("supplier_batch_id"));

					} else if (resultSet.getString("target").equalsIgnoreCase(
							"RADIUS")) {
						fetchOrderDBDetails.setRadiusFoid(resultSet
								.getString("fulfilment_order_id"));
						fetchOrderDBDetails.setRadiusFOStatusId(resultSet
								.getString("fulfilment_order_status_id"));
						fetchOrderDBDetails.setRadiusBatchId(resultSet
								.getString("supplier_batch_id"));

						if (resultSet.getString("supplier_batch_id") == null)
							fetchOrderDBDetails
									.setRadiusBatchId("Not Generated");
						else
							fetchOrderDBDetails.setRadiusBatchId(resultSet
									.getString("supplier_batch_id"));

					} else if (resultSet.getString("target").equalsIgnoreCase(
							"TRAFFIC_MGMT")) {
						fetchOrderDBDetails.setTmFoid(resultSet
								.getString("fulfilment_order_id"));
						fetchOrderDBDetails.setTmFOStatusId(resultSet
								.getString("fulfilment_order_status_id"));
						fetchOrderDBDetails.setTmBatchId(resultSet
								.getString("supplier_batch_id"));

						if (resultSet.getString("supplier_batch_id") == null)
							fetchOrderDBDetails.setTmBatchId("Not Generated");
						else
							fetchOrderDBDetails.setTmBatchId(resultSet
									.getString("supplier_batch_id"));

					}

					if (resultSet.getString("value") != null)
						fetchOrderDBDetails.setLandlinePhone(resultSet
								.getString("value"));
				}
				
				query = testProps.getProperty("prodNameQuery");

				query = query.replaceAll("orderId", orderDetails.getOrderId());

				resultSet = statement.executeQuery(query);

				logger.info("CheckDBOrderStatus : execute the query" + query);
				
				resultSet = statement.executeQuery(query);
				
				while(resultSet.next()){
					
					fetchOrderDBDetails.setProductName(resultSet.getString("display_name"));
				}
				
				query = testProps.getProperty("nadKey");

				query = query.replaceAll("orderId", orderDetails.getOrderId());

				resultSet = statement.executeQuery(query);

				logger.info("CheckDBOrderStatus : execute the query" + query);
				
				resultSet = statement.executeQuery(query);
				
				while(resultSet.next()){
					
					fetchOrderDBDetails.setNadKey(resultSet.getString("address_reference"));
				}
				
				if(fetchOrderDBDetails.getProductName().contains("Superfast") || 
						fetchOrderDBDetails.getProductName().contains("Fire")){
					
					query = testProps.getProperty("appDateQuery");

					query = query.replaceAll("orderId", orderDetails.getOrderId());

					resultSet = statement.executeQuery(query);

					logger.info("CheckDBOrderStatus : execute the query" + query);
					
					resultSet = statement.executeQuery(query);
					
					while(resultSet.next()){
						fetchOrderDBDetails.setAppointReference(resultSet.getString("appointment_supplier_reference"));
						fetchOrderDBDetails.setAppointmentDate(resultSet.getString("appointment_date"));
						fetchOrderDBDetails.setAppointmentTimeSlot(resultSet.getString("appointment_timeslot"));
					}
				}
				

				if ((fetchOrderDBDetails.getStatusId20CN() == "NA" || fetchOrderDBDetails
						.getStatusId20CN().contains("12"))
						&& (fetchOrderDBDetails.getStatusId21CN() == "NA" || fetchOrderDBDetails
								.getStatusId21CN().contains("12"))
						&& (fetchOrderDBDetails.getWlr3FOStatusId() == "NA" || fetchOrderDBDetails
								.getWlr3FOStatusId().contains("12"))
						&& (fetchOrderDBDetails.getWcliFOStatusId() == "NA" || fetchOrderDBDetails
								.getWcliFOStatusId().contains("12"))
						&& (fetchOrderDBDetails.getCpeFOStatusId() == "NA" || fetchOrderDBDetails
								.getCpeFOStatusId().contains("12"))
						&& (fetchOrderDBDetails.getTmFOStatusId() == "NA" || fetchOrderDBDetails
								.getTmFOStatusId().contains("12"))
						&& (fetchOrderDBDetails.getRadiusFOStatusId() == "NA" || fetchOrderDBDetails
								.getRadiusFOStatusId().contains("12"))) {

					fetchOrderDBDetails.setCurrentStatus("Active");

				} else {

					fetchOrderDBDetails.setCurrentStatus("In Active");
				}

				if (fetchOrderDBDetails != null) {
					fetchOrderDBDetailsList.add(fetchOrderDBDetails);
					logger.info("CheckDBOrderStatus : orderDetails object "
							+ fetchOrderDBDetails);
				}

				count++;
			}
			

			if (fetchOrderDBDetailsList.size() > 0) {

				logger
						.info("CheckDBOrderStatus : write the orders in CSV file");
				CSVOperation_New.write20CNOrderDetails("OrderDBDetails.csv",
						fetchOrderDBDetailsList);
			}

			logger
					.info("CheckDBOrderStatus : End the CheckDBOrderStatus process");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void setDefaultValues(FetchOrderDBDetails fetchOrderDBDetails) {

		fetchOrderDBDetails.setFullFillmentOrderId("NA");
		fetchOrderDBDetails.setStatusId20CN("NA");
		fetchOrderDBDetails.setStatusId21CN("NA");
		fetchOrderDBDetails.setWlr3Foid("NA");
		fetchOrderDBDetails.setWlr3FOStatusId("NA");
		fetchOrderDBDetails.setWcliFoid("NA");
		fetchOrderDBDetails.setWcliFOStatusId("NA");
		fetchOrderDBDetails.setCpeFoid("NA");
		fetchOrderDBDetails.setCpeFOStatusId("NA");
		fetchOrderDBDetails.setRadiusFoid("NA");
		fetchOrderDBDetails.setRadiusFOStatusId("NA");
		fetchOrderDBDetails.setTmFoid("NA");
		fetchOrderDBDetails.setTmFOStatusId("NA");
		fetchOrderDBDetails.setBuyersId("NA");
		fetchOrderDBDetails.setBatchId("NA");
		fetchOrderDBDetails.setWcliBatchId("NA");
		fetchOrderDBDetails.setWlr3BatchId("NA");
		fetchOrderDBDetails.setCpeBatchId("NA");
		fetchOrderDBDetails.setTmBatchId("NA");
		fetchOrderDBDetails.setRadiusBatchId("NA");
		fetchOrderDBDetails.setLandlinePhone("NA");
		fetchOrderDBDetails.setRadiusBatchId("NA");
		fetchOrderDBDetails.setProductName("NA");
		fetchOrderDBDetails.setNadKey("NA");
		fetchOrderDBDetails.setAppointReference("NA");
		fetchOrderDBDetails.setAppointmentDate("NA");
		fetchOrderDBDetails.setAppointmentTimeSlot("NA");
	}

	@AfterMethod
	public void tearDown() throws Exception {
		connection.close();
	}

}
