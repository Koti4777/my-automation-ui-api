package com.hqnRegression.isdn;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.ISDNDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AddressSelectionPageOperations;
import com.hqnRegression.pages.operations.AssignSiteContactPageOperations;
import com.hqnRegression.pages.operations.AssignUserContactPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LocationMovePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class HQN_TS_ISDN2eStd_006 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "HQN_TS_ISDN2eStd_006";

	private String IN_FILE = "HQN_TS_ISDN2eStd_006.csv";
	List<ISDNDetails> isdnDetailsList = null;
	ISDNDetails isdnDetails = null;

	private int count = 0;
	public Order order = null;

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		isdnDetailsList = CSVOperation_New.readISDNDetails(IN_FILE);
		order = new Order();

	}

	@Test
	public void testHQN_TS_ISDN2eStd_006(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());
		isdnDetails = isdnDetailsList.get(0);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(isdnDetails.getOrderId(), "Order Number",
						CLASS_NAME, method.getName());
		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
				.clickProductLink();

		LocationMovePageOperations locationMovePageOperations = accountDetailsPageOperations
				.clickPremisesMove(CLASS_NAME, method.getName());

		locationMovePageOperations.selectActivateDate();

		locationMovePageOperations
				.homeMoveNewAddress(isdnDetails.getNewSite(),
						isdnDetails.getPostCode(),
						isdnDetails.getAddressValue(),
						isdnDetails.getPremisesName(),
						isdnDetails.getStreetName(),
						isdnDetails.getTown(),
						isdnDetails.getCountry(), CLASS_NAME,
						method.getName());

		// locationMovePageOperations.enterLORN(broadBandDetails.getBusinessAccount(),
		// CLASS_NAME, name.getMethodName());

		AddressSelectionPageOperations addressSelectionPageOperations = locationMovePageOperations
				.clickLineCheckAddressSelection(CLASS_NAME,
						method.getName());

		/*LineCheckResultPageOperations lineCheckResultPageOperations = addressSelectionPageOperations
				.submitAddressButton(CLASS_NAME, name.getMethodName());*/

		AssignSiteContactPageOperations assignSiteContactPageOperations = addressSelectionPageOperations
				.clickNext_ISDN(CLASS_NAME, method.getName());

		AssignUserContactPageOperations assignUserContactPageOperations = assignSiteContactPageOperations
				.isdnSubmit(CLASS_NAME, method.getName());

		CRDAndAppointmentManagementPageOperations crdAndAppointmentManagementPageOperations = assignUserContactPageOperations
				.submit1(CLASS_NAME, method.getName());

		crdAndAppointmentManagementPageOperations.selectActivateDate();

		OrderSummaryPageOperations orderSummaryPageOperations = crdAndAppointmentManagementPageOperations
				.clickNext(CLASS_NAME, method.getName());
		orderSummaryPageOperations.selectCommunication(isdnDetails
				.getCommunicationBy());
		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
		
		orderSummaryPageOperations.confirmOrder(CLASS_NAME, method.getName());

	}

	@AfterMethod
	public void tearDown(Method method) {
		CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		driver.close();

	}

}
