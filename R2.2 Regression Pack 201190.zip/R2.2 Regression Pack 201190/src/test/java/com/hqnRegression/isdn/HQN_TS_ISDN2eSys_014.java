package com.hqnRegression.isdn;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.ISDNDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class HQN_TS_ISDN2eSys_014 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "HQN_TS_ISDN2eSys_014";

	private String IN_FILE = "HQN_TS_ISDN2eSys_014.csv";
	List<ISDNDetails> isdnDetailsList = null;
	ISDNDetails isdnDetails = null;

	private int count = 0;
	public Order order = null;

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		isdnDetailsList = CSVOperation_New.readISDNDetails(IN_FILE);
		order = new Order();

	}

	@Test
	public void testHQN_TS_ISDN2eSys_014(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());
		isdnDetails = isdnDetailsList.get(0);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations
				.search(isdnDetails.getOrderId(), "Order Number", CLASS_NAME,
						method.getName());
		String product = searchResultPageOperations.getProductForActiveOrder();

		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
				.clickProductLink();

		accountDetailsPageOperations.clickphoneLineTab(CLASS_NAME,
				method.getName());

		Assert.assertTrue(!"Renumber".equalsIgnoreCase(driver.findElement(
				By.cssSelector("td")).getText()));

	}

	@AfterMethod
	public void tearDown(Method method) {

		CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		driver.close();

	}

}
