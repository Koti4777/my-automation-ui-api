package com.hqnRegression.isdn;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.beans.BroadBandDetails;
import com.hqnRegression.beans.ISDNDetails;
import com.hqnRegression.beans.Order;
import com.hqnRegression.pages.operations.AccountDetailsPageOperations;
import com.hqnRegression.pages.operations.AgentDetailsPageOperations;
import com.hqnRegression.pages.operations.CMCHomePageOperations;
import com.hqnRegression.pages.operations.CRDAndAppointmentManagementPageOperations;
import com.hqnRegression.pages.operations.HomePageOperations;
import com.hqnRegression.pages.operations.LoginPageOperations;
import com.hqnRegression.pages.operations.OrderConfirmationPageOperations;
import com.hqnRegression.pages.operations.OrderSummaryPageOperations;
import com.hqnRegression.pages.operations.ProductDetailsPageOperations;
import com.hqnRegression.pages.operations.SearchResultPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.CSVOperations;
import com.hqnRegression.util.CommonMethods;
import com.hqnRegression.util.SeleniumImplementation;

public class HQN_TS_ISDN30ETSI_002 extends SeleniumImplementation {

	private WebDriver driver;
	private String CLASS_NAME = "HQN_TS_ISDN30ETSI_002";

	private String IN_FILE = "HQN_TS_ISDN30ETSI_002.csv";
	List<ISDNDetails> isdnDetailsList = null;
	ISDNDetails isdnDetails = null;

	private int count = 0;
	public Order order = null;

	/*@Rule
	public TestName name = new TestName();*/

	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		isdnDetailsList = CSVOperation_New.readISDNDetails(IN_FILE);
		order = new Order();

	}

	@Test
	public void testHQN_TS_ISDN2eSys_002(Method method) throws IOException {

		isdnDetails = isdnDetailsList.get(0);

		LoginPageOperations loginPageOperations = CMCHomePageOperations
				.navigateTo(driver);

		HomePageOperations homePageOperations = loginPageOperations.adminLogin(
				CLASS_NAME, method.getName());

		SearchResultPageOperations searchResultPageOperations = homePageOperations.search(
				isdnDetails.getOrderId(), "Order Number", CLASS_NAME,
				method.getName());
		AccountDetailsPageOperations accountDetailsPageOperations = searchResultPageOperations
				.clickProductLink(CLASS_NAME, method.getName());

		AgentDetailsPageOperations agentDetailsPageOperations = accountDetailsPageOperations
				.clickModify(CLASS_NAME, method.getName());

		agentDetailsPageOperations.clickSameAgent();
		
		ProductDetailsPageOperations productDetailsPageOperations = agentDetailsPageOperations
				.clickNextForModify(CLASS_NAME, method.getName());

		productDetailsPageOperations.selectProductOffering_ISDN_Modify(
				isdnDetails.getProposition(), isdnDetails.getPostCode(),
				isdnDetails.getTitle(), isdnDetails.getFirstName(),
				isdnDetails.getSurName(), isdnDetails.getContract(),
				isdnDetails.getServiceID(), isdnDetails.getDdiRangenum(),
				isdnDetails.getSnddiRangeNum(), CLASS_NAME,
				method.getName());

		CRDAndAppointmentManagementPageOperations appointmentManagementPageOperations = null;

		appointmentManagementPageOperations = productDetailsPageOperations
				.clickNextForCRD(CLASS_NAME, method.getName());

		appointmentManagementPageOperations.selectActivateDate();
		OrderSummaryPageOperations orderSummaryPageOperations = appointmentManagementPageOperations
				.clickNext(CLASS_NAME, method.getName());
		orderSummaryPageOperations.selectCommunication(isdnDetails
				.getCommunicationBy());
		orderSummaryPageOperations.selectTermsAndConditionsCheckBox();
		/*OrderConfirmationPageOperations orderConfirmationPageOperations = orderSummaryPageOperations
				.confirmOrder(CLASS_NAME, method.getName());
		String orderId = orderConfirmationPageOperations.getOrderId();

		// calling save method for storing order object in CSV
		//CSVOperations.saveOrders("Order.csv", order);

		orderConfirmationPageOperations.clickCompleteOrder(CLASS_NAME,
				method.getName());*/

	}

	@AfterMethod
	public void tearDown(Method method) {
		/*CommonMethods.logOut(driver, CLASS_NAME, method.getName());
		driver.close();*/

	}

}
