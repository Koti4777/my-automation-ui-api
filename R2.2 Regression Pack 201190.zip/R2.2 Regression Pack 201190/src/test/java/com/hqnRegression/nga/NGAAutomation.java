/**
 * 
 */
package com.hqnRegression.nga;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hqnRegression.nga.beans.AppointmentDetails;
import com.hqnRegression.nga.pages.operations.LoginPageOperations;
import com.hqnRegression.nga.pages.operations.MenuPageOperations;
import com.hqnRegression.nga.pages.operations.RoutingManagementPageOperations;
import com.hqnRegression.nga.pages.operations.RoutingPageOperations;
import com.hqnRegression.util.CSVOperation_New;
import com.hqnRegression.util.SeleniumImplementation;

/**
 * @author 605112580
 * 
 */
public class NGAAutomation extends SeleniumImplementation {

	private static WebDriver driver = null;
	private String CLASS_NAME = "NGAAutomation";
	private String METHOD_NAME = "NGAAutomation";
	private String baseUrl = null;

	private String IN_FILE = "appointment.csv";
	List<AppointmentDetails> appointmentDetailsList = null;
	AppointmentDetails appointmentDetails = null;

	private int testCount = 0;
	private int count = 0;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {

		driver = createBrowserInstance(BrowserType.FIREFOX);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		baseUrl = "http://10.213.247.145:61121/";
		driver.manage().window().maximize();

		appointmentDetailsList = CSVOperation_New
				.readAppointmentDetails(IN_FILE);

		if (appointmentDetailsList != null && appointmentDetailsList.size() > 0) {
			testCount = appointmentDetailsList.size();
		}

	}

	@Test
	public void testNGAAutomation(Method method) throws IOException {
		System.out.println("method name is --->"+method.getName());
		LoginPageOperations loginPageOperations = LoginPageOperations
				.navigateTo(driver);

		MenuPageOperations menuPageOperations = loginPageOperations.login();

		menuPageOperations = menuPageOperations.clickConfigurationManagement();

		RoutingPageOperations routePageOperations = menuPageOperations
				.clickRouting();

		RoutingManagementPageOperations routingManagementPageOperations = routePageOperations
				.clickRoutingManagement();

		while (count < testCount) {

			try {

				appointmentDetails = appointmentDetailsList.get(count);

				/*
				 * routingManagementPageOperations.clickSearch(appointmentDetails
				 * .getMessageId());
				 */

				routingManagementPageOperations.addOperation(
						appointmentDetails.getMessageId(), "AddAppointment",
						"BTW-Model-A", "Openreach-CVF");

				routingManagementPageOperations.addOperation(
						appointmentDetails.getMessageId(),
						"AddAppointmentAvailabilityRequest", "BTW-Model-A",
						"Openreach-CVF");

				routingManagementPageOperations.addOperation(
						appointmentDetails.getMessageId(),
						"AddLineCharacteristicsRequest", "BTW-Model-A",
						"Openreach-CVF");

				routingManagementPageOperations.addOperation(
						appointmentDetails.getMessageId(),
						"AddLineCharacteristicsRequest2", "BTW-Model-A",
						"Openreach-CVF");

				routingManagementPageOperations.addOperation(
						appointmentDetails.getMessageId(),
						"AddNetworkAvailabilityRequest", "BTW-Model-A",
						"Openreach-CVF");

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			count++;
		}
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterMethod
	public void tearDown() throws Exception {
		
		driver.findElement(By.linkText("Logout"));
		driver.close();
		driver.quit();
		
	}

}
