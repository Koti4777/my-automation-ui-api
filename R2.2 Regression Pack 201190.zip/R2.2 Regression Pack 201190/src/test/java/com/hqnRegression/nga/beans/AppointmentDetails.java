package com.hqnRegression.nga.beans;

public class AppointmentDetails {

	private String messageId;

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	
}
