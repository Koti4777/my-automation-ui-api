package com.hqnRegression.nga.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	
	@FindBy(name="loginId")
	private WebElement userId;
	
	@FindBy(name="password")
	private WebElement passWord;
	
	@FindBy(className="submit")
	private WebElement submit;
	
	private WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserId() {
		return userId;
	}

	public WebElement getPassWord() {
		return passWord;
	}

	public WebElement getSubmit() {
		return submit;
	}

	public WebDriver getDriver() {
		return driver;
	}

}
