package com.hqnRegression.nga.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MenuPage {

	@FindBy(linkText="Log Management")
	private WebElement logManagement;
	
	@FindBy(linkText="Configuration Management")
	private WebElement configurationManagement;
	
	
	@FindBy(linkText="Test Data Build")
	private WebElement testDataBuild;
	
	@FindBy(linkText="Notifications")
	private WebElement notifications;
	
	@FindBy(linkText="Routing")
	private WebElement routing;
	
	@FindBy(linkText="Application Configuration")
	private WebElement applicationConfiguration;
	
	
	
	
	
	
	private WebDriver driver;

	public MenuPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getLogManagement() {
		return logManagement;
	}

	public WebElement getConfigurationManagement() {
		return configurationManagement;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getTestDataBuild() {
		return testDataBuild;
	}

	public WebElement getNotifications() {
		return notifications;
	}

	public WebElement getRouting() {
		return routing;
	}

	public WebElement getApplicationConfiguration() {
		return applicationConfiguration;
	}
	
	
	
}
