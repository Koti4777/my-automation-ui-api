package com.hqnRegression.nga.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RoutingManagementPage {
	
	@FindBy(name="search")
	private WebElement messageKey;
	
	private WebElement searchSubmit;
	
	@FindBy(name="messageKeyValue")
	private WebElement messageKeyValue;
	
	@FindBy(name="messageType")
	private WebElement messageType;
	
	@FindBy(name="senderPartnerId")
	private WebElement sender;
	
	@FindBy(name="recieverPartnerId")
	private WebElement reciever;
	
	private WebElement add;
	
	private WebElement reSet;
	
	private WebDriver driver;

	public RoutingManagementPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getMessageKey() {
		return messageKey;
	}

	public WebElement getSearchSubmit() {
		return searchSubmit;
	}

	public WebElement getMessageKeyValue() {
		return messageKeyValue;
	}

	public WebElement getMessageType() {
		return messageType;
	}

	public WebElement getSender() {
		return sender;
	}

	public WebElement getReciever() {
		return reciever;
	}

	public WebElement getAdd() {
		return add;
	}

	public WebElement getReSet() {
		return reSet;
	}

	public WebDriver getDriver() {
		return driver;
	}
	

}
