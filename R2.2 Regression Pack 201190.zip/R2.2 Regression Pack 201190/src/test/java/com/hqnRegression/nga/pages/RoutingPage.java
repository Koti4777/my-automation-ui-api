package com.hqnRegression.nga.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RoutingPage {
	
	@FindBy(linkText="Routing Management")
	private WebElement routingManagement;
	
	@FindBy(linkText="Partner Management ")
	private WebElement partnerManagement;
	
	WebDriver driver;

	public RoutingPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getRoutingManagement() {
		return routingManagement;
	}

	public WebElement getPartnerManagement() {
		return partnerManagement;
	}

	public WebDriver getDriver() {
		return driver;
	}
	
	

}
