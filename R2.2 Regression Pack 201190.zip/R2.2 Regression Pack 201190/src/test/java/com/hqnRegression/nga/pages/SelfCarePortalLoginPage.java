package com.hqnRegression.nga.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SelfCarePortalLoginPage 
{
	private WebDriver driver;

	public WebDriver getDriver() {
		return driver;
	}

	public SelfCarePortalLoginPage(WebDriver driver) {
		this.driver = driver;
	}

	
	@FindBy(id = "j_username")
	private WebElement userName;
	
	@FindBy(id = "j_password")
	private WebElement password;
	
	@FindBy(name = "submit")
	private WebElement submitButn;

	public WebElement getSubmitButn() {
		return submitButn;
	}

	public WebElement getUserName() {
		return userName;
	}

	public WebElement getPassword() {
		return password;
	}
	
	@FindBy(id = "j_username")
	private WebElement selfCareUsername;

	@FindBy(id = "j_password")
	private WebElement SelfCarePassword;
	public WebElement getSelfCareUsername() {
		return selfCareUsername;
	}

	public WebElement getSelfCarePassword() {
		return SelfCarePassword;
	}
	@FindBy(name = "submit")
	private WebElement selfcareLoginButton;
	public WebElement getSelfcareLLoginButton() {
		return selfcareLoginButton;
	}
}
