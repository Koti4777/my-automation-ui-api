package com.hqnRegression.nga.pages.operations;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hqnRegression.nga.pages.LoginPage;
import com.hqnRegression.util.CommonMethods;

public class LoginPageOperations extends LoginPage {

	WebDriver driver;
	//static String baseUrl = "http://10.213.247.145:61121/";
	static Properties testProps = null;

	public LoginPageOperations(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public static LoginPageOperations navigateTo(WebDriver driver)
			throws IOException {
		testProps = CommonMethods.appointmentLoginDetails(driver);
		// CommonMethods.openBaseUrl(driver);
		driver.get(testProps.getProperty("baseUrl") + "StubEMPUI/Login.do");
		return PageFactory.initElements(driver, LoginPageOperations.class);
	}

	public MenuPageOperations login() {
		
		try {
			testProps = CommonMethods.appointmentLoginDetails(driver);
			
			getUserId().clear();
			getUserId().sendKeys(testProps.getProperty("username"));

			getPassWord().clear();
			getPassWord().sendKeys(testProps.getProperty("password"));

			driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		

		// getSubmit().click();

		return PageFactory.initElements(driver, MenuPageOperations.class);

	}

}
