package com.hqnRegression.nga.pages.operations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hqnRegression.nga.pages.MenuPage;

public class MenuPageOperations extends MenuPage {

	WebDriver driver;

	public MenuPageOperations(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public MenuPageOperations clickLogManagement() {

		getLogManagement().click();

		return PageFactory.initElements(driver, MenuPageOperations.class);

	}

	public MenuPageOperations clickConfigurationManagement() {

		getConfigurationManagement().click();

		return PageFactory.initElements(driver, MenuPageOperations.class);

	}

	public void clickTestDataBuild() {
		getTestDataBuild().click();
	}

	public void clickNotification() {
		getNotifications().click();
	}

	public RoutingPageOperations clickRouting() {
		getRouting().click();
		return PageFactory.initElements(driver, RoutingPageOperations.class);
	}

	public void clickApplicationConfiguration() {
		getApplicationConfiguration().click();
	}

}
