package com.hqnRegression.nga.pages.operations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.hqnRegression.nga.pages.RoutingManagementPage;
import com.hqnRegression.util.CommonMethods;

public class RoutingManagementPageOperations extends RoutingManagementPage {

	WebDriver driver;

	public RoutingManagementPageOperations(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public RoutingManagementPageOperations clickSearch(String message) {

		getMessageKey().clear();
		getMessageKey().sendKeys(message);

		//getSearchSubmit().click();
		driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	
		return PageFactory.initElements(driver,
				RoutingManagementPageOperations.class);
	}

	public RoutingManagementPageOperations addOperation(String message,
			String messageTypeOperation, String senderID, String recieverId) {
		
		
		CommonMethods.doPause(5);

		getMessageKeyValue().clear();
		getMessageKeyValue().sendKeys(message);
		
		new Select(getMessageType()).selectByVisibleText(messageTypeOperation);
		
		new Select(getSender()).selectByVisibleText(senderID);
		
		new Select(getReciever()).selectByVisibleText(recieverId);
		
		//getAdd().click();
		driver.findElement(By.xpath("//input[@value='Add']")).click();

		return PageFactory.initElements(driver,
				RoutingManagementPageOperations.class);

	}

}
