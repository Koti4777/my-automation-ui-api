package com.hqnRegression.nga.pages.operations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.hqnRegression.nga.pages.RoutingPage;

public class RoutingPageOperations extends RoutingPage{
	
	WebDriver driver;

	public RoutingPageOperations(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public RoutingManagementPageOperations clickRoutingManagement(){
		getRoutingManagement().click();
		
		return PageFactory.initElements(driver, RoutingManagementPageOperations.class);
	}
	
	
	public void clickPartnerManagement(){
		getPartnerManagement().click();
	}
	

}
