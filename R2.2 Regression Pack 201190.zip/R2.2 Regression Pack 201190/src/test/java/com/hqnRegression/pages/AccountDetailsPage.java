package com.hqnRegression.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hqnRegression.beans.WLRFaultCareLevel;

public class AccountDetailsPage {

	@FindBy(id = "productAnchorId")
	private WebElement accountDetailsTab;

	@FindBy(linkText = "Broadband Usage")
	private WebElement broadBandUsage;

	@FindBy(linkText = "B2B ")
	private WebElement b2BLink;

	@FindBy(linkText = "B2C")
	private WebElement b2CLink;

	@FindBy(linkText = "Abuse Management")
	private WebElement abuseManagementLink;
	@FindBy(xpath = "//div[@id='ticketTree67826OPEN']/img")
	private WebElement ticketNumTab;
	@FindBy(id = "notifyByEmail")
	private WebElement checkboxEmail;
	@FindBy(linkText = "Just to confirm that we've cancelled your abuse investigation, as requested. Please contact us on the number below if you'd like us to remove any of the options we applied for you.")
	private WebElement emailText;

	public WebElement getEmailText() {
		return emailText;
	}

	public void setEmailText(WebElement emailText) {
		this.emailText = emailText;
	}

	public WebElement getCheckboxEmail() {
		return checkboxEmail;
	}

	public void setCheckboxEmail(WebElement checkboxEmail) {
		this.checkboxEmail = checkboxEmail;
	}

	public WebElement getTicketNumTab() {
		return ticketNumTab;
	}

	public void setTicketNumTab(WebElement ticketNumTab) {
		this.ticketNumTab = ticketNumTab;
	}

	public WebElement getAbuseManagementLink() {
		return abuseManagementLink;
	}

	public void setAbuseManagementLink(WebElement abuseManagementLink) {
		this.abuseManagementLink = abuseManagementLink;
	}

	public WebElement getB2CLink() {
		return b2CLink;
	}

	public void setB2CLink(WebElement b2cLink) {
		b2CLink = b2cLink;
	}

	public WebElement getB2BLink() {
		return b2BLink;
	}

	public void setB2BLink(WebElement b2bLink) {
		b2BLink = b2bLink;
	}

	public WebElement getPoolDropdown() {
		return poolDropdown;
	}

	public WebElement getBroadBandUsage() {
		return broadBandUsage;
	}

	public void setBroadBandUsage(WebElement broadBandUsage) {
		this.broadBandUsage = broadBandUsage;
	}

	@FindBy(id = "ticketTypeId")
	private WebElement ticketTypeButton;

	@FindBy(id = "ticketPoolId")
	private WebElement poolDropdown;

	@FindBy(id = "ticketSubtypeId")
	private WebElement ticketSubTypeDropdown;

	@FindBy(id = "channelId")
	private WebElement contactTypeDropdown;

	@FindBy(id = "internal-notes-box")
	private WebElement internalnotes;

	@FindBy(id = "ticketAnchorId")
	private WebElement ticketsTab;

	// added by gopikrishna

	@FindBy(linkText = "Broadband")
	private WebElement broadbandTab;

	@FindBy(id = "phonelineAnchorId")
	private WebElement phoneLineTab;

	@FindBy(id = "broadbandAnchorId")
	private WebElement broadBandTab;

	public WebElement getRenumberLineLink() {
		return renumberLineLink;
	}

	@FindBy(id = "phonelineFaultChecker")
	private WebElement phoneLineFaultCheckerLink;

	@FindBy(id = "renumberLine")
	private WebElement renumberLineLink;

	@FindBy(linkText = "Broadband Fault Checker")
	private WebElement broadBandFaultCheckerLink;

	// Added by gopikrishna

	@FindBy(id = "Top up fee for additional data usage")
	private WebElement Topup;

	@FindBy(id = "macKey")
	private WebElement generateMacKey;

	@FindBy(name = "_eventId_submitRefresh")
	private WebElement btnRefresh;

	@FindBy(linkText = "report")
	private WebElement reports;

	@FindBy(linkText = "Cancel")
	private WebElement cancel;

	public WebElement getCancel() {
		return cancel;
	}

	public void setCancel(WebElement cancel) {
		this.cancel = cancel;
	}

	@FindBy(css = "div.hitarea.lastExpandable-hitarea")
	private WebElement ticketsNumberTab;

	@FindBy(linkText = "Take Control")
	private WebElement takeControl;

	// added by gopikrishna

	@FindBy(linkText = "Broadband Usage")
	private WebElement broadbandusage;

	@FindBy(linkText = "Top up Broadband")
	private WebElement broadband;

	@FindBy(linkText = "Request Control")
	private WebElement requestControl;

	@FindBy(linkText = "Update")
	private WebElement update;

	@FindBy(linkText = "Resolve")
	private WebElement resolve;

	public WebElement getResolve() {
		return resolve;
	}

	public void setResolve(WebElement resolve) {
		this.resolve = resolve;
	}

	@FindBy(xpath = "/html/body/div/div/div[6]/div/div/div[5]/div[2]/div/ul/li/ul/table/tbody/tr/td/a[3]")
	private WebElement ticketsChangepool;

	public WebElement getTicketsChangepool() {
		return ticketsChangepool;
	}

	public void setTicketsChangepool(WebElement ticketsChangepool) {
		this.ticketsChangepool = ticketsChangepool;
	}

	public WebElement getUpdate() {
		return update;
	}

	public void setUpdate(WebElement update) {
		this.update = update;
	}

	public WebElement getTakeControl() {
		return takeControl;
	}

	public void setTakeControl(WebElement takeControl) {
		this.takeControl = takeControl;
	}

	public WebElement getTicketsNumberTab() {
		return ticketsNumberTab;
	}

	public void setTicketsNumberTab(WebElement ticketsNumberTab) {
		this.ticketsNumberTab = ticketsNumberTab;
	}

	public WebElement getReports() {
		return reports;
	}

	public WebElement getBroadBandTab() {
		return broadBandTab;
	}

	public WebElement getBroadBandFaultCheckerLink() {
		return broadBandFaultCheckerLink;
	}

	// @FindBy(xpath = "//input[value='Initiate Ticket']")
	// private WebElement initiateTicket;

	@FindBy(css = "div.btn-panel > #command > input[type=\"button\"]")
	private WebElement initiateTicket;

	@FindBy(xpath = "//div[2]/div/ul/li/table/tbody/tr/td[1]")
	private WebElement ticketNum;

	@FindBy(xpath = "//*[@id='productComponent']/div/table[3]/tbody/tr[3]/td[2]/div/input")
	private WebElement button;

	@FindBy(name = "_eventId_submitConfirm")
	private WebElement conform;

	@FindBy(name = "_eventId_editProductDetails")
	private WebElement editCustomerAccountDetailsButton;

	@FindBy(name = "_eventId_applyDunningRestrictions")
	private WebElement applyDunningRestrictionsButton;

	@FindBy(name = "_eventId_submitCreateTicketDetails")
	private WebElement submitTicketButton;

	@FindBy(name = "_eventId_modifyOrder")
	private WebElement modifyOrderButton;

	@FindBy(name = "_eventId_regradeOrder")
	private WebElement regradeButton;

	@FindBy(name = "_eventId_ceaseOrder")
	private WebElement ceaseButton;

	@FindBy(name = "_eventId_housemove")
	private WebElement premisesButton;

	@FindBy(linkText = "Amend Order")
	private WebElement amendOrderLink;

	@FindBy(id = "convergedAccountNo.errors")
	private WebElement mobileAccountNumberErrormsg;

	@FindBy(id = "convergedAccountNo")
	private WebElement mobileAccountNumber;

	/*
	 * @FindBy(id = "ticketTypeId") private WebElement ticketTypeButton;
	 * 
	 * @FindBy(id = "ticketSubtypeId") private WebElement ticketSubTypeDropdown;
	 * 
	 * @FindBy(id = "ticketPoolId") private WebElement poolDropdown;
	 * 
	 * 
	 * @FindBy(id = "channelId") private WebElement contactTypeDropdown;
	 * 
	 * @FindBy(id = "internal-notes-box") private WebElement internalnotes;
	 * 
	 * @FindBy(name = "_eventId_submitCreateTicketDetails") private WebElement
	 * submitTicketButton;
	 */

	public WebElement getSubmitTicketButton() {
		return submitTicketButton;
	}

	public WebElement getInternalnotes() {
		return internalnotes;
	}

	public WebElement getContactTypeDropdown() {
		return contactTypeDropdown;
	}

	public WebElement getPooldropdown() {
		return poolDropdown;
	}

	public WebElement getTicketSubTypeDropdown() {
		return ticketSubTypeDropdown;
	}

	public WebElement getTicketTypeButton() {
		return ticketTypeButton;
	}

	public WebElement getAmendOrderLink() {
		return amendOrderLink;
	}

	public WebElement getTicketNum() {
		return ticketNum;
	}

	public WebElement getInitiateTicket() {
		return initiateTicket;
	}

	public WebElement getAccountDetailsTab() {
		return accountDetailsTab;
	}

	public WebElement getTicketsTab() {
		return ticketsTab;
	}

	public WebElement getPhoneLineTab() {
		return phoneLineTab;
	}

	public WebElement getPhoneLineFaultCheckerLink() {
		return phoneLineFaultCheckerLink;
	}

	private WebDriver driver;

	public AccountDetailsPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getEditCustomerAccountDetailsButton() {
		return editCustomerAccountDetailsButton;
	}

	public WebElement getApplyDunningRestrictionsButton() {
		return applyDunningRestrictionsButton;
	}

	public WebElement getModifyOrderButton() {
		return modifyOrderButton;
	}

	public WebElement getRegradeButton() {
		return regradeButton;
	}

	public WebElement getCeaseButton() {
		return ceaseButton;
	}

	public WebElement getPremisesButton() {
		return premisesButton;
	}

	public WebElement getGenerateMacKey() {
		return generateMacKey;
	}

	public WebElement getBtnRefresh() {
		return btnRefresh;
	}

	public WebElement getMobileAccountNumberErrormsg() {
		return mobileAccountNumberErrormsg;

	}

	public WebElement getMobileAccountNumber() {
		return mobileAccountNumber;
	}

	public void setRequestControl(WebElement requestControl) {
		this.requestControl = requestControl;
	}

	public WebElement getRequestControl() {
		return requestControl;
	}

	public WebElement getBroadbandTab() {
		return broadbandTab;
	}

	public void setBroadbandTab(WebElement broadbandTab) {
		this.broadbandTab = broadbandTab;
	}

	public WebElement getBroadband() {
		return broadband;
	}

	public void setBroadband(WebElement broadband) {
		this.broadband = broadband;
	}

	public WebElement getTopup() {
		return Topup;
	}

	public void setTopup(WebElement topup) {
		Topup = topup;
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton(WebElement button) {
		this.button = button;
	}

	public WebElement getConform() {
		return conform;
	}

	public void setConform(WebElement conform) {
		this.conform = conform;
	}

	public WebElement getConvergeFlag() {
		return convergeFlag;
	}

	public void setConvergeFlag(WebElement convergeFlag) {
		this.convergeFlag = convergeFlag;
	}

	public WebElement getBtnsave() {
		return btnsave;
	}

	public void setBtnsave(WebElement btnsave) {
		this.btnsave = btnsave;
	}

	public WebElement getBroadbandusage() {
		return broadbandusage;
	}

	public void setBroadbandusage(WebElement broadbandusage) {
		this.broadbandusage = broadbandusage;
	}

	// ADDED FOR APPLYDUNNING OPETION

	/*
	 * @FindBy(name = "_eventId_applyDunningRestrictions") private WebElement
	 * applyDunningRestrictionsButton;
	 * 
	 * public WebElement getApplyDunningRestrictionsButton() { return
	 * applyDunningRestrictionsButton; }
	 */
	@FindBy(id = "isconverged")
	private WebElement convergeFlag;
	@FindBy(name = "_eventId_updateContactDetails")
	private WebElement btnsave;

	@FindBy(id = "broadbandAnchorId")
	private WebElement bBTab;

	public WebElement getbBTab() {

		return bBTab;

	}

	public void setbBTab(WebElement bBTab) {

		this.bBTab = bBTab;

	}

	@FindBy(id = "statusBroadBandHistoryButton")
	private WebElement serviceStatusHistory;

	@FindBy(id = "statusPhoneLineHistoryButton")
	private WebElement statusPhoneLineHistoryButton;

	public WebElement getStatusPhoneLineHistoryButton() {
		return statusPhoneLineHistoryButton;
	}

	public WebElement getServiceStatusHistory() {
		return serviceStatusHistory;
	}

	@FindBy(xpath = "//input[@id='statusBroadBandHistoryButton']/following-sibling::input[2]")
	private WebElement activateService;

	public WebElement getActivateService() {
		return activateService;
	}

	@FindBy(xpath = "//td[contains(.,'Service Plan Status')]/following-sibling::td[1]")
	private WebElement servicePlanStatus;

	public WebElement getServicePlanStatus() {
		return servicePlanStatus;
	}

	@FindBy(xpath = "//td[text()='Broadband']/following-sibling::td[2]")
	private WebElement broadBandServiceStatus;

	public WebElement getBroadBandServiceStatus() {
		return broadBandServiceStatus;
	}

	// added by sravani

		@FindBy(xpath = "//input[@value='Suspend Service']")
		 private WebElement suspendService;
		
		public WebElement getSuspendService() {
			return suspendService;}
		
		@FindBy(xpath = "//input[@value='Suspend Voice']")
		 private WebElement suspendVoice;
		
		public WebElement getSuspendVoice() {
			return suspendVoice;
		}
		@FindBy(xpath = "//input[@value='Remove Dunnings']")
		 private WebElement removeDunningRestriction;

		public WebElement getRemoveDunningRestriction() {
			return removeDunningRestriction;
		}

		@FindBy(linkText = "Change")
		 private WebElement changeLink;


		public WebElement getChangeLink() {
			return changeLink;
		}

	@FindBy(xpath = "//td[text()='PhoneLine']/following-sibling::td[2]")
	private WebElement phoneLineServiceStatus;

	public WebElement getPhoneLineServiceStatus() {
		return phoneLineServiceStatus;
	}

	public void setPhoneLineServiceStatus(WebElement phoneLineServiceStatus) {
		this.phoneLineServiceStatus = phoneLineServiceStatus;
	}

	@FindBy(id = "search_criteria")
	private WebElement searchBox;

	@FindBy(id = "searchBy")
	private WebElement searchBy;

	@FindBy(name = "submitSearch")
	private WebElement searchSubmit;

	public WebElement getSearchBox() {
		return searchBox;
	}

	public WebElement getSearchBy() {
		return searchBy;
	}

	public WebElement getSearchSubmit() {
		return searchSubmit;
	}

}
