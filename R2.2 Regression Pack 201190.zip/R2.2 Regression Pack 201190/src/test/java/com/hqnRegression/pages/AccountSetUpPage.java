package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountSetUpPage {
	
	@FindBy(id = "firstName")
	private WebElement firstName;

	@FindBy(id = "lastName")
	private WebElement lastName;

	@FindBy(id = "password")
	private WebElement passWord;

	@FindBy(id = "confirmPassword")
	private WebElement confirmPassword;

	@FindBy(id = "securityKey")
	private WebElement securityKey;

	@FindBy(id = "securityConfirmPassword")
	private WebElement securityConfirmPassword;
	
	@FindBy(name="_eventId_submitNext")
	private WebElement next;
	
	@FindBy(name="_eventId_submitBack")
	private WebElement back;
	
	private WebDriver driver;
	@FindBy(id="checkAvailability")
	private WebElement availabiltyButn;
	public WebElement getavailabiltyButn() {
		return availabiltyButn;
	}
	
	public AccountSetUpPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public WebElement getPassWord() {
		return passWord;
	}

	public WebElement getConfirmPassword() {
		return confirmPassword;
	}

	public WebElement getSecurityKey() {
		return securityKey;
	}

	public WebElement getSecurityConfirmPassword() {
		return securityConfirmPassword;
	}

	public WebElement getNext() {
		return next;
	}

	public WebElement getBack() {
		return back;
	}

	public WebDriver getDriver() {
		return driver;
	}


}
