package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddControlPage {
	private WebDriver driver;

	public AddControlPage(WebDriver driver) {
		this.driver = driver;
	}
	
	
	@FindBy(id = "listItemName")
	private WebElement StatusReason;
	
	@FindBy(id = "description")
	private WebElement Description;
	
	@FindBy(id = "sequence")
	private WebElement SequenceNumber;
	
	
	@FindBy(name="_eventId_submitAddStatusReason")
	private WebElement save;
	
	@FindBy(name="_eventId_submitSaveEditStatusReason")
	private WebElement editsave;
	
	public WebElement getEditsave() {
		return editsave;
	}


	@FindBy(linkText = "User & Group Admin")
	private WebElement usergroupadmin;

	public WebElement getUsergroupadmin() {
		return usergroupadmin;
	}

	public WebElement getSave() {
		return save;
	}

	public WebElement getStatusReason() {
		return StatusReason;
	}

	public WebElement getDescription() {
		return Description;
	}

	public WebElement getSequenceNumber() {
		return SequenceNumber;
	}
}
