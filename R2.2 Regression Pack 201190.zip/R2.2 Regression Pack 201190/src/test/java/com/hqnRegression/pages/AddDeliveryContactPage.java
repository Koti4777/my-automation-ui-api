package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddDeliveryContactPage {
	
	@FindBy(name="_eventId_submitHardwareDeliveryDetails")
	
	private WebElement next;
	
	@FindBy(name="_eventId_hardwareDetBack")
	private WebElement back;

	@FindBy(name = "_eventId_submitHardwareDeliveryDetails")
					
	private WebElement next_fibre;

	public WebElement getNext_fibre() {
		return next_fibre;
	}
	
	private WebDriver driver;
	
	public AddDeliveryContactPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getNext() {
		return next;
	}

	public WebElement getBack() {
		return back;
	}

	public WebDriver getDriver() {
		return driver;
	}
	@FindBy(id = "salutation")
	private WebElement title;

	@FindBy(id = "forename")
	private WebElement firstName;

	@FindBy(id = "surname")
	private WebElement surName;
	
	@FindBy(id = "postcode")
	private WebElement postCode;

	@FindBy(id = "premisesNameNumber")
	private WebElement premisesNameOrNumber;

	@FindBy(id = "throughfareName")
	private WebElement streetName;

	@FindBy(id = "postTown")
	private WebElement town;

	@FindBy(id = "county")
	private WebElement country;

	@FindBy(name = "_eventId_submitPostcode")
	private WebElement findAddressButton;

	@FindBy(id = "notes")
	private WebElement addressBox;
	
	@FindBy(name = "_eventId_submitHardwareDeliveryDetails")
	private WebElement crdNext;
	
	public WebElement getTitle() {
		return title;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getSurName() {
		return surName;
	}

	public WebElement getPostCode() {
		return postCode;
	}

	public WebElement getPremisesNameOrNumber() {
		return premisesNameOrNumber;
	}

	public WebElement getStreetName() {
		return streetName;
	}

	public WebElement getTown() {
		return town;
	}

	public WebElement getCountry() {
		return country;
	}

	public WebElement getFindAddressButton() {
		return findAddressButton;
	}

	public WebElement getAddressBox() {
		return addressBox;
	}
	
	public WebElement getCrdNext() {
		return crdNext;
	}
	

	

}
