package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddNewAddressPage {

	

	private WebDriver driver;

	public AddNewAddressPage(WebDriver driver) {
		this.driver = driver;
	}
	@FindBy(id = "postcode")
	private WebElement postcode;
	@FindBy(id = "premisesNameNumber")
	private WebElement premisesnamenumber;
	@FindBy(id = "throughfareName")
	private WebElement streetname;
	@FindBy(id = "postTown")
	private WebElement posttown;
	@FindBy(id = "county")
	private WebElement county;
	@FindBy(name = "_eventId_submitAddress")
	private WebElement createnewaddbtn;
	
	
	public WebElement getCreatenewaddbtn() {
		return createnewaddbtn;
	}
	public WebDriver getDriver() {
		return driver;
	}
	public WebElement getPostcode() {
		return postcode;
	}
	public WebElement getPremisesnamenumber() {
		return premisesnamenumber;
	}
	public WebElement getstreetname() {
		return streetname;
	}
	public WebElement getPosttown() {
		return posttown;
	}
	public WebElement getCounty() {
		return county;
	}
	
	
	
	
}
