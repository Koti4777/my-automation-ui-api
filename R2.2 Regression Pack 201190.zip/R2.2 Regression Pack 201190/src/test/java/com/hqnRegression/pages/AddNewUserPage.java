package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddNewUserPage {

	private WebDriver driver;
	
	public AddNewUserPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	@FindBy(id = "teamName")
	private WebElement teamName;
	
	@FindBy(id = "teamDesc")
	private WebElement teamDesc;
	
	@FindBy(id = "username")
	private WebElement userName;
	
	@FindBy(id = "password")
	private WebElement password;
	
	@FindBy(id = "forename")
	private WebElement firstName;
	
	@FindBy(id = "surname")
	private WebElement surName;
	
	@FindBy(id = "email")
	private WebElement emailAddress;
	
	
	
	
	@FindBy(name = "_eventId_submitUser")
	private WebElement save;
	
	//To-DO back button dont have Name or Id
	
	@FindBy(name = "_eventId_goBack")
	private WebElement back;
	
	@FindBy(id = "roleId2")
	private WebElement role;
	
	@FindBy(name = "teamIds")
	private WebElement agentName;
	
	
		public WebElement getAgentName() {
		return agentName;
	}


	public WebElement getRole() {
		return role;
	}
	
	
	public WebDriver getDriver() {
		return driver;
	}
	
	

	public WebElement getUserName() {
		return userName;
	}

	public WebElement getTeamName() {
		return teamName;
	}



	public WebElement getTeamDesc() {
		return teamDesc;
	}



	public WebElement getPassword() {
		return password;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getSurName() {
		return surName;
	}

	public WebElement getEmailAddress() {
		return emailAddress;
	}
	
	

	public WebElement getSave() {
		return save;
	}

	public WebElement getBack() {
		return back;
	}

	
	
	
}
