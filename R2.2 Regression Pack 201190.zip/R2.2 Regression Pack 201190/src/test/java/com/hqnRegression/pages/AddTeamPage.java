
package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddTeamPage  {
	
	private WebDriver driver;

	public AddTeamPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	@FindBy(id = "teamName")
	private WebElement teamName;
	
	@FindBy(id = "teamDesc")
	private WebElement teamDesc;
	
	@FindBy(id = "username")
	private WebElement userName;
	
	@FindBy(id = "password")
	private WebElement password;
	
	@FindBy(id = "forename")
	private WebElement firstName;
	
	@FindBy(id = "surname")
	private WebElement surName;
	
	@FindBy(id = "email")
	private WebElement emailAddress;
	
	

	
	//To-DO back button dont have Name or Id
	
	

	public WebDriver getDriver() {
		return driver;
	}
	
	public WebElement getTeamName() {
		return teamName;
	}
	
	public WebElement getTeamDesc() {
		return teamDesc;
	}

	public WebElement getUserName() {
		return userName;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getSurName() {
		return surName;
	}

	public WebElement getEmailAddress() {
		return emailAddress;
	}
	
	
	
	
	
	

	/*@FindBy(id = "teamName")
	private WebElement teamName;

	public WebElement getTeamName() {
		return teamName;
	}

	public WebElement getTeamDesc() {
		return teamDesc;
	}

	@FindBy(id = "teamDesc")
	private WebElement teamDesc;
	*/
	
	@FindBy(id = "B2B")
	private WebElement B2B;

	public WebElement getB2B() 
	{
		return B2B;
	}

      @FindBy(id = "B2C")
	private WebElement B2C;

	public WebElement getB2C() {
		return B2C;
	}

	@FindBy(id = "B2BAndB2C")
	private WebElement B2BAndB2C;

	public WebElement getB2BAndB2C() {
		return B2BAndB2C;
	}
	
	@FindBy(name ="_eventId_submitTeam")
	private WebElement save;
	
	public WebElement getSave() {
		return save;
	}

	

	@FindBy(name ="_eventId_goBack")
	private WebElement Back;
	
	public WebElement getBack() {
		return Back;
	}
	
	
	
	

	
}
	
	

