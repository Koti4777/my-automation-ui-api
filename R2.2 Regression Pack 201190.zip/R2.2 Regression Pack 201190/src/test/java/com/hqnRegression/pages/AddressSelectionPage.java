package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddressSelectionPage {

	@FindBy(linkText = "Address Details")
	private WebElement addressDetailsTab;

	@FindBy(linkText = "Line Plant Information")
	private WebElement linePlantInformationTab;

	@FindBy(linkText = "Stopped Lines")
	private WebElement stoppedLinesTab;

	@FindBy(linkText = "Working-lines")
	private WebElement workingLinesTab;

	
	//@FindBy(css="input[type=\'submit\']")
	@FindBy(name = "_eventId_submitAddressSelection")
	private WebElement next;

	@FindBy(id = "workingLine")
	private WebElement workingLineRadioButton;

	private WebDriver driver;

	public AddressSelectionPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getAddressDetailsTab() {
		return addressDetailsTab;
	}

	public WebElement getLinePlantInformationTab() {
		return linePlantInformationTab;
	}

	public WebElement getStoppedLinesTab() {
		return stoppedLinesTab;
	}

	public WebElement getWorkingLinesTab() {
		return workingLinesTab;
	}

	public WebElement getNext() {
		return next;
	}

	public WebElement getWorkingLineRadioButton() {
		return workingLineRadioButton;
	}

	public WebDriver getDriver() {
		return driver;
	}

	@FindBy(linkText = "Working-lines")
	private WebElement workingLines;

	public WebElement getWorkingLines() {
		return workingLines;
	}
	
	@FindBy(xpath = "//td[contains(.,'Number Retention Allowed?')]/following::tr[1]/td/input")
	private WebElement selectAWorkingLine;

	public WebElement getSelectAWorkingLine() {
		return selectAWorkingLine;
	}
	
	}
