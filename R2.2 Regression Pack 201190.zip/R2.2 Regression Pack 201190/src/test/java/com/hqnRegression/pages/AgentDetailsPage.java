package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AgentDetailsPage {

	@FindBy(id = "sameAgent")
	private WebElement sameAgent;

	@FindBy(id = "diffAgent")
	private WebElement differentAgent;
	
	@FindBy(name = "_eventId_submitNext")
	private WebElement next;
	
	public AgentDetailsPage(WebDriver driver) {
		this.driver = driver;
	}

	private WebDriver driver;

	public WebElement getSameAgent() {
		return sameAgent;
	}

	public WebElement getDifferentAgent() {
		return differentAgent;
	}

	public WebElement getNext() {
		return next;
	}

	public WebDriver getDriver() {
		return driver;
	}
	
	
}
