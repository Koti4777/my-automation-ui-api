package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmendBTTicketPage {

	@FindBy(id = "submitAmendTicketAppointment")
	private WebElement change;
	
	@FindBy(id = "accessNotes")
	private WebElement access_notes;
	
	
	
	@FindBy(id = "twentyFourValue")
	private WebElement twentyFourValue;
	
	@FindBy(id = "accessValue")
	private WebElement accessValue;
	
	@FindBy(id = "accessAvailability")
	private WebElement accessAvailability;
	
	@FindBy(id = "upperTRCBand")
	private WebElement TRCBand;
	
	@FindBy(id = "notes")
	private WebElement notes;
	
	@FindBy(id = "amendReason")
	private WebElement amendReason;
	
	@FindBy(id = "hazardNotes")
	private WebElement hazardNotes;
	
	@FindBy(id = "submitSelect")
	private WebElement next;
	
	@FindBy(id = "includeOutOfHoursAppt")
	private WebElement includeOutOfHoursAppt;
	
	@FindBy(id = "appointment.errors")
	private WebElement appointmentError;
	
	
	public WebElement getAppointmentError() {
		return appointmentError;
	}

	public WebElement getIncludeOutOfHoursAppt() {
		return includeOutOfHoursAppt;
	}

	public void setIncludeOutOfHoursAppt(WebElement includeOutOfHoursAppt) {
		this.includeOutOfHoursAppt = includeOutOfHoursAppt;
	}

	public WebElement getNext() {
		return next;
	}

	public void setNext(WebElement next) {
		this.next = next;
	}

	public WebElement getHazardNotes() {
		return hazardNotes;
	}

	public void setHazardNotes(WebElement hazardNotes) {
		this.hazardNotes = hazardNotes;
	}

	public WebElement getAmendReason() {
		return amendReason;
	}

	public void setAmendReason(WebElement amendReason) {
		this.amendReason = amendReason;
	}

	public WebElement getAccess_notes() {
		return access_notes;
	}

	public void setAccess_notes(WebElement access_notes) {
		this.access_notes = access_notes;
	}

	public WebElement getTwentyFourValue() {
		return twentyFourValue;
	}

	public void setTwentyFourValue(WebElement twentyFourValue) {
		this.twentyFourValue = twentyFourValue;
	}

	public WebElement getAccessValue() {
		return accessValue;
	}

	public void setAccessValue(WebElement accessValue) {
		this.accessValue = accessValue;
	}

	public WebElement getAccessAvailability() {
		return accessAvailability;
	}

	public void setAccessAvailability(WebElement accessAvailability) {
		this.accessAvailability = accessAvailability;
	}

	public WebElement getTRCBand() {
		return TRCBand;
	}

	public void setTRCBand(WebElement tRCBand) {
		TRCBand = tRCBand;
	}

	public WebElement getNotes() {
		return notes;
	}

	public void setNotes(WebElement notes) {
		this.notes = notes;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public void setChange(WebElement change) {
		this.change = change;
	}

	private WebDriver driver;

	public WebElement getChange() {
		return change;
	}

	public AmendBTTicketPage(WebDriver driver) {
		this.driver = driver;
	}

}
