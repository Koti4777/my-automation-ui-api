package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AmendOrderPage {

	/*
	 * @FindBy(id = "appmntRequired") private WebElement appointmentRequired;
	 * 
	 * @FindBy(name = "_eventId_submitRequestAppointment") private WebElement
	 * availableAppointmentsButton;
	 * 
	 * @FindBy(id = "includeOutOfHoursAppt") private WebElement
	 * outOfHoursAppointmentsCheckBox;
	 */

	
	@FindBy(name = "_eventId_submitAmendProductOrder")
	private WebElement submitAmendProductOrder;

	@FindBy(name = "_eventId_back")
	private WebElement back;

	@FindBy(name = "_eventId_cancel")
	private WebElement cancel;

	@FindBy(xpath = "//td[contains(.,'Customer Required Date')]/following::a")
	private WebElement requiredDateEdit;

	@FindBy(xpath = "//td[contains(.,'Special Arrangement Notes')]/following::a")
	private WebElement fttcNotesEdit;

	@FindBy(xpath = "//td[contains(.,'Hazard Notes*')]/following::a")
	private WebElement hazardNotesEdit;

	@FindBy(name = "_eventId_submitAmendAppointmentBroadband")
	private WebElement requestAppointmentsFTTCButton;

	@FindBy(id = "requestAppointment")
	private WebElement requestAppointmentbutton;

	@FindBy(id = "amend")
	private WebElement amendOrder;

	@FindBy(id = "amendOrderReason")
	private WebElement amendOrderReason;

	@FindBy(name = "_eventId_submitAmendAppointment")
	private WebElement voiceAppointmentButton;
					

	@FindBy(name = "includeOutOfHoursAppt")
	private WebElement includeOutOfHoursAppt;

	private WebDriver driver;

	
	
	
	
	public WebElement getIncludeOutOfHoursAppt() {
		return includeOutOfHoursAppt;
	}

	public WebElement getAmendOrderReason() {
		return amendOrderReason;
	}

	public WebElement getamendOrder() {
		return amendOrder;
	}

	public WebElement getVoiceAppointmentButton() {
		return voiceAppointmentButton;
	}

	public WebElement getRequestAppointmentbutton() {
		return requestAppointmentbutton;
	}

	/*
	 * 
	 * public WebElement getAppointmentRequired() { return appointmentRequired;
	 * }
	 * 
	 * public WebElement getAvailableAppointmentsButton() { return
	 * availableAppointmentsButton; }
	 * 
	 * public WebElement getOutOfHoursAppointmentsCheckBox() { return
	 * outOfHoursAppointmentsCheckBox; }
	 */

	public WebElement getSubmitAmendProductOrder() {
		return submitAmendProductOrder;
	}

	public WebElement getCancel() {
		return cancel;
	}

	public WebElement getRequiredDateEdit() {
		return requiredDateEdit;
	}

	public WebElement getFttcNotesEdit() {
		return fttcNotesEdit;
	}

	public WebElement getHazardNotesEdit() {
		return hazardNotesEdit;
	}

	public WebElement getRequestAppointmentsFTTCButton() {
		return requestAppointmentsFTTCButton;
	}

	public WebElement getBack() {
		return back;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public AmendOrderPage(WebDriver driver) {
		this.driver = driver;
	}

}
