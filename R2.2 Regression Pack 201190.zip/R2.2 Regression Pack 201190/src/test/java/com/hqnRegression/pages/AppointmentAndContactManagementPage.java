package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AppointmentAndContactManagementPage {

	@FindBy(id = "datepicker")
	private WebElement customerRequiredDate;

	@FindBy(css = "img.ui-datepicker-trigger")
	private WebElement datePickerImg;
	
	@FindBy(id = "chargeBand")
	private WebElement chargeBand;
	
	@FindBy(id = "engineeringNotes")
	private WebElement engineeringNotes;
	
	@FindBy(id = "appointmentRequired")
	private WebElement appointmentRequired;
	
	@FindBy(id = "includeOutOfHoursAppt")
	private WebElement outOfHoursAppointmentsCheckBox;
	
	public WebElement getAvailableAppointmentsButton() {
		return availableAppointmentsButton;
	}

	public void setAvailableAppointmentsButton(
			WebElement availableAppointmentsButton) {
		this.availableAppointmentsButton = availableAppointmentsButton;
	}





	@FindBy(name = "_eventId_submitRequestAppointment")
	private WebElement availableAppointmentsButton;
	
	@FindBy(id = "twentyFourValue")
	private WebElement twentyFourhrAccess;
	
	@FindBy(id = "accessValue")
	private WebElement accessValue;
	
	@FindBy(id = "customerReportedNotes")
	private WebElement customerReportNotesCheckBox;
	
	@FindBy(id = "hazardNotes")
	private WebElement hazardNotes;
	
	@FindBy(id = "requestAppointment")
	private WebElement requestAvailableApp;
	
		@FindBy(id = "chargeBand")
	private WebElement TRBandType;
	
	@FindBy(xpath = "//html/body/div/div/div[6]/form/div/table/tbody/tr/td[2]/table/tbody/tr[3]/td/label")
	private WebElement flxebleAppointment;
	
	public WebElement getTRBandType() {
		return TRBandType;
	}

	public WebElement getFlxebleAppointment() {
		return flxebleAppointment;
	}

	public void setFlxebleAppointment(WebElement flxebleAppointment) {
		this.flxebleAppointment = flxebleAppointment;
	}

	public WebElement getRequestAvailableApp() {
		return requestAvailableApp;
	}





	
	
	public WebElement getCustomerRequiredDate() {
		return customerRequiredDate;
	}



	public WebElement getDatePickerImg() {
		return datePickerImg;
	}



	public WebElement getChargeBand() {
		return chargeBand;
	}



	public WebElement getEngineeringNotes() {
		return engineeringNotes;
	}



	public WebElement getAppointmentRequired() {
		return appointmentRequired;
	}



	public WebElement getOutOfHoursAppointmentsCheckBox() {
		return outOfHoursAppointmentsCheckBox;
	}



	public WebElement getTwentyFourhrAccess() {
		return twentyFourhrAccess;
	}



	public WebElement getAccessValue() {
		return accessValue;
	}



	public WebElement getCustomerReportNotesCheckBox() {
		return customerReportNotesCheckBox;
	}



	public WebElement getHazardNotes() {
		return hazardNotes;
	}

	@FindBy(id = "submitSelect")
	private WebElement next;
	


	public WebElement getNext() {
		return next;
	}


	@FindBy(name = "_eventId_submitCreateWlr3Fault")
	private WebElement close;
	


	public WebElement getClose() {
		return close;
	}


	
	private WebDriver driver;

	public AppointmentAndContactManagementPage(WebDriver driver) {
		this.driver = driver;
	}

	

	public WebDriver getDriver() {
		return driver;
	}
	
	 

	
	@FindBy(id = "includeOutOfHoursAppt")
	private WebElement includeFlexibleAppointment;

	public WebElement getIncludeFlexibleAppointment() {
		return includeFlexibleAppointment;
	}
	
	


	
}
