package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AskQuestionLinkPage 
{
	
	private WebDriver driver;

	public AskQuestionLinkPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	 @FindBy(linkText="ask a question")
	   private WebElement askqLink;

	  public WebElement getAskqLink()
	  {
		return askqLink;
	  }

}
