package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AskQuestionPage {
private WebDriver driver;

	
	public AskQuestionPage(WebDriver driver) {
		this.driver = driver;
	}
	@FindBy(id = "ticketSubtypeId")
	private WebElement clickAskQuestion;

	public WebElement getClickAskQuestion() {
		return clickAskQuestion;
	}
	
	@FindBy(id = "internal-notes-box")
	private WebElement questionNotes;

	public WebElement getQuestionNotes() {
		return questionNotes;
	}
	
	@FindBy(name = "_eventId_submitCreateTicketDetails")
	private WebElement submitButn;

	public WebElement getSubmitButn() {
		return submitButn;
	}
	@FindBy(name = "_eventId_submitToMyAccount")
	private WebElement returnButn;

	public WebElement getReturnButn() {
		return returnButn;
	}
}
