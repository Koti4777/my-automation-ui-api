package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AssignContactsPage {
	
	@FindBy(name="_eventId_submitContactGroups")
	private WebElement next;
	
	@FindBy(name="_eventId_submitContactGroups")
	private WebElement back;
	
	private WebDriver driver;
	
	public AssignContactsPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getNext() {
		return next;
	}

	public WebElement getBack() {
		return back;
	}

	public WebDriver getDriver() {
		return driver;
	}


	

}
