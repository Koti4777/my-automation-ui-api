package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AssignSiteContactPage {
	
	@FindBy(name="_eventId_submitStart")
	
	private WebElement next;
	
	@FindBy(name="_eventId_submitSiteUserContactNext")
	private WebElement assignUserContact;
	
	@FindBy(id="mycheck")
	private WebElement isdnNext;
	
	

	@FindBy(name="_eventId_submitBack")
	private WebElement back;
	
	private WebDriver driver;
	
	public AssignSiteContactPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getNext() {
		return next;
	}

	public WebElement getBack() {
		return back;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getIsdnNext() {
		return isdnNext;
	}

	public void setAssignUserContact(WebElement assignUserContact) {
		this.assignUserContact = assignUserContact;
	}

	public WebElement getAssignUserContact() {
		return assignUserContact;
	}

	@FindBy(name = "_eventId_submitStart")
	private WebElement submitNext;


	public WebElement getSubmitNext() {
		return submitNext;
	}
	
	@FindBy(name = "_eventId_submitStart")
	private WebElement  HomeMoveSubmitStart;

	public WebElement getHomeMoveSubmitStart() {
		return HomeMoveSubmitStart;
	}
	

}
