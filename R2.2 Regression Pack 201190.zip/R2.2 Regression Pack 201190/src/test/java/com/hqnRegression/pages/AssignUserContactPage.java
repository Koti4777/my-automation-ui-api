package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AssignUserContactPage {
	


	@FindBy(name="_eventId_submitSiteUserContactNext")
	private WebElement next;
	
	@FindBy(name="_eventId_submitProductDetails")
	private WebElement next1;
	
	
	@FindBy(name="_eventId_submitApptContactManagement")
	private WebElement homeIsdnNext;
	
/*	@FindBy(id="next")
	private WebElement isdnMoveNext;*/
	
	public WebElement getHomeIsdnNext() {
		return homeIsdnNext;
	}

	public void setHomeIsdnNext(WebElement homeIsdnNext) {
		this.homeIsdnNext = homeIsdnNext;
	}

	@FindBy(name="_eventId_submitBack")
	private WebElement back;
	
	private WebDriver driver;
	
	public AssignUserContactPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getNext() {
		return next;
	}

	public WebElement getBack() {
		return back;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getNext1() {
		return next1;
	}

/*	public WebElement getIsdnMoveNext() {
		return isdnMoveNext;
	}*/
	@FindBy(name="_eventId_submitSiteUserContactNext")
	private WebElement assignUserContact;

	public WebElement getAssignUserContact() {
		return assignUserContact;
	}

}
