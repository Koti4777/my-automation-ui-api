package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BBAmendTicketPage {
	
	@FindBy(id = "amendReason")
	private WebElement amendmentReason;

	@FindBy(id = "appointmentRequired")
	private WebElement reAppointmentRequired;

	@FindBy(id = "includeOutOfHoursAppt")
	private WebElement includeOutOfHoursAppt;

	@FindBy(id = "appointment")
	private WebElement appointmentDate;

	@FindBy(id = "submitAmendTicketAppointment")
	private WebElement change;

	@FindBy(id = "apptTimeSlotDisplay")
	private WebElement appointmentTimeSlot;
	
	@FindBy(id="twentyFourValue")
	private WebElement t24hourAccess;
	
	@FindBy(id="accessValue")
	private WebElement accessValue;
	
	@FindBy(id="latestAccessDate")
	private WebElement latestAccessDate;
	
	@FindBy(id="accessAvailability")
	private WebElement accessAvailability;
	
	@FindBy(id="accessNotes")
	private WebElement 	accessNotes;
	
	@FindBy(id="hazardNotes")
	private WebElement 	hazardNotes;
	
	
	@FindBy(id="upperTRCBand")
	private WebElement 	trcBand;
	
	@FindBy(id="notes")
	private WebElement 	notes;
	
	@FindBy(name= "_eventId_back")
	private WebElement 	back;
	
	
	@FindBy(id = "submitSelect")
	private WebElement next;
	
	
	
	
	
	
	
	
	
	
	
	public WebElement getAmendmentReason() {
		return amendmentReason;
	}



	public WebElement getReAppointmentRequired() {
		return reAppointmentRequired;
	}



	public WebElement getIncludeOutOfHoursAppt() {
		return includeOutOfHoursAppt;
	}



	public WebElement getAppointmentDate() {
		return appointmentDate;
	}



	public WebElement getChange() {
		return change;
	}



	public WebElement getAppointmentTimeSlot() {
		return appointmentTimeSlot;
	}



	public WebElement getT24hourAccess() {
		return t24hourAccess;
	}



	public WebElement getAccessValue() {
		return accessValue;
	}



	public WebElement getLatestAccessDate() {
		return latestAccessDate;
	}



	public WebElement getAccessAvailability() {
		return accessAvailability;
	}



	public WebElement getAccessNotes() {
		return accessNotes;
	}



	public WebElement getHazardNotes() {
		return hazardNotes;
	}



	public WebElement getTrcBand() {
		return trcBand;
	}



	public WebElement getNotes() {
		return notes;
	}



	public WebElement getBack() {
		return back;
	}



	public WebElement getNext() {
		return next;
	}



	private WebDriver driver;
	
	public BBAmendTicketPage(WebDriver driver) {
		this.driver = driver;
	}

	

	public WebDriver getDriver() {
		return driver;
	}


}
