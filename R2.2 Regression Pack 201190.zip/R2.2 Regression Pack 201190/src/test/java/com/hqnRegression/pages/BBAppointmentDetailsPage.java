package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BBAppointmentDetailsPage {

	public BBAppointmentDetailsPage(WebDriver driver) {
		this.driver = driver;
	}

	private WebDriver driver;

	public WebDriver getDriver() {
		return driver;
	}

	@FindBy(id = "hazardNotes")
	private WebElement hazardNotes;

	public WebElement getHazardNotes() {
		return hazardNotes;
	}

	@FindBy(id = "accessAvailability")
	private WebElement accessAvailability;

	public WebElement getAccessAvailability() {
		return accessAvailability;
	}

	@FindBy(id = "accessNotes")
	private WebElement accessNotes;

	public WebElement getAccessNotes() {
		return accessNotes;
	}

	@FindBy(id = "contactTime")
	private WebElement contactTime;

	public WebElement getContactTime() {
		return contactTime;
	}

	@FindBy(id = "submitSelect")
	private WebElement submitSelect;

	public WebElement getSubmitSelect() {
		return submitSelect;
	}

}
