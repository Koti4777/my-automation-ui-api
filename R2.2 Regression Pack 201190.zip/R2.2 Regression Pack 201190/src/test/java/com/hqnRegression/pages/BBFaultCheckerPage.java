package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BBFaultCheckerPage {

	@FindBy(id = "yes")
	private WebElement continues;

	@FindBy(id = "ticketSubtypeId")
	private WebElement ticketSubtypeID;

	@FindBy(name = "channelId")
	private WebElement channelId;

	@FindBy(id = "submitPreChecks")
	private WebElement bbContinues;

	public WebElement getContinues() {
		return continues;
	}

	private WebDriver driver;

	public BBFaultCheckerPage(WebDriver driver) {
		this.driver = driver;
	}

	

	public WebDriver getDriver() {
		return driver;
	}
	

	public WebElement getTicketSubtypeID() {
		return ticketSubtypeID;
	}


	public WebElement getChannelId() {
		return channelId;
	}



	public WebElement getBbContinues() {
		return bbContinues;
	}



	
}
