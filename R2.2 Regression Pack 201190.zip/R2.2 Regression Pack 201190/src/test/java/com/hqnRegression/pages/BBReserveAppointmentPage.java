package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BBReserveAppointmentPage {

	@FindBy(id = "reserveAppointment")
	private WebElement reserveAppointmentButton;

	@FindBy(id = "requestAvailableAppointments")
	private WebElement reRequestAppointmentButton;

	@FindBy(id = "apptDateTime")
	private WebElement firstAvailableAppointmentDateRadioButton;

	@FindBy(id = "next")
	private WebElement next;

	@FindBy(css = "img.ui-datepicker-trigger")
	private WebElement datePickerImg;

	private WebDriver driver;

	public BBReserveAppointmentPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getReserveAppointmentButton() {
		return reserveAppointmentButton;
	}

	public WebElement getReRequestAppointmentButton() {
		return reRequestAppointmentButton;
	}

	public WebElement getFirstAvailableAppointmentDateRadioButton() {
		return firstAvailableAppointmentDateRadioButton;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getNext() {
		return next;
	}

	public WebElement getDatePickerImg() {
		return datePickerImg;
	}

}
