package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BBandServiceStatusHistoryPage {
	
	private WebDriver driver;
	public WebDriver getDriver() {
		return driver;
	}
	
	public BBandServiceStatusHistoryPage(WebDriver driver) {
		this.driver = driver;
	}
	
	@FindBy(name = "_eventId_closeStatusHistory")
	private WebElement close;
	public WebElement getClose() {
		return close;
	}

	
}
