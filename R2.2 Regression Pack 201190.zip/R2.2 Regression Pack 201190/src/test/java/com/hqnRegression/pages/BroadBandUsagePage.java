

package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class BroadBandUsagePage  {
	
	private WebDriver driver;

	public BroadBandUsagePage (WebDriver driver) {
		super();
		this.driver = driver;
	}


	@FindBy(linkText = "Top up Broadband")
	private WebElement topUpBroadband;

	public WebElement getTopUpBroadband() {
		return topUpBroadband;
	}
	public void setTopUpBroadband(WebElement topUpBroadband) {
		this.topUpBroadband = topUpBroadband;
	}

	
	
	public class PurchageTopUpConfirmPage  {
		
		private WebDriver driver;

		public PurchageTopUpConfirmPage (WebDriver driver) {
			super();
			this.driver = driver;
		}
	}
}

	
