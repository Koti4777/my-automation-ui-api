package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CallingAndNetworkFeaturesPage {
	
	private WebDriver driver;

	public CallingAndNetworkFeaturesPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebDriver getDriver() {
		return driver;
	}
	
	@FindBy(name = "_eventId_submitCNFPage")
	private WebElement callerAndNetworkFeaturesContinue;
	

	public WebElement getCallerAndNetworkFeaturesContinue() {
		return callerAndNetworkFeaturesContinue;
	}
}
