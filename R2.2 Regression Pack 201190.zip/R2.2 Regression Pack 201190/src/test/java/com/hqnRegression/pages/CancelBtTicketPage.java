package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CancelBtTicketPage {
	
	private WebDriver driver;

	public CancelBtTicketPage(WebDriver driver) {
		this.driver = driver;
		
	}
	
	public WebElement getSubmitCancelBtn() {
		return submitCancelBtn;
	}

	public void setSubmitCancelBtn(WebElement submitCancelBtn) {
		this.submitCancelBtn = submitCancelBtn;
	}

	@FindBy(id = "submitCancel")
	private WebElement submitCancelBtn;
	
	
	
	@FindBy(id = "ticketCodes")
	private WebElement reasonCode;

	public WebElement getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(WebElement reasonCode) {
		this.reasonCode = reasonCode;
	}
}
