package com.hqnRegression.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class broadbandPage {
	private WebDriver driver;

	public WebDriver getDriver() {
		return driver;
	}

	@FindBy(xpath = "//td[contains(.,'unlimited')]")
	private WebElement unLimited;

	@FindBy(xpath = "//td[contains(.,'Monthly Allowance')]")
	private WebElement monthlyAllowance;
	
	@FindBy(id = "newDN")
	private WebElement newDN;
	;

	public WebElement getMonthlyAllowance() {
		return monthlyAllowance;
	}

	public void setMonthlyAllowance(WebElement monthlyAllowance) {
		this.monthlyAllowance = monthlyAllowance;
	}

	public broadbandPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void setUnLimited(WebElement unLimited) {
		this.unLimited = unLimited;
	}

	public WebElement getUnLimited() {
		return unLimited;
	}

	@FindBy(name = "_eventId_submitChangePlan")
	private WebElement continueBtn;

	public WebElement getContinueBtn() {
		return continueBtn;
	}

	public void setContinueBtn(WebElement continueBtn) {
		this.continueBtn = continueBtn;
	}

	@FindBy(name = "_eventId_submitNewPlan")
	private WebElement selectBtn;

	public WebElement getSelectBtn() {
		return selectBtn;
	}

	public void setSelectBtn(WebElement selectBtn) {
		this.selectBtn = selectBtn;
	}

	public WebElement getNewDN() {
		return newDN;
	}

	public void setNewDN(WebElement newDN) {
		this.newDN = newDN;
	}

}
