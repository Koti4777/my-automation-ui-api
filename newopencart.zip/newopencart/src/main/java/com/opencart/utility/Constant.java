package com.opencart.utility;


public class Constant {

   public static final String URL = "http://10.207.182.108:81/opencart";

   public static final String Username = "test4777@gmail.com";

   public static final String Password = "admin";

   public static final String Path_TestData = "D:///newopencart";

   public static final String File_TestData = "TestData.xlsx";

}
