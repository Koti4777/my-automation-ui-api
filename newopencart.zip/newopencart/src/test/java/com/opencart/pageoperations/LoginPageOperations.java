package com.opencart.pageoperations;



import org.openqa.selenium.WebDriver;

import com.opencart.pages.HomePage;
import com.opencart.pages.LoginPage;


public class LoginPageOperations  {

	public WebDriver driver;
	LoginPage ologinpage;// = new LoginPage(driver);
	HomePage ohomepage;// = new HomePage(driver);

	// PageFactory.initElements(driver, this);




	
	public void login() {
		ohomepage = new HomePage(driver);
		ologinpage = new LoginPage(driver);
		// TODO Auto-generated method stub
		//setLogger(getExtent().startTest("Login"));
		//driver.get("http://10.207.182.108:81/opencart");
		System.out.println("Login method invoked");

		// Use page Object library now
		//driver.get("http://10.207.182.108:81/opencart");
		//driver.(ohomepage.loginLink).click();
		HomePage.loginLink.click();
		System.out.println("went to Homepage");
		ologinpage.userEmail.sendKeys("test4777@gmail.com");		
		ologinpage.userPassword.sendKeys("admin");
		ologinpage.submitBtn.click();
		//getLogger().log(LogStatus.PASS, "Login test case pass");
	}

	public LoginPageOperations(WebDriver driver) {
		this.driver=driver;
		// TODO Auto-generated constructor stub
	}

	
public void logout(){
	ohomepage = new HomePage(driver);
	HomePage.logoutLink.click();
}


}
